#!/usr/bin/env bash
set -euo pipefail

PSQL="${PSQL:-/Library/PostgreSQL/17/bin/psql}"

IDENTITY_URL="${IDENTITY_URL:-http://localhost:5101}"
CART_URL="${CART_URL:-http://localhost:5105}"
ORDERS_URL="${ORDERS_URL:-http://localhost:5106}"
INVENTORY_URL="${INVENTORY_URL:-http://localhost:5104}"
PAYMENTS_URL="${PAYMENTS_URL:-http://localhost:5107}"
NOTIFICATIONS_URL="${NOTIFICATIONS_URL:-http://localhost:5108}"
SHIPPING_URL="${SHIPPING_URL:-http://localhost:5109}"
SUPPORT_URL="${SUPPORT_URL:-http://localhost:5222}"

PGHOST="${PGHOST:-localhost}"
PGPORT="${PGPORT:-55432}"
PGUSER="${PGUSER:-zellamart}"
PGPASSWORD="${PGPASSWORD:-zellamart}"
export PGPASSWORD

require_service() {
  local name="$1"
  local url="$2"
  curl -fsS "$url/health" >/dev/null || {
    echo "$name is not running at $url"
    exit 1
  }
}

json_value() {
  python3 -c "import json,sys; data=json.loads(sys.stdin.read()); print($1)"
}

post_json() {
  local url="$1"
  local token="$2"
  local body="$3"
  curl -fsS -X POST "$url" \
    -H "Authorization: Bearer $token" \
    -H "Content-Type: application/json" \
    -d "$body"
}

post_empty() {
  local url="$1"
  local token="$2"
  curl -fsS -X POST "$url" -H "Authorization: Bearer $token"
}

echo "Checking Month 3 services..."
require_service "Identity" "$IDENTITY_URL"
require_service "Cart" "$CART_URL"
require_service "Orders" "$ORDERS_URL"
require_service "Inventory" "$INVENTORY_URL"
require_service "Payments" "$PAYMENTS_URL"
require_service "Notifications" "$NOTIFICATIONS_URL"
require_service "Shipping" "$SHIPPING_URL"
require_service "Support" "$SUPPORT_URL"

email="month3-demo-$(date +%s)@zellamart.test"
password="Password123!"
product_id="$(uuidgen | tr '[:upper:]' '[:lower:]')"
seller_id="$(uuidgen | tr '[:upper:]' '[:lower:]')"
inventory_id="$(uuidgen | tr '[:upper:]' '[:lower:]')"
delivery_partner_id="$(uuidgen | tr '[:upper:]' '[:lower:]')"
support_agent_id="$(uuidgen | tr '[:upper:]' '[:lower:]')"

echo "Registering customer..."
register_response="$(
  curl -fsS -X POST "$IDENTITY_URL/api/auth/register" \
    -H "Content-Type: application/json" \
    -d "{\"fullName\":\"Month3 Demo Customer\",\"email\":\"$email\",\"password\":\"$password\"}"
)"
token="$(json_value "data['value']['accessToken']" <<< "$register_response")"

echo "Adding inventory..."
"$PSQL" -h "$PGHOST" -p "$PGPORT" -U "$PGUSER" -d zellamart_inventory >/dev/null <<SQL
INSERT INTO inventory_items ("Id", "ProductId", "SellerId", "Sku", "QuantityOnHand", "ReservedQuantity", "CreatedAtUtc")
VALUES ('$inventory_id', '$product_id', '$seller_id', 'M3-DEMO-$product_id', 5, 0, now());
SQL

echo "Creating cart item..."
post_json "$CART_URL/api/cart/items" "$token" \
  "{\"productId\":\"$product_id\",\"sellerId\":\"$seller_id\",\"productName\":\"Month3 Demo Phone\",\"unitPrice\":2500,\"quantity\":1,\"currency\":\"INR\"}" >/dev/null

cart_response="$(curl -fsS "$CART_URL/api/cart/me" -H "Authorization: Bearer $token")"
order_payload="$(
  python3 - <<PY
import json
cart = json.loads('''$cart_response''')['value']
items = [
    {
        "productId": item["productId"],
        "sellerId": item["sellerId"],
        "productName": item["productName"],
        "unitPrice": item["unitPrice"],
        "quantity": item["quantity"]
    }
    for item in cart["items"]
]
print(json.dumps({"items": items, "currency": cart["currency"]}))
PY
)"

echo "Creating order..."
order_response="$(post_json "$ORDERS_URL/api/orders/from-cart" "$token" "$order_payload")"
order_id="$(json_value "data['value']['id']" <<< "$order_response")"
order_item_id="$(json_value "data['value']['items'][0]['id']" <<< "$order_response")"

echo "Starting and succeeding payment..."
payment_response="$(post_json "$PAYMENTS_URL/api/payments/start" "$token" "{\"orderId\":\"$order_id\"}")"
payment_id="$(json_value "data['value']['id']" <<< "$payment_response")"
post_empty "$PAYMENTS_URL/api/payments/$payment_id/success" "$token" >/dev/null
confirmed_status="$("$PSQL" -h "$PGHOST" -p "$PGPORT" -U "$PGUSER" -d zellamart_orders -t -A -c "SELECT \"Status\" FROM orders WHERE \"Id\"='$order_id';")"
echo "Order confirmed: $confirmed_status"

echo "Creating shipment..."
shipment_response="$(post_json "$SHIPPING_URL/api/shipping/create-for-order" "$token" "{\"orderId\":\"$order_id\",\"shippingAddress\":\"Hyderabad, Telangana\"}")"
shipment_id="$(json_value "data['value']['id']" <<< "$shipment_response")"
echo "Shipment created: $shipment_id"

echo "Packing shipment..."
post_empty "$SHIPPING_URL/api/shipping/$shipment_id/pack" "$token" >/dev/null
packed_status="$("$PSQL" -h "$PGHOST" -p "$PGPORT" -U "$PGUSER" -d zellamart_shipping -t -A -c "SELECT \"Status\" FROM shipments WHERE \"Id\"='$shipment_id';")"
echo "Packed: $packed_status"

echo "Shipping shipment..."
post_empty "$SHIPPING_URL/api/shipping/$shipment_id/ship" "$token" >/dev/null
shipped_status="$("$PSQL" -h "$PGHOST" -p "$PGPORT" -U "$PGUSER" -d zellamart_shipping -t -A -c "SELECT \"Status\" FROM shipments WHERE \"Id\"='$shipment_id';")"
echo "Shipped: $shipped_status"

post_json "$SHIPPING_URL/api/shipping/$shipment_id/assign-partner" "$token" "{\"deliveryPartnerId\":\"$delivery_partner_id\"}" >/dev/null
post_empty "$SHIPPING_URL/api/shipping/$shipment_id/out-for-delivery" "$token" >/dev/null
post_empty "$SHIPPING_URL/api/shipping/$shipment_id/delivered" "$token" >/dev/null
post_empty "$ORDERS_URL/api/orders/$order_id/delivered" "$token" >/dev/null
delivered_status="$("$PSQL" -h "$PGHOST" -p "$PGPORT" -U "$PGUSER" -d zellamart_shipping -t -A -c "SELECT \"Status\" FROM shipments WHERE \"Id\"='$shipment_id';")"
echo "Delivered: $delivered_status"

echo "Creating support ticket..."
ticket_response="$(post_json "$SUPPORT_URL/api/support/tickets" "$token" "{\"orderId\":\"$order_id\",\"type\":6,\"subject\":\"Product damaged\",\"description\":\"The delivered product is damaged.\"}")"
ticket_id="$(json_value "data['value']['id']" <<< "$ticket_response")"
post_json "$SUPPORT_URL/api/support/tickets/$ticket_id/messages" "$token" "{\"message\":\"My product is damaged.\"}" >/dev/null
post_json "$SUPPORT_URL/api/support/tickets/$ticket_id/assign" "$token" "{\"agentId\":\"$support_agent_id\"}" >/dev/null
echo "Support ticket created: $ticket_id"

echo "Requesting return..."
return_response="$(post_json "$SUPPORT_URL/api/support/returns" "$token" "{\"orderId\":\"$order_id\",\"orderItemId\":\"$order_item_id\",\"productId\":\"$product_id\",\"reason\":\"Product damaged\"}")"
return_id="$(json_value "data['value']['id']" <<< "$return_response")"
echo "Return requested: $return_id"

post_empty "$SUPPORT_URL/api/support/returns/$return_id/approve" "$token" >/dev/null
approved_status="$("$PSQL" -h "$PGHOST" -p "$PGPORT" -U "$PGUSER" -d zellamart_support -t -A -c "SELECT \"Status\" FROM return_requests WHERE \"Id\"='$return_id';")"
echo "Return approved: $approved_status"
post_empty "$SUPPORT_URL/api/support/returns/$return_id/mark-picked-up" "$token" >/dev/null
post_empty "$SUPPORT_URL/api/support/returns/$return_id/refund" "$token" >/dev/null
refunded_status="$("$PSQL" -h "$PGHOST" -p "$PGPORT" -U "$PGUSER" -d zellamart_support -t -A -c "SELECT \"Status\" FROM return_requests WHERE \"Id\"='$return_id';")"
echo "Refund completed: $refunded_status"

if [[ "$confirmed_status" != "Confirmed" || "$delivered_status" != "Delivered" || "$approved_status" != "Approved" || "$refunded_status" != "Refunded" ]]; then
  echo "Month 3 demo failed."
  exit 1
fi

echo "Month 3 demo passed."
echo "Customer: $email"
echo "OrderId: $order_id"
echo "ShipmentId: $shipment_id"
echo "SupportTicketId: $ticket_id"
echo "ReturnId: $return_id"
