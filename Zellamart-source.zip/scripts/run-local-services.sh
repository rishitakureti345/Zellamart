#!/usr/bin/env bash
set -euo pipefail

DOTNET="${DOTNET:-/Users/rishitha/.dotnet/dotnet}"
export DOTNET_ROOT="${DOTNET_ROOT:-/Users/rishitha/.dotnet}"
export PATH="$DOTNET_ROOT:$DOTNET_ROOT/tools:$PATH"
export ASPNETCORE_ENVIRONMENT="${ASPNETCORE_ENVIRONMENT:-Development}"

mkdir -p .logs
: > .logs/services.pids

start_service() {
  local name="$1"
  local project="$2"
  local log=".logs/$name.log"

  echo "Starting $name..."
  nohup "$DOTNET" run --project "$project" --launch-profile http > "$log" 2>&1 &
  echo "$! $name" >> .logs/services.pids
}

start_service "identity" "src/Services/Identity/Zellamart.Identity.Api/Zellamart.Identity.Api.csproj"
start_service "seller" "src/Services/Seller/Zellamart.Seller.Api/Zellamart.Seller.Api.csproj"
start_service "catalog" "src/Services/Catalog/Zellamart.Catalog.Api/Zellamart.Catalog.Api.csproj"
start_service "inventory" "src/Services/Inventory/Zellamart.Inventory.Api/Zellamart.Inventory.Api.csproj"
start_service "cart" "src/Services/Cart/Zellamart.Cart.Api/Zellamart.Cart.Api.csproj"
start_service "orders" "src/Services/Orders/Zellamart.Orders.Api/Zellamart.Orders.Api.csproj"
start_service "payments" "src/Services/Payments/Zellamart.Payments.Api/Zellamart.Payments.Api.csproj"
start_service "notifications" "src/Services/Notifications/Zellamart.Notifications.Api/Zellamart.Notifications.Api.csproj"
start_service "shipping" "src/Services/Shipping/Zellamart.Shipping.Api/Zellamart.Shipping.Api.csproj"
start_service "support" "src/Services/Support/Zellamart.Support.Api/Zellamart.Support.Api.csproj"
start_service "finance" "src/Services/Finance/Zellamart.Finance.Api/Zellamart.Finance.Api.csproj"
start_service "gateway" "src/Gateways/Zellamart.Gateway/Zellamart.Gateway.csproj"

echo "Services are starting. Logs are in .logs/*.log"
echo "Run scripts/stop-local-services.sh to stop them."
