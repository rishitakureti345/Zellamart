#!/usr/bin/env bash
set -euo pipefail

if [[ ! -f .logs/services.pids ]]; then
  echo "No .logs/services.pids file found."
  exit 0
fi

while read -r pid name; do
  if kill -0 "$pid" >/dev/null 2>&1; then
    echo "Stopping $name..."
    kill "$pid" >/dev/null 2>&1 || true
  fi
done < .logs/services.pids

rm -f .logs/services.pids
echo "Stopped local services."
