#!/usr/bin/env bash
set -euo pipefail

DOTNET="${DOTNET:-/Users/rishitha/.dotnet/dotnet}"
export DOTNET_ROOT="${DOTNET_ROOT:-/Users/rishitha/.dotnet}"
export PATH="$DOTNET_ROOT:$DOTNET_ROOT/tools:$PATH"

run_migration() {
  local name="$1"
  local infrastructure="$2"
  local startup="$3"

  echo "Applying $name migrations..."
  "$DOTNET" ef database update --project "$infrastructure" --startup-project "$startup"
}

run_migration "Identity" \
  "src/Services/Identity/Zellamart.Identity.Infrastructure/Zellamart.Identity.Infrastructure.csproj" \
  "src/Services/Identity/Zellamart.Identity.Api/Zellamart.Identity.Api.csproj"
run_migration "Seller" \
  "src/Services/Seller/Zellamart.Seller.Infrastructure/Zellamart.Seller.Infrastructure.csproj" \
  "src/Services/Seller/Zellamart.Seller.Api/Zellamart.Seller.Api.csproj"
run_migration "Catalog" \
  "src/Services/Catalog/Zellamart.Catalog.Infrastructure/Zellamart.Catalog.Infrastructure.csproj" \
  "src/Services/Catalog/Zellamart.Catalog.Api/Zellamart.Catalog.Api.csproj"
run_migration "Inventory" \
  "src/Services/Inventory/Zellamart.Inventory.Infrastructure/Zellamart.Inventory.Infrastructure.csproj" \
  "src/Services/Inventory/Zellamart.Inventory.Api/Zellamart.Inventory.Api.csproj"
run_migration "Cart" \
  "src/Services/Cart/Zellamart.Cart.Infrastructure/Zellamart.Cart.Infrastructure.csproj" \
  "src/Services/Cart/Zellamart.Cart.Api/Zellamart.Cart.Api.csproj"
run_migration "Orders" \
  "src/Services/Orders/Zellamart.Orders.Infrastructure/Zellamart.Orders.Infrastructure.csproj" \
  "src/Services/Orders/Zellamart.Orders.Api/Zellamart.Orders.Api.csproj"
run_migration "Payments" \
  "src/Services/Payments/Zellamart.Payments.Infrastructure/Zellamart.Payments.Infrastructure.csproj" \
  "src/Services/Payments/Zellamart.Payments.Api/Zellamart.Payments.Api.csproj"
run_migration "Notifications" \
  "src/Services/Notifications/Zellamart.Notifications.Infrastructure/Zellamart.Notifications.Infrastructure.csproj" \
  "src/Services/Notifications/Zellamart.Notifications.Api/Zellamart.Notifications.Api.csproj"
run_migration "Shipping" \
  "src/Services/Shipping/Zellamart.Shipping.Infrastructure/Zellamart.Shipping.Infrastructure.csproj" \
  "src/Services/Shipping/Zellamart.Shipping.Api/Zellamart.Shipping.Api.csproj"
run_migration "Support" \
  "src/Services/Support/Zellamart.Support.Infrastructure/Zellamart.Support.Infrastructure.csproj" \
  "src/Services/Support/Zellamart.Support.Api/Zellamart.Support.Api.csproj"
run_migration "Finance" \
  "src/Services/Finance/Zellamart.Finance.Infrastructure/Zellamart.Finance.Infrastructure.csproj" \
  "src/Services/Finance/Zellamart.Finance.Api/Zellamart.Finance.Api.csproj"

echo "All migrations applied."
