#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
PSQL="/Library/PostgreSQL/17/bin/psql"

IDENTITY_URL="${IDENTITY_URL:-http://localhost:5101}"
CART_URL="${CART_URL:-http://localhost:5105}"
ORDERS_URL="${ORDERS_URL:-http://localhost:5106}"
INVENTORY_URL="${INVENTORY_URL:-http://localhost:5104}"
PAYMENTS_URL="${PAYMENTS_URL:-http://localhost:5107}"
NOTIFICATIONS_URL="${NOTIFICATIONS_URL:-http://localhost:5108}"

PGHOST="${PGHOST:-localhost}"
PGPORT="${PGPORT:-55432}"
PGUSER="${PGUSER:-zellamart}"
PGPASSWORD="${PGPASSWORD:-zellamart}"
export PGPASSWORD

require_service() {
  local name="$1"
  local url="$2"
  curl -fsS "$url/health" >/dev/null || {
    echo "$name is not running at $url"
    exit 1
  }
}

json_value() {
  python3 -c "import json,sys; data=json.loads(sys.stdin.read()); print($1)"
}

echo "Checking Month 2 services..."
require_service "Identity" "$IDENTITY_URL"
require_service "Cart" "$CART_URL"
require_service "Orders" "$ORDERS_URL"
require_service "Inventory" "$INVENTORY_URL"
require_service "Payments" "$PAYMENTS_URL"
require_service "Notifications" "$NOTIFICATIONS_URL"

email="month2-demo-$(date +%s)@zellamart.test"
password="Password123!"
product_id="$(uuidgen | tr '[:upper:]' '[:lower:]')"
seller_id="$(uuidgen | tr '[:upper:]' '[:lower:]')"
inventory_id="$(uuidgen | tr '[:upper:]' '[:lower:]')"

echo "Registering customer..."
register_response="$(
  curl -fsS -X POST "$IDENTITY_URL/api/auth/register" \
    -H "Content-Type: application/json" \
    -d "{\"fullName\":\"Month2 Demo Customer\",\"email\":\"$email\",\"password\":\"$password\"}"
)"
customer_id="$(json_value "data['value']['userId']" <<< "$register_response")"
token="$(json_value "data['value']['accessToken']" <<< "$register_response")"

echo "Adding inventory..."
"$PSQL" -h "$PGHOST" -p "$PGPORT" -U "$PGUSER" -d zellamart_inventory >/dev/null <<SQL
INSERT INTO inventory_items ("Id", "ProductId", "SellerId", "Sku", "QuantityOnHand", "ReservedQuantity", "CreatedAtUtc")
VALUES ('$inventory_id', '$product_id', '$seller_id', 'M2-DEMO-$product_id', 5, 0, now());
SQL

echo "Adding item to cart..."
curl -fsS -X POST "$CART_URL/api/cart/items" \
  -H "Authorization: Bearer $token" \
  -H "Content-Type: application/json" \
  -d "{\"productId\":\"$product_id\",\"sellerId\":\"$seller_id\",\"productName\":\"Month2 Demo Phone\",\"unitPrice\":1500,\"quantity\":1,\"currency\":\"INR\"}" >/dev/null

cart_response="$(curl -fsS "$CART_URL/api/cart/me" -H "Authorization: Bearer $token")"
order_payload="$(
  python3 - <<PY
import json
cart = json.loads('''$cart_response''')['value']
items = [
    {
        "productId": item["productId"],
        "sellerId": item["sellerId"],
        "productName": item["productName"],
        "unitPrice": item["unitPrice"],
        "quantity": item["quantity"]
    }
    for item in cart["items"]
]
print(json.dumps({"items": items, "currency": cart["currency"]}))
PY
)"

echo "Creating order from cart snapshot..."
order_response="$(
  curl -fsS -X POST "$ORDERS_URL/api/orders/from-cart" \
    -H "Authorization: Bearer $token" \
    -H "Content-Type: application/json" \
    -d "$order_payload"
)"
order_id="$(json_value "data['value']['id']" <<< "$order_response")"

echo "Starting fake payment..."
payment_response="$(
  curl -fsS -X POST "$PAYMENTS_URL/api/payments/start" \
    -H "Authorization: Bearer $token" \
    -H "Content-Type: application/json" \
    -d "{\"orderId\":\"$order_id\"}"
)"
payment_id="$(json_value "data['value']['id']" <<< "$payment_response")"

echo "Marking fake payment success..."
curl -fsS -X POST "$PAYMENTS_URL/api/payments/$payment_id/success" \
  -H "Authorization: Bearer $token" >/dev/null

order_status="$("$PSQL" -h "$PGHOST" -p "$PGPORT" -U "$PGUSER" -d zellamart_orders -t -A -c "SELECT \"Status\" FROM orders WHERE \"Id\"='$order_id';")"
stock_quantity="$("$PSQL" -h "$PGHOST" -p "$PGPORT" -U "$PGUSER" -d zellamart_inventory -t -A -c "SELECT \"QuantityOnHand\" FROM inventory_items WHERE \"Id\"='$inventory_id';")"
notifications_response="$(curl -fsS "$NOTIFICATIONS_URL/api/notifications/me" -H "Authorization: Bearer $token")"
notification_count="$(json_value "len(data['value'])" <<< "$notifications_response")"

echo "Order status: $order_status"
echo "Inventory quantity: $stock_quantity"
echo "Notification count: $notification_count"

if [[ "$order_status" != "Confirmed" || "$stock_quantity" != "4" || "$notification_count" -lt 1 ]]; then
  echo "Month 2 demo failed."
  exit 1
fi

echo "Month 2 demo passed."
echo "Customer: $email"
echo "OrderId: $order_id"
echo "PaymentId: $payment_id"
