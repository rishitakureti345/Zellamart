#!/usr/bin/env bash
set -euo pipefail

PSQL="${PSQL:-/Library/PostgreSQL/17/bin/psql}"

IDENTITY_URL="${IDENTITY_URL:-http://localhost:5101}"
SELLER_URL="${SELLER_URL:-http://localhost:5102}"
CATALOG_URL="${CATALOG_URL:-http://localhost:5103}"
INVENTORY_URL="${INVENTORY_URL:-http://localhost:5104}"
CART_URL="${CART_URL:-http://localhost:5105}"
ORDERS_URL="${ORDERS_URL:-http://localhost:5106}"
PAYMENTS_URL="${PAYMENTS_URL:-http://localhost:5107}"
SHIPPING_URL="${SHIPPING_URL:-http://localhost:5109}"
SUPPORT_URL="${SUPPORT_URL:-http://localhost:5222}"
FINANCE_URL="${FINANCE_URL:-http://localhost:5110}"

PGHOST="${PGHOST:-localhost}"
PGPORT="${PGPORT:-55432}"
PGUSER="${PGUSER:-zellamart}"
PGPASSWORD="${PGPASSWORD:-zellamart}"
export PGPASSWORD

ADMIN_ROLE_ID="10000000-0000-0000-0000-000000000002"
SELLER_ROLE_ID="10000000-0000-0000-0000-000000000003"
FINANCE_ROLE_ID="10000000-0000-0000-0000-000000000007"

require_service() {
  local name="$1"
  local url="$2"
  curl -fsS "$url/health" >/dev/null || {
    echo "$name is not running at $url"
    exit 1
  }
}

json_value() {
  python3 -c "import json,sys; data=json.loads(sys.stdin.read()); print($1)"
}

post_json() {
  local url="$1"
  local token="$2"
  local body="$3"
  curl -fsS -X POST "$url" \
    -H "Authorization: Bearer $token" \
    -H "Content-Type: application/json" \
    -d "$body"
}

post_empty() {
  local url="$1"
  local token="$2"
  curl -fsS -X POST "$url" -H "Authorization: Bearer $token"
}

register_user() {
  local full_name="$1"
  local email="$2"
  local password="$3"
  curl -fsS -X POST "$IDENTITY_URL/api/auth/register" \
    -H "Content-Type: application/json" \
    -d "{\"fullName\":\"$full_name\",\"email\":\"$email\",\"password\":\"$password\"}"
}

login_user() {
  local email="$1"
  local password="$2"
  curl -fsS -X POST "$IDENTITY_URL/api/auth/login" \
    -H "Content-Type: application/json" \
    -d "{\"email\":\"$email\",\"password\":\"$password\"}"
}

assign_role() {
  local user_id="$1"
  local role_id="$2"
  "$PSQL" -h "$PGHOST" -p "$PGPORT" -U "$PGUSER" -d zellamart_identity >/dev/null <<SQL
INSERT INTO user_roles ("UserId", "RoleId")
VALUES ('$user_id', '$role_id')
ON CONFLICT DO NOTHING;
SQL
}

echo "Checking Month 4 services..."
for service in \
  "Identity:$IDENTITY_URL" \
  "Seller:$SELLER_URL" \
  "Catalog:$CATALOG_URL" \
  "Inventory:$INVENTORY_URL" \
  "Cart:$CART_URL" \
  "Orders:$ORDERS_URL" \
  "Payments:$PAYMENTS_URL" \
  "Shipping:$SHIPPING_URL" \
  "Support:$SUPPORT_URL" \
  "Finance:$FINANCE_URL"; do
  require_service "${service%%:*}" "${service#*:}"
done

suffix="$(date +%s)"
password="Password123!"
admin_email="month4-admin-$suffix@zellamart.test"
seller_email="month4-seller-$suffix@zellamart.test"
finance_email="month4-finance-$suffix@zellamart.test"
customer_email="month4-customer-$suffix@zellamart.test"

echo "Registering role users..."
admin_register="$(register_user "Month4 Admin" "$admin_email" "$password")"
seller_register="$(register_user "Month4 Seller" "$seller_email" "$password")"
finance_register="$(register_user "Month4 Finance" "$finance_email" "$password")"
customer_register="$(register_user "Month4 Customer" "$customer_email" "$password")"

admin_id="$(json_value "data['value']['userId']" <<< "$admin_register")"
seller_user_id="$(json_value "data['value']['userId']" <<< "$seller_register")"
finance_id="$(json_value "data['value']['userId']" <<< "$finance_register")"
customer_id="$(json_value "data['value']['userId']" <<< "$customer_register")"

assign_role "$admin_id" "$ADMIN_ROLE_ID"
assign_role "$seller_user_id" "$SELLER_ROLE_ID"
assign_role "$finance_id" "$FINANCE_ROLE_ID"

admin_token="$(json_value "data['value']['accessToken']" <<< "$(login_user "$admin_email" "$password")")"
seller_token="$(json_value "data['value']['accessToken']" <<< "$(login_user "$seller_email" "$password")")"
finance_token="$(json_value "data['value']['accessToken']" <<< "$(login_user "$finance_email" "$password")")"
customer_token="$(json_value "data['value']['accessToken']" <<< "$customer_register")"

echo "Admin login: $admin_email"
echo "Seller applies..."
seller_response="$(post_json "$SELLER_URL/api/sellers/apply" "$seller_token" \
  "{\"businessName\":\"Month4 Demo Store\",\"ownerName\":\"Month4 Seller\",\"contactEmail\":\"$seller_email\",\"phone\":\"9999999999\",\"address\":\"Hyderabad\",\"gstNumber\":\"GST-M4-$suffix\"}")"
seller_profile_id="$(json_value "data['value']['id']" <<< "$seller_response")"

echo "Admin approves seller..."
post_empty "$SELLER_URL/api/sellers/$seller_profile_id/approve" "$admin_token" >/dev/null

echo "Admin creates category..."
category_response="$(post_json "$CATALOG_URL/api/categories" "$admin_token" \
  "{\"name\":\"Month4 Electronics $suffix\",\"slug\":\"month4-electronics-$suffix\",\"description\":\"Demo category\",\"parentCategoryId\":null}")"
category_id="$(json_value "data['value']['id']" <<< "$category_response")"

echo "Seller adds product..."
product_response="$(post_json "$CATALOG_URL/api/products/submit" "$seller_token" \
  "{\"sellerId\":\"$seller_user_id\",\"categoryId\":\"$category_id\",\"name\":\"Month4 Demo Phone\",\"slug\":\"month4-demo-phone-$suffix\",\"description\":\"Demo product\",\"price\":2500,\"currency\":\"INR\",\"imageUrl\":null}")"
product_id="$(json_value "data['value']['id']" <<< "$product_response")"
second_product_response="$(post_json "$CATALOG_URL/api/products/submit" "$seller_token" \
  "{\"sellerId\":\"$seller_user_id\",\"categoryId\":\"$category_id\",\"name\":\"Month4 Demo Earbuds\",\"slug\":\"month4-demo-earbuds-$suffix\",\"description\":\"Demo payout product\",\"price\":1500,\"currency\":\"INR\",\"imageUrl\":null}")"
second_product_id="$(json_value "data['value']['id']" <<< "$second_product_response")"

echo "Admin approves product..."
post_empty "$CATALOG_URL/api/products/$product_id/approve" "$admin_token" >/dev/null
post_empty "$CATALOG_URL/api/products/$second_product_id/approve" "$admin_token" >/dev/null

echo "Inventory added..."
inventory_response="$(post_json "$INVENTORY_URL/api/inventory/from-product-approved" "$admin_token" \
  "{\"productId\":\"$product_id\",\"sellerId\":\"$seller_user_id\",\"sku\":\"M4-DEMO-PHONE-$suffix\"}")"
inventory_id="$(json_value "data['value']['id']" <<< "$inventory_response")"
post_json "$INVENTORY_URL/api/inventory/$inventory_id/stock/add" "$admin_token" \
  "{\"quantity\":5,\"reason\":\"Month4 demo stock\",\"referenceId\":null}" >/dev/null
second_inventory_response="$(post_json "$INVENTORY_URL/api/inventory/from-product-approved" "$admin_token" \
  "{\"productId\":\"$second_product_id\",\"sellerId\":\"$seller_user_id\",\"sku\":\"M4-DEMO-EARBUDS-$suffix\"}")"
second_inventory_id="$(json_value "data['value']['id']" <<< "$second_inventory_response")"
post_json "$INVENTORY_URL/api/inventory/$second_inventory_id/stock/add" "$admin_token" \
  "{\"quantity\":5,\"reason\":\"Month4 demo stock\",\"referenceId\":null}" >/dev/null

echo "Customer adds product to cart..."
post_json "$CART_URL/api/cart/items" "$customer_token" \
  "{\"productId\":\"$product_id\",\"sellerId\":\"$seller_user_id\",\"productName\":\"Month4 Demo Phone\",\"unitPrice\":2500,\"quantity\":1,\"currency\":\"INR\"}" >/dev/null
post_json "$CART_URL/api/cart/items" "$customer_token" \
  "{\"productId\":\"$second_product_id\",\"sellerId\":\"$seller_user_id\",\"productName\":\"Month4 Demo Earbuds\",\"unitPrice\":1500,\"quantity\":1,\"currency\":\"INR\"}" >/dev/null

cart_response="$(curl -fsS "$CART_URL/api/cart/me" -H "Authorization: Bearer $customer_token")"
order_payload="$(
  python3 - <<PY
import json
cart = json.loads('''$cart_response''')['value']
items = [
    {
        "productId": item["productId"],
        "sellerId": item["sellerId"],
        "productName": item["productName"],
        "unitPrice": item["unitPrice"],
        "quantity": item["quantity"]
    }
    for item in cart["items"]
]
print(json.dumps({"items": items, "currency": cart["currency"]}))
PY
)"

echo "Customer places order..."
order_response="$(post_json "$ORDERS_URL/api/orders/from-cart" "$customer_token" "$order_payload")"
order_id="$(json_value "data['value']['id']" <<< "$order_response")"
order_item_id="$(json_value "next(item['id'] for item in data['value']['items'] if item['productId'] == '$product_id')" <<< "$order_response")"

echo "Payment succeeds and order confirmed..."
payment_response="$(post_json "$PAYMENTS_URL/api/payments/start" "$customer_token" "{\"orderId\":\"$order_id\"}")"
payment_id="$(json_value "data['value']['id']" <<< "$payment_response")"
post_empty "$PAYMENTS_URL/api/payments/$payment_id/success" "$customer_token" >/dev/null
order_status="$("$PSQL" -h "$PGHOST" -p "$PGPORT" -U "$PGUSER" -d zellamart_orders -t -A -c "SELECT \"Status\" FROM orders WHERE \"Id\"='$order_id';")"
echo "Order confirmed: $order_status"

echo "Shipment created and delivered..."
shipment_response="$(post_json "$SHIPPING_URL/api/shipping/create-for-order" "$customer_token" \
  "{\"orderId\":\"$order_id\",\"shippingAddress\":\"Hyderabad, Telangana\"}")"
shipment_id="$(json_value "data['value']['id']" <<< "$shipment_response")"
post_empty "$SHIPPING_URL/api/shipping/$shipment_id/pack" "$admin_token" >/dev/null
post_empty "$SHIPPING_URL/api/shipping/$shipment_id/ship" "$admin_token" >/dev/null
post_json "$SHIPPING_URL/api/shipping/$shipment_id/assign-partner" "$admin_token" "{\"deliveryPartnerId\":\"$admin_id\"}" >/dev/null
post_empty "$SHIPPING_URL/api/shipping/$shipment_id/out-for-delivery" "$admin_token" >/dev/null
post_empty "$SHIPPING_URL/api/shipping/$shipment_id/delivered" "$admin_token" >/dev/null
post_empty "$ORDERS_URL/api/orders/$order_id/delivered" "$customer_token" >/dev/null
order_status="$("$PSQL" -h "$PGHOST" -p "$PGPORT" -U "$PGUSER" -d zellamart_orders -t -A -c "SELECT \"Status\" FROM orders WHERE \"Id\"='$order_id';")"

echo "Seller earning created..."
earning_response="$(post_json "$FINANCE_URL/api/finance/earnings/create-for-order" "$finance_token" "{\"orderId\":\"$order_id\"}")"
refunded_earning_id="$(json_value "next(item['id'] for item in data['value'] if item['productId'] == '$product_id')" <<< "$earning_response")"
payable_earning_id="$(json_value "next(item['id'] for item in data['value'] if item['productId'] == '$second_product_id')" <<< "$earning_response")"

echo "Customer raises support ticket..."
ticket_response="$(post_json "$SUPPORT_URL/api/support/tickets" "$customer_token" \
  "{\"orderId\":\"$order_id\",\"type\":6,\"subject\":\"Product damaged\",\"description\":\"The delivered product is damaged.\"}")"
ticket_id="$(json_value "data['value']['id']" <<< "$ticket_response")"
post_json "$SUPPORT_URL/api/support/tickets/$ticket_id/messages" "$customer_token" "{\"message\":\"My product is damaged.\"}" >/dev/null

echo "Customer requests return..."
return_response="$(post_json "$SUPPORT_URL/api/support/returns" "$customer_token" \
  "{\"orderId\":\"$order_id\",\"orderItemId\":\"$order_item_id\",\"productId\":\"$product_id\",\"reason\":\"Product damaged\"}")"
return_id="$(json_value "data['value']['id']" <<< "$return_response")"

echo "Return approved and refund completed..."
post_empty "$SUPPORT_URL/api/support/returns/$return_id/approve" "$admin_token" >/dev/null
post_empty "$SUPPORT_URL/api/support/returns/$return_id/mark-picked-up" "$admin_token" >/dev/null
post_empty "$SUPPORT_URL/api/support/returns/$return_id/refund" "$admin_token" >/dev/null

echo "Finance refund recorded..."
refund_response="$(post_json "$FINANCE_URL/api/finance/refunds/create-for-return" "$finance_token" "{\"returnId\":\"$return_id\"}")"
refund_type="$(json_value "data['value']['type']" <<< "$refund_response")"

echo "Seller payout requested..."
payout_request="$(post_empty "$FINANCE_URL/api/finance/sellers/$seller_user_id/payouts/request" "$seller_token")"
payout_id="$(json_value "data['value']['id']" <<< "$payout_request")"
echo "Finance manager marks payout paid..."
post_empty "$FINANCE_URL/api/finance/payouts/$payout_id/mark-paid" "$finance_token" >/dev/null

refunded_earning_status="$("$PSQL" -h "$PGHOST" -p "$PGPORT" -U "$PGUSER" -d zellamart_finance -t -A -c "SELECT \"Status\" FROM seller_earnings WHERE \"Id\"='$refunded_earning_id';")"
paid_earning_status="$("$PSQL" -h "$PGHOST" -p "$PGPORT" -U "$PGUSER" -d zellamart_finance -t -A -c "SELECT \"Status\" FROM seller_earnings WHERE \"Id\"='$payable_earning_id';")"
payout_status="$("$PSQL" -h "$PGHOST" -p "$PGPORT" -U "$PGUSER" -d zellamart_finance -t -A -c "SELECT \"Status\" FROM seller_payouts WHERE \"Id\"='$payout_id';")"
shipment_status="$("$PSQL" -h "$PGHOST" -p "$PGPORT" -U "$PGUSER" -d zellamart_shipping -t -A -c "SELECT \"Status\" FROM shipments WHERE \"Id\"='$shipment_id';")"
return_status="$("$PSQL" -h "$PGHOST" -p "$PGPORT" -U "$PGUSER" -d zellamart_support -t -A -c "SELECT \"Status\" FROM return_requests WHERE \"Id\"='$return_id';")"

if [[ "$order_status" != "Delivered" || "$shipment_status" != "Delivered" || "$return_status" != "Refunded" || ( "$refund_type" != "Refund" && "$refund_type" != "4" ) || "$refunded_earning_status" != "Refunded" || "$payout_status" != "Paid" ]]; then
  echo "OrderStatus: $order_status"
  echo "ShipmentStatus: $shipment_status"
  echo "ReturnStatus: $return_status"
  echo "RefundType: $refund_type"
  echo "RefundedEarningStatus: $refunded_earning_status"
  echo "PayoutStatus: $payout_status"
  echo "Month 4 demo failed."
  exit 1
fi

echo "Month 4 demo passed."
echo "Admin: $admin_email"
echo "Seller: $seller_email"
echo "FinanceManager: $finance_email"
echo "Customer: $customer_email"
echo "SellerProfileId: $seller_profile_id"
echo "SellerFinanceId: $seller_user_id"
echo "ProductId: $product_id"
echo "SecondProductId: $second_product_id"
echo "OrderId: $order_id"
echo "ShipmentId: $shipment_id"
echo "SupportTicketId: $ticket_id"
echo "ReturnId: $return_id"
echo "RefundedEarningStatus: $refunded_earning_status"
echo "PaidEarningStatus: $paid_earning_status"
echo "PayoutId: $payout_id"
