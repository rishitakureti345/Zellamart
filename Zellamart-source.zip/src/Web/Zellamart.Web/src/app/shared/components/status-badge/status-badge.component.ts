import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-status-badge',
  standalone: true,
  template: `<span class="status-badge" [attr.data-status]="status">{{ label || displayStatus() }}</span>`
})
export class StatusBadgeComponent {
  @Input({ required: true }) status: string | number = '';
  @Input() label = '';
  @Input() kind: 'order' | 'payment' | 'shipping' | 'ticket' | 'return' | 'seller' | 'product' | 'payout' | 'earning' | 'transaction' | 'generic' = 'generic';

  displayStatus(): string {
    if (typeof this.status === 'string' && Number.isNaN(Number(this.status))) {
      return this.status;
    }

    const value = Number(this.status);
    return statusLabels[this.kind][value] ?? statusLabels['generic'][value] ?? String(this.status);
  }
}

const statusLabels: Record<string, Record<number, string>> = {
  order: {
    1: 'Pending payment',
    2: 'Payment succeeded',
    3: 'Payment failed',
    4: 'Confirmed',
    5: 'Cancelled',
    6: 'Delivered',
    7: 'Packed',
    8: 'Shipped',
    9: 'Refunded'
  },
  payment: {
    1: 'Pending',
    2: 'Succeeded',
    3: 'Failed',
    4: 'Refunded'
  },
  shipping: {
    1: 'Pending packing',
    2: 'Packed',
    3: 'Shipped',
    4: 'Out for delivery',
    5: 'Delivered',
    6: 'Delivery failed',
    7: 'Cancelled'
  },
  ticket: {
    1: 'Open',
    2: 'In progress',
    3: 'Resolved',
    4: 'Rejected',
    5: 'Closed'
  },
  return: {
    1: 'Requested',
    2: 'Approved',
    3: 'Rejected',
    4: 'Pickup scheduled',
    5: 'Picked up',
    6: 'Refund initiated',
    7: 'Refunded',
    8: 'Closed'
  },
  seller: {
    1: 'Pending',
    2: 'Approved',
    3: 'Rejected',
    4: 'Suspended'
  },
  product: {
    1: 'Pending',
    2: 'Approved',
    3: 'Rejected',
    4: 'Disabled'
  },
  payout: {
    1: 'Requested',
    2: 'Processing',
    3: 'Paid',
    4: 'Cancelled'
  },
  earning: {
    1: 'Pending',
    2: 'Available',
    3: 'Refunded',
    4: 'Cancelled',
    5: 'Paid'
  },
  transaction: {
    1: 'Earning',
    2: 'Commission',
    3: 'Payout',
    4: 'Refund',
    5: 'Adjustment'
  },
  generic: {
    1: 'Pending',
    2: 'In progress',
    3: 'Failed',
    4: 'Confirmed',
    5: 'Cancelled',
    6: 'Delivered',
    7: 'Packed',
    8: 'Shipped',
    9: 'Refunded',
    10: 'Closed'
  }
};
