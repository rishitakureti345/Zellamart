import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink, RouterLinkActive } from '@angular/router';

export interface DashboardNavItem {
  label: string;
  path: string;
}

@Component({
  selector: 'app-dashboard-sidebar',
  standalone: true,
  imports: [CommonModule, RouterLink, RouterLinkActive],
  template: `
    <nav class="dashboard-sidebar" aria-label="Dashboard navigation">
      <a *ngFor="let item of items" [routerLink]="item.path" routerLinkActive="active">
        {{ item.label }}
      </a>
    </nav>
  `
})
export class DashboardSidebarComponent {
  @Input() items: DashboardNavItem[] = [];
}
