import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-form-field',
  standalone: true,
  template: `
    <label class="form-field">
      <span>{{ label }}</span>
      <ng-content></ng-content>
      <small *ngIf="hint">{{ hint }}</small>
    </label>
  `
})
export class FormFieldComponent {
  @Input() label = '';
  @Input() hint = '';
}
