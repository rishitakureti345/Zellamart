import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterLink, RouterLinkActive } from '@angular/router';
import { AuthService } from '../../../core/services/auth.service';

@Component({
  selector: 'app-store-navbar',
  standalone: true,
  imports: [CommonModule, RouterLink, RouterLinkActive],
  template: `
    <header class="store-nav">
      <a class="store-brand" routerLink="/">
        <span class="store-brand-mark">Z</span>
        <span>
          <strong>Zellamart</strong>
          <small>Independent marketplace</small>
        </span>
      </a>

      <nav aria-label="Store navigation">
        <a routerLink="/" routerLinkActive="active" [routerLinkActiveOptions]="{ exact: true }">Home</a>
        <a routerLink="/products" routerLinkActive="active" *ngIf="showShoppingLinks()">New in</a>
        <a routerLink="/products" *ngIf="showShoppingLinks()">Women</a>
        <a routerLink="/products" *ngIf="showShoppingLinks()">Home</a>

        <ng-container *ngIf="showWorkspaceLinks(); else workspaceSwitcher">
          <a *ngFor="let workspace of auth.workspaces()" [routerLink]="workspace.path" routerLinkActive="active">
            {{ workspace.label }}
          </a>
        </ng-container>

        <ng-template #workspaceSwitcher>
          <label class="workspace-switcher" *ngIf="auth.workspaces().length > 1">
            <span>Workspace</span>
            <select [value]="selectedWorkspaceKey()" (change)="switchWorkspace($event)">
              <option *ngFor="let workspace of auth.workspaces()" [value]="workspace.key">
                {{ workspace.label }}
              </option>
            </select>
          </label>
          <a *ngIf="auth.workspaces().length === 1" [routerLink]="auth.workspaces()[0].path" routerLinkActive="active">
            {{ auth.workspaces()[0].label }}
          </a>
        </ng-template>
      </nav>

      <div class="store-actions">
        <a class="cart-link" routerLink="/cart" *ngIf="showShoppingLinks()">Cart</a>
        <ng-container *ngIf="auth.session(); else signedOut">
          <a class="account-link" [routerLink]="auth.defaultDashboardPath()">{{ dashboardLabel() }}</a>
          <button class="logout-link" type="button" (click)="logout()">Logout</button>
        </ng-container>
        <ng-template #signedOut>
          <a class="account-link" routerLink="/login">Sign in</a>
        </ng-template>
      </div>
    </header>
  `
})
export class StoreNavbarComponent {
  constructor(
    readonly auth: AuthService,
    private readonly router: Router
  ) {}

  logout(): void {
    this.auth.logout();
    void this.router.navigateByUrl('/');
  }

  showWorkspaceLinks(): boolean {
    return this.auth.isSuperAdmin() || this.auth.hasExactRole('Admin') || this.staffOnlyWorkspaces();
  }

  showShoppingLinks(): boolean {
    if (!this.auth.session()) {
      return true;
    }

    if (this.auth.isSuperAdmin() || this.auth.hasExactRole('Admin')) {
      return false;
    }

    return this.auth.hasExactRole('Customer') || this.auth.hasExactRole('Seller');
  }

  dashboardLabel(): string {
    return this.auth.activeWorkspace()?.label ?? 'Dashboard';
  }

  selectedWorkspaceKey(): string {
    return this.auth.activeWorkspace()?.key ?? '';
  }

  switchWorkspace(event: Event): void {
    const key = (event.target as HTMLSelectElement).value;
    const workspace = this.auth.setActiveWorkspace(key);
    if (workspace) {
      void this.router.navigateByUrl(workspace.path);
    }
  }

  private staffOnlyWorkspaces(): boolean {
    const hasStaffWorkspace = this.auth.hasAnyRole([
      'SupportManager',
      'SupportAgent',
      'WarehouseManager',
      'InventoryStaff',
      'DeliveryManager',
      'DeliveryPartner',
      'OrderManager',
      'FinanceManager',
      'PaymentTeam'
    ]);

    return hasStaffWorkspace && !this.auth.hasExactRole('Customer') && !this.auth.hasExactRole('Seller');
  }
}
