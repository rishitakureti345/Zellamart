import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-data-table',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="table surface">
      <table>
        <thead>
          <tr>
            <th *ngFor="let column of columns">{{ column }}</th>
          </tr>
        </thead>
        <tbody>
          <ng-content></ng-content>
        </tbody>
      </table>
    </div>
  `
})
export class DataTableComponent {
  @Input() columns: string[] = [];
}
