import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-toast',
  standalone: true,
  imports: [CommonModule],
  template: `<p class="toast" *ngIf="message">{{ message }}</p>`
})
export class ToastComponent {
  @Input() message = '';
}
