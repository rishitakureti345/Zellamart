import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-loading-skeleton',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="skeleton-list" aria-label="Loading">
      <span *ngFor="let item of placeholders"></span>
    </div>
  `
})
export class LoadingSkeletonComponent {
  @Input() rows = 4;

  get placeholders(): number[] {
    return Array.from({ length: this.rows }, (_, index) => index);
  }
}
