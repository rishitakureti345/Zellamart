import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { AuthService } from '../../../core/services/auth.service';

@Component({
  selector: 'app-workspace-switcher',
  standalone: true,
  imports: [CommonModule],
  template: `
    <section class="surface workspace-card" *ngIf="auth.workspaces().length > 1">
      <div>
        <span class="eyebrow">Workspace access</span>
        <h2>Switch workspace</h2>
        <p>Use the workspace that matches what you want to do right now.</p>
      </div>

      <label>Current workspace
        <select [value]="selectedWorkspaceKey()" (change)="switchWorkspace($event)">
          <option *ngFor="let workspace of auth.workspaces()" [value]="workspace.key">
            {{ workspace.label }}
          </option>
        </select>
      </label>
    </section>
  `
})
export class WorkspaceSwitcherComponent {
  constructor(
    readonly auth: AuthService,
    private readonly router: Router
  ) {}

  selectedWorkspaceKey(): string {
    return this.auth.activeWorkspace()?.key ?? '';
  }

  switchWorkspace(event: Event): void {
    const key = (event.target as HTMLSelectElement).value;
    const workspace = this.auth.setActiveWorkspace(key);
    if (workspace) {
      void this.router.navigateByUrl(workspace.path);
    }
  }
}
