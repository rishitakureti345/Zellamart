import { Component, EventEmitter, Input, Output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { Product } from '../../../public/models/catalog.model';
import { InventoryItem } from '../../../public/models/inventory.model';
import { formatMoney } from '../../utils/currency';

@Component({
  selector: 'app-product-card',
  standalone: true,
  imports: [CommonModule, RouterLink],
  template: `
    <article class="product-card">
      <a class="product-media" [routerLink]="['/products', product.id]" [attr.aria-label]="product.name">
        <img *ngIf="product.imageUrl; else fallback" [src]="product.imageUrl" [alt]="product.name">
        <ng-template #fallback>
          <span>{{ product.name.slice(0, 2).toUpperCase() }}</span>
        </ng-template>
      </a>
      <div class="product-copy">
        <a class="product-name" [routerLink]="['/products', product.id]">{{ product.name }}</a>
        <p>{{ product.description }}</p>
        <span class="stock-chip" [class.out]="stock && stock.availableQuantity <= 0">
          {{ stockLabel() }}
        </span>
        <div class="product-foot">
          <strong>{{ money(product.price, product.currency) }}</strong>
          <button type="button" [disabled]="stock?.availableQuantity === 0" (click)="add.emit(product)">Add</button>
        </div>
      </div>
    </article>
  `
})
export class ProductCardComponent {
  @Input({ required: true }) product!: Product;
  @Input() stock?: InventoryItem | null;
  @Output() add = new EventEmitter<Product>();

  money = formatMoney;

  stockLabel(): string {
    if (!this.stock) {
      return 'Stock checking';
    }

    if (this.stock.availableQuantity <= 0) {
      return 'Out of stock';
    }

    return `${this.stock.availableQuantity} available`;
  }
}
