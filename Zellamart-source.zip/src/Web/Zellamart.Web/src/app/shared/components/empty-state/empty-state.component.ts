import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-empty-state',
  standalone: true,
  template: `
    <section class="empty-state">
      <strong>{{ title }}</strong>
      <p>{{ message }}</p>
    </section>
  `
})
export class EmptyStateComponent {
  @Input() title = 'Nothing here yet';
  @Input() message = 'Try changing filters or checking again later.';
}
