import { Component, EventEmitter, Input, Output } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-modal',
  standalone: true,
  imports: [CommonModule],
  template: `
    <section class="modal-backdrop" *ngIf="open">
      <div class="modal-panel" role="dialog" aria-modal="true" [attr.aria-label]="title">
        <header>
          <h2>{{ title }}</h2>
          <button type="button" class="icon-button" (click)="closed.emit()">x</button>
        </header>
        <ng-content></ng-content>
      </div>
    </section>
  `
})
export class ModalComponent {
  @Input() open = false;
  @Input() title = 'Dialog';
  @Output() closed = new EventEmitter<void>();
}
