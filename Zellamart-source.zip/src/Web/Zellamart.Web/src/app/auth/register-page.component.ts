import { Component, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { AuthService } from '../core/services/auth.service';
import { ErrorMessageService } from '../core/services/error-message.service';
import { ToastComponent } from '../shared/components/toast/toast.component';

@Component({
  selector: 'app-register-page',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink, ToastComponent],
  template: `
    <main class="auth-page">
      <section class="auth-card">
        <a routerLink="/" class="back-link">Back to store</a>
        <span class="eyebrow">Create account</span>
        <h1>Start shopping on Zellamart</h1>
        <p>New accounts are created as customers and can use catalog, cart, orders, support, and returns.</p>

        <app-toast [message]="message()"></app-toast>

        <form class="auth-form" (ngSubmit)="register()">
          <label>Full name<input [(ngModel)]="fullName" name="fullName" autocomplete="name" required></label>
          <label>Email<input [(ngModel)]="email" name="email" type="email" autocomplete="email" required></label>
          <label>Password<input [(ngModel)]="password" name="password" type="password" autocomplete="new-password" required></label>
          <button type="submit" [disabled]="busy()">Register</button>
        </form>

        <p class="auth-switch">Already have an account? <a routerLink="/login">Sign in</a></p>
      </section>
    </main>
  `
})
export class RegisterPageComponent {
  fullName = '';
  email = '';
  password = 'Password123!';
  readonly busy = signal(false);
  readonly message = signal('');

  constructor(
    private readonly auth: AuthService,
    private readonly errors: ErrorMessageService,
    private readonly router: Router
  ) {}

  register(): void {
    this.busy.set(true);
    this.message.set('');
    this.auth.register(this.fullName, this.email, this.password).subscribe({
      next: () => {
        this.busy.set(false);
        void this.router.navigateByUrl(this.auth.defaultDashboardPath());
      },
      error: (error) => {
        this.busy.set(false);
        this.message.set(this.errors.from(error));
      }
    });
  }
}
