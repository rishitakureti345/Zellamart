import { Component, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { AuthService } from '../core/services/auth.service';
import { ErrorMessageService } from '../core/services/error-message.service';
import { ToastComponent } from '../shared/components/toast/toast.component';

@Component({
  selector: 'app-login-page',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink, ToastComponent],
  template: `
    <main class="auth-page">
      <section class="auth-card">
        <a routerLink="/" class="back-link">Back to store</a>
        <span class="eyebrow">Welcome back</span>
        <h1>Sign in to Zellamart</h1>
        <p>Customers, sellers, support, operations, and finance users are sent to the right dashboard after login.</p>

        <app-toast [message]="message()"></app-toast>

        <form class="auth-form" (ngSubmit)="login()">
          <label>Email<input [(ngModel)]="email" name="email" type="email" autocomplete="email" required></label>
          <label>Password<input [(ngModel)]="password" name="password" type="password" autocomplete="current-password" required></label>
          <button type="submit" [disabled]="busy()">Login</button>
        </form>

        <p class="auth-switch">New customer? <a routerLink="/register">Create an account</a></p>
      </section>
    </main>
  `
})
export class LoginPageComponent {
  email = '';
  password = 'Password123!';
  readonly busy = signal(false);
  readonly message = signal('');

  constructor(
    private readonly auth: AuthService,
    private readonly errors: ErrorMessageService,
    private readonly router: Router
  ) {}

  login(): void {
    this.busy.set(true);
    this.message.set('');
    this.auth.login(this.email, this.password).subscribe({
      next: () => {
        this.busy.set(false);
        void this.router.navigateByUrl(this.auth.defaultDashboardPath());
      },
      error: (error) => {
        this.busy.set(false);
        this.message.set(this.errors.from(error));
      }
    });
  }
}
