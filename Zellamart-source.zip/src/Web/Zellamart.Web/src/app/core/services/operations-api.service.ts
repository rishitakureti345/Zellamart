import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ApiResult } from '../models/api-result.model';
import { OrderSummary, ReturnSummary, ShipmentSummary, SupportTicketSummary } from '../models/operations.model';

@Injectable({ providedIn: 'root' })
export class OperationsApiService {
  constructor(private readonly http: HttpClient) {}

  myOrders(): Observable<ApiResult<OrderSummary[]>> {
    return this.http.get<ApiResult<OrderSummary[]>>('/api/orders/me');
  }

  myShipments(): Observable<ApiResult<ShipmentSummary[]>> {
    return this.http.get<ApiResult<ShipmentSummary[]>>('/api/shipping/me');
  }

  myTickets(): Observable<ApiResult<SupportTicketSummary[]>> {
    return this.http.get<ApiResult<SupportTicketSummary[]>>('/api/support/tickets/me');
  }

  myReturns(): Observable<ApiResult<ReturnSummary[]>> {
    return this.http.get<ApiResult<ReturnSummary[]>>('/api/support/returns/me');
  }
}
