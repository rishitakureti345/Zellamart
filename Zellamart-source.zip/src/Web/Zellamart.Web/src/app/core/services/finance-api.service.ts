import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ApiResult } from '../models/api-result.model';
import {
  AdminSummary,
  FinanceTransaction,
  SellerBalance,
  SellerBalanceRow,
  SellerEarning,
  SellerPayout
} from '../models/finance.model';

@Injectable({ providedIn: 'root' })
export class FinanceApiService {
  constructor(private readonly http: HttpClient) {}

  sellerBalance(): Observable<ApiResult<SellerBalance>> {
    return this.http.get<ApiResult<SellerBalance>>('/api/finance/me/balance');
  }

  sellerEarnings(): Observable<ApiResult<SellerEarning[]>> {
    return this.http.get<ApiResult<SellerEarning[]>>('/api/finance/me/earnings');
  }

  sellerPayouts(): Observable<ApiResult<SellerPayout[]>> {
    return this.http.get<ApiResult<SellerPayout[]>>('/api/finance/me/payouts');
  }

  sellerTransactions(): Observable<ApiResult<FinanceTransaction[]>> {
    return this.http.get<ApiResult<FinanceTransaction[]>>('/api/finance/me/transactions');
  }

  requestPayout(sellerId: string): Observable<ApiResult<SellerPayout>> {
    return this.http.post<ApiResult<SellerPayout>>(`/api/finance/sellers/${sellerId}/payouts/request`, {});
  }

  adminSummary(): Observable<ApiResult<AdminSummary>> {
    return this.http.get<ApiResult<AdminSummary>>('/api/finance/admin/summary');
  }

  adminSellerBalances(): Observable<ApiResult<SellerBalanceRow[]>> {
    return this.http.get<ApiResult<SellerBalanceRow[]>>('/api/finance/admin/seller-balances');
  }

  adminPayouts(): Observable<ApiResult<SellerPayout[]>> {
    return this.http.get<ApiResult<SellerPayout[]>>('/api/finance/admin/payouts');
  }

  markPayoutPaid(payoutId: string): Observable<ApiResult<SellerPayout>> {
    return this.http.post<ApiResult<SellerPayout>>(`/api/finance/payouts/${payoutId}/mark-paid`, {});
  }

  sellerTransactionsById(sellerId: string): Observable<ApiResult<FinanceTransaction[]>> {
    return this.http.get<ApiResult<FinanceTransaction[]>>(`/api/finance/sellers/${sellerId}/transactions`);
  }

  createRefundForReturn(returnId: string): Observable<ApiResult<FinanceTransaction>> {
    return this.http.post<ApiResult<FinanceTransaction>>('/api/finance/refunds/create-for-return', { returnId });
  }
}
