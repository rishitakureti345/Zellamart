import { Injectable, computed, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, tap } from 'rxjs';
import { ApiResult } from '../models/api-result.model';
import { AuthResponse, UpdateUserProfileRequest, UserProfileResponse, WorkspaceAccess } from '../models/auth.model';

const SESSION_KEY = 'zellamart_session';
const TOKEN_KEY = 'zellamart_token';
const WORKSPACE_KEY = 'zellamart_workspace';

@Injectable({ providedIn: 'root' })
export class AuthService {
  readonly session = signal<AuthResponse | null>(this.readSession());
  readonly roles = computed(() => this.session()?.roles ?? []);
  readonly workspaces = computed(() => this.sessionWorkspaces(this.session()));
  readonly activeWorkspaceKey = signal(this.readWorkspaceKey());
  readonly activeWorkspace = computed(() => {
    const workspaces = this.workspaces();
    const selected = workspaces.find((workspace) => workspace.key === this.activeWorkspaceKey());
    return selected ?? workspaces.find((workspace) => workspace.key === this.session()?.defaultWorkspaceKey) ?? workspaces[0] ?? null;
  });

  constructor(private readonly http: HttpClient) {}

  login(email: string, password: string): Observable<ApiResult<AuthResponse>> {
    return this.http.post<ApiResult<AuthResponse>>('/api/auth/login', { email, password }).pipe(
      tap((result) => this.storeSession(result.value))
    );
  }

  register(fullName: string, email: string, password: string): Observable<ApiResult<AuthResponse>> {
    return this.http.post<ApiResult<AuthResponse>>('/api/auth/register', { fullName, email, password }).pipe(
      tap((result) => this.storeSession(result.value))
    );
  }

  profile(): Observable<ApiResult<UserProfileResponse>> {
    return this.http.get<ApiResult<UserProfileResponse>>('/api/auth/me').pipe(
      tap((result) => this.mergeProfile(result.value))
    );
  }

  updateProfile(request: UpdateUserProfileRequest): Observable<ApiResult<UserProfileResponse>> {
    return this.http.put<ApiResult<UserProfileResponse>>('/api/auth/me/profile', request).pipe(
      tap((result) => this.mergeProfile(result.value))
    );
  }

  logout(): void {
    localStorage.removeItem(SESSION_KEY);
    localStorage.removeItem(TOKEN_KEY);
    localStorage.removeItem(WORKSPACE_KEY);
    this.session.set(null);
    this.activeWorkspaceKey.set('');
  }

  token(): string | null {
    return localStorage.getItem(TOKEN_KEY);
  }

  hasRole(role: string): boolean {
    return this.roles().includes('SuperAdmin') || this.roles().includes(role);
  }

  hasExactRole(role: string): boolean {
    return this.roles().includes(role);
  }

  isSuperAdmin(): boolean {
    return this.hasExactRole('SuperAdmin');
  }

  hasAnyRole(roles: string[]): boolean {
    return roles.some((role) => this.hasRole(role));
  }

  setActiveWorkspace(key: string): WorkspaceAccess | null {
    const workspace = this.workspaces().find((item) => item.key === key) ?? null;
    if (!workspace) {
      return null;
    }

    localStorage.setItem(WORKSPACE_KEY, workspace.key);
    this.activeWorkspaceKey.set(workspace.key);
    return workspace;
  }

  defaultDashboardPath(): string {
    const workspace = this.activeWorkspace();
    if (workspace) {
      return workspace.path;
    }

    const session = this.session();
    if (session?.defaultDashboardPath) {
      return session.defaultDashboardPath;
    }

    return '/';
  }

  private storeSession(session: AuthResponse): void {
    const workspaces = this.sessionWorkspaces(session);
    const storedWorkspaceKey = this.readWorkspaceKey();
    const activeWorkspace = workspaces.find((workspace) => workspace.key === storedWorkspaceKey)
      ?? workspaces.find((workspace) => workspace.key === session.defaultWorkspaceKey)
      ?? workspaces[0]
      ?? null;

    localStorage.setItem(SESSION_KEY, JSON.stringify(session));
    localStorage.setItem(TOKEN_KEY, session.accessToken);
    if (activeWorkspace) {
      localStorage.setItem(WORKSPACE_KEY, activeWorkspace.key);
      this.activeWorkspaceKey.set(activeWorkspace.key);
    } else {
      localStorage.removeItem(WORKSPACE_KEY);
      this.activeWorkspaceKey.set('');
    }
    this.session.set(session);
  }

  private mergeProfile(profile: UserProfileResponse): void {
    const current = this.session();
    if (!current) {
      return;
    }

    this.storeSession({
      ...current,
      userId: profile.userId,
      fullName: profile.fullName,
      email: profile.email,
      isActive: profile.isActive,
      phone: profile.phone,
      defaultShippingAddress: profile.defaultShippingAddress,
      roles: profile.roles,
      permissions: profile.permissions,
      workspaces: profile.workspaces,
      defaultWorkspaceKey: profile.defaultWorkspaceKey,
      defaultDashboardPath: profile.defaultDashboardPath
    });
  }

  private readSession(): AuthResponse | null {
    const raw = localStorage.getItem(SESSION_KEY);
    return raw ? JSON.parse(raw) as AuthResponse : null;
  }

  private readWorkspaceKey(): string {
    return localStorage.getItem(WORKSPACE_KEY) ?? '';
  }

  private sessionWorkspaces(session: AuthResponse | null): WorkspaceAccess[] {
    if (session?.workspaces?.length) {
      return session.workspaces;
    }

    const roles = session?.roles ?? [];
    const hasExactRole = (role: string) => roles.includes(role);
    const hasAnyRole = (allowedRoles: string[]) => allowedRoles.some((role) => hasExactRole(role));
    const workspaces: WorkspaceAccess[] = [];
    const add = (key: string, label: string, path: string) => {
      workspaces.push({ key, label, path, isPrimary: workspaces.length === 0 });
    };

    if (hasExactRole('SuperAdmin')) {
      add('superadmin', 'SuperAdmin', '/superadmin/dashboard');
      add('admin', 'Admin', '/admin/dashboard');
      add('operations', 'Operations', '/operations/dashboard');
      add('support', 'Support', '/support/tickets');
      add('finance', 'Finance', '/finance/dashboard');
      return workspaces;
    }

    if (hasExactRole('Admin')) {
      add('admin', 'Admin', '/admin/dashboard');
      add('operations', 'Operations', '/operations/dashboard');
      add('support', 'Support', '/support/tickets');
      add('finance', 'Finance', '/finance/dashboard');
      return workspaces;
    }

    if (hasExactRole('Seller')) {
      add('seller', 'Seller', '/seller/dashboard');
    }

    if (hasAnyRole(['SupportManager', 'SupportAgent'])) {
      add('support', 'Support', '/support/tickets');
    }

    if (hasAnyRole(['WarehouseManager', 'DeliveryManager', 'DeliveryPartner', 'InventoryStaff', 'OrderManager'])) {
      add('operations', 'Operations', '/operations/dashboard');
    }

    if (hasAnyRole(['FinanceManager', 'PaymentTeam'])) {
      add('finance', 'Finance', '/finance/dashboard');
    }

    if (hasExactRole('Customer')) {
      add('customer', 'Customer', '/customer/dashboard');
    }

    return workspaces;
  }
}
