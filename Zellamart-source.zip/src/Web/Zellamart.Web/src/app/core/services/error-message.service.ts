import { Injectable } from '@angular/core';

@Injectable({ providedIn: 'root' })
export class ErrorMessageService {
  from(error: unknown): string {
    const fallback = 'Request failed.';
    if (typeof error !== 'object' || !error || !('error' in error)) {
      return fallback;
    }

    const body = (error as { error?: { error?: { message?: string }; message?: string } }).error;
    return body?.error?.message ?? body?.message ?? fallback;
  }
}
