export interface SellerBalance {
  sellerId: string;
  availableBalance: number;
  pendingEarnings: number;
  totalPaidOut: number;
  refundDeductions: number;
  adjustmentBalance: number;
}

export interface SellerEarning {
  id: string;
  sellerId: string;
  orderId: string;
  orderItemId: string;
  productId: string;
  grossAmount: number;
  commissionAmount: number;
  netAmount: number;
  status: string;
  createdAtUtc: string;
}

export interface SellerPayout {
  id: string;
  sellerId: string;
  amount: number;
  status: string;
  requestedAtUtc: string;
  paidAtUtc?: string;
  referenceNumber: string;
}

export interface FinanceTransaction {
  id: string;
  sellerId: string;
  orderId?: string;
  type: string;
  amount: number;
  description: string;
  referenceId?: string;
  createdAtUtc: string;
}

export interface AdminSummary {
  totalSales: number;
  totalCommission: number;
  totalSellerEarnings: number;
  totalPayouts: number;
  totalRefunds: number;
  pendingPayoutAmount: number;
}

export interface SellerBalanceRow extends SellerBalance {}
