export interface OrderSummary {
  id: string;
  status: string;
  subtotal: number;
  currency: string;
  createdAtUtc: string;
}

export interface ShipmentSummary {
  id: string;
  orderId: string;
  deliveryPartnerId?: string;
  status: string;
  shippingAddress: string;
  trackingNumber: string;
  createdAtUtc: string;
}

export interface SupportTicketSummary {
  id: string;
  customerId: string;
  orderId?: string;
  type: string;
  subject: string;
  status: string;
  assignedAgentId?: string;
  createdAtUtc: string;
}

export interface ReturnSummary {
  id: string;
  orderId: string;
  orderItemId: string;
  productId: string;
  reason: string;
  status: string;
  refundAmount: number;
  createdAtUtc: string;
}
