export interface AuthResponse {
  userId: string;
  fullName: string;
  email: string;
  isActive?: boolean;
  phone?: string | null;
  defaultShippingAddress?: string | null;
  roles: string[];
  permissions: string[];
  workspaces?: WorkspaceAccess[];
  defaultWorkspaceKey?: string;
  defaultDashboardPath?: string;
  accessToken: string;
}

export interface UserProfileResponse {
  userId: string;
  fullName: string;
  email: string;
  isActive: boolean;
  phone?: string | null;
  defaultShippingAddress?: string | null;
  roles: string[];
  permissions: string[];
  workspaces?: WorkspaceAccess[];
  defaultWorkspaceKey?: string;
  defaultDashboardPath?: string;
}

export interface UpdateUserProfileRequest {
  phone?: string | null;
  defaultShippingAddress?: string | null;
}

export interface WorkspaceAccess {
  key: string;
  label: string;
  path: string;
  isPrimary: boolean;
}
