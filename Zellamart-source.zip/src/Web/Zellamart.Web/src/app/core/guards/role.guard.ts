import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { AuthService } from '../services/auth.service';

export const roleGuard: CanActivateFn = (route) => {
  const auth = inject(AuthService);
  const router = inject(Router);
  const session = auth.session();

  if (!session) {
    return router.parseUrl('/login');
  }

  const allowedRoles = route.data['roles'] as string[] | undefined;
  if (!allowedRoles?.length || allowedRoles.some((role) => auth.hasRole(role))) {
    return true;
  }

  return router.parseUrl(auth.defaultDashboardPath());
};
