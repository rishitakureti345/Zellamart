import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterOutlet } from '@angular/router';
import { StoreNavbarComponent } from '../../shared/components/store-navbar/store-navbar.component';
import { DashboardNavItem, DashboardSidebarComponent } from '../../shared/components/dashboard-sidebar/dashboard-sidebar.component';
import { AuthService } from '../../core/services/auth.service';
import { StatusBadgeComponent } from '../../shared/components/status-badge/status-badge.component';

@Component({
  selector: 'app-finance-layout',
  standalone: true,
  imports: [CommonModule, RouterOutlet, StoreNavbarComponent, DashboardSidebarComponent, StatusBadgeComponent],
  template: `
    <app-store-navbar></app-store-navbar>
    <main class="seller-shell">
      <aside class="admin-sidebar">
        <section class="admin-identity" *ngIf="auth.session() as session">
          <span>Finance workspace</span>
          <strong>{{ session.fullName }}</strong>
          <small>{{ session.email }}</small>
          <p class="badge-row">
            <app-status-badge *ngFor="let role of financeRoles()" [status]="role"></app-status-badge>
          </p>
        </section>
        <app-dashboard-sidebar [items]="items"></app-dashboard-sidebar>
      </aside>

      <section class="admin-workspace">
        <header class="admin-topbar" *ngIf="auth.session() as session">
          <div>
            <span class="eyebrow">Finance center</span>
            <strong>{{ session.email }}</strong>
          </div>
          <button type="button" class="ghost-light" (click)="logout()">Logout</button>
        </header>

        <section class="seller-status-banner customer-status-banner">
          <div>
            <strong>Payments and payouts</strong>
            <p>Track revenue, seller balances, payouts, refund deductions, and payment transactions in one shared finance view.</p>
          </div>
          <app-status-badge status="Finance" label="Finance"></app-status-badge>
        </section>

        <section class="dashboard-content"><router-outlet></router-outlet></section>
      </section>
    </main>
  `
})
export class FinanceLayoutComponent {
  readonly items: DashboardNavItem[] = [
    { label: 'Dashboard', path: '/finance/dashboard' },
    { label: 'Seller balances', path: '/finance/seller-balances' },
    { label: 'Payouts', path: '/finance/payouts' },
    { label: 'Transactions', path: '/finance/transactions' },
    { label: 'Refunds', path: '/finance/refunds' }
  ];

  constructor(
    readonly auth: AuthService,
    private readonly router: Router
  ) {}

  financeRoles(): string[] {
    return this.auth.roles().filter((role) => ['FinanceManager', 'PaymentTeam', 'Admin', 'SuperAdmin'].includes(role));
  }

  logout(): void {
    this.auth.logout();
    void this.router.navigateByUrl('/');
  }
}
