import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FinanceApiService } from '../../core/services/finance-api.service';
import { ErrorMessageService } from '../../core/services/error-message.service';
import { SellerPayout } from '../../core/models/finance.model';
import { MoneyPipe } from '../../shared/pipes/money.pipe';
import { StatusBadgeComponent } from '../../shared/components/status-badge/status-badge.component';
import { EmptyStateComponent } from '../../shared/components/empty-state/empty-state.component';
import { ToastComponent } from '../../shared/components/toast/toast.component';

@Component({
  selector: 'app-finance-payouts',
  standalone: true,
  imports: [CommonModule, MoneyPipe, StatusBadgeComponent, EmptyStateComponent, ToastComponent],
  template: `
    <section class="dashboard-header"><div><span class="eyebrow">Finance</span><h1>Payout approvals</h1><p>Review requested payouts and mark processing payouts as paid.</p></div><button (click)="load()">Refresh</button></section>
    <app-toast [message]="message()"></app-toast>
    <section class="surface dashboard-panel" *ngIf="payouts().length">
      <table><tr><th>Reference</th><th>Seller</th><th>Amount</th><th>Status</th><th>Requested</th><th>Action</th></tr>
        <tr *ngFor="let payout of payouts()"><td>{{ payout.referenceNumber }}</td><td>{{ payout.sellerId }}</td><td>{{ payout.amount | money }}</td><td><app-status-badge kind="payout" [status]="payout.status"></app-status-badge></td><td>{{ payout.requestedAtUtc | date:'medium' }}</td><td><button (click)="markPaid(payout.id)">Mark paid</button></td></tr>
      </table>
    </section>
    <app-empty-state *ngIf="!payouts().length" title="No payouts" message="Seller payout requests will appear here."></app-empty-state>
  `
})
export class FinancePayoutsComponent implements OnInit {
  readonly payouts = signal<SellerPayout[]>([]);
  readonly message = signal('');
  constructor(private readonly finance: FinanceApiService, private readonly errors: ErrorMessageService) {}
  ngOnInit(): void { this.load(); }
  load(): void {
    this.finance.adminPayouts().subscribe({
      next: (result) => this.payouts.set(result.value ?? []),
      error: (error) => this.message.set(this.errors.from(error))
    });
  }
  markPaid(payoutId: string): void {
    this.finance.markPayoutPaid(payoutId).subscribe({
      next: () => { this.message.set('Payout marked paid.'); this.load(); },
      error: (error) => this.message.set(this.errors.from(error))
    });
  }
}
