import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { FinanceApiService } from '../../core/services/finance-api.service';
import { ErrorMessageService } from '../../core/services/error-message.service';
import { FinanceTransaction } from '../../core/models/finance.model';
import { SupportStaffApiService } from '../../support/services/support-staff-api.service';
import { ReturnRequest } from '../../customer/models/support.model';
import { MoneyPipe } from '../../shared/pipes/money.pipe';
import { StatusBadgeComponent } from '../../shared/components/status-badge/status-badge.component';
import { ToastComponent } from '../../shared/components/toast/toast.component';
import { EmptyStateComponent } from '../../shared/components/empty-state/empty-state.component';

@Component({
  selector: 'app-finance-refunds',
  standalone: true,
  imports: [CommonModule, FormsModule, MoneyPipe, StatusBadgeComponent, ToastComponent, EmptyStateComponent],
  template: `
    <section class="dashboard-header">
      <div>
        <span class="eyebrow">Finance</span>
        <h1>Refund review</h1>
        <p>Review approved or picked-up returns, mark refunds complete, and create aligned finance transactions.</p>
      </div>
      <button type="button" (click)="load()">Refresh</button>
    </section>
    <app-toast [message]="message()"></app-toast>

    <section class="ops-toolbar surface">
      <label>Status
        <select [(ngModel)]="statusFilter" name="statusFilter">
          <option value="all">All returns</option>
          <option value="approved">Approved</option>
          <option value="pickedup">Picked up</option>
          <option value="refunded">Refunded</option>
          <option value="refundrejected">Refund rejected</option>
        </select>
      </label>
      <label>Search<input [(ngModel)]="search" name="search" placeholder="Return, order, product, customer"></label>
    </section>

    <section class="surface dashboard-panel" *ngIf="filteredReturns().length">
      <table>
        <tr><th>Return</th><th>Order</th><th>Customer</th><th>Amount</th><th>Status</th><th>Created</th><th>Action</th></tr>
        <tr *ngFor="let item of filteredReturns()">
          <td>{{ item.id }}</td>
          <td>{{ item.orderId }}</td>
          <td>{{ item.customerId }}</td>
          <td>{{ item.refundAmount | money }}</td>
          <td><app-status-badge kind="return" [status]="item.status"></app-status-badge></td>
          <td>{{ item.createdAtUtc | date:'medium' }}</td>
          <td class="action-row">
            <button type="button" (click)="createRefund(item)" [disabled]="busyId() === item.id || !canCreateRefund(item)">
              {{ busyId() === item.id ? 'Working...' : 'Create refund' }}
            </button>
          </td>
        </tr>
      </table>
    </section>

    <app-empty-state *ngIf="!filteredReturns().length" title="No refund items" message="Approved and picked-up return requests will appear here."></app-empty-state>

    <section class="surface profile-card" *ngIf="transaction() as tx">
      <div><span>Type</span><strong><app-status-badge kind="transaction" [status]="tx.type"></app-status-badge></strong></div>
      <div><span>Amount</span><strong>{{ tx.amount | money }}</strong></div>
      <div><span>Seller</span><strong>{{ tx.sellerId }}</strong></div>
      <div><span>Description</span><p>{{ tx.description }}</p></div>
    </section>
  `
})
export class FinanceRefundsComponent implements OnInit {
  search = '';
  statusFilter = 'all';
  readonly returns = signal<ReturnRequest[]>([]);
  readonly transaction = signal<FinanceTransaction | null>(null);
  readonly message = signal('');
  readonly busyId = signal<string | null>(null);

  filteredReturns(): ReturnRequest[] {
    const query = this.search.trim().toLowerCase();
    const status = this.statusFilter.toLowerCase();
    return this.returns().filter((item) => {
      const itemStatus = this.statusText(item.status);
      const matchesStatus = status === 'all' || itemStatus === status;
      const haystack = `${item.id} ${item.orderId} ${item.productId} ${item.customerId} ${item.reason}`.toLowerCase();
      return matchesStatus && (!query || haystack.includes(query));
    });
  }

  constructor(
    private readonly finance: FinanceApiService,
    private readonly support: SupportStaffApiService,
    private readonly errors: ErrorMessageService
  ) {}

  ngOnInit(): void {
    this.load();
  }

  load(): void {
    this.support.returns().subscribe({
      next: (items) => this.returns.set(items),
      error: (error) => this.message.set(this.errors.from(error))
    });
  }

  createRefund(item: ReturnRequest): void {
    if (!this.canCreateRefund(item)) {
      this.message.set('Return must be approved or picked up before a refund can be created.');
      return;
    }

    this.busyId.set(item.id);
    this.support.refund(item.id).subscribe({
      next: () => {
        this.finance.createRefundForReturn(item.id).subscribe({
          next: (result) => {
            this.transaction.set(result.value);
            this.message.set('Refund transaction created and return marked refunded.');
            this.busyId.set(null);
            this.load();
          },
          error: (error) => { this.busyId.set(null); this.message.set(this.errors.from(error)); }
        });
      },
      error: (error) => { this.busyId.set(null); this.message.set(this.errors.from(error)); }
    });
  }

  canCreateRefund(item: ReturnRequest): boolean {
    const status = this.statusText(item.status);
    return status === 'approved' || status === 'pickedup';
  }

  private statusText(status: string | number): string {
    const numericLabels: Record<number, string> = {
      1: 'requested',
      2: 'approved',
      3: 'rejected',
      4: 'pickupscheduled',
      5: 'pickedup',
      6: 'refundinitiated',
      7: 'refunded',
      8: 'closed'
    };
    const numericStatus = Number(status);
    if (!Number.isNaN(numericStatus)) {
      return numericLabels[numericStatus] ?? String(status);
    }

    return String(status).toLowerCase().replace(/[\s_-]/g, '');
  }
}
