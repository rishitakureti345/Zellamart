import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FinanceApiService } from '../../core/services/finance-api.service';
import { AdminSummary } from '../../core/models/finance.model';
import { MoneyPipe } from '../../shared/pipes/money.pipe';
import { ToastComponent } from '../../shared/components/toast/toast.component';

@Component({
  selector: 'app-finance-dashboard',
  standalone: true,
  imports: [CommonModule, MoneyPipe, ToastComponent],
  template: `
    <section class="dashboard-header"><div><span class="eyebrow">Finance</span><h1>Dashboard</h1><p>Platform sales, commission, payouts, and refunds.</p></div><button (click)="load()">Refresh</button></section>
    <app-toast [message]="message()"></app-toast>
    <section class="metric-row">
      <article class="metric"><span>Total sales</span><strong>{{ summary()?.totalSales || 0 | money }}</strong></article>
      <article class="metric"><span>Commission</span><strong>{{ summary()?.totalCommission || 0 | money }}</strong></article>
      <article class="metric"><span>Seller earnings</span><strong>{{ summary()?.totalSellerEarnings || 0 | money }}</strong></article>
      <article class="metric"><span>Total payouts</span><strong>{{ summary()?.totalPayouts || 0 | money }}</strong></article>
      <article class="metric"><span>Total refunds</span><strong>{{ summary()?.totalRefunds || 0 | money }}</strong></article>
    </section>
  `
})
export class FinanceDashboardComponent implements OnInit {
  readonly summary = signal<AdminSummary | null>(null);
  readonly message = signal('');
  constructor(private readonly finance: FinanceApiService) {}
  ngOnInit(): void { this.load(); }
  load(): void {
    this.finance.adminSummary().subscribe({
      next: (result) => this.summary.set(result.value),
      error: () => this.message.set('Could not load finance summary.')
    });
  }
}
