import { Component, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { FinanceApiService } from '../../core/services/finance-api.service';
import { ErrorMessageService } from '../../core/services/error-message.service';
import { FinanceTransaction } from '../../core/models/finance.model';
import { MoneyPipe } from '../../shared/pipes/money.pipe';
import { StatusBadgeComponent } from '../../shared/components/status-badge/status-badge.component';
import { EmptyStateComponent } from '../../shared/components/empty-state/empty-state.component';
import { ToastComponent } from '../../shared/components/toast/toast.component';

@Component({
  selector: 'app-finance-transactions',
  standalone: true,
  imports: [CommonModule, FormsModule, MoneyPipe, StatusBadgeComponent, EmptyStateComponent, ToastComponent],
  template: `
    <section class="dashboard-header"><div><span class="eyebrow">Finance</span><h1>Transactions</h1><p>Look up finance transactions for a seller.</p></div></section>
    <app-toast [message]="message()"></app-toast>
    <form class="ops-toolbar surface" (ngSubmit)="load()"><label>Seller ID<input [(ngModel)]="sellerId" name="sellerId" required></label><button type="submit">Load transactions</button></form>
    <section class="surface dashboard-panel" *ngIf="transactions().length">
      <table><tr><th>Type</th><th>Amount</th><th>Order</th><th>Description</th><th>Created</th></tr>
        <tr *ngFor="let tx of transactions()"><td><app-status-badge kind="transaction" [status]="tx.type"></app-status-badge></td><td>{{ tx.amount | money }}</td><td>{{ tx.orderId || '-' }}</td><td>{{ tx.description }}</td><td>{{ tx.createdAtUtc | date:'medium' }}</td></tr>
      </table>
    </section>
    <app-empty-state *ngIf="searched() && !transactions().length" title="No transactions" message="No finance transactions were found for this seller."></app-empty-state>
  `
})
export class FinanceTransactionsComponent {
  sellerId = '';
  readonly transactions = signal<FinanceTransaction[]>([]);
  readonly searched = signal(false);
  readonly message = signal('');
  constructor(private readonly finance: FinanceApiService, private readonly errors: ErrorMessageService) {}
  load(): void {
    if (!this.sellerId.trim()) { this.message.set('Seller ID is required.'); return; }
    this.searched.set(true);
    this.finance.sellerTransactionsById(this.sellerId.trim()).subscribe({
      next: (result) => this.transactions.set(result.value ?? []),
      error: (error) => this.message.set(this.errors.from(error))
    });
  }
}
