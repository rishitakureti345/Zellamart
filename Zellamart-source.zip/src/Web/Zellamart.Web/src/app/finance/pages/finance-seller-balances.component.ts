import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FinanceApiService } from '../../core/services/finance-api.service';
import { SellerBalanceRow } from '../../core/models/finance.model';
import { MoneyPipe } from '../../shared/pipes/money.pipe';
import { EmptyStateComponent } from '../../shared/components/empty-state/empty-state.component';
import { ToastComponent } from '../../shared/components/toast/toast.component';

@Component({
  selector: 'app-finance-seller-balances',
  standalone: true,
  imports: [CommonModule, MoneyPipe, EmptyStateComponent, ToastComponent],
  template: `
    <section class="dashboard-header"><div><span class="eyebrow">Finance</span><h1>Seller balances</h1><p>Available, pending, paid, refund, and adjustment balances.</p></div><button (click)="load()">Refresh</button></section>
    <app-toast [message]="message()"></app-toast>
    <section class="surface dashboard-panel" *ngIf="balances().length">
      <table><tr><th>Seller</th><th>Available</th><th>Pending</th><th>Paid</th><th>Refunds</th><th>Adjustments</th></tr>
        <tr *ngFor="let row of balances()"><td>{{ row.sellerId }}</td><td>{{ row.availableBalance | money }}</td><td>{{ row.pendingEarnings | money }}</td><td>{{ row.totalPaidOut | money }}</td><td>{{ row.refundDeductions | money }}</td><td>{{ row.adjustmentBalance | money }}</td></tr>
      </table>
    </section>
    <app-empty-state *ngIf="!balances().length" title="No balances yet" message="Seller balances appear after earnings are created."></app-empty-state>
  `
})
export class FinanceSellerBalancesComponent implements OnInit {
  readonly balances = signal<SellerBalanceRow[]>([]);
  readonly message = signal('');
  constructor(private readonly finance: FinanceApiService) {}
  ngOnInit(): void { this.load(); }
  load(): void {
    this.finance.adminSellerBalances().subscribe({
      next: (result) => this.balances.set(result.value ?? []),
      error: () => this.message.set('Could not load seller balances.')
    });
  }
}
