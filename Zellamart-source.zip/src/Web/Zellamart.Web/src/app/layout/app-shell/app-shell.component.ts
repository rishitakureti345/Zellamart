import { Component, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router, RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';
import { AuthService } from '../../core/services/auth.service';
import { ErrorMessageService } from '../../core/services/error-message.service';

interface NavItem {
  label: string;
  path: string;
  roles: string[];
}

@Component({
  selector: 'app-shell',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink, RouterLinkActive, RouterOutlet],
  templateUrl: './app-shell.component.html'
})
export class AppShellComponent {
  email = '';
  password = 'Password123!';
  fullName = 'Zellamart User';
  message = signal('');
  busy = signal(false);

  readonly session = this.auth.session;
  readonly roles = this.auth.roles;
  readonly navItems: NavItem[] = [
    { label: 'Customer', path: '/customer/dashboard', roles: ['Customer', 'Admin', 'SuperAdmin'] },
    { label: 'Seller', path: '/seller', roles: ['Seller', 'SuperAdmin'] },
    { label: 'Admin', path: '/admin/dashboard', roles: ['Admin', 'SuperAdmin'] },
    { label: 'Finance', path: '/finance/dashboard', roles: ['FinanceManager', 'Admin', 'SuperAdmin'] },
    { label: 'Support', path: '/support/tickets', roles: ['SupportManager', 'SupportAgent', 'Admin', 'SuperAdmin'] },
    { label: 'Shipping', path: '/operations/dashboard', roles: ['WarehouseManager', 'DeliveryManager', 'DeliveryPartner', 'Admin', 'SuperAdmin'] }
  ];

  constructor(
    private readonly auth: AuthService,
    private readonly errors: ErrorMessageService,
    private readonly router: Router
  ) {}

  login(): void {
    this.busy.set(true);
    this.message.set('');
    this.auth.login(this.email, this.password).subscribe({
      next: () => {
        this.finish('Signed in.');
        void this.router.navigateByUrl(this.auth.defaultDashboardPath());
      },
      error: (error) => this.fail(error)
    });
  }

  register(): void {
    this.busy.set(true);
    this.message.set('');
    this.auth.register(this.fullName, this.email, this.password).subscribe({
      next: () => {
        this.finish('Account created.');
        void this.router.navigateByUrl(this.auth.defaultDashboardPath());
      },
      error: (error) => this.fail(error)
    });
  }

  logout(): void {
    this.auth.logout();
    this.message.set('');
    void this.router.navigateByUrl('/');
  }

  visibleNavItems(): NavItem[] {
    const session = this.session();
    if (!session) {
      return [];
    }

    return this.navItems.filter((item) => this.auth.hasAnyRole(item.roles));
  }

  private finish(message: string): void {
    this.busy.set(false);
    this.message.set(message);
  }

  private fail(error: unknown): void {
    this.busy.set(false);
    this.message.set(this.errors.from(error));
  }
}
