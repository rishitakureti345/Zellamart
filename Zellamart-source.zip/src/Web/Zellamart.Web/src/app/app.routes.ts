import { Routes } from '@angular/router';
import { AppShellComponent } from './layout/app-shell/app-shell.component';
import { AdminFinanceComponent } from './features/finance/admin-finance/admin-finance.component';
import { SellerFinanceComponent } from './features/finance/seller-finance/seller-finance.component';
import { CustomerDashboardComponent } from './features/operations/customer-dashboard/customer-dashboard.component';
import { ShippingDashboardComponent } from './features/operations/shipping-dashboard/shipping-dashboard.component';
import { SupportDashboardComponent } from './features/operations/support-dashboard/support-dashboard.component';
import { roleGuard } from './core/guards/role.guard';
import { HomeDashboardComponent } from './features/home/home-dashboard.component';
import { StorefrontLayoutComponent } from './public/layout/storefront-layout.component';
import { HomePageComponent } from './public/home/home-page.component';
import { ProductListPageComponent } from './public/products/product-list-page.component';
import { ProductDetailPageComponent } from './public/products/product-detail-page.component';
import { LoginPageComponent } from './auth/login-page.component';
import { RegisterPageComponent } from './auth/register-page.component';
import { CustomerLayoutComponent } from './customer/layout/customer-layout.component';
import { CustomerOverviewComponent } from './customer/dashboard/customer-overview.component';
import { CustomerProfileComponent } from './customer/profile/customer-profile.component';
import { CartPageComponent } from './customer/cart/cart-page.component';
import { CheckoutPageComponent } from './customer/checkout/checkout-page.component';
import { PaymentPageComponent } from './customer/payment/payment-page.component';
import { CustomerOrdersPageComponent } from './customer/orders/customer-orders-page.component';
import { OrderDetailPageComponent } from './customer/orders/order-detail-page.component';
import { CustomerShipmentsPageComponent } from './customer/shipments/customer-shipments-page.component';
import { CustomerShipmentDetailPageComponent } from './customer/shipments/customer-shipment-detail-page.component';
import { CustomerSupportPageComponent } from './customer/support/customer-support-page.component';
import { CustomerSupportDetailPageComponent } from './customer/support/customer-support-detail-page.component';
import { CustomerReturnsPageComponent } from './customer/returns/customer-returns-page.component';
import { NewReturnPageComponent } from './customer/returns/new-return-page.component';
import { ReturnDetailPageComponent } from './customer/returns/return-detail-page.component';
import { CustomerNotificationsPageComponent } from './customer/notifications/customer-notifications-page.component';
import { SellerLayoutComponent } from './seller/layout/seller-layout.component';
import { SellerDashboardComponent } from './seller/pages/seller-dashboard.component';
import { SellerApplyComponent } from './seller/pages/seller-apply.component';
import { SellerProfileComponent } from './seller/pages/seller-profile.component';
import { SellerProductsComponent } from './seller/pages/seller-products.component';
import { SellerProductNewComponent } from './seller/pages/seller-product-new.component';
import { SellerInventoryComponent } from './seller/pages/seller-inventory.component';
import { SellerOrdersComponent } from './seller/pages/seller-orders.component';
import { SellerEarningsComponent } from './seller/pages/seller-earnings.component';
import { SellerPayoutsComponent } from './seller/pages/seller-payouts.component';
import { AdminLayoutComponent } from './admin/layout/admin-layout.component';
import { AdminDashboardComponent } from './admin/pages/admin-dashboard.component';
import { AdminSellersComponent } from './admin/pages/admin-sellers.component';
import { AdminProductsComponent } from './admin/pages/admin-products.component';
import { AdminCategoriesComponent } from './admin/pages/admin-categories.component';
import { AdminUsersComponent } from './admin/pages/admin-users.component';
import { AdminOrdersComponent } from './admin/pages/admin-orders.component';
import { AdminInventoryComponent } from './admin/pages/admin-inventory.component';
import { AdminShippingComponent } from './admin/pages/admin-shipping.component';
import { AdminSupportComponent } from './admin/pages/admin-support.component';
import { AdminReturnsComponent } from './admin/pages/admin-returns.component';
import { AdminNotificationsComponent } from './admin/pages/admin-notifications.component';
import { AdminReportsComponent } from './admin/pages/admin-reports.component';
import { AdminAuditLogsComponent } from './admin/pages/admin-audit-logs.component';
import { AdminSettingsComponent } from './admin/pages/admin-settings.component';
import { AdminProfileComponent } from './admin/pages/admin-profile.component';
import { AdminPlaceholderComponent } from './admin/pages/admin-placeholder.component';
import { OperationsLayoutComponent } from './operations/layout/operations-layout.component';
import { OperationsDashboardComponent } from './operations/pages/operations-dashboard.component';
import { PackingPageComponent } from './operations/pages/packing-page.component';
import { DeliveryPageComponent } from './operations/pages/delivery-page.component';
import { OperationsShipmentsPageComponent } from './operations/pages/operations-shipments-page.component';
import { OperationsInventoryPageComponent } from './operations/pages/operations-inventory-page.component';
import { SupportLayoutComponent } from './support/layout/support-layout.component';
import { SupportTicketsPageComponent } from './support/pages/support-tickets-page.component';
import { SupportTicketDetailPageComponent } from './support/pages/support-ticket-detail-page.component';
import { SupportReturnsPageComponent } from './support/pages/support-returns-page.component';
import { FinanceLayoutComponent } from './finance/layout/finance-layout.component';
import { FinanceDashboardComponent } from './finance/pages/finance-dashboard.component';
import { FinanceSellerBalancesComponent } from './finance/pages/finance-seller-balances.component';
import { FinancePayoutsComponent } from './finance/pages/finance-payouts.component';
import { FinanceTransactionsComponent } from './finance/pages/finance-transactions.component';
import { FinanceRefundsComponent } from './finance/pages/finance-refunds.component';
import { SuperAdminLayoutComponent } from './superadmin/layout/superadmin-layout.component';
import { SuperAdminDashboardComponent } from './superadmin/pages/superadmin-dashboard.component';
import { SuperAdminProfileComponent } from './superadmin/pages/superadmin-profile.component';
import { SuperAdminUsersComponent } from './superadmin/pages/superadmin-users.component';
import { SuperAdminRolesComponent } from './superadmin/pages/superadmin-roles.component';
import { SuperAdminMarketplaceComponent } from './superadmin/pages/superadmin-marketplace.component';
import { SuperAdminFinanceComponent } from './superadmin/pages/superadmin-finance.component';
import { SuperAdminOperationsComponent } from './superadmin/pages/superadmin-operations.component';
import { SuperAdminAuditComponent } from './superadmin/pages/superadmin-audit.component';
import { SuperAdminSettingsComponent } from './superadmin/pages/superadmin-settings.component';

export const routes: Routes = [
  { path: 'login', component: LoginPageComponent, title: 'Login' },
  { path: 'register', component: RegisterPageComponent, title: 'Register' },
  {
    path: '',
    component: StorefrontLayoutComponent,
    children: [
      { path: '', component: HomePageComponent, title: 'Zellamart marketplace' },
      { path: 'products', component: ProductListPageComponent, title: 'Shop products' },
      { path: 'products/:productId', component: ProductDetailPageComponent, title: 'Product detail' },
      { path: 'categories/:categoryId', component: ProductListPageComponent, title: 'Shop category' },
      {
        path: 'cart',
        component: CartPageComponent,
        canActivate: [roleGuard],
        data: { roles: ['Customer', 'Admin', 'SuperAdmin'] },
        title: 'Cart'
      },
      {
        path: 'checkout',
        component: CheckoutPageComponent,
        canActivate: [roleGuard],
        data: { roles: ['Customer', 'Admin', 'SuperAdmin'] },
        title: 'Checkout'
      },
      {
        path: 'payment/:orderId',
        component: PaymentPageComponent,
        canActivate: [roleGuard],
        data: { roles: ['Customer', 'Admin', 'SuperAdmin'] },
        title: 'Payment'
      }
    ]
  },
  {
    path: 'customer',
    component: CustomerLayoutComponent,
    canActivate: [roleGuard],
    data: { roles: ['Customer', 'Admin', 'SuperAdmin'] },
    children: [
      { path: '', pathMatch: 'full', redirectTo: 'dashboard' },
      { path: 'dashboard', component: CustomerOverviewComponent, title: 'Customer dashboard' },
      { path: 'profile', component: CustomerProfileComponent, title: 'Customer profile' },
      { path: 'orders', component: CustomerOrdersPageComponent, title: 'Customer orders' },
      { path: 'orders/:orderId', component: OrderDetailPageComponent, title: 'Order detail' },
      { path: 'shipments', component: CustomerShipmentsPageComponent, title: 'Shipments' },
      { path: 'shipments/:orderId', component: CustomerShipmentDetailPageComponent, title: 'Shipment tracking' },
      { path: 'support', component: CustomerSupportPageComponent, title: 'Support tickets' },
      { path: 'support/:ticketId', component: CustomerSupportDetailPageComponent, title: 'Support ticket' },
      { path: 'returns', component: CustomerReturnsPageComponent, title: 'Returns' },
      { path: 'returns/new', component: NewReturnPageComponent, title: 'Request return' },
      { path: 'returns/:returnId', component: ReturnDetailPageComponent, title: 'Return detail' },
      { path: 'notifications', component: CustomerNotificationsPageComponent, title: 'Notifications' }
    ]
  },
  {
    path: 'seller',
    component: SellerLayoutComponent,
    canActivate: [roleGuard],
    data: { roles: ['Seller', 'Customer', 'SuperAdmin'] },
    children: [
      { path: '', pathMatch: 'full', redirectTo: 'dashboard' },
      { path: 'dashboard', component: SellerDashboardComponent, canActivate: [roleGuard], data: { roles: ['Seller', 'SuperAdmin'] }, title: 'Seller dashboard' },
      { path: 'apply', component: SellerApplyComponent, title: 'Apply as seller' },
      { path: 'profile', component: SellerProfileComponent, canActivate: [roleGuard], data: { roles: ['Seller', 'SuperAdmin'] }, title: 'Seller profile' },
      { path: 'products', component: SellerProductsComponent, canActivate: [roleGuard], data: { roles: ['Seller', 'SuperAdmin'] }, title: 'Seller products' },
      { path: 'products/new', component: SellerProductNewComponent, canActivate: [roleGuard], data: { roles: ['Seller', 'SuperAdmin'] }, title: 'New seller product' },
      { path: 'inventory', component: SellerInventoryComponent, canActivate: [roleGuard], data: { roles: ['Seller', 'SuperAdmin'] }, title: 'Seller inventory' },
      { path: 'orders', component: SellerOrdersComponent, canActivate: [roleGuard], data: { roles: ['Seller', 'SuperAdmin'] }, title: 'Seller orders' },
      { path: 'earnings', component: SellerEarningsComponent, canActivate: [roleGuard], data: { roles: ['Seller', 'SuperAdmin'] }, title: 'Seller earnings' },
      { path: 'payouts', component: SellerPayoutsComponent, canActivate: [roleGuard], data: { roles: ['Seller', 'SuperAdmin'] }, title: 'Seller payouts' }
    ]
  },
  {
    path: 'superadmin',
    component: SuperAdminLayoutComponent,
    canActivate: [roleGuard],
    data: { roles: ['SuperAdmin'] },
    children: [
      { path: '', pathMatch: 'full', redirectTo: 'dashboard' },
      { path: 'dashboard', component: SuperAdminDashboardComponent, title: 'SuperAdmin dashboard' },
      { path: 'profile', component: SuperAdminProfileComponent, title: 'SuperAdmin profile' },
      { path: 'users', component: SuperAdminUsersComponent, title: 'SuperAdmin users' },
      { path: 'roles', component: SuperAdminRolesComponent, title: 'SuperAdmin roles' },
      { path: 'marketplace', component: SuperAdminMarketplaceComponent, title: 'SuperAdmin marketplace' },
      { path: 'finance', component: SuperAdminFinanceComponent, title: 'SuperAdmin finance' },
      { path: 'operations', component: SuperAdminOperationsComponent, title: 'SuperAdmin operations' },
      { path: 'audit', component: SuperAdminAuditComponent, title: 'SuperAdmin audit logs' },
      { path: 'settings', component: SuperAdminSettingsComponent, title: 'SuperAdmin settings' }
    ]
  },
  {
    path: 'admin',
    component: AdminLayoutComponent,
    canActivate: [roleGuard],
    data: { roles: ['Admin', 'SuperAdmin'] },
    children: [
      { path: '', pathMatch: 'full', redirectTo: 'dashboard' },
      { path: 'dashboard', component: AdminDashboardComponent, title: 'Admin dashboard' },
      { path: 'sellers', component: AdminSellersComponent, title: 'Seller approvals' },
      { path: 'products', component: AdminProductsComponent, title: 'Product approvals' },
      { path: 'categories', component: AdminCategoriesComponent, title: 'Category management' },
      { path: 'reports', component: AdminReportsComponent, title: 'Admin reports' },
      { path: 'profile', component: AdminProfileComponent, title: 'Admin profile' },
      { path: 'users', component: AdminUsersComponent, title: 'Users and roles' },
      { path: 'orders', component: AdminOrdersComponent, title: 'Order management' },
      { path: 'inventory', component: AdminInventoryComponent, title: 'Inventory monitoring' },
      { path: 'shipping', component: AdminShippingComponent, title: 'Shipping operations' },
      { path: 'support', component: AdminSupportComponent, title: 'Support management' },
      { path: 'returns', component: AdminReturnsComponent, title: 'Returns and refunds' },
      { path: 'notifications', component: AdminNotificationsComponent, title: 'Notifications' },
      { path: 'audit-logs', component: AdminAuditLogsComponent, title: 'Audit logs' },
      { path: 'settings', component: AdminSettingsComponent, title: 'Marketplace settings' }
    ]
  },
  {
    path: 'operations',
    component: OperationsLayoutComponent,
    canActivate: [roleGuard],
    data: { roles: ['WarehouseManager', 'InventoryStaff', 'DeliveryManager', 'DeliveryPartner', 'OrderManager', 'Admin', 'SuperAdmin'] },
    children: [
      { path: '', pathMatch: 'full', redirectTo: 'dashboard' },
      { path: 'dashboard', component: OperationsDashboardComponent, title: 'Operations dashboard' },
      { path: 'packing', component: PackingPageComponent, title: 'Packing' },
      { path: 'shipments', component: OperationsShipmentsPageComponent, title: 'Operations shipments' },
      { path: 'inventory', component: OperationsInventoryPageComponent, title: 'Operations inventory' },
      { path: 'delivery', component: DeliveryPageComponent, title: 'Delivery' }
    ]
  },
  {
    path: 'support',
    component: SupportLayoutComponent,
    canActivate: [roleGuard],
    data: { roles: ['SupportManager', 'SupportAgent', 'Admin', 'SuperAdmin'] },
    children: [
      { path: '', pathMatch: 'full', redirectTo: 'tickets' },
      { path: 'tickets', component: SupportTicketsPageComponent, title: 'Support tickets' },
      { path: 'tickets/:ticketId', component: SupportTicketDetailPageComponent, title: 'Support ticket' },
      { path: 'returns', component: SupportReturnsPageComponent, title: 'Support returns' }
    ]
  },
  {
    path: 'finance',
    component: FinanceLayoutComponent,
    canActivate: [roleGuard],
    data: { roles: ['FinanceManager', 'PaymentTeam', 'Admin', 'SuperAdmin'] },
    children: [
      { path: '', pathMatch: 'full', redirectTo: 'dashboard' },
      { path: 'dashboard', component: FinanceDashboardComponent, title: 'Finance dashboard' },
      { path: 'seller-balances', component: FinanceSellerBalancesComponent, title: 'Seller balances' },
      { path: 'payouts', component: FinancePayoutsComponent, title: 'Payout approvals' },
      { path: 'transactions', component: FinanceTransactionsComponent, title: 'Finance transactions' },
      { path: 'refunds', component: FinanceRefundsComponent, title: 'Finance refunds' }
    ]
  },
  {
    path: '',
    component: AppShellComponent,
    children: [
      { path: 'home', component: HomeDashboardComponent, title: 'Zellamart dashboards' },
      { path: 'customer-old', component: CustomerDashboardComponent, title: 'Customer operations' },
      { path: 'seller-old', component: SellerFinanceComponent, title: 'Seller finance' },
      { path: 'admin-old', component: AdminFinanceComponent, title: 'Admin finance' },
      {
        path: 'finance-old',
        component: AdminFinanceComponent,
        canActivate: [roleGuard],
        data: { roles: ['FinanceManager', 'Admin', 'SuperAdmin'] },
        title: 'Finance dashboard'
      },
      {
        path: 'support-old',
        component: SupportDashboardComponent,
        canActivate: [roleGuard],
        data: { roles: ['Customer', 'SupportManager', 'SupportAgent', 'Admin', 'SuperAdmin'] },
        title: 'Support dashboard'
      },
      {
        path: 'shipping',
        component: ShippingDashboardComponent,
        canActivate: [roleGuard],
        data: { roles: ['Customer', 'WarehouseManager', 'DeliveryManager', 'DeliveryPartner', 'Admin', 'SuperAdmin'] },
        title: 'Shipping dashboard'
      }
    ]
  },
  { path: '**', redirectTo: '' }
];
