import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { catchError, finalize, forkJoin, of } from 'rxjs';
import { CatalogApiService } from '../services/catalog-api.service';
import { InventoryReadApiService } from '../services/inventory-read-api.service';
import { Product } from '../models/catalog.model';
import { InventoryItem } from '../models/inventory.model';
import { CartApiService } from '../../customer/services/cart-api.service';
import { AuthService } from '../../core/services/auth.service';
import { ErrorMessageService } from '../../core/services/error-message.service';
import { EmptyStateComponent } from '../../shared/components/empty-state/empty-state.component';
import { LoadingSkeletonComponent } from '../../shared/components/loading-skeleton/loading-skeleton.component';
import { ToastComponent } from '../../shared/components/toast/toast.component';
import { formatMoney } from '../../shared/utils/currency';

@Component({
  selector: 'app-product-detail-page',
  standalone: true,
  imports: [CommonModule, RouterLink, EmptyStateComponent, LoadingSkeletonComponent, ToastComponent],
  template: `
    <app-loading-skeleton *ngIf="loading()" [rows]="4"></app-loading-skeleton>
    <app-toast [message]="message()"></app-toast>

    <article class="product-detail" *ngIf="!loading() && product() as item">
      <div class="detail-media">
        <img *ngIf="item.imageUrl; else fallback" [src]="item.imageUrl" [alt]="item.name">
        <ng-template #fallback><span>{{ item.name.slice(0, 2).toUpperCase() }}</span></ng-template>
      </div>
      <div class="detail-copy">
        <a routerLink="/products" class="back-link">Back to products</a>
        <span class="eyebrow">Approved product</span>
        <h1>{{ item.name }}</h1>
        <p>{{ item.description }}</p>
        <strong class="detail-price">{{ money(item.price, item.currency) }}</strong>
        <p class="stock-chip detail-stock" [class.out]="stock()?.availableQuantity === 0">{{ stockLabel() }}</p>
        <div class="detail-actions">
          <button type="button" [disabled]="stock()?.availableQuantity === 0" (click)="addToCart(item)">Add to cart</button>
          <a routerLink="/products">Continue shopping</a>
        </div>
        <dl class="detail-meta">
          <div><dt>Product ID</dt><dd>{{ item.id }}</dd></div>
          <div><dt>Seller ID</dt><dd>{{ item.sellerId }}</dd></div>
          <div><dt>Status</dt><dd>{{ item.status }}</dd></div>
          <div><dt>Available stock</dt><dd>{{ stock()?.availableQuantity ?? 'Sign in as customer to view' }}</dd></div>
        </dl>
      </div>
    </article>

    <app-empty-state *ngIf="!loading() && !product()" title="Product not found" message="This product may not be approved or may have been removed."></app-empty-state>
  `
})
export class ProductDetailPageComponent implements OnInit {
  readonly product = signal<Product | null>(null);
  readonly stock = signal<InventoryItem | null>(null);
  readonly loading = signal(true);
  readonly message = signal('');
  money = formatMoney;

  constructor(
    private readonly catalog: CatalogApiService,
    private readonly inventory: InventoryReadApiService,
    private readonly cart: CartApiService,
    private readonly auth: AuthService,
    private readonly errors: ErrorMessageService,
    private readonly route: ActivatedRoute
  ) {}

  ngOnInit(): void {
    const productId = this.route.snapshot.paramMap.get('productId');
    if (!productId) {
      this.loading.set(false);
      return;
    }

    forkJoin({
      product: this.catalog.getProduct(productId),
      stock: this.auth.session()
        ? this.inventory.getByProduct(productId).pipe(catchError(() => of(null)))
        : of(null)
    })
      .pipe(finalize(() => this.loading.set(false)))
      .subscribe({
        next: (result) => {
          this.product.set(result.product);
          this.stock.set(result.stock);
        },
        error: () => this.message.set('Could not load this product.')
      });
  }

  addToCart(product: Product): void {
    if (!this.auth.session()) {
      this.message.set('Sign in as a customer to add products to cart.');
      return;
    }

    if (this.stock()?.availableQuantity === 0) {
      this.message.set('This product is out of stock.');
      return;
    }

    this.cart.addProduct(product).subscribe({
      next: () => this.message.set(`${product.name} added to cart.`),
      error: (error) => this.message.set(this.errors.from(error))
    });
  }

  stockLabel(): string {
    const currentStock = this.stock();
    if (!this.auth.session()) {
      return 'Sign in as customer to view stock';
    }

    if (!currentStock) {
      return 'Stock not available yet';
    }

    if (currentStock.availableQuantity <= 0) {
      return 'Out of stock';
    }

    return `${currentStock.availableQuantity} available`;
  }
}
