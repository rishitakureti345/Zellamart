import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { catchError, combineLatest, finalize, forkJoin, of, switchMap } from 'rxjs';
import { CatalogApiService } from '../services/catalog-api.service';
import { InventoryReadApiService } from '../services/inventory-read-api.service';
import { Category, Product } from '../models/catalog.model';
import { InventoryItem } from '../models/inventory.model';
import { CartApiService } from '../../customer/services/cart-api.service';
import { AuthService } from '../../core/services/auth.service';
import { ErrorMessageService } from '../../core/services/error-message.service';
import { ProductCardComponent } from '../../shared/components/product-card/product-card.component';
import { LoadingSkeletonComponent } from '../../shared/components/loading-skeleton/loading-skeleton.component';
import { EmptyStateComponent } from '../../shared/components/empty-state/empty-state.component';
import { ToastComponent } from '../../shared/components/toast/toast.component';

@Component({
  selector: 'app-product-list-page',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    RouterLink,
    ProductCardComponent,
    LoadingSkeletonComponent,
    EmptyStateComponent,
    ToastComponent
  ],
  template: `
    <section class="catalog-header">
      <div>
        <span class="eyebrow">Catalog</span>
        <h1>{{ activeCategoryName() || 'All products' }}</h1>
        <p>Browse approved products from Zellamart sellers.</p>
      </div>
      <form class="catalog-search" (ngSubmit)="applySearch()">
        <input [(ngModel)]="search" name="search" placeholder="Search catalog">
        <button type="submit">Search</button>
      </form>
    </section>

    <app-toast [message]="message()"></app-toast>

    <div class="catalog-layout">
      <aside class="filters surface">
        <strong>Categories</strong>
        <a routerLink="/products" [class.active-filter]="!categoryId()">All products</a>
        <a *ngFor="let category of categories()" [routerLink]="['/categories', category.id]" [class.active-filter]="category.id === categoryId()">
          {{ category.name }}
        </a>
      </aside>

      <section>
        <app-loading-skeleton *ngIf="loading()" [rows]="6"></app-loading-skeleton>
        <div class="product-grid" *ngIf="!loading() && products().length">
          <app-product-card
            *ngFor="let product of products()"
            [product]="product"
            [stock]="stockFor(product.id)"
            (add)="addToCart($event)">
          </app-product-card>
        </div>
        <app-empty-state *ngIf="!loading() && !products().length" title="No matching products" message="Try another search or category."></app-empty-state>
      </section>
    </div>
  `
})
export class ProductListPageComponent implements OnInit {
  search = '';
  readonly products = signal<Product[]>([]);
  readonly categories = signal<Category[]>([]);
  readonly stockByProduct = signal<Record<string, InventoryItem | null>>({});
  readonly categoryId = signal<string | null>(null);
  readonly activeCategoryName = signal('');
  readonly loading = signal(true);
  readonly message = signal('');

  constructor(
    private readonly catalog: CatalogApiService,
    private readonly inventory: InventoryReadApiService,
    private readonly cart: CartApiService,
    private readonly auth: AuthService,
    private readonly errors: ErrorMessageService,
    private readonly route: ActivatedRoute,
    private readonly router: Router
  ) {}

  ngOnInit(): void {
    this.catalog.getCategories().subscribe((categories) => {
      this.categories.set(categories);
      this.syncActiveCategory();
    });

    combineLatest([this.route.paramMap, this.route.queryParamMap]).pipe(
      switchMap(([params, query]) => {
        this.loading.set(true);
        this.categoryId.set(params.get('categoryId'));
        this.search = query.get('search') ?? '';
        this.syncActiveCategory();
        return this.catalog.getProducts(this.categoryId(), this.search).pipe(finalize(() => this.loading.set(false)));
      })
    ).subscribe({
      next: (products) => {
        this.products.set(products);
        this.loadStock(products);
      },
      error: () => this.message.set('Could not load catalog.')
    });
  }

  applySearch(): void {
    const commands = this.categoryId() ? ['/categories', this.categoryId()] : ['/products'];
    void this.router.navigate(commands, { queryParams: { search: this.search || null } });
  }

  addToCart(product: Product): void {
    if (!this.auth.session()) {
      this.message.set('Sign in as a customer to add products to cart.');
      return;
    }

    const stock = this.stockFor(product.id);
    if (stock && stock.availableQuantity <= 0) {
      this.message.set('This product is out of stock.');
      return;
    }

    this.cart.addProduct(product).subscribe({
      next: () => this.message.set(`${product.name} added to cart.`),
      error: (error) => this.message.set(this.errors.from(error))
    });
  }

  stockFor(productId: string): InventoryItem | null | undefined {
    return this.stockByProduct()[productId];
  }

  private syncActiveCategory(): void {
    const category = this.categories().find((item) => item.id === this.categoryId());
    this.activeCategoryName.set(category?.name ?? '');
  }

  private loadStock(products: Product[]): void {
    this.stockByProduct.set({});
    if (!this.auth.session() || !products.length) {
      return;
    }

    const requests = products.map((product) =>
      this.inventory.getByProduct(product.id).pipe(catchError(() => of(null)))
    );

    forkJoin(requests).subscribe((items) => {
      const nextStock = products.reduce<Record<string, InventoryItem | null>>((acc, product, index) => {
        acc[product.id] = items[index];
        return acc;
      }, {});

      this.stockByProduct.set(nextStock);
    });
  }
}
