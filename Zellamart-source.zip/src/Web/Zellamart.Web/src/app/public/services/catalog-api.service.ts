import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { map, Observable } from 'rxjs';
import { ApiResult } from '../../core/models/api-result.model';
import { Category, Product } from '../models/catalog.model';

@Injectable({ providedIn: 'root' })
export class CatalogApiService {
  constructor(private readonly http: HttpClient) {}

  getCategories(): Observable<Category[]> {
    return this.http
      .get<ApiResult<Category[]>>('/api/categories')
      .pipe(map((result) => result.value ?? []));
  }

  getProducts(categoryId?: string | null, search?: string | null): Observable<Product[]> {
    let params = new HttpParams();
    if (categoryId) {
      params = params.set('categoryId', categoryId);
    }

    if (search?.trim()) {
      params = params.set('search', search.trim());
    }

    return this.http
      .get<ApiResult<Product[]>>('/api/products', { params })
      .pipe(map((result) => result.value ?? []));
  }

  getProduct(productId: string): Observable<Product> {
    return this.http
      .get<ApiResult<Product>>(`/api/products/${productId}`)
      .pipe(map((result) => result.value));
  }
}
