import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { map, Observable } from 'rxjs';
import { ApiResult } from '../../core/models/api-result.model';
import { InventoryItem } from '../models/inventory.model';

@Injectable({ providedIn: 'root' })
export class InventoryReadApiService {
  constructor(private readonly http: HttpClient) {}

  getByProduct(productId: string): Observable<InventoryItem> {
    return this.http
      .get<ApiResult<InventoryItem>>(`/api/inventory/product/${productId}`)
      .pipe(map((result) => result.value));
  }
}
