import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { StoreNavbarComponent } from '../../shared/components/store-navbar/store-navbar.component';

@Component({
  selector: 'app-storefront-layout',
  standalone: true,
  imports: [RouterOutlet, StoreNavbarComponent],
  template: `
    <app-store-navbar></app-store-navbar>
    <main class="store-main">
      <router-outlet></router-outlet>
    </main>
  `
})
export class StorefrontLayoutComponent {}
