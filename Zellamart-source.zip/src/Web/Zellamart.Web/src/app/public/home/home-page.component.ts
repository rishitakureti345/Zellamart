import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { finalize } from 'rxjs';
import { CatalogApiService } from '../services/catalog-api.service';
import { Category, Product } from '../models/catalog.model';
import { CartApiService } from '../../customer/services/cart-api.service';
import { AuthService } from '../../core/services/auth.service';
import { ErrorMessageService } from '../../core/services/error-message.service';
import { ProductCardComponent } from '../../shared/components/product-card/product-card.component';
import { LoadingSkeletonComponent } from '../../shared/components/loading-skeleton/loading-skeleton.component';
import { EmptyStateComponent } from '../../shared/components/empty-state/empty-state.component';
import { ToastComponent } from '../../shared/components/toast/toast.component';

@Component({
  selector: 'app-home-page',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    RouterLink,
    ProductCardComponent,
    LoadingSkeletonComponent,
    EmptyStateComponent,
    ToastComponent
  ],
  template: `
    <div class="announcement">Free delivery over ₹999 <span>•</span> Easy 7-day returns <span>•</span> Verified independent sellers</div>
    <section class="hero">
      <div class="hero-copy">
        <span class="eyebrow">The independent edit · 2026</span>
        <h1>Good finds.<br><em>Better stories.</em></h1>
        <p>Thoughtful fashion, home and everyday essentials from independent sellers—all reviewed, protected and delivered through one modern marketplace.</p>
        <form class="hero-search" (ngSubmit)="searchProducts()">
          <input [(ngModel)]="search" name="search" placeholder="What are you looking for?">
          <button type="submit">Explore →</button>
        </form>
        <div class="hero-proof"><span><b>120+</b> independent sellers</span><span><b>4.8/5</b> shopper rating</span></div>
      </div>
      <div class="hero-visual" aria-label="Featured shopping preview">
        <div class="hero-card large"><span class="product-kicker">THE WEEKEND EDIT</span><strong>Objects for slower, better days.</strong><a routerLink="/products">Shop the collection ↗</a></div>
        <div class="hero-card small-one"><span>New maker</span><strong>Terra Studio</strong></div>
        <div class="hero-card small-two"><span>Trending</span><strong>Everyday carry</strong></div>
      </div>
    </section>

    <app-toast [message]="message()"></app-toast>

    <section class="store-section">
      <div class="section-heading">
        <div>
          <span class="eyebrow">Find your thing</span>
          <h2>Shop by mood</h2>
        </div>
        <a routerLink="/products">View all products</a>
      </div>
      <div class="category-grid" *ngIf="categories().length">
        <a class="category-tile" *ngFor="let category of categories()" [routerLink]="['/categories', category.id]">
          <strong>{{ category.name }}</strong>
          <span>{{ category.description || 'Explore approved products' }}</span>
        </a>
      </div>
    </section>

    <section class="store-section">
      <div class="section-heading">
        <div>
          <span class="eyebrow">Curated this week</span>
          <h2>Fresh from the marketplace</h2>
        </div>
      </div>
      <app-loading-skeleton *ngIf="loading()" [rows]="4"></app-loading-skeleton>
      <div class="product-grid" *ngIf="!loading() && featuredProducts().length">
        <app-product-card *ngFor="let product of featuredProducts()" [product]="product" (add)="addToCart($event)"></app-product-card>
      </div>
    </section>

    <section class="seller-cta">
      <div>
        <span class="eyebrow">For independent brands</span>
        <h2>Your products deserve more than a listing. Build your next chapter on Zellamart.</h2>
      </div>
      <a routerLink="/seller">Start selling ↗</a>
    </section>

    <section class="trust-strip" aria-label="Service promises">
      <span>✓ Verified sellers</span>
      <span>⌁ Secure checkout</span>
      <span>◎ Live order tracking</span>
      <span>↺ Human-first support</span>
    </section>
  `
})
export class HomePageComponent implements OnInit {
  search = '';
  readonly categories = signal<Category[]>([]);
  readonly featuredProducts = signal<Product[]>([]);
  readonly loading = signal(true);
  readonly message = signal('');

  constructor(
    private readonly catalog: CatalogApiService,
    private readonly cart: CartApiService,
    private readonly auth: AuthService,
    private readonly errors: ErrorMessageService,
    private readonly router: Router
  ) {}

  ngOnInit(): void {
    this.categories.set(this.demoCategories);
    this.featuredProducts.set(this.demoProducts);
    this.catalog.getCategories().subscribe({ next: (categories) => categories.length && this.categories.set(categories.slice(0, 6)) });
    this.catalog.getProducts()
      .pipe(finalize(() => this.loading.set(false)))
      .subscribe({
        next: (products) => products.length && this.featuredProducts.set(products.slice(0, 8)),
        error: () => undefined
      });
  }

  searchProducts(): void {
    void this.router.navigate(['/products'], { queryParams: { search: this.search || null } });
  }

  addToCart(product: Product): void {
    if (!this.auth.session()) {
      this.message.set('Sign in as a customer to add products to cart.');
      return;
    }

    this.cart.addProduct(product).subscribe({
      next: () => this.message.set(`${product.name} added to cart.`),
      error: (error) => this.message.set(this.errors.from(error))
    });
  }

  featuredTitle(): string {
    return this.featuredProducts().at(0)?.name ?? 'Approved catalog';
  }

  private readonly demoCategories: Category[] = [
    { id: 'style', name: 'Wear it well', slug: 'style', description: 'Small-run fashion with personality', isActive: true },
    { id: 'home', name: 'Home, considered', slug: 'home', description: 'Useful objects for beautiful spaces', isActive: true },
    { id: 'care', name: 'Ritual & care', slug: 'care', description: 'Everyday wellness, thoughtfully made', isActive: true },
    { id: 'carry', name: 'Take it with you', slug: 'carry', description: 'Bags, stationery and daily essentials', isActive: true },
    { id: 'gifts', name: 'Gifts with meaning', slug: 'gifts', description: 'Memorable finds for favourite people', isActive: true },
    { id: 'new', name: 'Just landed', slug: 'new', description: 'The newest independent arrivals', isActive: true }
  ];

  private readonly demoProducts: Product[] = [
    { id: 'linen-set', sellerId: 'demo', categoryId: 'style', name: 'Weekend Linen Set', slug: 'weekend-linen-set', description: 'Easy tailoring in breathable natural linen.', price: 3490, currency: 'INR', imageUrl: null, status: 'Approved' },
    { id: 'ceramic-set', sellerId: 'demo', categoryId: 'home', name: 'Terra Cup Pair', slug: 'terra-cup-pair', description: 'Hand-finished stoneware for slow mornings.', price: 1280, currency: 'INR', imageUrl: null, status: 'Approved' },
    { id: 'carry-tote', sellerId: 'demo', categoryId: 'carry', name: 'Market Day Tote', slug: 'market-day-tote', description: 'A structured everyday bag in heavy canvas.', price: 1890, currency: 'INR', imageUrl: null, status: 'Approved' },
    { id: 'ritual-oil', sellerId: 'demo', categoryId: 'care', name: 'After Hours Body Oil', slug: 'after-hours-oil', description: 'A warm botanical blend for evening rituals.', price: 940, currency: 'INR', imageUrl: null, status: 'Approved' }
  ];
}
