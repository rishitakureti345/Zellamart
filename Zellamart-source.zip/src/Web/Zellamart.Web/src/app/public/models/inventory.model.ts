export interface InventoryItem {
  id: string;
  productId: string;
  sellerId: string;
  sku: string;
  quantityOnHand: number;
  reservedQuantity: number;
  availableQuantity: number;
}
