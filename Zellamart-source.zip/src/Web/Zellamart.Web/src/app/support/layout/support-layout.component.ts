import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterOutlet } from '@angular/router';
import { StoreNavbarComponent } from '../../shared/components/store-navbar/store-navbar.component';
import { DashboardNavItem, DashboardSidebarComponent } from '../../shared/components/dashboard-sidebar/dashboard-sidebar.component';
import { AuthService } from '../../core/services/auth.service';
import { StatusBadgeComponent } from '../../shared/components/status-badge/status-badge.component';

@Component({
  selector: 'app-support-layout',
  standalone: true,
  imports: [CommonModule, RouterOutlet, StoreNavbarComponent, DashboardSidebarComponent, StatusBadgeComponent],
  template: `
    <app-store-navbar></app-store-navbar>
    <main class="seller-shell">
      <aside class="admin-sidebar">
        <section class="admin-identity" *ngIf="auth.session() as session">
          <span>Support workspace</span>
          <strong>{{ session.fullName }}</strong>
          <small>{{ session.email }}</small>
          <p class="badge-row">
            <app-status-badge *ngFor="let role of supportRoles()" [status]="role"></app-status-badge>
          </p>
        </section>
        <app-dashboard-sidebar [items]="items"></app-dashboard-sidebar>
      </aside>

      <section class="admin-workspace">
        <header class="admin-topbar" *ngIf="auth.session() as session">
          <div>
            <span class="eyebrow">Support center</span>
            <strong>{{ session.email }}</strong>
          </div>
          <button type="button" class="ghost-light" (click)="logout()">Logout</button>
        </header>

        <section class="seller-status-banner customer-status-banner">
          <div>
            <strong>Customer care queue</strong>
            <p>Review tickets, reply to customers, resolve issues, and process return requests from one shared workspace.</p>
          </div>
          <app-status-badge status="Support" label="Support"></app-status-badge>
        </section>

        <section class="dashboard-content"><router-outlet></router-outlet></section>
      </section>
    </main>
  `
})
export class SupportLayoutComponent {
  readonly items: DashboardNavItem[] = [
    { label: 'Tickets', path: '/support/tickets' },
    { label: 'Returns', path: '/support/returns' }
  ];

  constructor(
    readonly auth: AuthService,
    private readonly router: Router
  ) {}

  supportRoles(): string[] {
    return this.auth.roles().filter((role) => ['SupportManager', 'SupportAgent', 'Admin', 'SuperAdmin'].includes(role));
  }

  logout(): void {
    this.auth.logout();
    void this.router.navigateByUrl('/');
  }
}
