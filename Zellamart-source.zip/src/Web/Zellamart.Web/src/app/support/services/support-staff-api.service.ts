import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { map, Observable } from 'rxjs';
import { ApiResult } from '../../core/models/api-result.model';
import { ReturnRequest, SupportTicket } from '../../customer/models/support.model';

@Injectable({ providedIn: 'root' })
export class SupportStaffApiService {
  constructor(private readonly http: HttpClient) {}

  tickets(): Observable<SupportTicket[]> {
    return this.http.get<ApiResult<SupportTicket[]>>('/api/support/tickets/admin/all').pipe(map((result) => result.value ?? []));
  }

  ticket(ticketId: string): Observable<SupportTicket> {
    return this.http.get<ApiResult<SupportTicket>>(`/api/support/tickets/${ticketId}`).pipe(map((result) => result.value));
  }

  assignTicket(ticketId: string, agentId: string): Observable<SupportTicket> {
    return this.http.post<ApiResult<SupportTicket>>(`/api/support/tickets/${ticketId}/assign`, { agentId })
      .pipe(map((result) => result.value));
  }

  resolveTicket(ticketId: string): Observable<SupportTicket> {
    return this.http.post<ApiResult<SupportTicket>>(`/api/support/tickets/${ticketId}/resolve`, {}).pipe(map((result) => result.value));
  }

  rejectTicket(ticketId: string): Observable<SupportTicket> {
    return this.http.post<ApiResult<SupportTicket>>(`/api/support/tickets/${ticketId}/reject`, {}).pipe(map((result) => result.value));
  }

  replyTicket(ticketId: string, message: string): Observable<SupportTicket> {
    return this.http.post<ApiResult<SupportTicket>>(`/api/support/tickets/admin/${ticketId}/messages`, { message })
      .pipe(map((result) => result.value));
  }

  closeTicket(ticketId: string): Observable<SupportTicket> {
    return this.http.post<ApiResult<SupportTicket>>(`/api/support/tickets/admin/${ticketId}/close`, {}).pipe(map((result) => result.value));
  }

  returns(): Observable<ReturnRequest[]> {
    return this.http.get<ApiResult<ReturnRequest[]>>('/api/support/returns/admin/all').pipe(map((result) => result.value ?? []));
  }

  approveReturn(returnId: string): Observable<ReturnRequest> {
    return this.http.post<ApiResult<ReturnRequest>>(`/api/support/returns/${returnId}/approve`, {}).pipe(map((result) => result.value));
  }

  rejectReturn(returnId: string): Observable<ReturnRequest> {
    return this.http.post<ApiResult<ReturnRequest>>(`/api/support/returns/${returnId}/reject`, {}).pipe(map((result) => result.value));
  }

  markPickedUp(returnId: string): Observable<ReturnRequest> {
    return this.http.post<ApiResult<ReturnRequest>>(`/api/support/returns/${returnId}/mark-picked-up`, {}).pipe(map((result) => result.value));
  }

  refund(returnId: string): Observable<ReturnRequest> {
    return this.http.post<ApiResult<ReturnRequest>>(`/api/support/returns/${returnId}/refund`, {}).pipe(map((result) => result.value));
  }
}
