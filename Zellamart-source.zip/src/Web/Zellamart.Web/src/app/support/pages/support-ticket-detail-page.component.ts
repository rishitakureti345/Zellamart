import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { SupportStaffApiService } from '../services/support-staff-api.service';
import { SupportTicket } from '../../customer/models/support.model';
import { AuthService } from '../../core/services/auth.service';
import { ErrorMessageService } from '../../core/services/error-message.service';
import { StatusBadgeComponent } from '../../shared/components/status-badge/status-badge.component';
import { ToastComponent } from '../../shared/components/toast/toast.component';

@Component({
  selector: 'app-support-ticket-detail-page',
  standalone: true,
  imports: [CommonModule, FormsModule, StatusBadgeComponent, ToastComponent],
  template: `
    <section class="dashboard-header"><div><span class="eyebrow">Ticket</span><h1>{{ ticket()?.subject || 'Ticket' }}</h1><p>{{ ticket()?.description }}</p></div></section>
    <app-toast [message]="message()"></app-toast>
    <section class="ops-toolbar surface"><label>Agent ID<input [(ngModel)]="agentId"></label></section>
    <section class="surface dashboard-panel" *ngIf="ticket() as item">
      <p><app-status-badge kind="ticket" [status]="item.status"></app-status-badge></p>
      <p><strong>Order:</strong> {{ item.orderId }}</p>
      <p><strong>Assigned:</strong> {{ item.assignedAgentId || '-' }}</p>
      <div class="action-row"><button (click)="assign()">Assign</button><button (click)="resolve()">Resolve</button><button class="ghost-light" (click)="reject()">Reject</button><button class="text-danger" (click)="close()">Close</button></div>
      <form class="checkout-form reply-form" (ngSubmit)="reply()">
        <label>Reply to customer<textarea [(ngModel)]="replyText" name="replyText" rows="4" maxlength="1200" required></textarea></label>
        <button type="submit">Send reply</button>
      </form>
      <div class="message-thread"><article *ngFor="let m of item.messages"><strong>{{ m.createdAtUtc | date:'medium' }}</strong><p>{{ m.message }}</p></article></div>
    </section>
  `
})
export class SupportTicketDetailPageComponent implements OnInit {
  readonly ticket = signal<SupportTicket | null>(null);
  readonly message = signal('');
  agentId = '';
  replyText = '';
  private ticketId = '';
  constructor(private readonly api: SupportStaffApiService, private readonly route: ActivatedRoute, private readonly errors: ErrorMessageService, auth: AuthService) { this.agentId = auth.session()?.userId ?? ''; }
  ngOnInit(): void { this.ticketId = this.route.snapshot.paramMap.get('ticketId') ?? ''; this.load(); }
  load(): void { this.api.ticket(this.ticketId).subscribe({ next: (ticket) => this.ticket.set(ticket), error: (e) => this.message.set(this.errors.from(e)) }); }
  assign(): void { if (!this.agentId) { this.message.set('Agent ID is required.'); return; } this.api.assignTicket(this.ticketId, this.agentId).subscribe({ next: (ticket) => { this.ticket.set(ticket); this.message.set('Ticket assigned.'); }, error: (e) => this.message.set(this.errors.from(e)) }); }
  reply(): void {
    const text = this.replyText.trim();
    if (!text) { this.message.set('Reply is required.'); return; }
    this.api.replyTicket(this.ticketId, text).subscribe({
      next: (ticket) => { this.ticket.set(ticket); this.replyText = ''; this.message.set('Reply sent to customer.'); },
      error: (e) => this.message.set(this.errors.from(e))
    });
  }
  resolve(): void { this.api.resolveTicket(this.ticketId).subscribe({ next: (ticket) => { this.ticket.set(ticket); this.message.set('Ticket resolved.'); }, error: (e) => this.message.set(this.errors.from(e)) }); }
  reject(): void { this.api.rejectTicket(this.ticketId).subscribe({ next: (ticket) => { this.ticket.set(ticket); this.message.set('Ticket rejected.'); }, error: (e) => this.message.set(this.errors.from(e)) }); }
  close(): void { this.api.closeTicket(this.ticketId).subscribe({ next: (ticket) => { this.ticket.set(ticket); this.message.set('Ticket closed.'); }, error: (e) => this.message.set(this.errors.from(e)) }); }
}
