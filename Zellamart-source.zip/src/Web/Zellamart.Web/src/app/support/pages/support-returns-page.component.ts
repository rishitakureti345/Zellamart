import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SupportStaffApiService } from '../services/support-staff-api.service';
import { ReturnRequest } from '../../customer/models/support.model';
import { ErrorMessageService } from '../../core/services/error-message.service';
import { MoneyPipe } from '../../shared/pipes/money.pipe';
import { StatusBadgeComponent } from '../../shared/components/status-badge/status-badge.component';
import { EmptyStateComponent } from '../../shared/components/empty-state/empty-state.component';
import { ToastComponent } from '../../shared/components/toast/toast.component';

@Component({
  selector: 'app-support-returns-page',
  standalone: true,
  imports: [CommonModule, MoneyPipe, StatusBadgeComponent, EmptyStateComponent, ToastComponent],
  template: `
    <section class="dashboard-header"><div><span class="eyebrow">Returns</span><h1>Returns management</h1><p>Approve, reject, pick up, and refund return requests.</p></div><button (click)="load()">Refresh</button></section>
    <app-toast [message]="message()"></app-toast>
    <section class="surface dashboard-panel" *ngIf="returns().length">
      <table><tr><th>Return</th><th>Order</th><th>Status</th><th>Refund</th><th>Actions</th></tr>
        <tr *ngFor="let item of returns()">
          <td>{{ item.id }}</td><td>{{ item.orderId }}</td><td><app-status-badge kind="return" [status]="item.status"></app-status-badge></td><td>{{ item.refundAmount | money }}</td>
          <td class="action-row"><button (click)="approve(item.id)">Approve</button><button class="ghost-light" (click)="reject(item.id)">Reject</button><button (click)="pickedUp(item.id)">Picked up</button><button class="text-danger" (click)="refund(item.id)">Refund</button></td>
        </tr>
      </table>
    </section>
    <app-empty-state *ngIf="!returns().length" title="No returns" message="Customer return requests will appear here."></app-empty-state>
  `
})
export class SupportReturnsPageComponent implements OnInit {
  readonly returns = signal<ReturnRequest[]>([]);
  readonly message = signal('');
  constructor(private readonly api: SupportStaffApiService, private readonly errors: ErrorMessageService) {}
  ngOnInit(): void { this.load(); }
  load(): void { this.api.returns().subscribe({ next: (items) => this.returns.set(items), error: (e) => this.message.set(this.errors.from(e)) }); }
  approve(id: string): void { this.api.approveReturn(id).subscribe({ next: () => { this.message.set('Return approved.'); this.load(); }, error: (e) => this.message.set(this.errors.from(e)) }); }
  reject(id: string): void { this.api.rejectReturn(id).subscribe({ next: () => { this.message.set('Return rejected.'); this.load(); }, error: (e) => this.message.set(this.errors.from(e)) }); }
  pickedUp(id: string): void { this.api.markPickedUp(id).subscribe({ next: () => { this.message.set('Return picked up.'); this.load(); }, error: (e) => this.message.set(this.errors.from(e)) }); }
  refund(id: string): void { this.api.refund(id).subscribe({ next: () => { this.message.set('Refund marked.'); this.load(); }, error: (e) => this.message.set(this.errors.from(e)) }); }
}
