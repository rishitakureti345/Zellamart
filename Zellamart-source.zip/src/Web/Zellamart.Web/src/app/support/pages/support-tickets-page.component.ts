import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { SupportStaffApiService } from '../services/support-staff-api.service';
import { SupportTicket } from '../../customer/models/support.model';
import { StatusBadgeComponent } from '../../shared/components/status-badge/status-badge.component';
import { EmptyStateComponent } from '../../shared/components/empty-state/empty-state.component';
import { ToastComponent } from '../../shared/components/toast/toast.component';

@Component({
  selector: 'app-support-tickets-page',
  standalone: true,
  imports: [CommonModule, RouterLink, StatusBadgeComponent, EmptyStateComponent, ToastComponent],
  template: `
    <section class="dashboard-header"><div><span class="eyebrow">Support</span><h1>Tickets</h1><p>All customer complaints and support requests.</p></div><button (click)="load()">Refresh</button></section>
    <app-toast [message]="message()"></app-toast>
    <section class="surface dashboard-panel" *ngIf="tickets().length">
      <table><tr><th>Subject</th><th>Customer</th><th>Order</th><th>Status</th><th></th></tr>
        <tr *ngFor="let ticket of tickets()"><td>{{ ticket.subject }}</td><td>{{ ticket.customerId }}</td><td>{{ ticket.orderId }}</td><td><app-status-badge kind="ticket" [status]="ticket.status"></app-status-badge></td><td><a [routerLink]="['/support/tickets', ticket.id]">Open</a></td></tr>
      </table>
    </section>
    <app-empty-state *ngIf="!tickets().length" title="No tickets" message="Customer support tickets will appear here."></app-empty-state>
  `
})
export class SupportTicketsPageComponent implements OnInit {
  readonly tickets = signal<SupportTicket[]>([]);
  readonly message = signal('');
  constructor(private readonly api: SupportStaffApiService) {}
  ngOnInit(): void { this.load(); }
  load(): void { this.api.tickets().subscribe({ next: (items) => this.tickets.set(items), error: () => this.message.set('Could not load tickets.') }); }
}
