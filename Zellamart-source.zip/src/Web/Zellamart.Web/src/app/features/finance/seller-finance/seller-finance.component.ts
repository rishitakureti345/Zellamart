import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { forkJoin } from 'rxjs';
import { AuthService } from '../../../core/services/auth.service';
import { ErrorMessageService } from '../../../core/services/error-message.service';
import { FinanceApiService } from '../../../core/services/finance-api.service';
import { FinanceTransaction, SellerBalance, SellerEarning, SellerPayout } from '../../../core/models/finance.model';
import { MoneyPipe } from '../../../shared/pipes/money.pipe';

@Component({
  selector: 'app-seller-finance',
  standalone: true,
  imports: [CommonModule, MoneyPipe],
  templateUrl: './seller-finance.component.html'
})
export class SellerFinanceComponent implements OnInit {
  balance = signal<SellerBalance | null>(null);
  earnings = signal<SellerEarning[]>([]);
  payouts = signal<SellerPayout[]>([]);
  transactions = signal<FinanceTransaction[]>([]);
  message = signal('');
  busy = signal(false);

  constructor(
    private readonly auth: AuthService,
    private readonly finance: FinanceApiService,
    private readonly errors: ErrorMessageService
  ) {}

  ngOnInit(): void {
    this.refresh();
  }

  refresh(): void {
    this.busy.set(true);
    this.message.set('');
    forkJoin({
      balance: this.finance.sellerBalance(),
      earnings: this.finance.sellerEarnings(),
      payouts: this.finance.sellerPayouts(),
      transactions: this.finance.sellerTransactions()
    }).subscribe({
      next: (data) => {
        this.balance.set(data.balance.value);
        this.earnings.set(data.earnings.value);
        this.payouts.set(data.payouts.value);
        this.transactions.set(data.transactions.value);
        this.finish('Seller finance refreshed.');
      },
      error: (error) => this.fail(error)
    });
  }

  requestPayout(): void {
    const sellerId = this.auth.session()?.userId;
    if (!sellerId) {
      this.message.set('Login as a seller to request payout.');
      return;
    }

    this.busy.set(true);
    this.message.set('');
    this.finance.requestPayout(sellerId).subscribe({
      next: () => {
        this.finish('Payout requested.');
        this.refresh();
      },
      error: (error) => this.fail(error)
    });
  }

  private finish(message: string): void {
    this.busy.set(false);
    this.message.set(message);
  }

  private fail(error: unknown): void {
    this.busy.set(false);
    this.message.set(this.errors.from(error));
  }
}
