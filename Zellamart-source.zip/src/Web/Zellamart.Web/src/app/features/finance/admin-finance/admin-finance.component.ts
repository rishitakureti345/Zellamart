import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { forkJoin } from 'rxjs';
import { ErrorMessageService } from '../../../core/services/error-message.service';
import { FinanceApiService } from '../../../core/services/finance-api.service';
import { AdminSummary, SellerBalanceRow, SellerPayout } from '../../../core/models/finance.model';
import { MoneyPipe } from '../../../shared/pipes/money.pipe';

@Component({
  selector: 'app-admin-finance',
  standalone: true,
  imports: [CommonModule, MoneyPipe],
  templateUrl: './admin-finance.component.html'
})
export class AdminFinanceComponent implements OnInit {
  summary = signal<AdminSummary | null>(null);
  sellerBalances = signal<SellerBalanceRow[]>([]);
  payouts = signal<SellerPayout[]>([]);
  message = signal('');
  busy = signal(false);

  constructor(
    private readonly finance: FinanceApiService,
    private readonly errors: ErrorMessageService
  ) {}

  ngOnInit(): void {
    this.refresh();
  }

  refresh(): void {
    this.busy.set(true);
    this.message.set('');
    forkJoin({
      summary: this.finance.adminSummary(),
      balances: this.finance.adminSellerBalances(),
      payouts: this.finance.adminPayouts()
    }).subscribe({
      next: (data) => {
        this.summary.set(data.summary.value);
        this.sellerBalances.set(data.balances.value);
        this.payouts.set(data.payouts.value);
        this.finish('Admin finance refreshed.');
      },
      error: (error) => this.fail(error)
    });
  }

  markPaid(payoutId: string): void {
    this.busy.set(true);
    this.message.set('');
    this.finance.markPayoutPaid(payoutId).subscribe({
      next: () => {
        this.finish('Payout marked paid.');
        this.refresh();
      },
      error: (error) => this.fail(error)
    });
  }

  private finish(message: string): void {
    this.busy.set(false);
    this.message.set(message);
  }

  private fail(error: unknown): void {
    this.busy.set(false);
    this.message.set(this.errors.from(error));
  }
}
