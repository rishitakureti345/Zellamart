import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { forkJoin } from 'rxjs';
import { ErrorMessageService } from '../../../core/services/error-message.service';
import { OperationsApiService } from '../../../core/services/operations-api.service';
import { ReturnSummary, SupportTicketSummary } from '../../../core/models/operations.model';
import { MoneyPipe } from '../../../shared/pipes/money.pipe';

@Component({
  selector: 'app-support-dashboard',
  standalone: true,
  imports: [CommonModule, MoneyPipe],
  templateUrl: './support-dashboard.component.html'
})
export class SupportDashboardComponent implements OnInit {
  tickets = signal<SupportTicketSummary[]>([]);
  returns = signal<ReturnSummary[]>([]);
  message = signal('');
  busy = signal(false);

  constructor(
    private readonly operations: OperationsApiService,
    private readonly errors: ErrorMessageService
  ) {}

  ngOnInit(): void {
    this.refresh();
  }

  refresh(): void {
    this.busy.set(true);
    this.message.set('');
    forkJoin({
      tickets: this.operations.myTickets(),
      returns: this.operations.myReturns()
    }).subscribe({
      next: (data) => {
        this.tickets.set(data.tickets.value);
        this.returns.set(data.returns.value);
        this.finish('Support dashboard refreshed.');
      },
      error: (error) => this.fail(error)
    });
  }

  private finish(message: string): void {
    this.busy.set(false);
    this.message.set(message);
  }

  private fail(error: unknown): void {
    this.busy.set(false);
    this.message.set(this.errors.from(error));
  }
}
