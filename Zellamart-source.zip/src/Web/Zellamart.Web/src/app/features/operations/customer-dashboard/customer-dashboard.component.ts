import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { forkJoin } from 'rxjs';
import { ErrorMessageService } from '../../../core/services/error-message.service';
import { OperationsApiService } from '../../../core/services/operations-api.service';
import { OrderSummary, ReturnSummary, ShipmentSummary } from '../../../core/models/operations.model';
import { MoneyPipe } from '../../../shared/pipes/money.pipe';

@Component({
  selector: 'app-customer-dashboard',
  standalone: true,
  imports: [CommonModule, MoneyPipe],
  templateUrl: './customer-dashboard.component.html'
})
export class CustomerDashboardComponent implements OnInit {
  orders = signal<OrderSummary[]>([]);
  shipments = signal<ShipmentSummary[]>([]);
  returns = signal<ReturnSummary[]>([]);
  message = signal('');
  busy = signal(false);

  constructor(
    private readonly operations: OperationsApiService,
    private readonly errors: ErrorMessageService
  ) {}

  ngOnInit(): void {
    this.refresh();
  }

  refresh(): void {
    this.busy.set(true);
    this.message.set('');
    forkJoin({
      orders: this.operations.myOrders(),
      shipments: this.operations.myShipments(),
      returns: this.operations.myReturns()
    }).subscribe({
      next: (data) => {
        this.orders.set(data.orders.value);
        this.shipments.set(data.shipments.value);
        this.returns.set(data.returns.value);
        this.finish('Customer dashboard refreshed.');
      },
      error: (error) => this.fail(error)
    });
  }

  private finish(message: string): void {
    this.busy.set(false);
    this.message.set(message);
  }

  private fail(error: unknown): void {
    this.busy.set(false);
    this.message.set(this.errors.from(error));
  }
}
