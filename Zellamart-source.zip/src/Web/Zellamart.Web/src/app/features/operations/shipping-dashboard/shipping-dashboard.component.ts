import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ErrorMessageService } from '../../../core/services/error-message.service';
import { OperationsApiService } from '../../../core/services/operations-api.service';
import { ShipmentSummary } from '../../../core/models/operations.model';

@Component({
  selector: 'app-shipping-dashboard',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './shipping-dashboard.component.html'
})
export class ShippingDashboardComponent implements OnInit {
  shipments = signal<ShipmentSummary[]>([]);
  message = signal('');
  busy = signal(false);

  constructor(
    private readonly operations: OperationsApiService,
    private readonly errors: ErrorMessageService
  ) {}

  ngOnInit(): void {
    this.refresh();
  }

  refresh(): void {
    this.busy.set(true);
    this.message.set('');
    this.operations.myShipments().subscribe({
      next: (data) => {
        this.shipments.set(data.value);
        this.finish('Shipping dashboard refreshed.');
      },
      error: (error) => this.fail(error)
    });
  }

  private finish(message: string): void {
    this.busy.set(false);
    this.message.set(message);
  }

  private fail(error: unknown): void {
    this.busy.set(false);
    this.message.set(this.errors.from(error));
  }
}
