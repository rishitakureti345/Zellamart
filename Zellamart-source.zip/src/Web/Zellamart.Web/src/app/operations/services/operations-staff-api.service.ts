import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { map, Observable } from 'rxjs';
import { ApiResult } from '../../core/models/api-result.model';
import { Order, Payment, Shipment } from '../../customer/models/order.model';
import { InventoryItem } from '../../seller/models/seller.model';
import { AdminProduct, AdminSeller, AdminStockMovement } from '../../admin/models/admin.model';

@Injectable({ providedIn: 'root' })
export class OperationsStaffApiService {
  constructor(private readonly http: HttpClient) {}

  orders(): Observable<Order[]> {
    return this.http.get<ApiResult<Order[]>>('/api/orders/admin/all').pipe(map((result) => result.value ?? []));
  }

  shipments(): Observable<Shipment[]> {
    return this.http.get<ApiResult<Shipment[]>>('/api/shipping/admin/all').pipe(map((result) => result.value ?? []));
  }

  orderPayments(orderId: string): Observable<Payment[]> {
    return this.http.get<ApiResult<Payment[]>>(`/api/payments/admin/order/${orderId}`).pipe(map((result) => result.value ?? []));
  }

  inventory(): Observable<InventoryItem[]> {
    return this.http.get<ApiResult<InventoryItem[]>>('/api/inventory/admin/all').pipe(map((result) => result.value ?? []));
  }

  products(): Observable<AdminProduct[]> {
    return this.http.get<ApiResult<AdminProduct[]>>('/api/products/admin/all').pipe(map((result) => result.value ?? []));
  }

  sellers(): Observable<AdminSeller[]> {
    return this.http.get<ApiResult<AdminSeller[]>>('/api/sellers/admin/all').pipe(map((result) => result.value ?? []));
  }

  stockMovements(inventoryItemId: string): Observable<AdminStockMovement[]> {
    return this.http.get<ApiResult<AdminStockMovement[]>>(`/api/inventory/${inventoryItemId}/movements`)
      .pipe(map((result) => result.value ?? []));
  }

  addStock(inventoryItemId: string, quantity: number, reason: string): Observable<InventoryItem> {
    return this.http.post<ApiResult<InventoryItem>>(`/api/inventory/${inventoryItemId}/stock/add`, {
      quantity,
      reason,
      referenceId: null
    }).pipe(map((result) => result.value));
  }

  setStock(inventoryItemId: string, quantityOnHand: number, reason: string): Observable<InventoryItem> {
    return this.http.post<ApiResult<InventoryItem>>(`/api/inventory/${inventoryItemId}/stock/set`, {
      quantityOnHand,
      reason,
      referenceId: null
    }).pipe(map((result) => result.value));
  }

  pack(shipmentId: string): Observable<Shipment> {
    return this.http.post<ApiResult<Shipment>>(`/api/shipping/${shipmentId}/pack`, {}).pipe(map((result) => result.value));
  }

  ship(shipmentId: string): Observable<Shipment> {
    return this.http.post<ApiResult<Shipment>>(`/api/shipping/${shipmentId}/ship`, {}).pipe(map((result) => result.value));
  }

  assignPartner(shipmentId: string, deliveryPartnerId: string): Observable<Shipment> {
    return this.http.post<ApiResult<Shipment>>(`/api/shipping/${shipmentId}/assign-partner`, { deliveryPartnerId })
      .pipe(map((result) => result.value));
  }

  outForDelivery(shipmentId: string): Observable<Shipment> {
    return this.http.post<ApiResult<Shipment>>(`/api/shipping/${shipmentId}/out-for-delivery`, {}).pipe(map((result) => result.value));
  }

  delivered(shipmentId: string): Observable<Shipment> {
    return this.http.post<ApiResult<Shipment>>(`/api/shipping/${shipmentId}/delivered`, {}).pipe(map((result) => result.value));
  }

  deliveryFailed(shipmentId: string, reason: string): Observable<Shipment> {
    return this.http.post<ApiResult<Shipment>>(`/api/shipping/${shipmentId}/delivery-failed`, { reason })
      .pipe(map((result) => result.value));
  }
}
