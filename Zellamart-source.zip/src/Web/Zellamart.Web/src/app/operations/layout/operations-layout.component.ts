import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterOutlet } from '@angular/router';
import { StoreNavbarComponent } from '../../shared/components/store-navbar/store-navbar.component';
import { DashboardNavItem, DashboardSidebarComponent } from '../../shared/components/dashboard-sidebar/dashboard-sidebar.component';
import { AuthService } from '../../core/services/auth.service';
import { StatusBadgeComponent } from '../../shared/components/status-badge/status-badge.component';

@Component({
  selector: 'app-operations-layout',
  standalone: true,
  imports: [CommonModule, RouterOutlet, StoreNavbarComponent, DashboardSidebarComponent, StatusBadgeComponent],
  template: `
    <app-store-navbar></app-store-navbar>
    <main class="operations-shell">
      <aside class="admin-sidebar">
        <section class="admin-identity" *ngIf="auth.session() as session">
          <span>Operations workspace</span>
          <strong>{{ session.fullName }}</strong>
          <small>{{ session.email }}</small>
          <p>{{ operationsRoleLabel() }}</p>
        </section>

        <app-dashboard-sidebar [items]="items"></app-dashboard-sidebar>
      </aside>

      <section class="admin-workspace">
        <header class="admin-topbar" *ngIf="auth.session() as session">
          <div>
            <span class="eyebrow">Fulfillment center</span>
            <strong>{{ session.email }}</strong>
          </div>
          <button type="button" class="ghost-light" (click)="logout()">Logout</button>
        </header>

        <section class="seller-status-banner operations-status-banner" *ngIf="auth.session()">
          <div>
            <strong>Operations staff active</strong>
            <p>Handle paid orders through packing, shipping, delivery, and inventory risk without duplicating admin business logic.</p>
          </div>
          <app-status-badge status="Operations" [label]="operationsRoleLabel()"></app-status-badge>
        </section>

        <section class="dashboard-content">
          <router-outlet></router-outlet>
        </section>
      </section>
    </main>
  `
})
export class OperationsLayoutComponent {
  readonly items: DashboardNavItem[] = [
    { label: 'Dashboard', path: '/operations/dashboard' },
    { label: 'Packing Queue', path: '/operations/packing' },
    { label: 'Shipments', path: '/operations/shipments' },
    { label: 'Inventory Worklist', path: '/operations/inventory' },
    { label: 'Delivery Tasks', path: '/operations/delivery' }
  ];

  private readonly operationsRoles = ['WarehouseManager', 'InventoryStaff', 'DeliveryManager', 'DeliveryPartner'];

  constructor(
    readonly auth: AuthService,
    private readonly router: Router
  ) {}

  operationsRoleLabel(): string {
    const roles = this.auth.session()?.roles ?? [];
    return roles.find((role) => this.operationsRoles.includes(role))
      ?? roles.find((role) => ['Admin', 'SuperAdmin'].includes(role))
      ?? 'Operations';
  }

  logout(): void {
    this.auth.logout();
    void this.router.navigateByUrl('/');
  }
}
