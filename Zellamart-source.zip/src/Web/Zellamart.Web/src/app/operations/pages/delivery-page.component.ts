import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { OperationsStaffApiService } from '../services/operations-staff-api.service';
import { Shipment } from '../../customer/models/order.model';
import { ErrorMessageService } from '../../core/services/error-message.service';
import { AuthService } from '../../core/services/auth.service';
import { StatusBadgeComponent } from '../../shared/components/status-badge/status-badge.component';
import { EmptyStateComponent } from '../../shared/components/empty-state/empty-state.component';
import { ToastComponent } from '../../shared/components/toast/toast.component';

@Component({
  selector: 'app-delivery-page',
  standalone: true,
  imports: [CommonModule, FormsModule, StatusBadgeComponent, EmptyStateComponent, ToastComponent],
  template: `
    <section class="dashboard-header">
      <div>
        <span class="eyebrow">Delivery</span>
        <h1>Delivery tasks</h1>
        <p>Track assigned shipments from dispatch to delivered or failed.</p>
      </div>
      <button type="button" (click)="load()">Refresh</button>
    </section>

    <app-toast [message]="message()"></app-toast>

    <section class="metric-grid">
      <article class="metric-card"><span>Assigned shipments</span><strong>{{ assignedShipments().length }}</strong></article>
      <article class="metric-card"><span>Ready to dispatch</span><strong>{{ countByStatus('Shipped') }}</strong></article>
      <article class="metric-card"><span>Out for delivery</span><strong>{{ countByStatus('Out for delivery') }}</strong></article>
      <article class="metric-card"><span>Delivery failed</span><strong>{{ countByStatus('Delivery failed') }}</strong></article>
    </section>

    <section class="seller-toolbar users-toolbar">
      <label>Search<input [(ngModel)]="search" placeholder="Tracking, order, customer, address"></label>
      <label>Failure reason<input [(ngModel)]="failureReason"></label>
      <span></span>
    </section>

    <section class="seller-admin-grid">
      <section class="surface dashboard-panel">
        <table *ngIf="filteredShipments().length">
          <tr>
            <th>Tracking</th>
            <th>Status</th>
            <th>Customer</th>
            <th>Address</th>
            <th>Partner</th>
            <th>Actions</th>
          </tr>
          <tr *ngFor="let shipment of filteredShipments()" [class.selected-row]="selectedShipment()?.id === shipment.id">
            <td>
              <button type="button" class="table-link" (click)="selectShipment(shipment)">
                <strong>{{ shipment.trackingNumber }}</strong>
                <br>
                <span class="muted-line">{{ shortId(shipment.orderId) }}</span>
              </button>
            </td>
            <td><app-status-badge kind="shipping" [status]="shipment.status"></app-status-badge></td>
            <td>{{ shortId(shipment.customerId) }}</td>
            <td>{{ shipment.shippingAddress }}</td>
            <td>{{ shipment.deliveryPartnerId || '-' }}</td>
            <td class="action-row">
              <button type="button" class="ghost-light" *ngIf="canOutForDelivery(shipment)" (click)="outForDelivery(shipment.id)" [disabled]="busyId() === shipment.id">
                Out for delivery
              </button>
              <button type="button" *ngIf="canComplete(shipment)" (click)="delivered(shipment.id)" [disabled]="busyId() === shipment.id">
                Delivered
              </button>
              <button type="button" class="text-danger" *ngIf="canComplete(shipment)" (click)="failed(shipment.id)" [disabled]="busyId() === shipment.id">
                Failed
              </button>
            </td>
          </tr>
        </table>
        <app-empty-state *ngIf="!filteredShipments().length" title="No delivery work" message="Assigned shipped and out-for-delivery shipments will appear here."></app-empty-state>
      </section>

      <aside class="surface seller-detail-pane" *ngIf="selectedShipment() as shipment">
        <div class="seller-detail-heading">
          <span class="eyebrow">Delivery detail</span>
          <h2>{{ shipment.trackingNumber }}</h2>
          <app-status-badge kind="shipping" [status]="shipment.status"></app-status-badge>
        </div>

        <div class="seller-detail-grid">
          <div><span>Order</span><strong>{{ shipment.orderId }}</strong></div>
          <div><span>Customer</span><strong>{{ shipment.customerId }}</strong></div>
          <div><span>Partner</span><strong>{{ shipment.deliveryPartnerId || 'Not assigned' }}</strong></div>
          <div><span>Created</span><strong>{{ shipment.createdAtUtc | date:'medium' }}</strong></div>
          <div class="profile-wide"><span>Delivery address</span><strong>{{ shipment.shippingAddress }}</strong></div>
        </div>

        <div class="action-row detail-actions">
          <button type="button" class="ghost-light" *ngIf="canOutForDelivery(shipment)" (click)="outForDelivery(shipment.id)" [disabled]="busyId() === shipment.id">Mark out for delivery</button>
          <button type="button" *ngIf="canComplete(shipment)" (click)="delivered(shipment.id)" [disabled]="busyId() === shipment.id">Mark delivered</button>
          <button type="button" class="text-danger" *ngIf="canComplete(shipment)" (click)="failed(shipment.id)" [disabled]="busyId() === shipment.id">Mark delivery failed</button>
        </div>

        <section>
          <h3>Delivery history</h3>
          <table *ngIf="shipment.statusHistory.length">
            <tr><th>Status</th><th>Note</th><th>Changed by</th><th>Changed</th></tr>
            <tr *ngFor="let entry of orderedHistory(shipment)">
              <td><app-status-badge kind="shipping" [status]="entry.status"></app-status-badge></td>
              <td>{{ entry.note }}</td>
              <td>{{ entry.changedByUserId || '-' }}</td>
              <td>{{ entry.changedAtUtc | date:'medium' }}</td>
            </tr>
          </table>
        </section>
      </aside>

      <aside class="surface seller-detail-pane" *ngIf="!selectedShipment()">
        <app-empty-state title="Select a delivery" message="Open a delivery task to view customer, address, and delivery history."></app-empty-state>
      </aside>
    </section>
  `
})
export class DeliveryPageComponent implements OnInit {
  search = '';
  failureReason = 'Customer not available';
  readonly shipments = signal<Shipment[]>([]);
  readonly selectedShipment = signal<Shipment | null>(null);
  readonly busyId = signal('');
  readonly message = signal('');

  constructor(private readonly api: OperationsStaffApiService, private readonly errors: ErrorMessageService, private readonly auth: AuthService) {}

  ngOnInit(): void { this.load(); }

  load(): void {
    this.api.shipments().subscribe({
      next: (items) => {
        const tasks = items.filter((item) => this.isDeliveryTask(item));
        this.shipments.set(tasks);
        this.selectedShipment.set(tasks.find((item) => item.id === this.selectedShipment()?.id) ?? tasks[0] ?? null);
      },
      error: (error) => this.message.set(this.errors.from(error))
    });
  }

  filteredShipments(): Shipment[] {
    const term = this.search.trim().toLowerCase();
    return this.assignedShipments().filter((shipment) => {
      const searchable = [
        shipment.trackingNumber,
        shipment.orderId,
        shipment.customerId,
        shipment.deliveryPartnerId ?? '',
        shipment.shippingAddress
      ].join(' ').toLowerCase();
      return !term || searchable.includes(term);
    });
  }

  assignedShipments(): Shipment[] {
    if (!this.auth.hasRole('DeliveryPartner')) {
      return this.shipments();
    }

    const userId = this.auth.session()?.userId;
    return this.shipments().filter((shipment) => shipment.deliveryPartnerId === userId);
  }

  selectShipment(shipment: Shipment): void {
    this.selectedShipment.set(shipment);
  }

  outForDelivery(id: string): void {
    this.run(id, this.api.outForDelivery(id), 'Shipment is out for delivery. Customer tracking and notifications are updated.');
  }

  delivered(id: string): void {
    this.run(id, this.api.delivered(id), 'Shipment delivered. Customer return/refund flow can now use delivered order items.');
  }

  failed(id: string): void {
    this.run(id, this.api.deliveryFailed(id, this.failureReason || 'Delivery failed.'), 'Delivery failed recorded. Admin and support can now see the exception.');
  }

  countByStatus(status: string): number {
    return this.assignedShipments().filter((shipment) => this.shippingStatusLabel(shipment.status) === status).length;
  }

  canOutForDelivery(shipment: Shipment): boolean {
    return this.shippingStatusLabel(shipment.status) === 'Shipped' && Boolean(shipment.deliveryPartnerId);
  }

  canComplete(shipment: Shipment): boolean {
    return this.shippingStatusLabel(shipment.status) === 'Out for delivery';
  }

  orderedHistory(shipment: Shipment) {
    return [...shipment.statusHistory].sort((left, right) => Date.parse(left.changedAtUtc) - Date.parse(right.changedAtUtc));
  }

  shortId(id: string): string {
    return id ? id.slice(0, 8) : '-';
  }

  shippingStatusLabel(status: string | number): string {
    const map: Record<string, string> = {
      '1': 'Pending packing',
      PendingPacking: 'Pending packing',
      '2': 'Packed',
      Packed: 'Packed',
      '3': 'Shipped',
      Shipped: 'Shipped',
      '4': 'Out for delivery',
      OutForDelivery: 'Out for delivery',
      '5': 'Delivered',
      Delivered: 'Delivered',
      '6': 'Delivery failed',
      DeliveryFailed: 'Delivery failed',
      '7': 'Cancelled',
      Cancelled: 'Cancelled'
    };
    return map[String(status)] ?? String(status);
  }

  private isDeliveryTask(shipment: Shipment): boolean {
    return ['Shipped', 'Out for delivery', 'Delivery failed'].includes(this.shippingStatusLabel(shipment.status));
  }

  private run(id: string, request: ReturnType<OperationsStaffApiService['outForDelivery']>, successMessage: string): void {
    this.busyId.set(id);
    request.subscribe({
      next: () => {
        this.busyId.set('');
        this.message.set(successMessage);
        this.load();
      },
      error: (error) => {
        this.busyId.set('');
        this.message.set(this.errors.from(error));
      }
    });
  }
}
