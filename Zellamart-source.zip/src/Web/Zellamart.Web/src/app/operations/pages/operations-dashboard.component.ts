import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { forkJoin } from 'rxjs';
import { OperationsStaffApiService } from '../services/operations-staff-api.service';
import { Order, Shipment } from '../../customer/models/order.model';
import { InventoryItem } from '../../seller/models/seller.model';
import { StatusBadgeComponent } from '../../shared/components/status-badge/status-badge.component';
import { EmptyStateComponent } from '../../shared/components/empty-state/empty-state.component';
import { ToastComponent } from '../../shared/components/toast/toast.component';

@Component({
  selector: 'app-operations-dashboard',
  standalone: true,
  imports: [CommonModule, StatusBadgeComponent, EmptyStateComponent, ToastComponent],
  template: `
    <section class="dashboard-header">
      <div>
        <span class="eyebrow">Operations</span>
        <h1>Fulfillment dashboard</h1>
        <p>Watch paid orders move through packing, shipping, delivery, and inventory risk.</p>
      </div>
      <button (click)="load()">Refresh</button>
    </section>

    <app-toast [message]="message()"></app-toast>

    <section class="metric-grid">
      <article class="metric-card"><span>Orders ready to pack</span><strong>{{ ordersReadyToPack() }}</strong></article>
      <article class="metric-card"><span>Packed shipments</span><strong>{{ countShipments('Packed') }}</strong></article>
      <article class="metric-card"><span>Shipped shipments</span><strong>{{ countShipments('Shipped') }}</strong></article>
      <article class="metric-card"><span>Out for delivery</span><strong>{{ countShipments('Out for delivery') }}</strong></article>
      <article class="metric-card"><span>Delivered today</span><strong>{{ deliveredToday().length }}</strong></article>
      <article class="metric-card"><span>Failed deliveries</span><strong>{{ countShipments('Delivery failed') }}</strong></article>
      <article class="metric-card"><span>Low-stock products</span><strong>{{ lowStockItems().length }}</strong></article>
      <article class="metric-card"><span>Out-of-stock products</span><strong>{{ outOfStockItems().length }}</strong></article>
    </section>

    <section class="dashboard-grid">
      <article class="surface dashboard-panel">
        <h2>Recent packed shipments</h2>
        <table *ngIf="recentPackedShipments().length">
          <tr><th>Tracking</th><th>Order</th><th>Packed</th></tr>
          <tr *ngFor="let shipment of recentPackedShipments()">
            <td>{{ shipment.trackingNumber }}</td>
            <td>{{ shortId(shipment.orderId) }}</td>
            <td>{{ lastChangedAt(shipment) | date:'medium' }}</td>
          </tr>
        </table>
        <app-empty-state *ngIf="!recentPackedShipments().length" title="No packed shipments" message="Packed shipments will appear here before shipping handoff."></app-empty-state>
      </article>

      <article class="surface dashboard-panel">
        <h2>Recent delivery failures</h2>
        <table *ngIf="recentDeliveryFailures().length">
          <tr><th>Tracking</th><th>Order</th><th>Failed</th></tr>
          <tr *ngFor="let shipment of recentDeliveryFailures()">
            <td>{{ shipment.trackingNumber }}</td>
            <td>{{ shortId(shipment.orderId) }}</td>
            <td>{{ lastChangedAt(shipment) | date:'medium' }}</td>
          </tr>
        </table>
        <app-empty-state *ngIf="!recentDeliveryFailures().length" title="No failed deliveries" message="Delivery exceptions will appear here."></app-empty-state>
      </article>

      <article class="surface dashboard-panel">
        <h2>Recent low-stock items</h2>
        <table *ngIf="recentLowStockItems().length">
          <tr><th>SKU</th><th>Available</th><th>Reserved</th></tr>
          <tr *ngFor="let item of recentLowStockItems()">
            <td>{{ item.sku }}</td>
            <td><strong>{{ item.availableQuantity }}</strong></td>
            <td>{{ item.reservedQuantity }}</td>
          </tr>
        </table>
        <app-empty-state *ngIf="!recentLowStockItems().length" title="No low-stock items" message="Inventory risk will appear here before orders fail."></app-empty-state>
      </article>
    </section>
  `
})
export class OperationsDashboardComponent implements OnInit {
  readonly orders = signal<Order[]>([]);
  readonly shipments = signal<Shipment[]>([]);
  readonly inventory = signal<InventoryItem[]>([]);
  readonly message = signal('');

  private readonly lowStockThreshold = 5;

  constructor(private readonly api: OperationsStaffApiService) {}

  ngOnInit(): void { this.load(); }

  load(): void {
    forkJoin({
      orders: this.api.orders(),
      shipments: this.api.shipments(),
      inventory: this.api.inventory()
    }).subscribe({
      next: (data) => {
        this.orders.set(this.byNewest(data.orders));
        this.shipments.set(this.byNewest(data.shipments));
        this.inventory.set(data.inventory);
      },
      error: () => this.message.set('Could not load operations dashboard.')
    });
  }

  ordersReadyToPack(): number {
    return this.countShipments('Pending packing');
  }

  countShipments(status: string): number {
    return this.shipments().filter((item) => this.shippingStatusLabel(item.status) === status).length;
  }

  deliveredToday(): Shipment[] {
    const today = new Date().toDateString();
    return this.shipments().filter((item) => {
      const deliveredAt = this.statusChangedAt(item, 'Delivered');
      return deliveredAt ? new Date(deliveredAt).toDateString() === today : false;
    });
  }

  lowStockItems(): InventoryItem[] {
    return this.inventory().filter((item) => item.availableQuantity > 0 && item.availableQuantity <= this.lowStockThreshold);
  }

  outOfStockItems(): InventoryItem[] {
    return this.inventory().filter((item) => item.availableQuantity <= 0);
  }

  recentPackedShipments(): Shipment[] {
    return this.shipmentsByStatus('Packed').slice(0, 6);
  }

  recentDeliveryFailures(): Shipment[] {
    return this.shipmentsByStatus('Delivery failed').slice(0, 6);
  }

  recentLowStockItems(): InventoryItem[] {
    return [...this.lowStockItems(), ...this.outOfStockItems()]
      .sort((left, right) => left.availableQuantity - right.availableQuantity)
      .slice(0, 8);
  }

  lastChangedAt(shipment: Shipment): string {
    return [...shipment.statusHistory]
      .sort((left, right) => Date.parse(right.changedAtUtc) - Date.parse(left.changedAtUtc))[0]?.changedAtUtc
      ?? shipment.createdAtUtc;
  }

  shortId(id: string): string {
    return id ? id.slice(0, 8) : '-';
  }

  shippingStatusLabel(status: string | number): string {
    const map: Record<string, string> = {
      '1': 'Pending packing',
      PendingPacking: 'Pending packing',
      '2': 'Packed',
      Packed: 'Packed',
      '3': 'Shipped',
      Shipped: 'Shipped',
      '4': 'Out for delivery',
      OutForDelivery: 'Out for delivery',
      '5': 'Delivered',
      Delivered: 'Delivered',
      '6': 'Delivery failed',
      DeliveryFailed: 'Delivery failed',
      '7': 'Cancelled',
      Cancelled: 'Cancelled'
    };
    return map[String(status)] ?? String(status);
  }

  private shipmentsByStatus(status: string): Shipment[] {
    return this.shipments()
      .filter((item) => this.shippingStatusLabel(item.status) === status)
      .sort((left, right) => Date.parse(this.lastChangedAt(right)) - Date.parse(this.lastChangedAt(left)));
  }

  private statusChangedAt(shipment: Shipment, status: string): string | null {
    return [...shipment.statusHistory]
      .reverse()
      .find((entry) => this.shippingStatusLabel(entry.status) === status)?.changedAtUtc ?? null;
  }

  private byNewest<T extends { createdAtUtc: string }>(items: T[]): T[] {
    return [...items].sort((left, right) => Date.parse(right.createdAtUtc) - Date.parse(left.createdAtUtc));
  }
}
