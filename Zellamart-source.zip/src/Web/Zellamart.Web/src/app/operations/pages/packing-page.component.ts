import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { catchError, forkJoin, of } from 'rxjs';
import { OperationsStaffApiService } from '../services/operations-staff-api.service';
import { Order, Payment, Shipment } from '../../customer/models/order.model';
import { ErrorMessageService } from '../../core/services/error-message.service';
import { StatusBadgeComponent } from '../../shared/components/status-badge/status-badge.component';
import { EmptyStateComponent } from '../../shared/components/empty-state/empty-state.component';
import { ToastComponent } from '../../shared/components/toast/toast.component';

interface PackingQueueRow {
  shipment: Shipment;
  order: Order | null;
  payments: Payment[];
}

@Component({
  selector: 'app-packing-page',
  standalone: true,
  imports: [CommonModule, StatusBadgeComponent, EmptyStateComponent, ToastComponent],
  template: `
    <section class="dashboard-header">
      <div>
        <span class="eyebrow">Warehouse</span>
        <h1>Packing queue</h1>
        <p>Pack confirmed and paid customer orders before shipment handoff.</p>
      </div>
      <button (click)="load()">Refresh</button>
    </section>

    <app-toast [message]="message()"></app-toast>

    <section class="metric-grid">
      <article class="metric-card"><span>Ready to pack</span><strong>{{ queue().length }}</strong></article>
      <article class="metric-card"><span>Confirmed orders</span><strong>{{ confirmedCount() }}</strong></article>
      <article class="metric-card"><span>Paid orders</span><strong>{{ paidCount() }}</strong></article>
      <article class="metric-card"><span>Packed today</span><strong>{{ packedTodayCount() }}</strong></article>
    </section>

    <section class="surface dashboard-panel" *ngIf="queue().length">
      <table>
        <tr>
          <th>Order</th>
          <th>Customer</th>
          <th>Products</th>
          <th>Shipping address</th>
          <th>Payment</th>
          <th>Shipment</th>
          <th>Actions</th>
        </tr>
        <tr *ngFor="let row of queue()">
          <td>
            <strong>{{ row.order?.orderNumber || shortId(row.shipment.orderId) }}</strong>
            <br>
            <span class="muted-line">{{ row.shipment.trackingNumber }}</span>
          </td>
          <td>{{ row.order?.customerId || row.shipment.customerId }}</td>
          <td>{{ productCount(row.order) }}</td>
          <td>{{ row.shipment.shippingAddress }}</td>
          <td><app-status-badge kind="payment" [status]="paymentStatus(row)"></app-status-badge></td>
          <td><app-status-badge kind="shipping" [status]="row.shipment.status"></app-status-badge></td>
          <td class="action-row">
            <button type="button" (click)="pack(row.shipment.id)" [disabled]="busyId() === row.shipment.id">
              {{ busyId() === row.shipment.id ? 'Packing...' : 'Mark packed' }}
            </button>
          </td>
        </tr>
      </table>
    </section>

    <app-empty-state *ngIf="!queue().length" title="No packing work" message="Confirmed and paid shipments waiting for packing will appear here."></app-empty-state>
  `
})
export class PackingPageComponent implements OnInit {
  readonly rows = signal<PackingQueueRow[]>([]);
  readonly shipments = signal<Shipment[]>([]);
  readonly orders = signal<Order[]>([]);
  readonly message = signal('');

  readonly busyId = signal('');

  constructor(private readonly api: OperationsStaffApiService, private readonly errors: ErrorMessageService) {}

  ngOnInit(): void { this.load(); }

  load(): void {
    forkJoin({
      shipments: this.api.shipments(),
      orders: this.api.orders()
    }).subscribe({
      next: ({ shipments, orders }) => {
        this.shipments.set(shipments);
        this.orders.set(orders);
        this.loadRows(shipments, orders);
      },
      error: (error) => this.message.set(this.errors.from(error))
    });
  }

  queue(): PackingQueueRow[] {
    return this.rows().filter((row) =>
      this.shippingStatusLabel(row.shipment.status) === 'Pending packing'
      && (this.isOrderConfirmed(row.order) || this.isPaymentSucceeded(row.payments)));
  }

  pack(id: string): void {
    this.busyId.set(id);
    this.api.pack(id).subscribe({
      next: () => {
        this.busyId.set('');
        this.message.set('Shipment packed. Admin, customer tracking, and shipping queues now show packed status.');
        this.load();
      },
      error: (error) => {
        this.busyId.set('');
        this.message.set(this.errors.from(error));
      }
    });
  }

  confirmedCount(): number {
    return this.queue().filter((row) => this.isOrderConfirmed(row.order)).length;
  }

  paidCount(): number {
    return this.queue().filter((row) => this.isPaymentSucceeded(row.payments)).length;
  }

  packedTodayCount(): number {
    const today = new Date().toDateString();
    return this.shipments().filter((shipment) => {
      const packedAt = this.statusChangedAt(shipment, 'Packed');
      return packedAt ? new Date(packedAt).toDateString() === today : false;
    }).length;
  }

  productCount(order: Order | null): number {
    return order?.items.reduce((total, item) => total + item.quantity, 0) ?? 0;
  }

  paymentStatus(row: PackingQueueRow): string | number {
    return row.payments[0]?.status ?? (this.isOrderConfirmed(row.order) ? 'Succeeded' : 'No payment');
  }

  shortId(id: string): string {
    return id ? id.slice(0, 8) : '-';
  }

  shippingStatusLabel(status: string | number): string {
    const map: Record<string, string> = {
      '1': 'Pending packing',
      PendingPacking: 'Pending packing',
      '2': 'Packed',
      Packed: 'Packed',
      '3': 'Shipped',
      Shipped: 'Shipped',
      '4': 'Out for delivery',
      OutForDelivery: 'Out for delivery',
      '5': 'Delivered',
      Delivered: 'Delivered',
      '6': 'Delivery failed',
      DeliveryFailed: 'Delivery failed',
      '7': 'Cancelled',
      Cancelled: 'Cancelled'
    };
    return map[String(status)] ?? String(status);
  }

  private loadRows(shipments: Shipment[], orders: Order[]): void {
    const pendingShipments = shipments.filter((shipment) => this.shippingStatusLabel(shipment.status) === 'Pending packing');
    if (!pendingShipments.length) {
      this.rows.set([]);
      return;
    }

    const calls = pendingShipments.map((shipment) =>
      this.api.orderPayments(shipment.orderId).pipe(catchError(() => of([] as Payment[])))
    );

    forkJoin(calls).subscribe({
      next: (paymentRows) => {
        this.rows.set(pendingShipments.map((shipment, index) => ({
          shipment,
          order: orders.find((order) => order.id === shipment.orderId) ?? null,
          payments: paymentRows[index]
        })));
      },
      error: (error) => this.message.set(this.errors.from(error))
    });
  }

  private isOrderConfirmed(order: Order | null): boolean {
    if (!order) {
      return false;
    }

    return ['Confirmed', 'PaymentSucceeded', '4', '2'].includes(String(order.status));
  }

  private isPaymentSucceeded(payments: Payment[]): boolean {
    return payments.some((payment) => ['Succeeded', 'PaymentSucceeded', '2'].includes(String(payment.status)));
  }

  private statusChangedAt(shipment: Shipment, status: string): string | null {
    return [...shipment.statusHistory]
      .reverse()
      .find((entry) => this.shippingStatusLabel(entry.status) === status)?.changedAtUtc ?? null;
  }
}
