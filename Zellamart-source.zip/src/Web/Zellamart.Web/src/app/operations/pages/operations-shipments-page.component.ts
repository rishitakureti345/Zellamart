import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { OperationsStaffApiService } from '../services/operations-staff-api.service';
import { AuthService } from '../../core/services/auth.service';
import { ErrorMessageService } from '../../core/services/error-message.service';
import { Shipment } from '../../customer/models/order.model';
import { StatusBadgeComponent } from '../../shared/components/status-badge/status-badge.component';
import { EmptyStateComponent } from '../../shared/components/empty-state/empty-state.component';
import { ToastComponent } from '../../shared/components/toast/toast.component';

@Component({
  selector: 'app-operations-shipments-page',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink, StatusBadgeComponent, EmptyStateComponent, ToastComponent],
  template: `
    <section class="dashboard-header">
      <div>
        <span class="eyebrow">Operations</span>
        <h1>Shipping queue</h1>
        <p>Move packed shipments into shipping and assign delivery ownership.</p>
      </div>
      <a class="button-link" routerLink="/operations/delivery">Open delivery tasks</a>
    </section>

    <app-toast [message]="message()"></app-toast>

    <section class="metric-grid">
      <article class="metric-card"><span>Packed shipments</span><strong>{{ packedShipments().length }}</strong></article>
      <article class="metric-card"><span>Shipped shipments</span><strong>{{ shippedShipments().length }}</strong></article>
      <article class="metric-card"><span>Need partner</span><strong>{{ needPartnerCount() }}</strong></article>
      <article class="metric-card"><span>Assigned</span><strong>{{ assignedCount() }}</strong></article>
    </section>

    <section class="seller-toolbar users-toolbar">
      <label>Search<input [(ngModel)]="search" placeholder="Tracking, order, customer, address"></label>
      <label>Partner ID<input [(ngModel)]="partnerId" placeholder="Delivery partner user id"></label>
      <button type="button" (click)="load()">Refresh</button>
    </section>

    <section class="seller-admin-grid">
      <section class="surface dashboard-panel">
        <table *ngIf="filteredShipments().length">
          <tr>
            <th>Tracking</th>
            <th>Status</th>
            <th>Order</th>
            <th>Customer</th>
            <th>Shipping address</th>
            <th>Partner</th>
            <th>Actions</th>
          </tr>
          <tr *ngFor="let shipment of filteredShipments()" [class.selected-row]="selectedShipment()?.id === shipment.id">
            <td>
              <button type="button" class="table-link" (click)="selectShipment(shipment)">
                <strong>{{ shipment.trackingNumber }}</strong>
                <br>
                <span class="muted-line">{{ shortId(shipment.id) }}</span>
              </button>
            </td>
            <td><app-status-badge kind="shipping" [status]="shipment.status"></app-status-badge></td>
            <td>{{ shortId(shipment.orderId) }}</td>
            <td>{{ shortId(shipment.customerId) }}</td>
            <td>{{ shipment.shippingAddress }}</td>
            <td>{{ shipment.deliveryPartnerId || '-' }}</td>
            <td class="action-row">
              <button type="button" *ngIf="canMarkShipped(shipment)" (click)="ship(shipment.id)" [disabled]="busyId() === shipment.id">
                {{ busyId() === shipment.id ? 'Shipping...' : 'Mark shipped' }}
              </button>
              <button type="button" class="ghost-light" *ngIf="canAssignPartner(shipment)" (click)="assign(shipment.id)" [disabled]="busyId() === shipment.id">
                Assign partner
              </button>
            </td>
          </tr>
        </table>
        <app-empty-state *ngIf="!filteredShipments().length" title="No shipments ready" message="Packed and shipped shipments will appear here."></app-empty-state>
      </section>

      <aside class="surface seller-detail-pane" *ngIf="selectedShipment() as shipment">
        <div class="seller-detail-heading">
          <span class="eyebrow">Shipment detail</span>
          <h2>{{ shipment.trackingNumber }}</h2>
          <app-status-badge kind="shipping" [status]="shipment.status"></app-status-badge>
        </div>

        <div class="seller-detail-grid">
          <div><span>Order</span><strong>{{ shipment.orderId }}</strong></div>
          <div><span>Customer</span><strong>{{ shipment.customerId }}</strong></div>
          <div><span>Partner</span><strong>{{ shipment.deliveryPartnerId || 'Not assigned' }}</strong></div>
          <div><span>Created</span><strong>{{ shipment.createdAtUtc | date:'medium' }}</strong></div>
          <div class="profile-wide"><span>Shipping address</span><strong>{{ shipment.shippingAddress }}</strong></div>
        </div>

        <div class="action-row detail-actions">
          <button type="button" *ngIf="canMarkShipped(shipment)" (click)="ship(shipment.id)" [disabled]="busyId() === shipment.id">Mark shipped</button>
          <button type="button" class="ghost-light" *ngIf="canAssignPartner(shipment)" (click)="assign(shipment.id)" [disabled]="busyId() === shipment.id">Assign delivery partner</button>
        </div>

        <section>
          <h3>Status timeline</h3>
          <table *ngIf="shipment.statusHistory.length">
            <tr><th>Status</th><th>Note</th><th>Changed by</th><th>Changed</th></tr>
            <tr *ngFor="let entry of orderedHistory(shipment)">
              <td><app-status-badge kind="shipping" [status]="entry.status"></app-status-badge></td>
              <td>{{ entry.note }}</td>
              <td>{{ entry.changedByUserId || '-' }}</td>
              <td>{{ entry.changedAtUtc | date:'medium' }}</td>
            </tr>
          </table>
        </section>
      </aside>

      <aside class="surface seller-detail-pane" *ngIf="!selectedShipment()">
        <app-empty-state title="Select a shipment" message="Open a shipment to view tracking, address, assignment, and status timeline."></app-empty-state>
      </aside>
    </section>
  `
})
export class OperationsShipmentsPageComponent implements OnInit {
  search = '';
  partnerId = '';
  readonly shipments = signal<Shipment[]>([]);
  readonly selectedShipment = signal<Shipment | null>(null);
  readonly busyId = signal('');
  readonly message = signal('');

  constructor(
    private readonly api: OperationsStaffApiService,
    private readonly auth: AuthService,
    private readonly errors: ErrorMessageService
  ) {}

  ngOnInit(): void {
    this.load();
  }

  load(): void {
    this.api.shipments().subscribe({
      next: (shipments) => {
        const queue = shipments.filter((shipment) => ['Packed', 'Shipped'].includes(this.shippingStatusLabel(shipment.status)));
        this.shipments.set(queue);
        this.selectedShipment.set(queue.find((item) => item.id === this.selectedShipment()?.id) ?? queue[0] ?? null);
      },
      error: (error) => this.message.set(this.errors.from(error))
    });
  }

  filteredShipments(): Shipment[] {
    const term = this.search.trim().toLowerCase();
    return this.shipments().filter((shipment) => {
      const searchable = [
        shipment.trackingNumber,
        shipment.orderId,
        shipment.customerId,
        shipment.deliveryPartnerId ?? '',
        shipment.shippingAddress
      ].join(' ').toLowerCase();
      return !term || searchable.includes(term);
    });
  }

  selectShipment(shipment: Shipment): void {
    this.selectedShipment.set(shipment);
  }

  ship(shipmentId: string): void {
    this.busyId.set(shipmentId);
    this.api.ship(shipmentId).subscribe({
      next: () => {
        this.busyId.set('');
        this.message.set('Shipment marked shipped. Admin and customer tracking now show shipped status.');
        this.load();
      },
      error: (error) => {
        this.busyId.set('');
        this.message.set(this.errors.from(error));
      }
    });
  }

  assign(shipmentId: string): void {
    if (!this.partnerId.trim()) {
      this.message.set('Delivery partner ID is required.');
      return;
    }

    this.busyId.set(shipmentId);
    this.api.assignPartner(shipmentId, this.partnerId.trim()).subscribe({
      next: () => {
        this.busyId.set('');
        this.message.set('Delivery partner assigned. Customer tracking and notifications stay aligned.');
        this.load();
      },
      error: (error) => {
        this.busyId.set('');
        this.message.set(this.errors.from(error));
      }
    });
  }

  packedShipments(): Shipment[] {
    return this.shipments().filter((shipment) => this.shippingStatusLabel(shipment.status) === 'Packed');
  }

  shippedShipments(): Shipment[] {
    return this.shipments().filter((shipment) => this.shippingStatusLabel(shipment.status) === 'Shipped');
  }

  needPartnerCount(): number {
    return this.shippedShipments().filter((shipment) => !shipment.deliveryPartnerId).length;
  }

  assignedCount(): number {
    return this.shippedShipments().filter((shipment) => Boolean(shipment.deliveryPartnerId)).length;
  }

  canMarkShipped(shipment: Shipment): boolean {
    return this.shippingStatusLabel(shipment.status) === 'Packed'
      && this.hasAnyRole(['WarehouseManager', 'Admin', 'SuperAdmin']);
  }

  canAssignPartner(shipment: Shipment): boolean {
    return this.shippingStatusLabel(shipment.status) === 'Shipped'
      && this.hasAnyRole(['DeliveryManager', 'Admin', 'SuperAdmin']);
  }

  orderedHistory(shipment: Shipment) {
    return [...shipment.statusHistory].sort((left, right) => Date.parse(left.changedAtUtc) - Date.parse(right.changedAtUtc));
  }

  shortId(id: string): string {
    return id ? id.slice(0, 8) : '-';
  }

  shippingStatusLabel(status: string | number): string {
    const map: Record<string, string> = {
      '1': 'Pending packing',
      PendingPacking: 'Pending packing',
      '2': 'Packed',
      Packed: 'Packed',
      '3': 'Shipped',
      Shipped: 'Shipped',
      '4': 'Out for delivery',
      OutForDelivery: 'Out for delivery',
      '5': 'Delivered',
      Delivered: 'Delivered',
      '6': 'Delivery failed',
      DeliveryFailed: 'Delivery failed',
      '7': 'Cancelled',
      Cancelled: 'Cancelled'
    };
    return map[String(status)] ?? String(status);
  }

  private hasAnyRole(roles: string[]): boolean {
    return roles.some((role) => this.auth.hasRole(role));
  }
}
