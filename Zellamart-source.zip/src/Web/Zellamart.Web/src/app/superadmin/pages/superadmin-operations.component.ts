import { Component } from '@angular/core';
import { AdminShippingComponent } from '../../admin/pages/admin-shipping.component';
import { OperationsDashboardComponent } from '../../operations/pages/operations-dashboard.component';
import { OperationsInventoryPageComponent } from '../../operations/pages/operations-inventory-page.component';
import { OperationsShipmentsPageComponent } from '../../operations/pages/operations-shipments-page.component';
import { PackingPageComponent } from '../../operations/pages/packing-page.component';
import { DeliveryPageComponent } from '../../operations/pages/delivery-page.component';
import { SupportReturnsPageComponent } from '../../support/pages/support-returns-page.component';
import { SupportTicketsPageComponent } from '../../support/pages/support-tickets-page.component';

@Component({
  selector: 'app-superadmin-operations',
  standalone: true,
  imports: [
    OperationsDashboardComponent,
    PackingPageComponent,
    OperationsShipmentsPageComponent,
    OperationsInventoryPageComponent,
    DeliveryPageComponent,
    AdminShippingComponent,
    SupportTicketsPageComponent,
    SupportReturnsPageComponent
  ],
  template: `
    <section class="dashboard-header">
      <div>
        <span class="eyebrow">SuperAdmin</span>
        <h1>Operations</h1>
        <p>Monitor fulfillment, delivery, inventory operations, support, and return queues from one platform view.</p>
      </div>
    </section>

    <section class="superadmin-module-stack">
      <app-operations-dashboard></app-operations-dashboard>
      <app-packing-page></app-packing-page>
      <app-operations-shipments-page></app-operations-shipments-page>
      <app-operations-inventory-page></app-operations-inventory-page>
      <app-delivery-page></app-delivery-page>
      <app-admin-shipping></app-admin-shipping>
      <app-support-tickets-page></app-support-tickets-page>
      <app-support-returns-page></app-support-returns-page>
    </section>
  `
})
export class SuperAdminOperationsComponent {}
