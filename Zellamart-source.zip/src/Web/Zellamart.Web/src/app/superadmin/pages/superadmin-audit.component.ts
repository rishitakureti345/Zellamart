import { Component } from '@angular/core';
import { AdminAuditLogsComponent } from '../../admin/pages/admin-audit-logs.component';

@Component({
  selector: 'app-superadmin-audit',
  standalone: true,
  imports: [AdminAuditLogsComponent],
  template: `
    <section class="dashboard-header">
      <div>
        <span class="eyebrow">SuperAdmin</span>
        <h1>Audit logs</h1>
        <p>Review platform activity across seller, catalog, refund, and user-access events.</p>
      </div>
    </section>

    <section class="superadmin-module-stack">
      <app-admin-audit-logs></app-admin-audit-logs>
    </section>
  `
})
export class SuperAdminAuditComponent {}
