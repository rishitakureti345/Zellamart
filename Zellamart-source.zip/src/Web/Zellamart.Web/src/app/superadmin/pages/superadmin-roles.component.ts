import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { catchError, forkJoin, of } from 'rxjs';
import { AdminRole, AdminUser } from '../../admin/models/admin.model';
import { AdminApiService } from '../../admin/services/admin-api.service';
import { ErrorMessageService } from '../../core/services/error-message.service';
import { EmptyStateComponent } from '../../shared/components/empty-state/empty-state.component';
import { StatusBadgeComponent } from '../../shared/components/status-badge/status-badge.component';
import { ToastComponent } from '../../shared/components/toast/toast.component';

const CORE_ROLES: AdminRole[] = [
  { id: 'preset-superadmin', name: 'SuperAdmin', description: 'Platform owner access across every workspace.' },
  { id: 'preset-admin', name: 'Admin', description: 'Marketplace operations management.' },
  { id: 'preset-customer', name: 'Customer', description: 'Shopping, orders, shipments, support, and returns.' },
  { id: 'preset-seller', name: 'Seller', description: 'Seller dashboard, products, inventory, earnings, and payouts.' },
  { id: 'preset-finance', name: 'FinanceManager', description: 'Finance reports, balances, refunds, and payouts.' },
  { id: 'preset-support-manager', name: 'SupportManager', description: 'Support and return workflow management.' },
  { id: 'preset-support-agent', name: 'SupportAgent', description: 'Assigned support ticket workflow.' },
  { id: 'preset-order-manager', name: 'OrderManager', description: 'Order management and fulfillment coordination.' },
  { id: 'preset-warehouse', name: 'WarehouseManager', description: 'Packing and shipping operations.' },
  { id: 'preset-inventory', name: 'InventoryStaff', description: 'Inventory stock operations.' },
  { id: 'preset-delivery-manager', name: 'DeliveryManager', description: 'Delivery assignment and status management.' },
  { id: 'preset-delivery-partner', name: 'DeliveryPartner', description: 'Delivery task status updates.' },
  { id: 'preset-payment', name: 'PaymentTeam', description: 'Payment operation support.' },
  { id: 'preset-product', name: 'ProductManager', description: 'Product approval and catalog operations.' },
  { id: 'preset-category', name: 'CategoryManager', description: 'Category operation support.' }
];

@Component({
  selector: 'app-superadmin-roles',
  standalone: true,
  imports: [CommonModule, FormsModule, EmptyStateComponent, StatusBadgeComponent, ToastComponent],
  template: `
    <section class="dashboard-header">
      <div>
        <span class="eyebrow">SuperAdmin</span>
        <h1>Roles & permissions</h1>
        <p>Review available roles, inspect assignments, and grant access to platform users.</p>
      </div>
      <button type="button" (click)="load()">Refresh</button>
    </section>

    <app-toast [message]="message()"></app-toast>

    <section class="control-metrics">
      <article class="metric"><span>Roles</span><strong>{{ roles().length }}</strong></article>
      <article class="metric"><span>Assigned users</span><strong>{{ assignedUsers() }}</strong></article>
      <article class="metric"><span>SuperAdmins</span><strong>{{ usersForRole('SuperAdmin').length }}</strong></article>
      <article class="metric"><span>Admins</span><strong>{{ usersForRole('Admin').length }}</strong></article>
    </section>

    <section class="ops-form-grid">
      <section class="surface dashboard-panel">
        <h2>Available roles</h2>
        <div class="action-row report-actions">
          <button type="button" (click)="createMissingCoreRoles()">Create missing core roles</button>
        </div>
        <div class="activity-list" *ngIf="roles().length; else noRoles">
          <button type="button" class="table-link" *ngFor="let role of roles()" (click)="selectRole(role)">
            <strong>{{ role.name }}</strong>
            <span>{{ role.description }}</span>
          </button>
        </div>
        <ng-template #noRoles>
          <app-empty-state title="No roles found" message="Create role rows before assigning platform access."></app-empty-state>
        </ng-template>
      </section>

      <section class="surface dashboard-panel">
        <form class="checkout-form" (ngSubmit)="createRole()">
          <h2>Create role</h2>
          <label>Name<input [(ngModel)]="newRoleName" name="newRoleName" maxlength="80" required></label>
          <label>Description<textarea [(ngModel)]="newRoleDescription" name="newRoleDescription" maxlength="240" rows="3" required></textarea></label>
          <button type="submit">Create role</button>
        </form>

        <form class="checkout-form" (ngSubmit)="assignRole()">
          <h2>Assign role</h2>
          <label>User
            <select [(ngModel)]="selectedUserId" name="selectedUserId" required>
              <option value="">Select user</option>
              <option *ngFor="let user of users()" [value]="user.id">{{ user.fullName }} - {{ user.email }}</option>
            </select>
          </label>
          <label>Role
            <select [(ngModel)]="selectedRoleName" name="selectedRoleName" required>
              <option value="">Select role</option>
              <option *ngFor="let role of roles()" [value]="role.name">{{ role.name }}</option>
            </select>
          </label>
          <button type="submit">Assign role</button>
        </form>
      </section>
    </section>

    <section class="surface dashboard-panel" *ngIf="selectedRole() as role">
      <div class="seller-detail-heading">
        <span class="eyebrow">Role detail</span>
        <h2>{{ role.name }}</h2>
        <p class="muted-line">{{ role.description }}</p>
      </div>

      <table *ngIf="usersForRole(role.name).length">
        <tr><th>User</th><th>Status</th><th>Roles</th></tr>
        <tr *ngFor="let user of usersForRole(role.name)">
          <td><strong>{{ user.fullName }}</strong><br><span class="muted-line">{{ user.email }}</span></td>
          <td><span class="status-pill" [class.status-muted]="!user.isActive">{{ user.isActive ? 'Active' : 'Suspended / blocked' }}</span></td>
          <td>
            <div class="chip-row">
              <app-status-badge *ngFor="let item of user.roles" [status]="item"></app-status-badge>
            </div>
          </td>
        </tr>
      </table>
      <app-empty-state *ngIf="!usersForRole(role.name).length" title="No users assigned" message="Assign this role to a user when they need this access."></app-empty-state>
    </section>
  `
})
export class SuperAdminRolesComponent implements OnInit {
  newRoleName = '';
  newRoleDescription = '';
  selectedUserId = '';
  selectedRoleName = '';
  readonly users = signal<AdminUser[]>([]);
  readonly roles = signal<AdminRole[]>([]);
  readonly selectedRole = signal<AdminRole | null>(null);
  readonly message = signal('');

  constructor(
    private readonly api: AdminApiService,
    private readonly errors: ErrorMessageService
  ) {}

  ngOnInit(): void {
    this.load();
  }

  load(): void {
    forkJoin({ users: this.api.users(), roles: this.api.roles() }).subscribe({
      next: ({ users, roles }) => {
        this.users.set(users);
        this.roles.set(roles);
        const selectedName = this.selectedRole()?.name;
        this.selectedRole.set(roles.find((role) => role.name === selectedName) ?? roles[0] ?? null);
      },
      error: (error) => this.message.set(this.errors.from(error))
    });
  }

  selectRole(role: AdminRole): void {
    this.selectedRole.set(role);
    this.selectedRoleName = role.name;
  }

  createMissingCoreRoles(): void {
    const existing = new Set(this.roles().map((role) => role.name.toLowerCase()));
    const missing = CORE_ROLES.filter((role) => !existing.has(role.name.toLowerCase()));
    if (!missing.length) {
      this.message.set('All core roles already exist.');
      return;
    }

    forkJoin(missing.map((role) => this.api.createRole(role.name, role.description).pipe(catchError(() => of(null)))))
      .subscribe({
        next: (created) => {
          const createdCount = created.filter(Boolean).length;
          this.message.set(`Created ${createdCount} core role${createdCount === 1 ? '' : 's'}.`);
          this.load();
        },
        error: (error) => this.message.set(this.errors.from(error))
      });
  }

  createRole(): void {
    if (!this.newRoleName.trim() || !this.newRoleDescription.trim()) {
      this.message.set('Role name and description are required.');
      return;
    }

    this.api.createRole(this.newRoleName, this.newRoleDescription).subscribe({
      next: (role) => {
        this.message.set('Role created.');
        this.newRoleName = '';
        this.newRoleDescription = '';
        this.selectedRoleName = role.name;
        this.selectedRole.set(role);
        this.load();
      },
      error: (error) => this.message.set(this.errors.from(error))
    });
  }

  assignRole(): void {
    if (!this.selectedUserId || !this.selectedRoleName) {
      this.message.set('Choose a user and role before assigning.');
      return;
    }

    this.api.assignRole(this.selectedUserId, this.selectedRoleName).subscribe({
      next: () => {
        this.message.set('Role assigned.');
        this.selectedUserId = '';
        this.load();
      },
      error: (error) => this.message.set(this.errors.from(error))
    });
  }

  usersForRole(roleName: string): AdminUser[] {
    return this.users().filter((user) => user.roles.includes(roleName));
  }

  assignedUsers(): number {
    return this.users().filter((user) => user.roles.length > 0).length;
  }
}
