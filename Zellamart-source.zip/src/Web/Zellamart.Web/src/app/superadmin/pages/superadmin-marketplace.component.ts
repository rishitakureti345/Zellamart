import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AdminCategoriesComponent } from '../../admin/pages/admin-categories.component';
import { AdminInventoryComponent } from '../../admin/pages/admin-inventory.component';
import { AdminOrdersComponent } from '../../admin/pages/admin-orders.component';
import { AdminProductsComponent } from '../../admin/pages/admin-products.component';
import { AdminReturnsComponent } from '../../admin/pages/admin-returns.component';
import { AdminSellersComponent } from '../../admin/pages/admin-sellers.component';

@Component({
  selector: 'app-superadmin-marketplace',
  standalone: true,
  imports: [
    CommonModule,
    AdminSellersComponent,
    AdminProductsComponent,
    AdminCategoriesComponent,
    AdminOrdersComponent,
    AdminInventoryComponent,
    AdminReturnsComponent
  ],
  template: `
    <section class="dashboard-header">
      <div>
        <span class="eyebrow">SuperAdmin</span>
        <h1>Marketplace</h1>
        <p>Run seller, catalog, order, inventory, and return controls from the platform owner workspace.</p>
      </div>
    </section>

    <section class="superadmin-module-stack">
      <app-admin-sellers></app-admin-sellers>
      <app-admin-products></app-admin-products>
      <app-admin-categories></app-admin-categories>
      <app-admin-orders></app-admin-orders>
      <app-admin-inventory></app-admin-inventory>
      <app-admin-returns></app-admin-returns>
    </section>
  `
})
export class SuperAdminMarketplaceComponent {}
