import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { forkJoin } from 'rxjs';
import { AdminRole, AdminUser } from '../../admin/models/admin.model';
import { AdminApiService } from '../../admin/services/admin-api.service';
import { ErrorMessageService } from '../../core/services/error-message.service';
import { EmptyStateComponent } from '../../shared/components/empty-state/empty-state.component';
import { StatusBadgeComponent } from '../../shared/components/status-badge/status-badge.component';
import { ToastComponent } from '../../shared/components/toast/toast.component';

@Component({
  selector: 'app-superadmin-users',
  standalone: true,
  imports: [CommonModule, FormsModule, EmptyStateComponent, StatusBadgeComponent, ToastComponent],
  template: `
    <section class="dashboard-header">
      <div>
        <span class="eyebrow">SuperAdmin</span>
        <h1>Users</h1>
        <p>Create staff users, review all platform accounts, and control account access.</p>
      </div>
      <button type="button" (click)="load()">Refresh</button>
    </section>

    <app-toast [message]="message()"></app-toast>

    <section class="metric-grid">
      <article class="metric-card"><span>Total users</span><strong>{{ users().length }}</strong></article>
      <article class="metric-card"><span>Active users</span><strong>{{ activeUsers().length }}</strong></article>
      <article class="metric-card"><span>Staff users</span><strong>{{ staffUsers().length }}</strong></article>
      <article class="metric-card"><span>Inactive accounts</span><strong>{{ inactiveUsers().length }}</strong></article>
    </section>

    <section class="ops-form-grid">
      <form class="surface checkout-form" (ngSubmit)="createStaff()">
        <h2>Create staff user</h2>
        <label>Name<input [(ngModel)]="staffName" name="staffName" required></label>
        <label>Email<input [(ngModel)]="staffEmail" name="staffEmail" type="email" required></label>
        <label>Password<input [(ngModel)]="staffPassword" name="staffPassword" type="password" required></label>
        <label>Initial role
          <select [(ngModel)]="staffRole" name="staffRole" required>
            <option value="">Select role</option>
            <option *ngFor="let role of staffRoleOptions()" [value]="role.name">{{ role.name }}</option>
          </select>
        </label>
        <button type="submit">Create staff</button>
      </form>

      <section class="surface dashboard-panel">
        <div class="seller-toolbar users-toolbar">
          <label>Search<input [(ngModel)]="search" placeholder="Name or email"></label>
          <label>Role
            <select [(ngModel)]="roleFilter">
              <option value="all">All roles</option>
              <option *ngFor="let role of roles()" [value]="role.name">{{ role.name }}</option>
            </select>
          </label>
          <label>Status
            <select [(ngModel)]="statusFilter">
              <option value="all">All status</option>
              <option value="active">Active</option>
              <option value="inactive">Suspended / blocked</option>
            </select>
          </label>
        </div>

        <table *ngIf="filteredUsers().length">
          <tr>
            <th>User</th>
            <th>Roles</th>
            <th>Status</th>
            <th>Actions</th>
          </tr>
          <tr *ngFor="let user of filteredUsers()" [class.selected-row]="selectedUser()?.id === user.id">
            <td>
              <button type="button" class="table-link" (click)="selectUser(user)">
                <strong>{{ user.fullName }}</strong><br>
                <span class="muted-line">{{ user.email }}</span>
              </button>
            </td>
            <td>
              <div class="chip-row">
                <app-status-badge *ngFor="let role of user.roles" [status]="role"></app-status-badge>
              </div>
            </td>
            <td><span class="status-pill" [class.status-muted]="!user.isActive">{{ statusLabel(user) }}</span></td>
            <td class="action-row">
              <button type="button" *ngIf="!user.isActive" class="ghost-light" (click)="activate(user.id)">Activate</button>
              <button type="button" *ngIf="user.isActive" class="ghost-light" (click)="suspend(user.id)">Suspend</button>
              <button type="button" *ngIf="user.isActive" class="text-danger" (click)="block(user.id)">Block</button>
            </td>
          </tr>
        </table>
        <app-empty-state *ngIf="!filteredUsers().length" title="No users found" message="Try another search, role, or status filter."></app-empty-state>
      </section>
    </section>

    <section class="surface seller-detail-pane" *ngIf="selectedUser() as user">
      <div class="seller-detail-heading">
        <span class="eyebrow">User detail</span>
        <h2>{{ user.fullName }}</h2>
        <p class="muted-line">{{ user.email }}</p>
      </div>
      <div class="seller-detail-grid">
        <div><span>Status</span><strong>{{ statusLabel(user) }}</strong></div>
        <div><span>Account type</span><strong>{{ isCustomer(user) ? 'Customer' : 'Staff / admin' }}</strong></div>
        <div><span>Roles</span><strong>{{ user.roles.join(', ') || 'No roles' }}</strong></div>
        <div><span>Permissions</span><strong>{{ user.permissions.length }}</strong></div>
      </div>
      <div class="permissions-grid" *ngIf="user.permissions.length">
        <span *ngFor="let permission of user.permissions">{{ permission }}</span>
      </div>
    </section>
  `
})
export class SuperAdminUsersComponent implements OnInit {
  search = '';
  roleFilter = 'all';
  statusFilter = 'all';
  staffName = '';
  staffEmail = '';
  staffPassword = '';
  staffRole = '';
  readonly users = signal<AdminUser[]>([]);
  readonly roles = signal<AdminRole[]>([]);
  readonly selectedUser = signal<AdminUser | null>(null);
  readonly message = signal('');

  constructor(
    private readonly api: AdminApiService,
    private readonly errors: ErrorMessageService
  ) {}

  ngOnInit(): void {
    this.load();
  }

  load(): void {
    forkJoin({ users: this.api.users(), roles: this.api.roles() }).subscribe({
      next: ({ users, roles }) => {
        this.users.set(users);
        this.roles.set(roles);
        const selectedId = this.selectedUser()?.id;
        this.selectedUser.set(users.find((user) => user.id === selectedId) ?? users[0] ?? null);
      },
      error: (error) => this.message.set(this.errors.from(error))
    });
  }

  filteredUsers(): AdminUser[] {
    const term = this.search.trim().toLowerCase();
    return this.users().filter((user) => {
      const roleMatches = this.roleFilter === 'all' || user.roles.includes(this.roleFilter);
      const statusMatches =
        this.statusFilter === 'all' ||
        (this.statusFilter === 'active' && user.isActive) ||
        (this.statusFilter === 'inactive' && !user.isActive);
      const searchable = `${user.fullName} ${user.email}`.toLowerCase();
      return roleMatches && statusMatches && (!term || searchable.includes(term));
    });
  }

  activeUsers(): AdminUser[] {
    return this.users().filter((user) => user.isActive);
  }

  staffUsers(): AdminUser[] {
    return this.users().filter((user) => !this.isCustomer(user));
  }

  inactiveUsers(): AdminUser[] {
    return this.users().filter((user) => !user.isActive);
  }

  staffRoleOptions(): AdminRole[] {
    return this.roles().filter((role) => role.name !== 'Customer');
  }

  selectUser(user: AdminUser): void {
    this.selectedUser.set(user);
  }

  createStaff(): void {
    this.api.createStaffUser({
      fullName: this.staffName,
      email: this.staffEmail,
      password: this.staffPassword,
      roleName: this.staffRole
    }).subscribe({
      next: () => {
        this.message.set('Staff user created.');
        this.staffName = '';
        this.staffEmail = '';
        this.staffPassword = '';
        this.staffRole = '';
        this.load();
      },
      error: (error) => this.message.set(this.errors.from(error))
    });
  }

  activate(userId: string): void {
    this.api.activateUser(userId).subscribe({
      next: () => {
        this.message.set('User activated.');
        this.load();
      },
      error: (error) => this.message.set(this.errors.from(error))
    });
  }

  suspend(userId: string): void {
    this.api.suspendUser(userId).subscribe({
      next: () => {
        this.message.set('User suspended.');
        this.load();
      },
      error: (error) => this.message.set(this.errors.from(error))
    });
  }

  block(userId: string): void {
    this.api.blockUser(userId).subscribe({
      next: () => {
        this.message.set('User blocked.');
        this.load();
      },
      error: (error) => this.message.set(this.errors.from(error))
    });
  }

  statusLabel(user: AdminUser): string {
    return user.isActive ? 'Active' : 'Suspended / blocked';
  }

  isCustomer(user: AdminUser): boolean {
    return user.roles.includes('Customer') && user.roles.length === 1;
  }
}
