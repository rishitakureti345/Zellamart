import { Component } from '@angular/core';
import { FinanceDashboardComponent } from '../../finance/pages/finance-dashboard.component';
import { FinancePayoutsComponent } from '../../finance/pages/finance-payouts.component';
import { FinanceRefundsComponent } from '../../finance/pages/finance-refunds.component';
import { FinanceSellerBalancesComponent } from '../../finance/pages/finance-seller-balances.component';
import { FinanceTransactionsComponent } from '../../finance/pages/finance-transactions.component';

@Component({
  selector: 'app-superadmin-finance',
  standalone: true,
  imports: [
    FinanceDashboardComponent,
    FinanceSellerBalancesComponent,
    FinancePayoutsComponent,
    FinanceTransactionsComponent,
    FinanceRefundsComponent
  ],
  template: `
    <section class="dashboard-header">
      <div>
        <span class="eyebrow">SuperAdmin</span>
        <h1>Finance</h1>
        <p>Oversee revenue, seller balances, payout approvals, transactions, and refund records.</p>
      </div>
    </section>

    <section class="superadmin-module-stack">
      <app-finance-dashboard></app-finance-dashboard>
      <app-finance-seller-balances></app-finance-seller-balances>
      <app-finance-payouts></app-finance-payouts>
      <app-finance-transactions></app-finance-transactions>
      <app-finance-refunds></app-finance-refunds>
    </section>
  `
})
export class SuperAdminFinanceComponent {}
