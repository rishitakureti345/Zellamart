import { Component } from '@angular/core';
import { AdminSettingsComponent } from '../../admin/pages/admin-settings.component';

@Component({
  selector: 'app-superadmin-settings',
  standalone: true,
  imports: [AdminSettingsComponent],
  template: `
    <section class="dashboard-header">
      <div>
        <span class="eyebrow">SuperAdmin</span>
        <h1>Platform settings</h1>
        <p>Manage marketplace-wide defaults, thresholds, payment configuration, and shipping settings.</p>
      </div>
    </section>

    <section class="superadmin-module-stack">
      <app-admin-settings></app-admin-settings>
    </section>
  `
})
export class SuperAdminSettingsComponent {}
