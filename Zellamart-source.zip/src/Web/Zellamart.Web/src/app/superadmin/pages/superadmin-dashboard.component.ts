import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { AdminProduct, AdminSeller, AdminUser } from '../../admin/models/admin.model';
import { Order } from '../../customer/models/order.model';
import { ReturnRequest, SupportTicket } from '../../customer/models/support.model';
import { AdminSummary, SellerPayout } from '../../core/models/finance.model';
import { MoneyPipe } from '../../shared/pipes/money.pipe';
import { ToastComponent } from '../../shared/components/toast/toast.component';
import { SuperAdminApiService } from '../services/superadmin-api.service';

@Component({
  selector: 'app-superadmin-dashboard',
  standalone: true,
  imports: [CommonModule, RouterLink, MoneyPipe, ToastComponent],
  template: `
    <section class="dashboard-header">
      <div>
        <span class="eyebrow">SuperAdmin</span>
        <h1>Platform command center</h1>
        <p>Users, roles, marketplace health, finance visibility, operations, audit, and settings in one workspace.</p>
      </div>
      <button type="button" (click)="load()">Refresh</button>
    </section>
    <app-toast [message]="message()"></app-toast>

    <section class="control-metrics">
      <article class="metric"><span>Total users</span><strong>{{ totalUsers() }}</strong></article>
      <article class="metric"><span>Active users</span><strong>{{ activeUsers() }}</strong></article>
      <article class="metric"><span>Admins</span><strong>{{ adminUsers() }}</strong></article>
      <article class="metric"><span>Sellers</span><strong>{{ sellerUsers() }}</strong></article>
      <article class="metric"><span>Customers</span><strong>{{ customerUsers() }}</strong></article>
      <article class="metric"><span>Pending sellers</span><strong>{{ pendingSellers().length }}</strong></article>
      <article class="metric"><span>Pending products</span><strong>{{ pendingProducts().length }}</strong></article>
      <article class="metric"><span>Total orders</span><strong>{{ orders().length }}</strong></article>
      <article class="metric"><span>Revenue</span><strong>{{ (financeSummary()?.totalSales || orderRevenue()) | money }}</strong></article>
      <article class="metric"><span>Refunds</span><strong>{{ (financeSummary()?.totalRefunds || refundTotal()) | money }}</strong></article>
      <article class="metric"><span>Open tickets</span><strong>{{ openTickets() }}</strong></article>
      <article class="metric"><span>Pending payouts</span><strong>{{ pendingPayouts() }}</strong></article>
    </section>

    <section class="grid">
      <a class="panel action-panel" routerLink="/superadmin/users">
        <span class="eyebrow">Users</span>
        <h2>Users and staff</h2>
        <p>{{ activeUsers() }} active of {{ totalUsers() }} accounts.</p>
      </a>
      <a class="panel action-panel" routerLink="/superadmin/roles">
        <span class="eyebrow">Access</span>
        <h2>Roles and permissions</h2>
        <p>{{ adminUsers() }} admin-level users, {{ sellerUsers() }} sellers, {{ customerUsers() }} customers.</p>
      </a>
      <a class="panel action-panel" routerLink="/superadmin/marketplace">
        <span class="eyebrow">Marketplace</span>
        <h2>Marketplace control</h2>
        <p>{{ pendingSellers().length }} seller applications and {{ pendingProducts().length }} products need review.</p>
      </a>
      <a class="panel action-panel" routerLink="/superadmin/finance">
        <span class="eyebrow">Finance</span>
        <h2>Finance oversight</h2>
        <p>{{ pendingPayouts() }} pending payouts, {{ (financeSummary()?.pendingPayoutAmount || 0) | money }} pending amount.</p>
      </a>
    </section>

    <section class="activity-grid">
      <article class="surface dashboard-panel activity-panel">
        <h2>Pending seller applications</h2>
        <div class="activity-list" *ngIf="pendingSellers().length; else noSellers">
          <a *ngFor="let seller of pendingSellers().slice(0, 5)" routerLink="/admin/sellers">
            <strong>{{ seller.businessName }}</strong>
            <span>{{ seller.ownerName }} &middot; {{ seller.contactEmail }}</span>
          </a>
        </div>
        <ng-template #noSellers><p class="muted-line">No seller applications need review.</p></ng-template>
      </article>

      <article class="surface dashboard-panel activity-panel">
        <h2>Pending product submissions</h2>
        <div class="activity-list" *ngIf="pendingProducts().length; else noProducts">
          <a *ngFor="let product of pendingProducts().slice(0, 5)" routerLink="/admin/products">
            <strong>{{ product.name }}</strong>
            <span>{{ product.price | money:product.currency }} &middot; {{ product.status }}</span>
          </a>
        </div>
        <ng-template #noProducts><p class="muted-line">No product submissions need review.</p></ng-template>
      </article>

      <article class="surface dashboard-panel activity-panel">
        <h2>Recent orders</h2>
        <div class="activity-list" *ngIf="recentOrders().length; else noOrders">
          <a *ngFor="let order of recentOrders()" routerLink="/admin/orders">
            <strong>{{ order.orderNumber || order.id }}</strong>
            <span>{{ order.status }} &middot; {{ order.subtotal | money:order.currency }}</span>
          </a>
        </div>
        <ng-template #noOrders><p class="muted-line">No orders are available yet.</p></ng-template>
      </article>

      <article class="surface dashboard-panel activity-panel">
        <h2>Support pressure</h2>
        <div class="activity-list" *ngIf="recentTickets().length; else noTickets">
          <a *ngFor="let ticket of recentTickets()" routerLink="/support/tickets">
            <strong>{{ ticket.subject }}</strong>
            <span>{{ ticket.status }} &middot; {{ ticket.type }}</span>
          </a>
        </div>
        <ng-template #noTickets><p class="muted-line">No support tickets are open right now.</p></ng-template>
      </article>
    </section>
  `
})
export class SuperAdminDashboardComponent implements OnInit {
  readonly users = signal<AdminUser[]>([]);
  readonly sellers = signal<AdminSeller[]>([]);
  readonly pendingSellers = signal<AdminSeller[]>([]);
  readonly pendingProducts = signal<AdminProduct[]>([]);
  readonly orders = signal<Order[]>([]);
  readonly tickets = signal<SupportTicket[]>([]);
  readonly returns = signal<ReturnRequest[]>([]);
  readonly financeSummary = signal<AdminSummary | null>(null);
  readonly payouts = signal<SellerPayout[]>([]);
  readonly message = signal('');

  constructor(private readonly superAdmin: SuperAdminApiService) {}

  ngOnInit(): void {
    this.load();
  }

  load(): void {
    this.message.set('');
    this.superAdmin.loadDashboard().subscribe({
      next: (summary) => {
        this.users.set(summary.users);
        this.sellers.set(summary.sellers);
        this.pendingSellers.set(summary.pendingSellers);
        this.pendingProducts.set(summary.pendingProducts);
        this.orders.set(summary.orders);
        this.tickets.set(summary.tickets);
        this.returns.set(summary.returns);
        this.financeSummary.set(summary.financeSummary);
        this.payouts.set(summary.payouts);
      },
      error: () => this.message.set('Could not load SuperAdmin dashboard.')
    });
  }

  totalUsers(): number {
    return this.users().length;
  }

  activeUsers(): number {
    return this.users().filter((user) => user.isActive).length;
  }

  adminUsers(): number {
    return this.users().filter((user) => user.roles.some((role) => ['Admin', 'SuperAdmin'].includes(role))).length;
  }

  sellerUsers(): number {
    return this.users().filter((user) => user.roles.includes('Seller')).length;
  }

  customerUsers(): number {
    return this.users().filter((user) => user.roles.includes('Customer')).length;
  }

  openTickets(): number {
    return this.tickets().filter((ticket) => !['resolved', 'closed', 'rejected'].includes(this.statusText(ticket.status))).length;
  }

  pendingPayouts(): number {
    return this.payouts().filter((payout) => !['paid', 'rejected', 'cancelled'].includes(this.statusText(payout.status))).length;
  }

  orderRevenue(): number {
    return this.orders().reduce((total, order) => total + order.subtotal, 0);
  }

  refundTotal(): number {
    return this.returns().reduce((total, item) => total + item.refundAmount, 0);
  }

  recentOrders(): Order[] {
    return this.latest(this.orders()).slice(0, 5);
  }

  recentTickets(): SupportTicket[] {
    return this.latest(this.tickets()).slice(0, 5);
  }

  private latest<T extends { createdAtUtc: string }>(items: T[]): T[] {
    return [...items].sort((left, right) => Date.parse(right.createdAtUtc) - Date.parse(left.createdAtUtc));
  }

  private statusText(status: string | number): string {
    return String(status).toLowerCase();
  }
}
