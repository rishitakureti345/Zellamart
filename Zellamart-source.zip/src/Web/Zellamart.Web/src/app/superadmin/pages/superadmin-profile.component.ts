import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../../core/services/auth.service';
import { StatusBadgeComponent } from '../../shared/components/status-badge/status-badge.component';
import { ToastComponent } from '../../shared/components/toast/toast.component';
import { WorkspaceSwitcherComponent } from '../../shared/components/workspace-switcher/workspace-switcher.component';

@Component({
  selector: 'app-superadmin-profile',
  standalone: true,
  imports: [CommonModule, FormsModule, StatusBadgeComponent, ToastComponent, WorkspaceSwitcherComponent],
  template: `
    <section class="dashboard-header">
      <div>
        <span class="eyebrow">Platform owner</span>
        <h1>SuperAdmin profile</h1>
        <p>Your account identity, elevated access, workspace availability, and contact details.</p>
      </div>
      <button type="button" class="ghost-light" (click)="logout()">Logout</button>
    </section>

    <app-toast [message]="message()"></app-toast>

    <app-workspace-switcher></app-workspace-switcher>

    <section class="metric-grid" *ngIf="auth.session() as session">
      <article class="metric-card"><span>Account status</span><strong>{{ session.isActive === false ? 'Inactive' : 'Active' }}</strong></article>
      <article class="metric-card"><span>Roles</span><strong>{{ session.roles.length }}</strong></article>
      <article class="metric-card"><span>Workspaces</span><strong>{{ auth.workspaces().length }}</strong></article>
      <article class="metric-card"><span>Permissions</span><strong>{{ session.permissions.length }}</strong></article>
    </section>

    <section class="settings-grid" *ngIf="auth.session() as session">
      <section class="surface profile-card">
        <div><span>Full name</span><strong>{{ session.fullName }}</strong></div>
        <div><span>Email</span><strong>{{ session.email }}</strong></div>
        <div><span>User ID</span><strong>{{ session.userId }}</strong></div>
        <div>
          <span>Roles</span>
          <p class="badge-row">
            <app-status-badge *ngFor="let role of session.roles" [status]="role"></app-status-badge>
          </p>
        </div>
        <div>
          <span>Workspaces</span>
          <p class="badge-row">
            <app-status-badge *ngFor="let workspace of auth.workspaces()" [status]="workspace.label"></app-status-badge>
          </p>
        </div>
        <div>
          <span>Default workspace</span>
          <strong>{{ activeWorkspaceLabel() }}</strong>
        </div>
      </section>

      <form class="surface checkout-form settings-form" (ngSubmit)="saveContact()">
        <h2>Contact details</h2>
        <label>Phone
          <input [(ngModel)]="phone" name="phone" maxlength="40" placeholder="Platform owner phone">
        </label>
        <label>Default shipping address
          <textarea [(ngModel)]="defaultShippingAddress" name="defaultShippingAddress" rows="5" maxlength="600" placeholder="Optional account address"></textarea>
        </label>
        <div class="action-row">
          <button type="submit" [disabled]="loading()">{{ loading() ? 'Saving...' : 'Save profile' }}</button>
          <button type="button" class="ghost-light" [disabled]="loading()" (click)="resetContact()">Reset</button>
        </div>
      </form>
    </section>
  `
})
export class SuperAdminProfileComponent implements OnInit {
  readonly message = signal('');
  readonly loading = signal(false);
  phone = '';
  defaultShippingAddress = '';

  constructor(
    readonly auth: AuthService,
    private readonly router: Router
  ) {}

  ngOnInit(): void {
    this.loadProfile();
  }

  saveContact(): void {
    this.loading.set(true);
    this.message.set('');
    this.auth.updateProfile({
      phone: this.phone,
      defaultShippingAddress: this.defaultShippingAddress
    }).subscribe({
      next: (result) => {
        this.phone = result.value.phone ?? '';
        this.defaultShippingAddress = result.value.defaultShippingAddress ?? '';
        this.message.set('SuperAdmin profile saved.');
        this.loading.set(false);
      },
      error: () => {
        this.message.set('Could not save SuperAdmin profile.');
        this.loading.set(false);
      }
    });
  }

  resetContact(): void {
    this.phone = '';
    this.defaultShippingAddress = '';
    this.saveContact();
  }

  activeWorkspaceLabel(): string {
    return this.auth.activeWorkspace()?.label ?? 'SuperAdmin';
  }

  logout(): void {
    this.auth.logout();
    void this.router.navigateByUrl('/');
  }

  private loadProfile(): void {
    const session = this.auth.session();
    this.phone = session?.phone ?? '';
    this.defaultShippingAddress = session?.defaultShippingAddress ?? '';

    this.loading.set(true);
    this.auth.profile().subscribe({
      next: (result) => {
        this.phone = result.value.phone ?? '';
        this.defaultShippingAddress = result.value.defaultShippingAddress ?? '';
        this.loading.set(false);
      },
      error: () => {
        this.message.set('Could not refresh SuperAdmin profile.');
        this.loading.set(false);
      }
    });
  }
}
