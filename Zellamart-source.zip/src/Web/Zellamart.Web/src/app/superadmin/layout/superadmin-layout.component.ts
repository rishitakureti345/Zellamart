import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';
import { StoreNavbarComponent } from '../../shared/components/store-navbar/store-navbar.component';
import { AuthService } from '../../core/services/auth.service';

interface SuperAdminNavItem {
  label: string;
  path: string;
}

@Component({
  selector: 'app-superadmin-layout',
  standalone: true,
  imports: [CommonModule, RouterLink, RouterLinkActive, RouterOutlet, StoreNavbarComponent],
  template: `
    <app-store-navbar></app-store-navbar>
    <main class="admin-shell">
      <aside class="admin-sidebar">
        <section class="admin-identity" *ngIf="auth.session() as session">
          <span>SuperAdmin workspace</span>
          <strong>{{ session.fullName }}</strong>
          <small>{{ session.email }}</small>
          <p>{{ session.roles.join(', ') }}</p>
        </section>

        <nav aria-label="SuperAdmin navigation">
          <a *ngFor="let item of items" [routerLink]="item.path" routerLinkActive="active">
            {{ item.label }}
          </a>
        </nav>
      </aside>

      <section class="admin-workspace">
        <header class="admin-topbar" *ngIf="auth.session() as session">
          <div>
            <span class="eyebrow">Platform owner</span>
            <strong>{{ session.email }}</strong>
          </div>
          <button type="button" class="ghost-light" (click)="logout()">Logout</button>
        </header>

        <section class="dashboard-content"><router-outlet></router-outlet></section>
      </section>
    </main>
  `
})
export class SuperAdminLayoutComponent {
  readonly items: SuperAdminNavItem[] = [
    { label: 'Dashboard', path: '/superadmin/dashboard' },
    { label: 'Profile', path: '/superadmin/profile' },
    { label: 'Users', path: '/superadmin/users' },
    { label: 'Roles & Permissions', path: '/superadmin/roles' },
    { label: 'Marketplace', path: '/superadmin/marketplace' },
    { label: 'Finance', path: '/superadmin/finance' },
    { label: 'Operations', path: '/superadmin/operations' },
    { label: 'Audit Logs', path: '/superadmin/audit' },
    { label: 'Platform Settings', path: '/superadmin/settings' }
  ];

  constructor(
    readonly auth: AuthService,
    private readonly router: Router
  ) {}

  logout(): void {
    this.auth.logout();
    void this.router.navigateByUrl('/');
  }
}
