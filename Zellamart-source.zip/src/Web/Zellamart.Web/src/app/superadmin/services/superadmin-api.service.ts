import { Injectable } from '@angular/core';
import { catchError, forkJoin, map, Observable, of } from 'rxjs';
import { AdminProduct, AdminSeller, AdminUser } from '../../admin/models/admin.model';
import { AdminApiService } from '../../admin/services/admin-api.service';
import { Order } from '../../customer/models/order.model';
import { ReturnRequest, SupportTicket } from '../../customer/models/support.model';
import { AdminSummary, SellerPayout } from '../../core/models/finance.model';
import { FinanceApiService } from '../../core/services/finance-api.service';
import { OperationsStaffApiService } from '../../operations/services/operations-staff-api.service';
import { SupportStaffApiService } from '../../support/services/support-staff-api.service';

export interface SuperAdminDashboardSummary {
  users: AdminUser[];
  sellers: AdminSeller[];
  pendingSellers: AdminSeller[];
  pendingProducts: AdminProduct[];
  orders: Order[];
  tickets: SupportTicket[];
  returns: ReturnRequest[];
  financeSummary: AdminSummary | null;
  payouts: SellerPayout[];
}

@Injectable({ providedIn: 'root' })
export class SuperAdminApiService {
  constructor(
    private readonly admin: AdminApiService,
    private readonly finance: FinanceApiService,
    private readonly operations: OperationsStaffApiService,
    private readonly support: SupportStaffApiService
  ) {}

  loadDashboard(): Observable<SuperAdminDashboardSummary> {
    return forkJoin({
      users: this.admin.users().pipe(catchError(() => of([]))),
      sellers: this.admin.sellers().pipe(catchError(() => of([]))),
      pendingSellers: this.admin.pendingSellers().pipe(catchError(() => of([]))),
      pendingProducts: this.admin.pendingProducts().pipe(catchError(() => of([]))),
      orders: this.operations.orders().pipe(catchError(() => of([]))),
      tickets: this.support.tickets().pipe(catchError(() => of([]))),
      returns: this.support.returns().pipe(catchError(() => of([]))),
      financeSummary: this.finance.adminSummary().pipe(
        map((result) => result.value),
        catchError(() => of(null))
      ),
      payouts: this.finance.adminPayouts().pipe(
        map((result) => result.value ?? []),
        catchError(() => of([]))
      )
    });
  }
}
