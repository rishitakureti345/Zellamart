import { Category, Product } from '../../public/models/catalog.model';
import { SellerProfile } from '../../seller/models/seller.model';
import { AdminSummary, SellerBalanceRow } from '../../core/models/finance.model';

export type AdminSeller = SellerProfile;
export type AdminProduct = Product;
export type AdminCategory = Category;
export type AdminFinanceSummary = AdminSummary;
export type AdminSellerBalance = SellerBalanceRow;

export interface AdminUser {
  id: string;
  fullName: string;
  email: string;
  isActive: boolean;
  roles: string[];
  permissions: string[];
}

export interface AdminRole {
  id: string;
  name: string;
  description: string;
}

export interface AdminStockMovement {
  id: string;
  inventoryItemId: string;
  productId: string;
  sellerId: string;
  type: string | number;
  quantityChange: number;
  quantityAfter: number;
  reason: string;
  referenceId?: string | null;
  changedByUserId?: string | null;
  changedAtUtc: string;
}
