import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';
import { StoreNavbarComponent } from '../../shared/components/store-navbar/store-navbar.component';
import { AuthService } from '../../core/services/auth.service';

interface AdminNavItem {
  label: string;
  path: string;
}

@Component({
  selector: 'app-admin-layout',
  standalone: true,
  imports: [CommonModule, RouterLink, RouterLinkActive, RouterOutlet, StoreNavbarComponent],
  template: `
    <app-store-navbar></app-store-navbar>
    <main class="admin-shell">
      <aside class="admin-sidebar">
        <section class="admin-identity" *ngIf="auth.session() as session">
          <span>Admin workspace</span>
          <strong>{{ session.fullName }}</strong>
          <small>{{ session.email }}</small>
          <p>{{ session.roles.join(', ') }}</p>
        </section>

        <nav aria-label="Admin navigation">
          <a *ngFor="let item of items" [routerLink]="item.path" routerLinkActive="active">
            {{ item.label }}
          </a>
        </nav>
      </aside>

      <section class="admin-workspace">
        <header class="admin-topbar" *ngIf="auth.session() as session">
          <div>
            <span class="eyebrow">Control center</span>
            <strong>{{ session.email }}</strong>
          </div>
          <button type="button" class="ghost-light" (click)="logout()">Logout</button>
        </header>
        <section class="dashboard-content"><router-outlet></router-outlet></section>
      </section>
    </main>
  `
})
export class AdminLayoutComponent {
  readonly items: AdminNavItem[] = [
    { label: 'Dashboard', path: '/admin/dashboard' },
    { label: 'Profile', path: '/admin/profile' },
    { label: 'Sellers', path: '/admin/sellers' },
    { label: 'Products', path: '/admin/products' },
    { label: 'Categories', path: '/admin/categories' },
    { label: 'Users & Roles', path: '/admin/users' },
    { label: 'Orders', path: '/admin/orders' },
    { label: 'Inventory', path: '/admin/inventory' },
    { label: 'Shipping', path: '/admin/shipping' },
    { label: 'Support', path: '/admin/support' },
    { label: 'Returns & Refunds', path: '/admin/returns' },
    { label: 'Finance', path: '/finance' },
    { label: 'Notifications', path: '/admin/notifications' },
    { label: 'Reports', path: '/admin/reports' },
    { label: 'Audit Logs', path: '/admin/audit-logs' },
    { label: 'Settings', path: '/admin/settings' }
  ];

  constructor(
    readonly auth: AuthService,
    private readonly router: Router
  ) {}

  logout(): void {
    this.auth.logout();
    void this.router.navigateByUrl('/');
  }
}
