import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { map, Observable, switchMap } from 'rxjs';
import { ApiResult } from '../../core/models/api-result.model';
import { AdminCategory, AdminFinanceSummary, AdminProduct, AdminRole, AdminSeller, AdminSellerBalance, AdminStockMovement, AdminUser } from '../models/admin.model';
import { Order, Payment, Shipment } from '../../customer/models/order.model';
import { InventoryItem } from '../../seller/models/seller.model';
import { NotificationItem, ReturnRequest, SupportTicket } from '../../customer/models/support.model';

interface CategoryWriteRequest {
  name?: string;
  slug?: string | null;
  description?: string | null;
  parentCategoryId?: string | null;
}

interface CreateStaffUserRequest {
  fullName: string;
  email: string;
  password: string;
  roleName: string;
}

@Injectable({ providedIn: 'root' })
export class AdminApiService {
  constructor(private readonly http: HttpClient) {}

  pendingSellers(): Observable<AdminSeller[]> {
    return this.http.get<ApiResult<AdminSeller[]>>('/api/sellers/pending').pipe(map((result) => result.value ?? []));
  }

  sellers(): Observable<AdminSeller[]> {
    return this.http.get<ApiResult<AdminSeller[]>>('/api/sellers/admin/all').pipe(map((result) => result.value ?? []));
  }

  users(): Observable<AdminUser[]> {
    return this.http.get<ApiResult<AdminUser[]>>('/api/users').pipe(map((result) => result.value ?? []));
  }

  roles(): Observable<AdminRole[]> {
    return this.http.get<ApiResult<AdminRole[]>>('/api/roles').pipe(map((result) => result.value ?? []));
  }

  createRole(name: string, description: string): Observable<AdminRole> {
    return this.http.post<ApiResult<AdminRole>>('/api/roles', { name, description }).pipe(map((result) => result.value));
  }

  createStaffUser(request: CreateStaffUserRequest): Observable<AdminUser> {
    return this.http.post<ApiResult<AdminUser>>('/api/users/staff', request).pipe(map((result) => result.value));
  }

  assignRole(userId: string, roleName: string): Observable<void> {
    return this.http.post<ApiResult<unknown>>('/api/roles/assign', { userId, roleName }).pipe(map(() => undefined));
  }

  activateUser(userId: string): Observable<AdminUser> {
    return this.http.post<ApiResult<AdminUser>>(`/api/users/${userId}/activate`, {}).pipe(map((result) => result.value));
  }

  suspendUser(userId: string): Observable<AdminUser> {
    return this.http.post<ApiResult<AdminUser>>(`/api/users/${userId}/suspend`, {}).pipe(map((result) => result.value));
  }

  blockUser(userId: string): Observable<AdminUser> {
    return this.http.post<ApiResult<AdminUser>>(`/api/users/${userId}/block`, {}).pipe(map((result) => result.value));
  }

  approveSeller(sellerId: string): Observable<AdminSeller> {
    return this.http.post<ApiResult<AdminSeller>>(`/api/sellers/${sellerId}/approve`, {}).pipe(map((result) => result.value));
  }

  rejectSeller(sellerId: string, reason: string): Observable<AdminSeller> {
    return this.http.post<ApiResult<AdminSeller>>(`/api/sellers/${sellerId}/reject`, { reason }).pipe(map((result) => result.value));
  }

  suspendSeller(sellerId: string, reason: string): Observable<AdminSeller> {
    return this.http.post<ApiResult<AdminSeller>>(`/api/sellers/${sellerId}/suspend`, { reason }).pipe(map((result) => result.value));
  }

  reactivateSeller(sellerId: string): Observable<AdminSeller> {
    return this.http.post<ApiResult<AdminSeller>>(`/api/sellers/${sellerId}/reactivate`, {}).pipe(map((result) => result.value));
  }

  pendingProducts(): Observable<AdminProduct[]> {
    return this.http.get<ApiResult<AdminProduct[]>>('/api/products/pending').pipe(map((result) => result.value ?? []));
  }

  products(): Observable<AdminProduct[]> {
    return this.http.get<ApiResult<AdminProduct[]>>('/api/products/admin/all').pipe(map((result) => result.value ?? []));
  }

  approveProduct(productId: string): Observable<AdminProduct> {
    return this.http.post<ApiResult<AdminProduct>>(`/api/products/${productId}/approve`, {}).pipe(map((result) => result.value));
  }

  rejectProduct(productId: string, reason: string): Observable<AdminProduct> {
    return this.http.post<ApiResult<AdminProduct>>(`/api/products/${productId}/reject`, { reason }).pipe(map((result) => result.value));
  }

  disableProduct(productId: string, reason: string): Observable<AdminProduct> {
    return this.http.post<ApiResult<AdminProduct>>(`/api/products/${productId}/disable`, { reason }).pipe(map((result) => result.value));
  }

  updateProduct(productId: string, request: {
    categoryId: string;
    name: string;
    slug?: string | null;
    description: string;
    price: number;
    currency: string;
    imageUrl?: string | null;
  }): Observable<AdminProduct> {
    return this.http.put<ApiResult<AdminProduct>>(`/api/products/${productId}`, request).pipe(map((result) => result.value));
  }

  sellerProducts(sellerId: string): Observable<AdminProduct[]> {
    return this.http.get<ApiResult<AdminProduct[]>>(`/api/products/seller/${sellerId}`).pipe(map((result) => result.value ?? []));
  }

  sellerOrders(sellerId: string): Observable<Order[]> {
    return this.http.get<ApiResult<Order[]>>(`/api/orders/seller/${sellerId}`).pipe(map((result) => result.value ?? []));
  }

  orders(): Observable<Order[]> {
    return this.http.get<ApiResult<Order[]>>('/api/orders/admin/all').pipe(map((result) => result.value ?? []));
  }

  order(orderId: string): Observable<Order> {
    return this.http.get<ApiResult<Order>>(`/api/orders/${orderId}`).pipe(map((result) => result.value));
  }

  orderPayments(orderId: string): Observable<Payment[]> {
    return this.http.get<ApiResult<Payment[]>>(`/api/payments/admin/order/${orderId}`).pipe(map((result) => result.value ?? []));
  }

  orderShipment(orderId: string): Observable<Shipment> {
    return this.http.get<ApiResult<Shipment>>(`/api/shipping/admin/order/${orderId}`).pipe(map((result) => result.value));
  }

  shipments(): Observable<Shipment[]> {
    return this.http.get<ApiResult<Shipment[]>>('/api/shipping/admin/all').pipe(map((result) => result.value ?? []));
  }

  packShipment(shipmentId: string): Observable<Shipment> {
    return this.http.post<ApiResult<Shipment>>(`/api/shipping/${shipmentId}/pack`, {}).pipe(map((result) => result.value));
  }

  shipShipment(shipmentId: string): Observable<Shipment> {
    return this.http.post<ApiResult<Shipment>>(`/api/shipping/${shipmentId}/ship`, {}).pipe(map((result) => result.value));
  }

  assignDeliveryPartner(shipmentId: string, deliveryPartnerId: string): Observable<Shipment> {
    return this.http.post<ApiResult<Shipment>>(`/api/shipping/${shipmentId}/assign-partner`, { deliveryPartnerId })
      .pipe(map((result) => result.value));
  }

  markOutForDelivery(shipmentId: string): Observable<Shipment> {
    return this.http.post<ApiResult<Shipment>>(`/api/shipping/${shipmentId}/out-for-delivery`, {}).pipe(map((result) => result.value));
  }

  markDelivered(shipmentId: string): Observable<Shipment> {
    return this.http.post<ApiResult<Shipment>>(`/api/shipping/${shipmentId}/delivered`, {}).pipe(map((result) => result.value));
  }

  markDeliveryFailed(shipmentId: string, reason: string): Observable<Shipment> {
    return this.http.post<ApiResult<Shipment>>(`/api/shipping/${shipmentId}/delivery-failed`, { reason })
      .pipe(map((result) => result.value));
  }

  cancelOrder(orderId: string, reason: string): Observable<Order> {
    return this.http.post<ApiResult<Order>>(`/api/orders/admin/${orderId}/cancel`, { reason }).pipe(map((result) => result.value));
  }

  forceOrderStatus(orderId: string, status: string | number, note: string): Observable<Order> {
    return this.http.post<ApiResult<Order>>(`/api/orders/admin/${orderId}/force-status`, { status, note }).pipe(map((result) => result.value));
  }

  productInventory(productId: string): Observable<InventoryItem> {
    return this.http.get<ApiResult<InventoryItem>>(`/api/inventory/product/${productId}`).pipe(map((result) => result.value));
  }

  inventory(): Observable<InventoryItem[]> {
    return this.http.get<ApiResult<InventoryItem[]>>('/api/inventory/admin/all').pipe(map((result) => result.value ?? []));
  }

  addStock(inventoryItemId: string, quantity: number, reason: string): Observable<InventoryItem> {
    return this.http.post<ApiResult<InventoryItem>>(`/api/inventory/${inventoryItemId}/stock/add`, {
      quantity,
      reason,
      referenceId: null
    }).pipe(map((result) => result.value));
  }

  setStock(inventoryItemId: string, quantityOnHand: number, reason: string): Observable<InventoryItem> {
    return this.http.post<ApiResult<InventoryItem>>(`/api/inventory/${inventoryItemId}/stock/set`, {
      quantityOnHand,
      reason,
      referenceId: null
    }).pipe(map((result) => result.value));
  }

  stockMovements(inventoryItemId: string): Observable<AdminStockMovement[]> {
    return this.http.get<ApiResult<AdminStockMovement[]>>(`/api/inventory/${inventoryItemId}/movements`)
      .pipe(map((result) => result.value ?? []));
  }

  supportTickets(): Observable<SupportTicket[]> {
    return this.http.get<ApiResult<SupportTicket[]>>('/api/support/tickets/admin/all').pipe(map((result) => result.value ?? []));
  }

  assignSupportTicket(ticketId: string, agentId: string): Observable<SupportTicket> {
    return this.http.post<ApiResult<SupportTicket>>(`/api/support/tickets/${ticketId}/assign`, { agentId })
      .pipe(map((result) => result.value));
  }

  replySupportTicket(ticketId: string, message: string): Observable<SupportTicket> {
    return this.http.post<ApiResult<SupportTicket>>(`/api/support/tickets/admin/${ticketId}/messages`, { message })
      .pipe(map((result) => result.value));
  }

  resolveSupportTicket(ticketId: string): Observable<SupportTicket> {
    return this.http.post<ApiResult<SupportTicket>>(`/api/support/tickets/${ticketId}/resolve`, {}).pipe(map((result) => result.value));
  }

  closeSupportTicket(ticketId: string): Observable<SupportTicket> {
    return this.http.post<ApiResult<SupportTicket>>(`/api/support/tickets/admin/${ticketId}/close`, {}).pipe(map((result) => result.value));
  }

  returns(): Observable<ReturnRequest[]> {
    return this.http.get<ApiResult<ReturnRequest[]>>('/api/support/returns/admin/all').pipe(map((result) => result.value ?? []));
  }

  approveReturn(returnId: string): Observable<ReturnRequest> {
    return this.http.post<ApiResult<ReturnRequest>>(`/api/support/returns/${returnId}/approve`, {}).pipe(map((result) => result.value));
  }

  rejectReturn(returnId: string, reason: string): Observable<ReturnRequest> {
    return this.http.post<ApiResult<ReturnRequest>>(`/api/support/returns/${returnId}/reject`, { reason }).pipe(map((result) => result.value));
  }

  markReturnPickedUp(returnId: string): Observable<ReturnRequest> {
    return this.http.post<ApiResult<ReturnRequest>>(`/api/support/returns/${returnId}/mark-picked-up`, {}).pipe(map((result) => result.value));
  }

  approveRefund(returnId: string): Observable<ReturnRequest> {
    return this.http.post<ApiResult<ReturnRequest>>(`/api/support/returns/${returnId}/refund`, {}).pipe(
      map((result) => result.value),
      switchMap((returnRequest) => this.http.post<ApiResult<unknown>>('/api/finance/refunds/create-for-return', { returnId }).pipe(
        map(() => returnRequest)
      ))
    );
  }

  rejectRefund(returnId: string, reason: string): Observable<ReturnRequest> {
    return this.http.post<ApiResult<ReturnRequest>>(`/api/support/returns/${returnId}/refund/reject`, { reason })
      .pipe(map((result) => result.value));
  }

  notifications(): Observable<NotificationItem[]> {
    return this.http.get<ApiResult<NotificationItem[]>>('/api/notifications/admin/all').pipe(map((result) => result.value ?? []));
  }

  createNotification(userId: string, type: string, title: string, message: string): Observable<NotificationItem> {
    return this.http.post<ApiResult<NotificationItem>>('/api/notifications', {
      userId,
      type,
      title,
      message
    }).pipe(map((result) => result.value));
  }

  categories(): Observable<AdminCategory[]> {
    return this.http.get<ApiResult<AdminCategory[]>>('/api/categories/admin/all').pipe(map((result) => result.value ?? []));
  }

  createCategory(request: CategoryWriteRequest): Observable<AdminCategory> {
    return this.http.post<ApiResult<AdminCategory>>('/api/categories', request).pipe(map((result) => result.value));
  }

  updateCategory(categoryId: string, request: CategoryWriteRequest): Observable<AdminCategory> {
    return this.http.put<ApiResult<AdminCategory>>(`/api/categories/${categoryId}`, request).pipe(map((result) => result.value));
  }

  deactivateCategory(categoryId: string): Observable<AdminCategory> {
    return this.http.delete<ApiResult<AdminCategory>>(`/api/categories/${categoryId}`).pipe(map((result) => result.value));
  }

  activateCategory(categoryId: string): Observable<AdminCategory> {
    return this.http.post<ApiResult<AdminCategory>>(`/api/categories/${categoryId}/activate`, {}).pipe(map((result) => result.value));
  }

  financeSummary(): Observable<AdminFinanceSummary> {
    return this.http.get<ApiResult<AdminFinanceSummary>>('/api/finance/admin/summary').pipe(map((result) => result.value));
  }

  sellerBalances(): Observable<AdminSellerBalance[]> {
    return this.http.get<ApiResult<AdminSellerBalance[]>>('/api/finance/admin/seller-balances').pipe(map((result) => result.value ?? []));
  }
}
