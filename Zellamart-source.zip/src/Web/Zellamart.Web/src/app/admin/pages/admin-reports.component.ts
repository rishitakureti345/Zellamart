import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { catchError, forkJoin, of } from 'rxjs';
import { AdminApiService } from '../services/admin-api.service';
import { AdminFinanceSummary, AdminProduct, AdminSeller, AdminSellerBalance, AdminUser } from '../models/admin.model';
import { Order } from '../../customer/models/order.model';
import { ReturnRequest, SupportTicket } from '../../customer/models/support.model';
import { MoneyPipe } from '../../shared/pipes/money.pipe';
import { StatusBadgeComponent } from '../../shared/components/status-badge/status-badge.component';
import { EmptyStateComponent } from '../../shared/components/empty-state/empty-state.component';
import { ToastComponent } from '../../shared/components/toast/toast.component';

type ReportType = 'sales' | 'sellers' | 'products' | 'orders' | 'refunds' | 'customers' | 'support';

@Component({
  selector: 'app-admin-reports',
  standalone: true,
  imports: [CommonModule, FormsModule, MoneyPipe, StatusBadgeComponent, EmptyStateComponent, ToastComponent],
  template: `
    <section class="dashboard-header">
      <div>
        <span class="eyebrow">Reports</span>
        <h1>Admin reports</h1>
        <p>Filter, review, and export marketplace business data.</p>
      </div>
      <button (click)="load()">Refresh</button>
    </section>

    <app-toast [message]="message()"></app-toast>

    <section class="metric-grid">
      <article class="metric-card"><span>Sales</span><strong>{{ salesTotal() | money }}</strong></article>
      <article class="metric-card"><span>Orders</span><strong>{{ filteredOrders().length }}</strong></article>
      <article class="metric-card"><span>Refunds</span><strong>{{ refundTotal() | money }}</strong></article>
      <article class="metric-card"><span>Open support</span><strong>{{ openSupportCount() }}</strong></article>
    </section>

    <section class="surface dashboard-panel">
      <div class="report-tabs">
        <button *ngFor="let report of reports" [class.active-tab]="activeReport() === report.id" (click)="selectReport(report.id)">
          {{ report.label }}
        </button>
      </div>

      <section class="seller-toolbar report-toolbar">
        <label>Search<input [(ngModel)]="search" placeholder="Search current report"></label>
        <label>From<input [(ngModel)]="dateFrom" type="date"></label>
        <label>To<input [(ngModel)]="dateTo" type="date"></label>
        <label>Status
          <select [(ngModel)]="statusFilter">
            <option value="all">All statuses</option>
            <option *ngFor="let status of statusOptions()" [value]="status">{{ status }}</option>
          </select>
        </label>
      </section>

      <div class="action-row report-actions">
        <button (click)="exportCurrentReport()">Download CSV</button>
        <button class="ghost-light" (click)="resetFilters()">Reset filters</button>
      </div>
    </section>

    <section class="surface dashboard-panel" [ngSwitch]="activeReport()">
      <ng-container *ngSwitchCase="'sales'">
        <h2>Sales report</h2>
        <table *ngIf="filteredOrders().length">
          <tr><th>Order</th><th>Status</th><th>Customer</th><th>Items</th><th>Total</th><th>Created</th></tr>
          <tr *ngFor="let order of filteredOrders()">
            <td>{{ order.orderNumber }}</td>
            <td><app-status-badge kind="order" [status]="order.status"></app-status-badge></td>
            <td>{{ order.customerId }}</td>
            <td>{{ order.items.length }}</td>
            <td>{{ order.subtotal | money:order.currency }}</td>
            <td>{{ order.createdAtUtc | date:'medium' }}</td>
          </tr>
        </table>
      </ng-container>

      <ng-container *ngSwitchCase="'sellers'">
        <h2>Seller report</h2>
        <table *ngIf="filteredSellers().length">
          <tr><th>Business</th><th>Owner</th><th>Email</th><th>Status</th><th>Available</th><th>Pending</th><th>Refunds</th></tr>
          <tr *ngFor="let seller of filteredSellers()">
            <td>{{ seller.businessName }}</td>
            <td>{{ seller.ownerName }}</td>
            <td>{{ seller.contactEmail }}</td>
            <td><app-status-badge kind="seller" [status]="seller.status"></app-status-badge></td>
            <td>{{ (sellerBalance(seller.id)?.availableBalance || 0) | money }}</td>
            <td>{{ (sellerBalance(seller.id)?.pendingEarnings || 0) | money }}</td>
            <td>{{ (sellerBalance(seller.id)?.refundDeductions || 0) | money }}</td>
          </tr>
        </table>
      </ng-container>

      <ng-container *ngSwitchCase="'products'">
        <h2>Product report</h2>
        <table *ngIf="filteredProducts().length">
          <tr><th>Product</th><th>Seller</th><th>Category</th><th>Status</th><th>Price</th></tr>
          <tr *ngFor="let product of filteredProducts()">
            <td>{{ product.name }}</td>
            <td>{{ product.sellerId }}</td>
            <td>{{ product.categoryId }}</td>
            <td><app-status-badge kind="product" [status]="product.status"></app-status-badge></td>
            <td>{{ product.price | money:product.currency }}</td>
          </tr>
        </table>
      </ng-container>

      <ng-container *ngSwitchCase="'orders'">
        <h2>Order report</h2>
        <table *ngIf="filteredOrders().length">
          <tr><th>Order</th><th>Customer</th><th>Status</th><th>Subtotal</th><th>Created</th></tr>
          <tr *ngFor="let order of filteredOrders()">
            <td>{{ order.orderNumber }}</td>
            <td>{{ order.customerId }}</td>
            <td><app-status-badge kind="order" [status]="order.status"></app-status-badge></td>
            <td>{{ order.subtotal | money:order.currency }}</td>
            <td>{{ order.createdAtUtc | date:'medium' }}</td>
          </tr>
        </table>
      </ng-container>

      <ng-container *ngSwitchCase="'refunds'">
        <h2>Refund report</h2>
        <table *ngIf="filteredReturns().length">
          <tr><th>Return</th><th>Order</th><th>Customer</th><th>Status</th><th>Refund</th><th>Created</th></tr>
          <tr *ngFor="let item of filteredReturns()">
            <td>{{ item.id }}</td>
            <td>{{ item.orderId }}</td>
            <td>{{ item.customerId }}</td>
            <td><app-status-badge kind="return" [status]="item.status"></app-status-badge></td>
            <td>{{ item.refundAmount | money }}</td>
            <td>{{ item.createdAtUtc | date:'medium' }}</td>
          </tr>
        </table>
      </ng-container>

      <ng-container *ngSwitchCase="'customers'">
        <h2>Customer report</h2>
        <table *ngIf="filteredCustomers().length">
          <tr><th>Name</th><th>Email</th><th>Status</th><th>Roles</th><th>Orders</th><th>Tickets</th></tr>
          <tr *ngFor="let user of filteredCustomers()">
            <td>{{ user.fullName }}</td>
            <td>{{ user.email }}</td>
            <td><span class="status-pill" [class.status-muted]="!user.isActive">{{ user.isActive ? 'Active' : 'Inactive' }}</span></td>
            <td>{{ user.roles.join(', ') }}</td>
            <td>{{ customerOrderCount(user.id) }}</td>
            <td>{{ customerTicketCount(user.id) }}</td>
          </tr>
        </table>
      </ng-container>

      <ng-container *ngSwitchCase="'support'">
        <h2>Support report</h2>
        <table *ngIf="filteredTickets().length">
          <tr><th>Subject</th><th>Customer</th><th>Order</th><th>Status</th><th>Agent</th><th>Created</th></tr>
          <tr *ngFor="let ticket of filteredTickets()">
            <td>{{ ticket.subject }}</td>
            <td>{{ ticket.customerId }}</td>
            <td>{{ ticket.orderId }}</td>
            <td><app-status-badge kind="ticket" [status]="ticket.status"></app-status-badge></td>
            <td>{{ ticket.assignedAgentId || '-' }}</td>
            <td>{{ ticket.createdAtUtc | date:'medium' }}</td>
          </tr>
        </table>
      </ng-container>

      <app-empty-state *ngIf="!currentRows().length" title="No report rows" message="Try another date range, status, or search filter."></app-empty-state>
    </section>
  `
})
export class AdminReportsComponent implements OnInit {
  readonly reports: Array<{ id: ReportType; label: string }> = [
    { id: 'sales', label: 'Sales' },
    { id: 'sellers', label: 'Sellers' },
    { id: 'products', label: 'Products' },
    { id: 'orders', label: 'Orders' },
    { id: 'refunds', label: 'Refunds' },
    { id: 'customers', label: 'Customers' },
    { id: 'support', label: 'Support' }
  ];
  readonly activeReport = signal<ReportType>('sales');
  readonly summary = signal<AdminFinanceSummary | null>(null);
  readonly balances = signal<AdminSellerBalance[]>([]);
  readonly sellers = signal<AdminSeller[]>([]);
  readonly products = signal<AdminProduct[]>([]);
  readonly orders = signal<Order[]>([]);
  readonly returns = signal<ReturnRequest[]>([]);
  readonly users = signal<AdminUser[]>([]);
  readonly tickets = signal<SupportTicket[]>([]);
  readonly message = signal('');
  search = '';
  dateFrom = '';
  dateTo = '';
  statusFilter = 'all';

  constructor(private readonly api: AdminApiService) {}

  ngOnInit(): void {
    this.load();
  }

  selectReport(report: ReportType): void {
    this.activeReport.set(report);
    this.statusFilter = 'all';
  }

  load(): void {
    forkJoin({
      summary: this.api.financeSummary().pipe(catchError(() => of(null))),
      balances: this.api.sellerBalances().pipe(catchError(() => of([]))),
      sellers: this.api.sellers().pipe(catchError(() => of([]))),
      products: this.api.products().pipe(catchError(() => of([]))),
      orders: this.api.orders().pipe(catchError(() => of([]))),
      returns: this.api.returns().pipe(catchError(() => of([]))),
      users: this.api.users().pipe(catchError(() => of([]))),
      tickets: this.api.supportTickets().pipe(catchError(() => of([])))
    }).subscribe({
      next: (data) => {
        this.summary.set(data.summary);
        this.balances.set(data.balances);
        this.sellers.set(data.sellers);
        this.products.set(data.products);
        this.orders.set(data.orders);
        this.returns.set(data.returns);
        this.users.set(data.users);
        this.tickets.set(data.tickets);
      },
      error: () => this.message.set('Could not load reports.')
    });
  }

  filteredOrders(): Order[] {
    return this.orders()
      .filter((order) => this.inDateRange(order.createdAtUtc))
      .filter((order) => this.matchesStatus(order.status))
      .filter((order) => this.matchesSearch([order.orderNumber, order.customerId, order.status, ...order.items.map((item) => item.productName)]));
  }

  filteredSellers(): AdminSeller[] {
    return this.sellers()
      .filter((seller) => this.matchesStatus(seller.status))
      .filter((seller) => this.matchesSearch([seller.businessName, seller.ownerName, seller.contactEmail, seller.status]));
  }

  filteredProducts(): AdminProduct[] {
    return this.products()
      .filter((product) => this.matchesStatus(product.status))
      .filter((product) => this.matchesSearch([product.name, product.description, product.sellerId, product.categoryId, product.status]));
  }

  filteredReturns(): ReturnRequest[] {
    return this.returns()
      .filter((item) => this.inDateRange(item.createdAtUtc))
      .filter((item) => this.matchesStatus(item.status))
      .filter((item) => this.matchesSearch([item.id, item.orderId, item.customerId, item.productId, item.reason, item.status]));
  }

  filteredCustomers(): AdminUser[] {
    return this.users()
      .filter((user) => user.roles.includes('Customer'))
      .filter((user) => this.matchesStatus(user.isActive ? 'Active' : 'Inactive'))
      .filter((user) => this.matchesSearch([user.fullName, user.email, user.roles.join(' ')]));
  }

  filteredTickets(): SupportTicket[] {
    return this.tickets()
      .filter((ticket) => this.inDateRange(ticket.createdAtUtc))
      .filter((ticket) => this.matchesStatus(ticket.status))
      .filter((ticket) => this.matchesSearch([ticket.subject, ticket.description, ticket.customerId, ticket.orderId, ticket.status]));
  }

  currentRows(): unknown[] {
    const map: Record<ReportType, unknown[]> = {
      sales: this.filteredOrders(),
      sellers: this.filteredSellers(),
      products: this.filteredProducts(),
      orders: this.filteredOrders(),
      refunds: this.filteredReturns(),
      customers: this.filteredCustomers(),
      support: this.filteredTickets()
    };
    return map[this.activeReport()];
  }

  statusOptions(): string[] {
    const rows = this.rawRowsForActiveReport();
    const statuses = rows.map((row) => this.rowStatus(row)).filter(Boolean);
    return Array.from(new Set(statuses)).sort();
  }

  exportCurrentReport(): void {
    const rows = this.csvRows();
    if (!rows.length) {
      this.message.set('No rows to export.');
      return;
    }

    const csv = rows.map((row) => row.map((value) => `"${String(value ?? '').replace(/"/g, '""')}"`).join(',')).join('\n');
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${this.activeReport()}-report.csv`;
    link.click();
    URL.revokeObjectURL(url);
  }

  resetFilters(): void {
    this.search = '';
    this.dateFrom = '';
    this.dateTo = '';
    this.statusFilter = 'all';
  }

  salesTotal(): number {
    return this.filteredOrders().reduce((total, order) => total + order.subtotal, 0);
  }

  refundTotal(): number {
    return this.filteredReturns().reduce((total, item) => total + item.refundAmount, 0);
  }

  openSupportCount(): number {
    return this.tickets().filter((ticket) => ['1', 'Open', '2', 'InProgress'].includes(String(ticket.status))).length;
  }

  sellerBalance(sellerId: string): AdminSellerBalance | undefined {
    return this.balances().find((balance) => balance.sellerId === sellerId);
  }

  customerOrderCount(customerId: string): number {
    return this.orders().filter((order) => order.customerId === customerId).length;
  }

  customerTicketCount(customerId: string): number {
    return this.tickets().filter((ticket) => ticket.customerId === customerId).length;
  }

  private rawRowsForActiveReport(): Array<Record<string, unknown>> {
    const map: Record<ReportType, Array<Record<string, unknown>>> = {
      sales: this.orders() as unknown as Array<Record<string, unknown>>,
      sellers: this.sellers() as unknown as Array<Record<string, unknown>>,
      products: this.products() as unknown as Array<Record<string, unknown>>,
      orders: this.orders() as unknown as Array<Record<string, unknown>>,
      refunds: this.returns() as unknown as Array<Record<string, unknown>>,
      customers: this.users().filter((user) => user.roles.includes('Customer')) as unknown as Array<Record<string, unknown>>,
      support: this.tickets() as unknown as Array<Record<string, unknown>>
    };
    return map[this.activeReport()];
  }

  private rowStatus(row: Record<string, unknown>): string {
    if ('isActive' in row) {
      return row['isActive'] ? 'Active' : 'Inactive';
    }

    return String(row['status'] ?? '');
  }

  private matchesStatus(status: string | number | boolean): boolean {
    if (this.statusFilter === 'all') {
      return true;
    }

    if (typeof status === 'boolean') {
      return (status ? 'Active' : 'Inactive') === this.statusFilter;
    }

    return String(status) === this.statusFilter;
  }

  private matchesSearch(values: Array<string | number | undefined | null>): boolean {
    const term = this.search.trim().toLowerCase();
    if (!term) {
      return true;
    }

    return values.join(' ').toLowerCase().includes(term);
  }

  private inDateRange(value?: string): boolean {
    if (!value || (!this.dateFrom && !this.dateTo)) {
      return true;
    }

    const date = new Date(value).getTime();
    const from = this.dateFrom ? new Date(`${this.dateFrom}T00:00:00`).getTime() : Number.NEGATIVE_INFINITY;
    const to = this.dateTo ? new Date(`${this.dateTo}T23:59:59`).getTime() : Number.POSITIVE_INFINITY;
    return date >= from && date <= to;
  }

  private csvRows(): unknown[][] {
    switch (this.activeReport()) {
      case 'sellers':
        return [['Business', 'Owner', 'Email', 'Status', 'Available', 'Pending'], ...this.filteredSellers().map((seller) => [
          seller.businessName, seller.ownerName, seller.contactEmail, seller.status, this.sellerBalance(seller.id)?.availableBalance ?? 0, this.sellerBalance(seller.id)?.pendingEarnings ?? 0
        ])];
      case 'products':
        return [['Product', 'Seller', 'Category', 'Status', 'Price'], ...this.filteredProducts().map((product) => [
          product.name, product.sellerId, product.categoryId, product.status, product.price
        ])];
      case 'refunds':
        return [['Return', 'Order', 'Customer', 'Status', 'Refund', 'Created'], ...this.filteredReturns().map((item) => [
          item.id, item.orderId, item.customerId, item.status, item.refundAmount, item.createdAtUtc
        ])];
      case 'customers':
        return [['Name', 'Email', 'Status', 'Roles', 'Orders', 'Tickets'], ...this.filteredCustomers().map((user) => [
          user.fullName, user.email, user.isActive ? 'Active' : 'Inactive', user.roles.join('; '), this.customerOrderCount(user.id), this.customerTicketCount(user.id)
        ])];
      case 'support':
        return [['Subject', 'Customer', 'Order', 'Status', 'Agent', 'Created'], ...this.filteredTickets().map((ticket) => [
          ticket.subject, ticket.customerId, ticket.orderId, ticket.status, ticket.assignedAgentId ?? '', ticket.createdAtUtc
        ])];
      case 'sales':
      case 'orders':
      default:
        return [['Order', 'Customer', 'Status', 'Items', 'Total', 'Created'], ...this.filteredOrders().map((order) => [
          order.orderNumber, order.customerId, order.status, order.items.length, order.subtotal, order.createdAtUtc
        ])];
    }
  }
}
