import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { AdminApiService } from '../services/admin-api.service';
import { AdminCategory } from '../models/admin.model';
import { ErrorMessageService } from '../../core/services/error-message.service';
import { EmptyStateComponent } from '../../shared/components/empty-state/empty-state.component';
import { ToastComponent } from '../../shared/components/toast/toast.component';

@Component({
  selector: 'app-admin-categories',
  standalone: true,
  imports: [CommonModule, FormsModule, EmptyStateComponent, ToastComponent],
  template: `
    <section class="dashboard-header">
      <div>
        <span class="eyebrow">Catalog</span>
        <h1>Category management</h1>
        <p>Create storefront categories, organize subcategories, and deactivate old catalog areas.</p>
      </div>
      <button (click)="load()">Refresh</button>
    </section>

    <app-toast [message]="message()"></app-toast>

    <section class="metric-grid">
      <article class="metric-card">
        <span>Active categories</span>
        <strong>{{ activeCount() }}</strong>
      </article>
      <article class="metric-card">
        <span>Inactive categories</span>
        <strong>{{ inactiveCount() }}</strong>
      </article>
      <article class="metric-card">
        <span>Parent categories</span>
        <strong>{{ parentCount() }}</strong>
      </article>
      <article class="metric-card">
        <span>Subcategories</span>
        <strong>{{ childCount() }}</strong>
      </article>
    </section>

    <section class="ops-form-grid">
      <form class="surface checkout-form" (ngSubmit)="save()">
        <h2>{{ editingId ? 'Edit category' : 'New category' }}</h2>
        <label>Name<input [(ngModel)]="name" name="name" required></label>
        <label>Slug<input [(ngModel)]="slug" name="slug" placeholder="Auto-generated when empty"></label>
        <label>Parent category
          <select [(ngModel)]="parentCategoryId" name="parentCategoryId">
            <option value="">Top-level category</option>
            <option *ngFor="let category of parentOptions()" [value]="category.id" [disabled]="category.id === editingId">
              {{ category.name }}
            </option>
          </select>
        </label>
        <label>Description<textarea [(ngModel)]="description" name="description" rows="4"></textarea></label>
        <div class="action-row">
          <button type="submit">{{ editingId ? 'Update category' : 'Create category' }}</button>
          <button type="button" class="ghost-light" (click)="reset()">Reset</button>
        </div>
      </form>

      <section class="surface dashboard-panel">
        <div class="seller-toolbar compact-toolbar">
          <label>Search<input [(ngModel)]="search" placeholder="Category or slug"></label>
          <label>Status
            <select [(ngModel)]="statusFilter">
              <option value="all">All categories</option>
              <option value="active">Active</option>
              <option value="inactive">Inactive</option>
            </select>
          </label>
        </div>

        <table *ngIf="filteredCategories().length">
          <tr>
            <th>Name</th>
            <th>Parent</th>
            <th>Slug</th>
            <th>Status</th>
            <th>Actions</th>
          </tr>
          <tr *ngFor="let category of filteredCategories()">
            <td>
              <button class="table-link category-name-cell" (click)="edit(category)">
                <span *ngIf="category.parentCategoryId" class="subcategory-marker">Sub</span>
                {{ category.name }}
              </button>
            </td>
            <td>{{ parentName(category.parentCategoryId) }}</td>
            <td>{{ category.slug }}</td>
            <td><span class="status-pill" [class.status-muted]="!category.isActive">{{ category.isActive ? 'Active' : 'Inactive' }}</span></td>
            <td class="action-row">
              <button (click)="edit(category)">Edit</button>
              <button *ngIf="category.isActive" class="text-danger" (click)="deactivate(category.id)">Deactivate</button>
              <button *ngIf="!category.isActive" (click)="activate(category.id)">Activate</button>
            </td>
          </tr>
        </table>
        <app-empty-state *ngIf="!filteredCategories().length" title="No categories found" message="Create a category or change the current filters."></app-empty-state>
      </section>
    </section>
  `
})
export class AdminCategoriesComponent implements OnInit {
  editingId = '';
  name = '';
  slug = '';
  parentCategoryId = '';
  description = '';
  search = '';
  statusFilter = 'all';
  readonly categories = signal<AdminCategory[]>([]);
  readonly message = signal('');

  constructor(private readonly api: AdminApiService, private readonly errors: ErrorMessageService) {}

  ngOnInit(): void {
    this.load();
  }

  load(): void {
    this.api.categories().subscribe({
      next: (categories) => this.categories.set(categories),
      error: (error) => this.message.set(this.errors.from(error))
    });
  }

  filteredCategories(): AdminCategory[] {
    const term = this.search.trim().toLowerCase();
    return this.categories().filter((category) => {
      const statusMatches =
        this.statusFilter === 'all' ||
        (this.statusFilter === 'active' && category.isActive) ||
        (this.statusFilter === 'inactive' && !category.isActive);
      const searchable = [category.name, category.slug, category.description ?? '', this.parentName(category.parentCategoryId)]
        .join(' ')
        .toLowerCase();
      return statusMatches && (!term || searchable.includes(term));
    });
  }

  parentOptions(): AdminCategory[] {
    return this.categories().filter((category) => category.isActive && category.id !== this.editingId);
  }

  edit(category: AdminCategory): void {
    this.editingId = category.id;
    this.name = category.name;
    this.slug = category.slug;
    this.parentCategoryId = category.parentCategoryId ?? '';
    this.description = category.description ?? '';
  }

  reset(): void {
    this.editingId = '';
    this.name = '';
    this.slug = '';
    this.parentCategoryId = '';
    this.description = '';
  }

  save(): void {
    const request = {
      name: this.name,
      slug: this.slug || null,
      description: this.description || null,
      parentCategoryId: this.parentCategoryId || null
    };
    const call = this.editingId ? this.api.updateCategory(this.editingId, request) : this.api.createCategory(request);
    call.subscribe({
      next: () => {
        this.message.set(this.editingId ? 'Category updated.' : 'Category created.');
        this.reset();
        this.load();
      },
      error: (error) => this.message.set(this.errors.from(error))
    });
  }

  deactivate(id: string): void {
    this.api.deactivateCategory(id).subscribe({
      next: () => {
        this.message.set('Category deactivated.');
        this.load();
      },
      error: (error) => this.message.set(this.errors.from(error))
    });
  }

  activate(id: string): void {
    this.api.activateCategory(id).subscribe({
      next: () => {
        this.message.set('Category activated.');
        this.load();
      },
      error: (error) => this.message.set(this.errors.from(error))
    });
  }

  parentName(parentCategoryId?: string | null): string {
    if (!parentCategoryId) {
      return 'Top level';
    }

    return this.categories().find((category) => category.id === parentCategoryId)?.name ?? 'Unknown parent';
  }

  activeCount(): number {
    return this.categories().filter((category) => category.isActive).length;
  }

  inactiveCount(): number {
    return this.categories().filter((category) => !category.isActive).length;
  }

  parentCount(): number {
    return this.categories().filter((category) => !category.parentCategoryId).length;
  }

  childCount(): number {
    return this.categories().filter((category) => category.parentCategoryId).length;
  }
}
