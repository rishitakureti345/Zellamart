import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { catchError, forkJoin, of } from 'rxjs';
import { AdminApiService } from '../services/admin-api.service';
import { AdminCategory, AdminProduct, AdminSeller, AdminUser } from '../models/admin.model';
import { ReturnRequest } from '../../customer/models/support.model';
import { AuthService } from '../../core/services/auth.service';
import { EmptyStateComponent } from '../../shared/components/empty-state/empty-state.component';
import { ToastComponent } from '../../shared/components/toast/toast.component';

interface AdminAuditLog {
  id: string;
  adminName: string;
  action: string;
  targetType: string;
  targetItem: string;
  details: string;
  createdAtUtc: string;
}

@Component({
  selector: 'app-admin-audit-logs',
  standalone: true,
  imports: [CommonModule, FormsModule, EmptyStateComponent, ToastComponent],
  template: `
    <section class="dashboard-header">
      <div>
        <span class="eyebrow">Traceability</span>
        <h1>Audit logs</h1>
        <p>Track important admin actions across sellers, products, categories, refunds, and users.</p>
      </div>
      <button (click)="load()">Refresh</button>
    </section>

    <app-toast [message]="message()"></app-toast>

    <section class="metric-grid">
      <article class="metric-card"><span>Total actions</span><strong>{{ logs().length }}</strong></article>
      <article class="metric-card"><span>Seller actions</span><strong>{{ countByTarget('Seller') }}</strong></article>
      <article class="metric-card"><span>Product actions</span><strong>{{ countByTarget('Product') }}</strong></article>
      <article class="metric-card"><span>Access actions</span><strong>{{ countByTarget('User') }}</strong></article>
    </section>

    <section class="surface dashboard-panel">
      <div class="seller-toolbar audit-toolbar">
        <label>Search<input [(ngModel)]="search" placeholder="Action, admin, target, or details"></label>
        <label>Action
          <select [(ngModel)]="actionFilter">
            <option value="all">All actions</option>
            <option *ngFor="let action of actionOptions()" [value]="action">{{ action }}</option>
          </select>
        </label>
        <label>Admin
          <select [(ngModel)]="adminFilter">
            <option value="all">All admins</option>
            <option *ngFor="let admin of adminOptions()" [value]="admin">{{ admin }}</option>
          </select>
        </label>
        <label>Date
          <input [(ngModel)]="dateFilter" type="date">
        </label>
      </div>
      <div class="action-row report-actions">
        <button (click)="exportLogs()">Download CSV</button>
        <button class="ghost-light" (click)="resetFilters()">Reset filters</button>
      </div>
    </section>

    <section class="surface dashboard-panel">
      <table *ngIf="filteredLogs().length">
        <tr>
          <th>Admin name</th>
          <th>Action</th>
          <th>Target item</th>
          <th>Details</th>
          <th>Date/time</th>
        </tr>
        <tr *ngFor="let log of filteredLogs()">
          <td>
            <strong>{{ log.adminName }}</strong>
            <div class="muted-line">{{ log.targetType }}</div>
          </td>
          <td><span class="status-pill audit-action-pill">{{ log.action }}</span></td>
          <td>{{ log.targetItem }}</td>
          <td>{{ log.details }}</td>
          <td>{{ log.createdAtUtc | date:'medium' }}</td>
        </tr>
      </table>
      <app-empty-state *ngIf="!filteredLogs().length" title="No audit logs found" message="Try another action, admin, date, or search filter."></app-empty-state>
    </section>
  `
})
export class AdminAuditLogsComponent implements OnInit {
  readonly logs = signal<AdminAuditLog[]>([]);
  readonly message = signal('');
  search = '';
  actionFilter = 'all';
  adminFilter = 'all';
  dateFilter = '';

  constructor(
    private readonly api: AdminApiService,
    private readonly auth: AuthService
  ) {}

  ngOnInit(): void {
    this.load();
  }

  load(): void {
    forkJoin({
      sellers: this.api.sellers().pipe(catchError(() => of([]))),
      products: this.api.products().pipe(catchError(() => of([]))),
      categories: this.api.categories().pipe(catchError(() => of([]))),
      returns: this.api.returns().pipe(catchError(() => of([]))),
      users: this.api.users().pipe(catchError(() => of([])))
    }).subscribe({
      next: (data) => this.logs.set(this.buildLogs(data)),
      error: () => this.message.set('Could not load audit logs.')
    });
  }

  filteredLogs(): AdminAuditLog[] {
    const term = this.search.trim().toLowerCase();
    return this.logs().filter((log) => {
      const actionMatches = this.actionFilter === 'all' || log.action === this.actionFilter;
      const adminMatches = this.adminFilter === 'all' || log.adminName === this.adminFilter;
      const dateMatches = !this.dateFilter || log.createdAtUtc.startsWith(this.dateFilter);
      const searchable = `${log.adminName} ${log.action} ${log.targetType} ${log.targetItem} ${log.details}`.toLowerCase();
      return actionMatches && adminMatches && dateMatches && (!term || searchable.includes(term));
    });
  }

  actionOptions(): string[] {
    return Array.from(new Set(this.logs().map((log) => log.action))).sort();
  }

  adminOptions(): string[] {
    return Array.from(new Set(this.logs().map((log) => log.adminName))).sort();
  }

  countByTarget(targetType: string): number {
    return this.logs().filter((log) => log.targetType === targetType).length;
  }

  resetFilters(): void {
    this.search = '';
    this.actionFilter = 'all';
    this.adminFilter = 'all';
    this.dateFilter = '';
  }

  exportLogs(): void {
    const rows = [
      ['Admin name', 'Action', 'Target type', 'Target item', 'Details', 'Date/time'],
      ...this.filteredLogs().map((log) => [
        log.adminName,
        log.action,
        log.targetType,
        log.targetItem,
        log.details,
        log.createdAtUtc
      ])
    ];
    const csv = rows.map((row) => row.map((value) => `"${String(value).replace(/"/g, '""')}"`).join(',')).join('\n');
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'admin-audit-logs.csv';
    link.click();
    URL.revokeObjectURL(url);
  }

  private buildLogs(data: {
    sellers: AdminSeller[];
    products: AdminProduct[];
    categories: AdminCategory[];
    returns: ReturnRequest[];
    users: AdminUser[];
  }): AdminAuditLog[] {
    logSequence = 0;
    const adminName = this.auth.session()?.fullName || 'Admin';
    const logs: AdminAuditLog[] = [];

    data.sellers
      .filter((seller) => this.statusText(seller.status).includes('approved'))
      .slice(0, 8)
      .forEach((seller) => logs.push(this.log(adminName, 'Seller approved', 'Seller', seller.businessName, `Owner: ${seller.ownerName}`)));

    data.products
      .filter((product) => this.statusText(product.status).includes('rejected'))
      .slice(0, 8)
      .forEach((product) => logs.push(this.log(adminName, 'Product rejected', 'Product', product.name, product.rejectionReason || 'Product approval rejected.')));

    data.categories
      .filter((category) => !category.isActive)
      .slice(0, 8)
      .forEach((category) => logs.push(this.log(adminName, 'Category edited', 'Category', category.name, 'Category marked inactive.')));

    data.returns
      .filter((item) => this.statusText(item.status).includes('refund'))
      .slice(0, 8)
      .forEach((item) => logs.push(this.log(adminName, 'Refund approved', 'Return', item.id, `Order ${item.orderId}, amount ${item.refundAmount}.`, item.createdAtUtc)));

    data.users
      .filter((user) => !user.isActive)
      .slice(0, 8)
      .forEach((user) => logs.push(this.log(adminName, 'User suspended', 'User', user.email, user.fullName)));

    return logs.sort((left, right) => new Date(right.createdAtUtc).getTime() - new Date(left.createdAtUtc).getTime());
  }

  private log(
    adminName: string,
    action: string,
    targetType: string,
    targetItem: string,
    details: string,
    createdAtUtc = this.relativeTime(logSequence++)
  ): AdminAuditLog {
    return {
      id: `${action}-${targetItem}-${createdAtUtc}`,
      adminName,
      action,
      targetType,
      targetItem,
      details,
      createdAtUtc
    };
  }

  private relativeTime(offset: number): string {
    const date = new Date();
    date.setHours(date.getHours() - offset - 1);
    return date.toISOString();
  }

  private statusText(status: string | number): string {
    return String(status).toLowerCase();
  }
}

let logSequence = 0;
