import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { forkJoin } from 'rxjs';
import { AdminApiService } from '../services/admin-api.service';
import { AdminProduct, AdminSeller, AdminStockMovement } from '../models/admin.model';
import { InventoryItem } from '../../seller/models/seller.model';
import { ErrorMessageService } from '../../core/services/error-message.service';
import { EmptyStateComponent } from '../../shared/components/empty-state/empty-state.component';
import { ToastComponent } from '../../shared/components/toast/toast.component';

@Component({
  selector: 'app-admin-inventory',
  standalone: true,
  imports: [CommonModule, FormsModule, EmptyStateComponent, ToastComponent],
  template: `
    <section class="dashboard-header">
      <div>
        <span class="eyebrow">Inventory</span>
        <h1>Stock monitoring</h1>
        <p>Track available stock, catch low inventory, and review movement history before orders fail.</p>
      </div>
      <button (click)="load()">Refresh</button>
    </section>

    <app-toast [message]="message()"></app-toast>

    <section class="metric-grid">
      <article class="metric-card"><span>Products with stock</span><strong>{{ items().length }}</strong></article>
      <article class="metric-card"><span>Low stock</span><strong>{{ lowStockItems().length }}</strong></article>
      <article class="metric-card"><span>Out of stock</span><strong>{{ outOfStockItems().length }}</strong></article>
      <article class="metric-card"><span>Reserved units</span><strong>{{ reservedUnits() }}</strong></article>
    </section>

    <section class="seller-toolbar users-toolbar">
      <label>Search<input [(ngModel)]="search" placeholder="Product, seller, SKU"></label>
      <label>Stock view
        <select [(ngModel)]="stockFilter">
          <option value="all">All stock</option>
          <option value="low">Low stock</option>
          <option value="out">Out of stock</option>
        </select>
      </label>
      <label>Low threshold<input [(ngModel)]="lowThreshold" type="number" min="1"></label>
    </section>

    <section class="seller-admin-grid">
      <section class="surface dashboard-panel">
        <table *ngIf="filteredItems().length">
          <tr>
            <th>Product</th>
            <th>Seller</th>
            <th>SKU</th>
            <th>On hand</th>
            <th>Reserved</th>
            <th>Available</th>
            <th>Actions</th>
          </tr>
          <tr *ngFor="let item of filteredItems()" [class.selected-row]="selectedItem()?.id === item.id" [class.warning-row]="isLowStock(item)" [class.danger-row]="isOutOfStock(item)">
            <td><button class="table-link" (click)="selectItem(item)">{{ productName(item.productId) }}</button></td>
            <td>{{ sellerName(item.sellerId) }}</td>
            <td>{{ item.sku }}</td>
            <td>{{ item.quantityOnHand }}</td>
            <td>{{ item.reservedQuantity }}</td>
            <td><strong>{{ item.availableQuantity }}</strong></td>
            <td class="action-row">
              <button (click)="selectItem(item)">History</button>
            </td>
          </tr>
        </table>
        <app-empty-state *ngIf="!filteredItems().length" title="No stock records found" message="Try another filter or wait for approved products to create inventory."></app-empty-state>
      </section>

      <aside class="surface seller-detail-pane" *ngIf="selectedItem() as item">
        <div class="seller-detail-heading">
          <span class="eyebrow">Stock detail</span>
          <h2>{{ productName(item.productId) }}</h2>
          <p class="muted-line">{{ item.sku }} · {{ sellerName(item.sellerId) }}</p>
        </div>

        <div class="seller-detail-grid">
          <div><span>On hand</span><strong>{{ item.quantityOnHand }}</strong></div>
          <div><span>Reserved</span><strong>{{ item.reservedQuantity }}</strong></div>
          <div><span>Available</span><strong>{{ item.availableQuantity }}</strong></div>
          <div><span>Status</span><strong>{{ stockStatus(item) }}</strong></div>
        </div>

        <form class="stock-update-form" (ngSubmit)="addStock(item.id)">
          <h3>Manual stock update</h3>
          <label>Quantity to add<input [(ngModel)]="stockQuantity" name="stockQuantity" type="number" min="1" required></label>
          <label>Reason<input [(ngModel)]="stockReason" name="stockReason"></label>
          <button type="submit">Add stock</button>
        </form>

        <form class="stock-update-form" (ngSubmit)="setStock(item.id)">
          <h3>Set stock count</h3>
          <label>On-hand count<input [(ngModel)]="setQuantityOnHand" name="setQuantityOnHand" type="number" [min]="item.reservedQuantity" required></label>
          <label>Reason<input [(ngModel)]="setStockReason" name="setStockReason"></label>
          <button type="submit">Set stock count</button>
          <p class="muted-line">Count cannot be lower than reserved stock: {{ item.reservedQuantity }}.</p>
        </form>

        <section>
          <h3>Movement history</h3>
          <table *ngIf="movements().length">
            <tr><th>Type</th><th>Change</th><th>After</th><th>Reason</th><th>Changed</th></tr>
            <tr *ngFor="let movement of movements()">
              <td>{{ movementTypeLabel(movement.type) }}</td>
              <td>{{ movement.quantityChange }}</td>
              <td>{{ movement.quantityAfter }}</td>
              <td>{{ movement.reason }}</td>
              <td>{{ movement.changedAtUtc | date:'medium' }}</td>
            </tr>
          </table>
          <app-empty-state *ngIf="!movements().length" title="No movements" message="Stock changes will appear here."></app-empty-state>
        </section>
      </aside>

      <aside class="surface seller-detail-pane" *ngIf="!selectedItem()">
        <app-empty-state title="Select stock" message="Choose an inventory row to update stock and inspect history."></app-empty-state>
      </aside>
    </section>
  `
})
export class AdminInventoryComponent implements OnInit {
  search = '';
  stockFilter = 'all';
  lowThreshold = 5;
  stockQuantity = 10;
  stockReason = 'Manual stock adjustment by admin.';
  setQuantityOnHand = 0;
  setStockReason = 'Stock count adjusted by admin.';
  readonly items = signal<InventoryItem[]>([]);
  readonly products = signal<AdminProduct[]>([]);
  readonly sellers = signal<AdminSeller[]>([]);
  readonly selectedItem = signal<InventoryItem | null>(null);
  readonly movements = signal<AdminStockMovement[]>([]);
  readonly message = signal('');

  constructor(private readonly api: AdminApiService, private readonly errors: ErrorMessageService) {}

  ngOnInit(): void {
    this.load();
  }

  load(): void {
    forkJoin({
      items: this.api.inventory(),
      products: this.api.products(),
      sellers: this.api.sellers()
    }).subscribe({
      next: ({ items, products, sellers }) => {
        this.items.set(items);
        this.products.set(products);
        this.sellers.set(sellers);
        const nextSelected = items.find((item) => item.id === this.selectedItem()?.id) ?? items[0] ?? null;
        this.selectItem(nextSelected);
      },
      error: (error) => this.message.set(this.errors.from(error))
    });
  }

  filteredItems(): InventoryItem[] {
    const term = this.search.trim().toLowerCase();
    return this.items().filter((item) => {
      const stockMatches =
        this.stockFilter === 'all' ||
        (this.stockFilter === 'low' && this.isLowStock(item)) ||
        (this.stockFilter === 'out' && this.isOutOfStock(item));
      const searchable = [item.sku, item.productId, item.sellerId, this.productName(item.productId), this.sellerName(item.sellerId)]
        .join(' ')
        .toLowerCase();
      return stockMatches && (!term || searchable.includes(term));
    });
  }

  selectItem(item: InventoryItem | null): void {
    this.selectedItem.set(item);
    this.movements.set([]);
    if (!item) {
      return;
    }

    this.setQuantityOnHand = item.quantityOnHand;

    this.api.stockMovements(item.id).subscribe({
      next: (movements) => this.movements.set(movements),
      error: (error) => this.message.set(this.errors.from(error))
    });
  }

  addStock(inventoryItemId: string): void {
    this.api.addStock(inventoryItemId, Number(this.stockQuantity), this.stockReason || 'Manual stock adjustment by admin.').subscribe({
      next: () => {
        this.message.set('Stock updated.');
        this.load();
      },
      error: (error) => this.message.set(this.errors.from(error))
    });
  }

  setStock(inventoryItemId: string): void {
    this.api.setStock(inventoryItemId, Number(this.setQuantityOnHand), this.setStockReason || 'Stock count adjusted by admin.').subscribe({
      next: () => {
        this.message.set('Stock count updated.');
        this.load();
      },
      error: (error) => this.message.set(this.errors.from(error))
    });
  }

  lowStockItems(): InventoryItem[] {
    return this.items().filter((item) => this.isLowStock(item));
  }

  outOfStockItems(): InventoryItem[] {
    return this.items().filter((item) => this.isOutOfStock(item));
  }

  reservedUnits(): number {
    return this.items().reduce((total, item) => total + item.reservedQuantity, 0);
  }

  isLowStock(item: InventoryItem): boolean {
    return item.availableQuantity > 0 && item.availableQuantity <= Number(this.lowThreshold || 5);
  }

  isOutOfStock(item: InventoryItem): boolean {
    return item.availableQuantity <= 0;
  }

  stockStatus(item: InventoryItem): string {
    if (this.isOutOfStock(item)) {
      return 'Out of stock';
    }

    if (this.isLowStock(item)) {
      return 'Low stock';
    }

    return 'Healthy';
  }

  productName(productId: string): string {
    return this.products().find((product) => product.id === productId)?.name ?? productId;
  }

  sellerName(sellerId: string): string {
    const seller = this.sellers().find((item) => item.id === sellerId || item.userId === sellerId);
    return seller?.businessName ?? sellerId;
  }

  movementTypeLabel(type: string | number): string {
    const map: Record<string, string> = {
      '1': 'Inventory created',
      InventoryCreated: 'Inventory created',
      '2': 'Stock added',
      StockAdded: 'Stock added',
      '3': 'Stock adjusted',
      StockAdjusted: 'Stock adjusted',
      '4': 'Stock reserved',
      StockReserved: 'Stock reserved',
      '5': 'Stock released',
      StockReleased: 'Stock released',
      '6': 'Stock deducted',
      StockDeducted: 'Stock deducted'
    };
    return map[String(type)] ?? String(type);
  }
}
