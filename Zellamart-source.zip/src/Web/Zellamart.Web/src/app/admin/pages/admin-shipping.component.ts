import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { AdminApiService } from '../services/admin-api.service';
import { Shipment } from '../../customer/models/order.model';
import { ErrorMessageService } from '../../core/services/error-message.service';
import { StatusBadgeComponent } from '../../shared/components/status-badge/status-badge.component';
import { EmptyStateComponent } from '../../shared/components/empty-state/empty-state.component';
import { ToastComponent } from '../../shared/components/toast/toast.component';

@Component({
  selector: 'app-admin-shipping',
  standalone: true,
  imports: [CommonModule, FormsModule, StatusBadgeComponent, EmptyStateComponent, ToastComponent],
  template: `
    <section class="dashboard-header">
      <div>
        <span class="eyebrow">Operations</span>
        <h1>Shipping operations</h1>
        <p>Control packing, shipment handoff, delivery assignment, and failed delivery handling.</p>
      </div>
      <button (click)="load()">Refresh</button>
    </section>

    <app-toast [message]="message()"></app-toast>

    <section class="metric-grid">
      <article class="metric-card"><span>Total shipments</span><strong>{{ shipments().length }}</strong></article>
      <article class="metric-card"><span>Needs packing</span><strong>{{ countByStatus('Pending packing') }}</strong></article>
      <article class="metric-card"><span>In delivery</span><strong>{{ activeDeliveryCount() }}</strong></article>
      <article class="metric-card"><span>Failed deliveries</span><strong>{{ countByStatus('Delivery failed') }}</strong></article>
    </section>

    <section class="seller-toolbar users-toolbar">
      <label>Search<input [(ngModel)]="search" placeholder="Tracking, order, customer, partner"></label>
      <label>Status
        <select [(ngModel)]="statusFilter">
          <option value="all">All statuses</option>
          <option *ngFor="let status of statusFilters" [value]="status">{{ status }}</option>
        </select>
      </label>
      <label>Partner ID<input [(ngModel)]="partnerId" placeholder="Delivery partner user id"></label>
    </section>

    <section class="seller-toolbar users-toolbar">
      <label>Failure reason<input [(ngModel)]="failureReason"></label>
      <span></span>
      <span></span>
    </section>

    <section class="seller-admin-grid">
      <section class="surface dashboard-panel">
        <table *ngIf="filteredShipments().length">
          <tr>
            <th>Tracking</th>
            <th>Status</th>
            <th>Order</th>
            <th>Partner</th>
            <th>Actions</th>
          </tr>
          <tr *ngFor="let shipment of filteredShipments()" [class.selected-row]="selectedShipment()?.id === shipment.id">
            <td>
              <button class="table-link" (click)="selectShipment(shipment)">
                <strong>{{ shipment.trackingNumber }}</strong><br>
                <span class="muted-line">{{ shipment.shippingAddress }}</span>
              </button>
            </td>
            <td><app-status-badge kind="shipping" [status]="shipment.status"></app-status-badge></td>
            <td>{{ shipment.orderId }}</td>
            <td>{{ shipment.deliveryPartnerId || '-' }}</td>
            <td class="action-row">
              <button *ngIf="isStatus(shipment, 'Pending packing')" (click)="pack(shipment.id)">Pack</button>
              <button *ngIf="isStatus(shipment, 'Packed')" (click)="ship(shipment.id)">Ship</button>
              <button *ngIf="isStatus(shipment, 'Shipped')" class="ghost-light" (click)="assign(shipment.id)">Assign</button>
              <button *ngIf="isStatus(shipment, 'Shipped')" (click)="outForDelivery(shipment.id)">Out</button>
              <button *ngIf="isStatus(shipment, 'Out for delivery')" (click)="delivered(shipment.id)">Delivered</button>
              <button *ngIf="isStatus(shipment, 'Out for delivery')" class="text-danger" (click)="failed(shipment.id)">Failed</button>
            </td>
          </tr>
        </table>
        <app-empty-state *ngIf="!filteredShipments().length" title="No shipments found" message="Try another status or search term."></app-empty-state>
      </section>

      <aside class="surface seller-detail-pane" *ngIf="selectedShipment() as shipment">
        <div class="seller-detail-heading">
          <span class="eyebrow">Shipment detail</span>
          <h2>{{ shipment.trackingNumber }}</h2>
          <app-status-badge kind="shipping" [status]="shipment.status"></app-status-badge>
        </div>

        <div class="seller-detail-grid">
          <div><span>Order</span><strong>{{ shipment.orderId }}</strong></div>
          <div><span>Customer</span><strong>{{ shipment.customerId }}</strong></div>
          <div><span>Partner</span><strong>{{ shipment.deliveryPartnerId || 'Not assigned' }}</strong></div>
          <div><span>Created</span><strong>{{ shipment.createdAtUtc | date:'medium' }}</strong></div>
          <div><span>Address</span><strong>{{ shipment.shippingAddress }}</strong></div>
          <div><span>History entries</span><strong>{{ shipment.statusHistory.length }}</strong></div>
        </div>

        <div class="action-row detail-actions">
          <button *ngIf="isStatus(shipment, 'Pending packing')" (click)="pack(shipment.id)">Mark packed</button>
          <button *ngIf="isStatus(shipment, 'Packed')" (click)="ship(shipment.id)">Mark shipped</button>
          <button *ngIf="isStatus(shipment, 'Shipped')" class="ghost-light" (click)="assign(shipment.id)">Assign partner</button>
          <button *ngIf="isStatus(shipment, 'Shipped')" (click)="outForDelivery(shipment.id)">Out for delivery</button>
          <button *ngIf="isStatus(shipment, 'Out for delivery')" (click)="delivered(shipment.id)">Mark delivered</button>
          <button *ngIf="isStatus(shipment, 'Out for delivery')" class="text-danger" (click)="failed(shipment.id)">Mark failed</button>
        </div>

        <section>
          <h3>Delivery history</h3>
          <table *ngIf="shipment.statusHistory.length">
            <tr><th>Status</th><th>Note</th><th>Changed by</th><th>Changed</th></tr>
            <tr *ngFor="let entry of shipment.statusHistory">
              <td><app-status-badge kind="shipping" [status]="entry.status"></app-status-badge></td>
              <td>{{ entry.note }}</td>
              <td>{{ entry.changedByUserId || '-' }}</td>
              <td>{{ entry.changedAtUtc | date:'medium' }}</td>
            </tr>
          </table>
        </section>
      </aside>

      <aside class="surface seller-detail-pane" *ngIf="!selectedShipment()">
        <app-empty-state title="Select a shipment" message="Open a shipment to see delivery history and workflow actions."></app-empty-state>
      </aside>
    </section>
  `
})
export class AdminShippingComponent implements OnInit {
  search = '';
  statusFilter = 'all';
  partnerId = '';
  failureReason = 'Customer not available.';
  readonly statusFilters = ['Pending packing', 'Packed', 'Shipped', 'Out for delivery', 'Delivered', 'Delivery failed', 'Cancelled'];
  readonly shipments = signal<Shipment[]>([]);
  readonly selectedShipment = signal<Shipment | null>(null);
  readonly message = signal('');

  constructor(private readonly api: AdminApiService, private readonly errors: ErrorMessageService) {}

  ngOnInit(): void {
    this.load();
  }

  load(): void {
    this.api.shipments().subscribe({
      next: (shipments) => {
        this.shipments.set(shipments);
        this.selectedShipment.set(shipments.find((item) => item.id === this.selectedShipment()?.id) ?? shipments[0] ?? null);
      },
      error: (error) => this.message.set(this.errors.from(error))
    });
  }

  filteredShipments(): Shipment[] {
    const term = this.search.trim().toLowerCase();
    return this.shipments().filter((shipment) => {
      const statusMatches = this.statusFilter === 'all' || this.shippingStatusLabel(shipment.status) === this.statusFilter;
      const searchable = [
        shipment.trackingNumber,
        shipment.orderId,
        shipment.customerId,
        shipment.deliveryPartnerId ?? '',
        shipment.shippingAddress
      ].join(' ').toLowerCase();
      return statusMatches && (!term || searchable.includes(term));
    });
  }

  selectShipment(shipment: Shipment): void {
    this.selectedShipment.set(shipment);
  }

  pack(id: string): void {
    this.run(this.api.packShipment(id), 'Shipment packed.');
  }

  ship(id: string): void {
    this.run(this.api.shipShipment(id), 'Shipment shipped.');
  }

  assign(id: string): void {
    if (!this.partnerId.trim()) {
      this.message.set('Delivery partner ID is required.');
      return;
    }

    this.run(this.api.assignDeliveryPartner(id, this.partnerId.trim()), 'Delivery partner assigned.');
  }

  outForDelivery(id: string): void {
    this.run(this.api.markOutForDelivery(id), 'Shipment is out for delivery.');
  }

  delivered(id: string): void {
    this.run(this.api.markDelivered(id), 'Shipment delivered.');
  }

  failed(id: string): void {
    this.run(this.api.markDeliveryFailed(id, this.failureReason || 'Delivery failed.'), 'Delivery failure recorded.');
  }

  countByStatus(status: string): number {
    return this.shipments().filter((shipment) => this.shippingStatusLabel(shipment.status) === status).length;
  }

  activeDeliveryCount(): number {
    return this.shipments().filter((shipment) => ['Shipped', 'Out for delivery'].includes(this.shippingStatusLabel(shipment.status))).length;
  }

  isStatus(shipment: Shipment, status: string): boolean {
    return this.shippingStatusLabel(shipment.status) === status;
  }

  shippingStatusLabel(status: string | number): string {
    const map: Record<string, string> = {
      '1': 'Pending packing',
      PendingPacking: 'Pending packing',
      '2': 'Packed',
      Packed: 'Packed',
      '3': 'Shipped',
      Shipped: 'Shipped',
      '4': 'Out for delivery',
      OutForDelivery: 'Out for delivery',
      '5': 'Delivered',
      Delivered: 'Delivered',
      '6': 'Delivery failed',
      DeliveryFailed: 'Delivery failed',
      '7': 'Cancelled',
      Cancelled: 'Cancelled'
    };
    return map[String(status)] ?? String(status);
  }

  private run(request: ReturnType<AdminApiService['packShipment']>, successMessage: string): void {
    request.subscribe({
      next: () => {
        this.message.set(successMessage);
        this.load();
      },
      error: (error) => this.message.set(this.errors.from(error))
    });
  }
}
