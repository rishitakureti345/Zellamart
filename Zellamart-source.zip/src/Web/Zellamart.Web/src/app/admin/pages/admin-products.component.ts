import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { catchError, forkJoin, of } from 'rxjs';
import { AdminApiService } from '../services/admin-api.service';
import { AdminCategory, AdminProduct, AdminSeller } from '../models/admin.model';
import { ErrorMessageService } from '../../core/services/error-message.service';
import { MoneyPipe } from '../../shared/pipes/money.pipe';
import { StatusBadgeComponent } from '../../shared/components/status-badge/status-badge.component';
import { EmptyStateComponent } from '../../shared/components/empty-state/empty-state.component';
import { ToastComponent } from '../../shared/components/toast/toast.component';
import { InventoryItem } from '../../seller/models/seller.model';

@Component({
  selector: 'app-admin-products',
  standalone: true,
  imports: [CommonModule, FormsModule, MoneyPipe, StatusBadgeComponent, EmptyStateComponent, ToastComponent],
  template: `
    <section class="dashboard-header">
      <div>
        <span class="eyebrow">Catalog</span>
        <h1>Product management</h1>
        <p>Review seller submissions and control what appears in the storefront.</p>
      </div>
      <button (click)="load()">Refresh</button>
    </section>

    <app-toast [message]="message()"></app-toast>

    <section class="metric-grid">
      <article class="metric-card">
        <span>Pending products</span>
        <strong>{{ countByStatus('pending') }}</strong>
      </article>
      <article class="metric-card">
        <span>Approved products</span>
        <strong>{{ countByStatus('approved') }}</strong>
      </article>
      <article class="metric-card">
        <span>Rejected products</span>
        <strong>{{ countByStatus('rejected') }}</strong>
      </article>
      <article class="metric-card">
        <span>Total catalog records</span>
        <strong>{{ products().length }}</strong>
      </article>
    </section>

    <section class="seller-toolbar">
      <label>Search<input [(ngModel)]="search" placeholder="Product, seller, category"></label>
      <label>Status
        <select [(ngModel)]="statusFilter">
          <option value="all">All products</option>
          <option value="pending">Pending</option>
          <option value="approved">Approved</option>
          <option value="rejected">Rejected</option>
        </select>
      </label>
      <label>Reject reason<input [(ngModel)]="rejectReason"></label>
      <label>Disable reason<input [(ngModel)]="disableReason"></label>
    </section>

    <section class="seller-admin-grid">
      <section class="surface dashboard-panel">
        <table *ngIf="filteredProducts().length">
          <tr>
            <th>Name</th>
            <th>Category</th>
            <th>Seller</th>
            <th>Price</th>
            <th>Status</th>
            <th>Actions</th>
          </tr>
          <tr *ngFor="let product of filteredProducts()" [class.selected-row]="selectedProduct()?.id === product.id">
            <td><button class="table-link" (click)="selectProduct(product)">{{ product.name }}</button></td>
            <td>{{ categoryName(product.categoryId) }}</td>
            <td>{{ sellerName(product.sellerId) }}</td>
            <td>{{ product.price | money:product.currency }}</td>
            <td><app-status-badge kind="product" [status]="product.status"></app-status-badge></td>
            <td class="action-row">
              <button *ngIf="isPending(product)" (click)="approve(product.id)">Approve</button>
              <button *ngIf="isPending(product)" class="ghost-light" (click)="reject(product.id)">Reject</button>
              <button *ngIf="isApproved(product)" class="text-danger" (click)="disable(product.id)">Disable</button>
              <button *ngIf="isRejected(product)" (click)="approve(product.id)">Re-approve</button>
            </td>
          </tr>
        </table>
        <app-empty-state *ngIf="!filteredProducts().length" title="No products found" message="Try another status or search term."></app-empty-state>
      </section>

      <aside class="surface seller-detail-pane" *ngIf="selectedProduct() as product">
        <div class="product-detail-media" *ngIf="product.imageUrl; else noImage">
          <img [src]="product.imageUrl" [alt]="product.name">
        </div>
        <ng-template #noImage>
          <div class="product-detail-media empty-media">No image</div>
        </ng-template>

        <div class="seller-detail-heading">
          <span class="eyebrow">Product detail</span>
          <h2>{{ product.name }}</h2>
          <app-status-badge kind="product" [status]="product.status"></app-status-badge>
        </div>

        <p class="muted">{{ product.description }}</p>

        <div class="seller-detail-grid">
          <div><span>Category</span><strong>{{ categoryName(product.categoryId) }}</strong></div>
          <div><span>Seller</span><strong>{{ sellerName(product.sellerId) }}</strong></div>
          <div><span>Price</span><strong>{{ product.price | money:product.currency }}</strong></div>
          <div><span>Stock</span><strong>{{ stockLabel() }}</strong></div>
          <div><span>Reserved</span><strong>{{ selectedInventory()?.reservedQuantity ?? 0 }}</strong></div>
          <div><span>SKU</span><strong>{{ selectedInventory()?.sku || 'Not created yet' }}</strong></div>
          <div><span>Reason</span><strong>{{ product.rejectionReason || 'None' }}</strong></div>
        </div>

        <div class="action-row detail-actions">
          <button *ngIf="isPending(product)" (click)="approve(product.id)">Approve product</button>
          <button *ngIf="isPending(product)" class="ghost-light" (click)="reject(product.id)">Reject product</button>
          <button *ngIf="isApproved(product)" class="text-danger" (click)="disable(product.id)">Disable product</button>
          <button *ngIf="isRejected(product)" (click)="approve(product.id)">Re-approve product</button>
        </div>

        <form class="stock-update-form" (ngSubmit)="saveProduct(product.id)">
          <h3>Edit product details</h3>
          <label>Category
            <select [(ngModel)]="editCategoryId" name="editCategoryId" required>
              <option *ngFor="let category of categories()" [value]="category.id">{{ category.name }}</option>
            </select>
          </label>
          <label>Name<input [(ngModel)]="editName" name="editName" required></label>
          <label>Slug<input [(ngModel)]="editSlug" name="editSlug" placeholder="Auto-generated when empty"></label>
          <label>Description<textarea [(ngModel)]="editDescription" name="editDescription" rows="4" required></textarea></label>
          <label>Price<input [(ngModel)]="editPrice" name="editPrice" type="number" min="1" required></label>
          <label>Currency
            <select [(ngModel)]="editCurrency" name="editCurrency" required>
              <option *ngFor="let item of currencies" [value]="item">{{ item }}</option>
            </select>
          </label>
          <label>Image URL<input [(ngModel)]="editImageUrl" name="editImageUrl"></label>
          <button type="submit" [disabled]="busy()">Save product details</button>
        </form>
      </aside>

      <aside class="surface seller-detail-pane" *ngIf="!selectedProduct()">
        <app-empty-state title="Select a product" message="Open a row to inspect images, seller, category, and stock."></app-empty-state>
      </aside>
    </section>
  `
})
export class AdminProductsComponent implements OnInit {
  search = '';
  statusFilter = 'all';
  rejectReason = 'Product does not meet catalog standards.';
  disableReason = 'Product disabled by admin.';
  readonly currencies = ['INR', 'USD', 'EUR', 'GBP', 'AED'];
  readonly busy = signal(false);
  editCategoryId = '';
  editName = '';
  editSlug = '';
  editDescription = '';
  editPrice = 0;
  editCurrency = 'INR';
  editImageUrl = '';
  readonly products = signal<AdminProduct[]>([]);
  readonly categories = signal<AdminCategory[]>([]);
  readonly sellers = signal<AdminSeller[]>([]);
  readonly selectedProduct = signal<AdminProduct | null>(null);
  readonly selectedInventory = signal<InventoryItem | null>(null);
  readonly message = signal('');

  constructor(private readonly api: AdminApiService, private readonly errors: ErrorMessageService) {}

  ngOnInit(): void {
    this.load();
  }

  load(): void {
    forkJoin({
      products: this.api.products(),
      categories: this.api.categories(),
      sellers: this.api.sellers()
    }).subscribe({
      next: ({ products, categories, sellers }) => {
        this.products.set(products);
        this.categories.set(categories);
        this.sellers.set(sellers);
        const selectedId = this.selectedProduct()?.id;
        const nextSelected = products.find((product) => product.id === selectedId) ?? products[0] ?? null;
        this.selectProduct(nextSelected);
      },
      error: (error) => this.message.set(this.errors.from(error))
    });
  }

  filteredProducts(): AdminProduct[] {
    const term = this.search.trim().toLowerCase();
    return this.products().filter((product) => {
      const statusMatches = this.statusFilter === 'all' || this.statusText(product.status) === this.statusFilter;
      const searchable = [
        product.name,
        product.description,
        this.categoryName(product.categoryId),
        this.sellerName(product.sellerId)
      ].join(' ').toLowerCase();
      return statusMatches && (!term || searchable.includes(term));
    });
  }

  selectProduct(product: AdminProduct | null): void {
    this.selectedProduct.set(product);
    this.selectedInventory.set(null);
    if (!product) {
      return;
    }

    this.fillEditForm(product);

    this.api.productInventory(product.id).pipe(catchError(() => of(null))).subscribe((inventory) => {
      this.selectedInventory.set(inventory);
    });
  }

  saveProduct(productId: string): void {
    this.busy.set(true);
    this.api.updateProduct(productId, {
      categoryId: this.editCategoryId,
      name: this.editName,
      slug: this.editSlug || null,
      description: this.editDescription,
      price: Number(this.editPrice),
      currency: this.editCurrency || 'INR',
      imageUrl: this.editImageUrl || null
    }).subscribe({
      next: (product) => {
        this.busy.set(false);
        this.message.set('Product details updated.');
        this.products.set(this.products().map((item) => item.id === product.id ? product : item));
        this.selectProduct(product);
      },
      error: (error) => {
        this.busy.set(false);
        this.message.set(this.errors.from(error));
      }
    });
  }

  approve(id: string): void {
    this.api.approveProduct(id).subscribe({
      next: () => {
        this.message.set('Product approved.');
        this.load();
      },
      error: (error) => this.message.set(this.errors.from(error))
    });
  }

  reject(id: string): void {
    this.api.rejectProduct(id, this.rejectReason || 'Product rejected.').subscribe({
      next: () => {
        this.message.set('Product rejected.');
        this.load();
      },
      error: (error) => this.message.set(this.errors.from(error))
    });
  }

  disable(id: string): void {
    this.api.disableProduct(id, this.disableReason || 'Product disabled by admin.').subscribe({
      next: () => {
        this.message.set('Product disabled.');
        this.load();
      },
      error: (error) => this.message.set(this.errors.from(error))
    });
  }

  countByStatus(status: string): number {
    return this.products().filter((product) => this.statusText(product.status) === status).length;
  }

  categoryName(categoryId: string): string {
    return this.categories().find((category) => category.id === categoryId)?.name ?? categoryId;
  }

  sellerName(sellerId: string): string {
    const seller = this.sellers().find((item) => item.id === sellerId || item.userId === sellerId);
    return seller?.businessName ?? sellerId;
  }

  stockLabel(): string {
    const inventory = this.selectedInventory();
    if (!inventory) {
      return 'No inventory item';
    }

    return `${inventory.availableQuantity} available / ${inventory.quantityOnHand} on hand`;
  }

  isPending(product: AdminProduct): boolean {
    return this.statusText(product.status) === 'pending';
  }

  isApproved(product: AdminProduct): boolean {
    return this.statusText(product.status) === 'approved';
  }

  isRejected(product: AdminProduct): boolean {
    return this.statusText(product.status) === 'rejected';
  }

  private statusText(status: string | number): string {
    if (typeof status === 'number') {
      return ({ 1: 'pending', 2: 'approved', 3: 'rejected' } as Record<number, string>)[status] ?? String(status);
    }

    return status.toLowerCase();
  }

  private fillEditForm(product: AdminProduct): void {
    this.editCategoryId = product.categoryId;
    this.editName = product.name;
    this.editSlug = product.slug;
    this.editDescription = product.description;
    this.editPrice = product.price;
    this.editCurrency = product.currency;
    this.editImageUrl = product.imageUrl ?? '';
  }
}
