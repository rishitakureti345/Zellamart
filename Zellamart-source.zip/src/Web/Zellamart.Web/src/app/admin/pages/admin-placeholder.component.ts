import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, RouterLink } from '@angular/router';

@Component({
  selector: 'app-admin-placeholder',
  standalone: true,
  imports: [CommonModule, RouterLink],
  template: `
    <section class="dashboard-header">
      <div>
        <span class="eyebrow">Admin</span>
        <h1>{{ title() }}</h1>
        <p>{{ description() }}</p>
      </div>
      <a class="button-link" routerLink="/admin/dashboard">Dashboard</a>
    </section>

    <section class="surface dashboard-panel admin-placeholder">
      <h2>Version 1 workspace</h2>
      <p>This admin section is reserved in the shell so the control center structure is complete before backend integration.</p>
      <div class="placeholder-grid">
        <span *ngFor="let item of plannedItems()">{{ item }}</span>
      </div>
    </section>
  `
})
export class AdminPlaceholderComponent implements OnInit {
  readonly title = signal('Admin section');
  readonly description = signal('This workspace is planned for the Version 1 admin control center.');
  readonly plannedItems = signal<string[]>([]);

  constructor(private readonly route: ActivatedRoute) {}

  ngOnInit(): void {
    this.route.data.subscribe((data) => {
      this.title.set(data['title'] ?? 'Admin section');
      this.description.set(data['description'] ?? 'This workspace is planned for the Version 1 admin control center.');
      this.plannedItems.set(data['plannedItems'] ?? []);
    });
  }
}
