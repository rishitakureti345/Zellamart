import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { catchError, forkJoin, of } from 'rxjs';
import { AdminApiService } from '../services/admin-api.service';
import { Order, Payment, Shipment } from '../../customer/models/order.model';
import { ErrorMessageService } from '../../core/services/error-message.service';
import { MoneyPipe } from '../../shared/pipes/money.pipe';
import { EmptyStateComponent } from '../../shared/components/empty-state/empty-state.component';
import { StatusBadgeComponent } from '../../shared/components/status-badge/status-badge.component';
import { ToastComponent } from '../../shared/components/toast/toast.component';

interface OrderEnrichment {
  payments: Payment[];
  shipment: Shipment | null;
}

@Component({
  selector: 'app-admin-orders',
  standalone: true,
  imports: [CommonModule, FormsModule, MoneyPipe, EmptyStateComponent, StatusBadgeComponent, ToastComponent],
  template: `
    <section class="dashboard-header">
      <div>
        <span class="eyebrow">Operations</span>
        <h1>Order management</h1>
        <p>Monitor payment, fulfillment, and intervene when customer orders need help.</p>
      </div>
      <button (click)="load()">Refresh</button>
    </section>

    <app-toast [message]="message()"></app-toast>

    <section class="metric-grid">
      <article class="metric-card"><span>Total orders</span><strong>{{ orders().length }}</strong></article>
      <article class="metric-card"><span>Pending</span><strong>{{ countByStatus('Pending') }}</strong></article>
      <article class="metric-card"><span>Confirmed</span><strong>{{ countByStatus('Confirmed') }}</strong></article>
      <article class="metric-card"><span>Delivered</span><strong>{{ countByStatus('Delivered') }}</strong></article>
    </section>

    <section class="seller-toolbar users-toolbar">
      <label>Search<input [(ngModel)]="search" placeholder="Order number, customer, item"></label>
      <label>Status
        <select [(ngModel)]="statusFilter">
          <option value="all">All statuses</option>
          <option *ngFor="let status of statusFilters" [value]="status">{{ status }}</option>
        </select>
      </label>
      <label>Force status
        <select [(ngModel)]="forceStatus">
          <option *ngFor="let status of forceStatuses" [value]="status.value">{{ status.label }}</option>
        </select>
      </label>
    </section>

    <section class="seller-toolbar users-toolbar">
      <label>Cancel reason<input [(ngModel)]="cancelReason"></label>
      <label>Force note<input [(ngModel)]="forceNote"></label>
      <span></span>
    </section>

    <section class="seller-admin-grid">
      <section class="surface dashboard-panel">
        <table *ngIf="filteredOrders().length">
          <tr>
            <th>Order</th>
            <th>Status</th>
            <th>Payment</th>
            <th>Shipping</th>
            <th>Total</th>
            <th>Actions</th>
          </tr>
          <tr *ngFor="let order of filteredOrders()" [class.selected-row]="selectedOrder()?.id === order.id">
            <td>
              <button class="table-link" (click)="selectOrder(order)">
                <strong>{{ order.orderNumber }}</strong><br>
                <span class="muted-line">{{ order.customerId }}</span>
              </button>
            </td>
            <td><app-status-badge kind="order" [status]="order.status" [label]="orderStatusLabel(order.status)"></app-status-badge></td>
            <td><app-status-badge kind="payment" [status]="paymentStatus(order.id)"></app-status-badge></td>
            <td><app-status-badge kind="shipping" [status]="shippingStatus(order.id)"></app-status-badge></td>
            <td>{{ order.subtotal | money:order.currency }}</td>
            <td class="action-row">
              <button (click)="selectOrder(order)">View</button>
              <button class="ghost-light" (click)="force(order.id)">Force</button>
              <button class="text-danger" *ngIf="canCancel(order)" (click)="cancel(order.id)">Cancel</button>
            </td>
          </tr>
        </table>
        <app-empty-state *ngIf="!filteredOrders().length" title="No orders found" message="Try another status or search term."></app-empty-state>
      </section>

      <aside class="surface seller-detail-pane" *ngIf="selectedOrder() as order">
        <div class="seller-detail-heading">
          <span class="eyebrow">Order detail</span>
          <h2>{{ order.orderNumber }}</h2>
          <app-status-badge kind="order" [status]="order.status" [label]="orderStatusLabel(order.status)"></app-status-badge>
        </div>

        <div class="seller-detail-grid">
          <div><span>Customer</span><strong>{{ order.customerId }}</strong></div>
          <div><span>Total</span><strong>{{ order.subtotal | money:order.currency }}</strong></div>
          <div><span>Payment status</span><strong>{{ paymentLabel(order.id) }}</strong></div>
          <div><span>Shipping status</span><strong>{{ shippingLabel(order.id) }}</strong></div>
          <div><span>Created</span><strong>{{ order.createdAtUtc | date:'medium' }}</strong></div>
          <div><span>Items</span><strong>{{ order.items.length }}</strong></div>
        </div>

        <div class="action-row detail-actions">
          <button class="ghost-light" (click)="force(order.id)">Force status update</button>
          <button class="text-danger" *ngIf="canCancel(order)" (click)="cancel(order.id)">Cancel order</button>
        </div>

        <section>
          <h3>Products</h3>
          <table>
            <tr><th>Product</th><th>Seller</th><th>Qty</th><th>Total</th></tr>
            <tr *ngFor="let item of order.items">
              <td>{{ item.productName }}</td>
              <td>{{ item.sellerId }}</td>
              <td>{{ item.quantity }}</td>
              <td>{{ item.lineTotal | money:order.currency }}</td>
            </tr>
          </table>
        </section>

        <section>
          <h3>Status history</h3>
          <table>
            <tr><th>Status</th><th>Note</th><th>Changed</th></tr>
            <tr *ngFor="let entry of order.statusHistory">
              <td><app-status-badge kind="order" [status]="entry.status" [label]="orderStatusLabel(entry.status)"></app-status-badge></td>
              <td>{{ entry.note }}</td>
              <td>{{ entry.changedAtUtc | date:'medium' }}</td>
            </tr>
          </table>
        </section>
      </aside>

      <aside class="surface seller-detail-pane" *ngIf="!selectedOrder()">
        <app-empty-state title="Select an order" message="Open a row to inspect payment, shipping, items, and history."></app-empty-state>
      </aside>
    </section>
  `
})
export class AdminOrdersComponent implements OnInit {
  search = '';
  statusFilter = 'all';
  forceStatus = 'Confirmed';
  cancelReason = 'Order cancelled by admin.';
  forceNote = 'Status updated by admin.';
  readonly statusFilters = ['Pending', 'Confirmed', 'Packed', 'Shipped', 'Delivered', 'Cancelled', 'Refunded'];
  readonly forceStatuses = [
    { label: 'Pending', value: 'PendingPayment' },
    { label: 'Confirmed', value: 'Confirmed' },
    { label: 'Packed', value: 'Packed' },
    { label: 'Shipped', value: 'Shipped' },
    { label: 'Delivered', value: 'Delivered' },
    { label: 'Cancelled', value: 'Cancelled' },
    { label: 'Refunded', value: 'Refunded' }
  ];
  readonly orders = signal<Order[]>([]);
  readonly enrichments = signal<Record<string, OrderEnrichment>>({});
  readonly selectedOrder = signal<Order | null>(null);
  readonly message = signal('');

  constructor(private readonly api: AdminApiService, private readonly errors: ErrorMessageService) {}

  ngOnInit(): void {
    this.load();
  }

  load(): void {
    this.api.orders().subscribe({
      next: (orders) => {
        this.orders.set(orders);
        this.selectedOrder.set(orders.find((order) => order.id === this.selectedOrder()?.id) ?? orders[0] ?? null);
        this.loadEnrichments(orders);
      },
      error: (error) => this.message.set(this.errors.from(error))
    });
  }

  filteredOrders(): Order[] {
    const term = this.search.trim().toLowerCase();
    return this.orders().filter((order) => {
      const statusMatches = this.statusFilter === 'all' || this.orderStatusLabel(order.status) === this.statusFilter;
      const searchable = [
        order.orderNumber,
        order.customerId,
        ...order.items.map((item) => `${item.productName} ${item.sellerId}`)
      ].join(' ').toLowerCase();
      return statusMatches && (!term || searchable.includes(term));
    });
  }

  selectOrder(order: Order): void {
    this.selectedOrder.set(order);
  }

  cancel(orderId: string): void {
    this.api.cancelOrder(orderId, this.cancelReason || 'Order cancelled by admin.').subscribe({
      next: () => {
        this.message.set('Order cancelled.');
        this.load();
      },
      error: (error) => this.message.set(this.errors.from(error))
    });
  }

  force(orderId: string): void {
    this.api.forceOrderStatus(orderId, this.forceStatus, this.forceNote || 'Status updated by admin.').subscribe({
      next: () => {
        this.message.set('Order status updated.');
        this.load();
      },
      error: (error) => this.message.set(this.errors.from(error))
    });
  }

  canCancel(order: Order): boolean {
    return !['Cancelled', 'Delivered', 'Refunded'].includes(this.orderStatusLabel(order.status));
  }

  countByStatus(status: string): number {
    return this.orders().filter((order) => this.orderStatusLabel(order.status) === status).length;
  }

  paymentStatus(orderId: string): string | number {
    return this.enrichments()[orderId]?.payments[0]?.status ?? 'No payment';
  }

  paymentLabel(orderId: string): string {
    const payment = this.enrichments()[orderId]?.payments[0];
    return payment ? String(payment.status) : 'No payment record';
  }

  shippingStatus(orderId: string): string | number {
    return this.enrichments()[orderId]?.shipment?.status ?? 'No shipment';
  }

  shippingLabel(orderId: string): string {
    const shipment = this.enrichments()[orderId]?.shipment;
    return shipment ? `${shipment.status} (${shipment.trackingNumber})` : 'No shipment record';
  }

  orderStatusLabel(status: string | number): string {
    const value = String(status);
    const map: Record<string, string> = {
      '1': 'Pending',
      PendingPayment: 'Pending',
      '2': 'Confirmed',
      PaymentSucceeded: 'Confirmed',
      '3': 'Pending',
      PaymentFailed: 'Pending',
      '4': 'Confirmed',
      Confirmed: 'Confirmed',
      '5': 'Cancelled',
      Cancelled: 'Cancelled',
      '6': 'Delivered',
      Delivered: 'Delivered',
      '7': 'Packed',
      Packed: 'Packed',
      '8': 'Shipped',
      Shipped: 'Shipped',
      '9': 'Refunded',
      Refunded: 'Refunded'
    };
    return map[value] ?? value;
  }

  private loadEnrichments(orders: Order[]): void {
    if (!orders.length) {
      this.enrichments.set({});
      return;
    }

    const calls = orders.map((order) =>
      forkJoin({
        payments: this.api.orderPayments(order.id).pipe(catchError(() => of([] as Payment[]))),
        shipment: this.api.orderShipment(order.id).pipe(catchError(() => of(null)))
      })
    );

    forkJoin(calls).subscribe((rows) => {
      const next: Record<string, OrderEnrichment> = {};
      rows.forEach((row, index) => {
        next[orders[index].id] = row;
      });
      this.enrichments.set(next);
    });
  }
}
