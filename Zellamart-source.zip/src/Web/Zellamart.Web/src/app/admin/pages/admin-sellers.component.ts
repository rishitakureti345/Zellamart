import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { catchError, forkJoin, of } from 'rxjs';
import { AdminApiService } from '../services/admin-api.service';
import { AdminProduct, AdminSeller, AdminSellerBalance } from '../models/admin.model';
import { ErrorMessageService } from '../../core/services/error-message.service';
import { Order } from '../../customer/models/order.model';
import { MoneyPipe } from '../../shared/pipes/money.pipe';
import { StatusBadgeComponent } from '../../shared/components/status-badge/status-badge.component';
import { EmptyStateComponent } from '../../shared/components/empty-state/empty-state.component';
import { ToastComponent } from '../../shared/components/toast/toast.component';

@Component({
  selector: 'app-admin-sellers',
  standalone: true,
  imports: [CommonModule, FormsModule, MoneyPipe, StatusBadgeComponent, EmptyStateComponent, ToastComponent],
  template: `
    <section class="dashboard-header">
      <div>
        <span class="eyebrow">Seller management</span>
        <h1>Sellers</h1>
        <p>View every seller, inspect applications, approve, reject, suspend, or reactivate accounts.</p>
      </div>
      <button (click)="load()">Refresh</button>
    </section>
    <app-toast [message]="message()"></app-toast>

    <section class="seller-admin-grid">
      <section class="seller-list-pane">
        <section class="surface seller-toolbar">
          <label>Search<input [(ngModel)]="search" placeholder="Business, owner, email"></label>
          <label>Status
            <select [(ngModel)]="statusFilter">
              <option value="All">All sellers</option>
              <option value="Pending">Pending</option>
              <option value="Approved">Approved</option>
              <option value="Rejected">Rejected</option>
              <option value="Suspended">Suspended</option>
            </select>
          </label>
        </section>

        <section class="surface dashboard-panel" *ngIf="filteredSellers().length">
          <table>
            <tr><th>Business</th><th>Owner</th><th>Email</th><th>Status</th><th>Actions</th></tr>
            <tr *ngFor="let seller of filteredSellers()" [class.selected-row]="selectedSeller()?.id === seller.id">
              <td><button class="table-link" type="button" (click)="selectSeller(seller)">{{ seller.businessName }}</button></td>
              <td>{{ seller.ownerName }}</td>
              <td>{{ seller.contactEmail }}</td>
              <td><app-status-badge kind="seller" [status]="seller.status"></app-status-badge></td>
              <td class="action-row">
                <button type="button" (click)="selectSeller(seller)">View</button>
                <button type="button" *ngIf="!isStatus(seller, 'Approved')" (click)="approve(seller.id)">Approve</button>
                <button type="button" class="ghost-light" *ngIf="isStatus(seller, 'Pending')" (click)="reject(seller.id)">Reject</button>
                <button type="button" class="text-danger" *ngIf="!isStatus(seller, 'Suspended')" (click)="suspend(seller.id)">Suspend</button>
                <button type="button" class="ghost-light" *ngIf="isStatus(seller, 'Suspended') || isStatus(seller, 'Rejected')" (click)="reactivate(seller.id)">Reactivate</button>
              </td>
            </tr>
          </table>
        </section>
        <app-empty-state *ngIf="!filteredSellers().length" title="No sellers found" message="Change filters or wait for seller applications."></app-empty-state>
      </section>

      <aside class="surface seller-detail-pane" *ngIf="selectedSeller() as seller; else noSellerSelected">
        <header>
          <div>
            <span class="eyebrow">Seller detail</span>
            <h2>{{ seller.businessName }}</h2>
          </div>
          <app-status-badge kind="seller" [status]="seller.status"></app-status-badge>
        </header>

        <section class="seller-detail-grid">
          <div><span>Business name</span><strong>{{ seller.businessName }}</strong></div>
          <div><span>Owner name</span><strong>{{ seller.ownerName }}</strong></div>
          <div><span>Email</span><strong>{{ seller.contactEmail }}</strong></div>
          <div><span>Phone</span><strong>{{ seller.phone || 'Not provided' }}</strong></div>
          <div><span>Status</span><strong>{{ sellerStatusLabel(seller.status) }}</strong></div>
          <div><span>Products</span><strong>{{ selectedProducts().length }}</strong></div>
          <div><span>Orders</span><strong>{{ selectedOrders().length }}</strong></div>
          <div><span>Available earnings</span><strong>{{ (selectedBalance()?.availableBalance || 0) | money }}</strong></div>
        </section>

        <section class="seller-finance-summary">
          <article><span>Pending earnings</span><strong>{{ (selectedBalance()?.pendingEarnings || 0) | money }}</strong></article>
          <article><span>Paid out</span><strong>{{ (selectedBalance()?.totalPaidOut || 0) | money }}</strong></article>
          <article><span>Refund deductions</span><strong>{{ (selectedBalance()?.refundDeductions || 0) | money }}</strong></article>
        </section>

        <label class="inline-reason">Reason<input [(ngModel)]="reason" placeholder="Reason for reject or suspend"></label>
        <div class="action-row">
          <button type="button" *ngIf="!isStatus(seller, 'Approved')" (click)="approve(seller.id)">Approve seller</button>
          <button type="button" class="ghost-light" *ngIf="isStatus(seller, 'Pending')" (click)="reject(seller.id)">Reject seller</button>
          <button type="button" class="text-danger" *ngIf="!isStatus(seller, 'Suspended')" (click)="suspend(seller.id)">Suspend seller</button>
          <button type="button" class="ghost-light" *ngIf="isStatus(seller, 'Suspended') || isStatus(seller, 'Rejected')" (click)="reactivate(seller.id)">Reactivate seller</button>
        </div>
      </aside>

      <ng-template #noSellerSelected>
        <aside class="surface seller-detail-pane">
          <app-empty-state title="Select a seller" message="Choose a seller from the table to view profile, products, orders, and earnings."></app-empty-state>
        </aside>
      </ng-template>
    </section>
  `
})
export class AdminSellersComponent implements OnInit {
  reason = 'Reviewed by admin.';
  search = '';
  statusFilter = 'All';
  readonly sellers = signal<AdminSeller[]>([]);
  readonly balances = signal<AdminSellerBalance[]>([]);
  readonly selectedSeller = signal<AdminSeller | null>(null);
  readonly selectedProducts = signal<AdminProduct[]>([]);
  readonly selectedOrders = signal<Order[]>([]);
  readonly selectedBalance = signal<AdminSellerBalance | null>(null);
  readonly message = signal('');
  constructor(private readonly api: AdminApiService, private readonly errors: ErrorMessageService) {}
  ngOnInit(): void { this.load(); }
  load(): void {
    forkJoin({
      sellers: this.api.sellers().pipe(catchError(() => of([] as AdminSeller[]))),
      pendingSellers: this.api.pendingSellers().pipe(catchError(() => of([] as AdminSeller[]))),
      balances: this.api.sellerBalances().pipe(catchError(() => of([])))
    }).subscribe({
      next: (data) => {
        const sellers = this.mergeSellerLists(data.sellers, data.pendingSellers);
        this.sellers.set(sellers);
        this.balances.set(data.balances);
        const selected = this.selectedSeller();
        const nextSelected = selected ? sellers.find((seller) => seller.id === selected.id) ?? null : sellers[0] ?? null;
        if (nextSelected) {
          this.selectSeller(nextSelected);
        } else {
          this.selectedSeller.set(null);
          this.selectedProducts.set([]);
          this.selectedOrders.set([]);
          this.selectedBalance.set(null);
        }
      },
      error: (e) => this.message.set(this.errors.from(e))
    });
  }

  filteredSellers(): AdminSeller[] {
    const search = this.search.trim().toLowerCase();
    return this.sellers().filter((seller) => {
      const matchesStatus = this.statusFilter === 'All' || this.statusText(seller.status) === this.statusFilter.toLowerCase();
      const matchesSearch = !search
        || seller.businessName.toLowerCase().includes(search)
        || seller.ownerName.toLowerCase().includes(search)
        || seller.contactEmail.toLowerCase().includes(search);
      return matchesStatus && matchesSearch;
    });
  }

  selectSeller(seller: AdminSeller): void {
    this.selectedSeller.set(seller);
    this.selectedBalance.set(this.balances().find((balance) => balance.sellerId === seller.id) ?? null);
    forkJoin({
      products: this.api.sellerProducts(seller.id).pipe(catchError(() => of([]))),
      orders: this.api.sellerOrders(seller.id).pipe(catchError(() => of([])))
    }).subscribe({
      next: (data) => {
        this.selectedProducts.set(data.products);
        this.selectedOrders.set(data.orders);
      },
      error: (e) => this.message.set(this.errors.from(e))
    });
  }

  approve(id: string): void { this.api.approveSeller(id).subscribe({ next: () => { this.message.set('Seller approved.'); this.load(); }, error: (e) => this.message.set(this.errors.from(e)) }); }
  reject(id: string): void { this.api.rejectSeller(id, this.reason || 'Seller rejected.').subscribe({ next: () => { this.message.set('Seller rejected.'); this.load(); }, error: (e) => this.message.set(this.errors.from(e)) }); }
  suspend(id: string): void { this.api.suspendSeller(id, this.reason || 'Seller suspended.').subscribe({ next: () => { this.message.set('Seller suspended.'); this.load(); }, error: (e) => this.message.set(this.errors.from(e)) }); }
  reactivate(id: string): void { this.api.reactivateSeller(id).subscribe({ next: () => { this.message.set('Seller reactivated.'); this.load(); }, error: (e) => this.message.set(this.errors.from(e)) }); }

  isStatus(seller: AdminSeller, status: string): boolean {
    return this.statusText(seller.status) === status.toLowerCase();
  }

  sellerStatusLabel(status: string | number): string {
    const text = this.statusText(status);
    return text.charAt(0).toUpperCase() + text.slice(1);
  }

  private statusText(status: string | number): string {
    const numericLabels: Record<number, string> = {
      1: 'pending',
      2: 'approved',
      3: 'rejected',
      4: 'suspended'
    };

    if (typeof status === 'number') {
      return numericLabels[status] ?? String(status).toLowerCase();
    }

    const numeric = Number(status);
    if (!Number.isNaN(numeric)) {
      return numericLabels[numeric] ?? status.toLowerCase();
    }

    return status.toLowerCase();
  }

  private mergeSellerLists(sellers: AdminSeller[], pendingSellers: AdminSeller[]): AdminSeller[] {
    const merged = new Map<string, AdminSeller>();
    for (const seller of sellers) {
      merged.set(seller.id, seller);
    }
    for (const seller of pendingSellers) {
      merged.set(seller.id, seller);
    }

    return Array.from(merged.values());
  }
}
