import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { forkJoin, of } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { AdminApiService } from '../services/admin-api.service';
import { AdminUser } from '../models/admin.model';
import { NotificationItem } from '../../customer/models/support.model';
import { ErrorMessageService } from '../../core/services/error-message.service';
import { EmptyStateComponent } from '../../shared/components/empty-state/empty-state.component';
import { ToastComponent } from '../../shared/components/toast/toast.component';

@Component({
  selector: 'app-admin-notifications',
  standalone: true,
  imports: [CommonModule, FormsModule, EmptyStateComponent, ToastComponent],
  template: `
    <section class="dashboard-header">
      <div>
        <span class="eyebrow">Communications</span>
        <h1>Notifications</h1>
        <p>Send announcements and review marketplace notification history.</p>
      </div>
      <button (click)="load()">Refresh</button>
    </section>

    <app-toast [message]="message()"></app-toast>

    <section class="metric-grid">
      <article class="metric-card"><span>Sent notifications</span><strong>{{ notifications().length }}</strong></article>
      <article class="metric-card"><span>Unread</span><strong>{{ unreadCount() }}</strong></article>
      <article class="metric-card"><span>Customers</span><strong>{{ customerUsers().length }}</strong></article>
      <article class="metric-card"><span>Sellers</span><strong>{{ sellerUsers().length }}</strong></article>
    </section>

    <section class="ops-form-grid">
      <form class="surface checkout-form" (ngSubmit)="send()">
        <h2>Send announcement</h2>
        <label>Audience
          <select [(ngModel)]="audience" name="audience">
            <option value="all">All users</option>
            <option value="sellers">Sellers</option>
            <option value="customers">Customers</option>
            <option value="specific">Specific user</option>
          </select>
        </label>
        <label *ngIf="audience === 'specific'">User
          <select [(ngModel)]="specificUserId" name="specificUserId">
            <option value="">Select user</option>
            <option *ngFor="let user of users()" [value]="user.id">{{ user.fullName }} · {{ user.email }}</option>
          </select>
        </label>
        <label>Notification type
          <select [(ngModel)]="notificationType" name="notificationType">
            <option value="SellerApproved">Seller approved</option>
            <option value="SellerRejected">Seller rejected</option>
            <option value="ProductApproved">Product approved</option>
            <option value="ProductRejected">Product rejected</option>
            <option value="OrderUpdate">Order update</option>
            <option value="RefundUpdate">Refund update</option>
            <option value="GeneralAnnouncement">General announcement</option>
          </select>
        </label>
        <label>Title<input [(ngModel)]="title" name="title" required></label>
        <label>Message<textarea [(ngModel)]="body" name="body" rows="5" required></textarea></label>
        <button type="submit">Send notification</button>
      </form>

      <section class="surface dashboard-panel">
        <div class="seller-toolbar compact-toolbar">
          <label>Search<input [(ngModel)]="search" placeholder="Title, message, user, type"></label>
          <label>Type
            <select [(ngModel)]="typeFilter">
              <option value="all">All types</option>
              <option *ngFor="let type of notificationTypes()" [value]="type">{{ type }}</option>
            </select>
          </label>
        </div>

        <table *ngIf="filteredNotifications().length">
          <tr><th>Title</th><th>User</th><th>Type</th><th>Status</th><th>Sent</th></tr>
          <tr *ngFor="let item of filteredNotifications()">
            <td><strong>{{ item.title }}</strong><br><span class="muted-line">{{ item.message }}</span></td>
            <td>{{ userLabel(item.userId) }}</td>
            <td>{{ item.type }}</td>
            <td><span class="status-pill" [class.status-muted]="item.isRead">{{ item.isRead ? 'Read' : 'Unread' }}</span></td>
            <td>{{ item.createdAtUtc | date:'medium' }}</td>
          </tr>
        </table>
        <app-empty-state *ngIf="!filteredNotifications().length" title="No notifications found" message="Sent notifications will appear here."></app-empty-state>
      </section>
    </section>
  `
})
export class AdminNotificationsComponent implements OnInit {
  audience = 'all';
  specificUserId = '';
  notificationType = 'GeneralAnnouncement';
  title = 'Marketplace announcement';
  body = 'A new marketplace update is available.';
  search = '';
  typeFilter = 'all';
  readonly users = signal<AdminUser[]>([]);
  readonly notifications = signal<NotificationItem[]>([]);
  readonly message = signal('');

  constructor(private readonly api: AdminApiService, private readonly errors: ErrorMessageService) {}

  ngOnInit(): void {
    this.load();
  }

  load(): void {
    forkJoin({
      users: this.api.users(),
      notifications: this.api.notifications()
    }).subscribe({
      next: ({ users, notifications }) => {
        this.users.set(users);
        this.notifications.set(notifications);
      },
      error: (error) => this.message.set(this.errors.from(error))
    });
  }

  send(): void {
    const recipients = this.recipients();
    if (!recipients.length) {
      this.message.set('Choose at least one recipient.');
      return;
    }

    if (!this.title.trim() || !this.body.trim()) {
      this.message.set('Title and message are required.');
      return;
    }

    forkJoin(recipients.map((user) =>
      this.api.createNotification(user.id, this.notificationType, this.title.trim(), this.body.trim()).pipe(catchError(() => of(null)))
    )).subscribe((results) => {
      const sent = results.filter(Boolean).length;
      this.message.set(`Sent ${sent} of ${recipients.length} notifications.`);
      this.load();
    });
  }

  filteredNotifications(): NotificationItem[] {
    const term = this.search.trim().toLowerCase();
    return this.notifications().filter((item) => {
      const typeMatches = this.typeFilter === 'all' || item.type === this.typeFilter;
      const searchable = [item.title, item.message, item.type, item.userId, this.userLabel(item.userId)].join(' ').toLowerCase();
      return typeMatches && (!term || searchable.includes(term));
    });
  }

  customerUsers(): AdminUser[] {
    return this.users().filter((user) => user.roles.includes('Customer'));
  }

  sellerUsers(): AdminUser[] {
    return this.users().filter((user) => user.roles.includes('Seller'));
  }

  unreadCount(): number {
    return this.notifications().filter((item) => !item.isRead).length;
  }

  notificationTypes(): string[] {
    return Array.from(new Set(this.notifications().map((item) => item.type))).sort();
  }

  userLabel(userId: string): string {
    const user = this.users().find((item) => item.id === userId);
    return user ? `${user.fullName} (${user.email})` : userId;
  }

  private recipients(): AdminUser[] {
    if (this.audience === 'customers') {
      return this.customerUsers();
    }

    if (this.audience === 'sellers') {
      return this.sellerUsers();
    }

    if (this.audience === 'specific') {
      return this.users().filter((user) => user.id === this.specificUserId);
    }

    return this.users();
  }
}
