import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs';
import { ToastComponent } from '../../shared/components/toast/toast.component';
import { ApiResult } from '../../core/models/api-result.model';
import { ErrorMessageService } from '../../core/services/error-message.service';

interface MarketplaceSettings {
  commissionPercentage: number;
  defaultCurrency: string;
  supportEmail: string;
  returnWindowDays: number;
  lowStockThreshold: number;
  paymentMode: string;
  paymentProvider: string;
  paymentSuccessCaptureEnabled: boolean;
  livePaymentGatewayEnabled: boolean;
  shippingMode: string;
  defaultWarehouse: string;
  adminDeliveryStatusUpdatesEnabled: boolean;
  externalCarrierApiEnabled: boolean;
  savedAtUtc?: string | null;
}

const DEFAULT_SETTINGS: MarketplaceSettings = {
  commissionPercentage: 10,
  defaultCurrency: 'INR',
  supportEmail: 'support@zellamart.test',
  returnWindowDays: 7,
  lowStockThreshold: 5,
  paymentMode: 'Simulation',
  paymentProvider: 'Internal payment simulator',
  paymentSuccessCaptureEnabled: true,
  livePaymentGatewayEnabled: false,
  shippingMode: 'Manual operations',
  defaultWarehouse: 'Main warehouse',
  adminDeliveryStatusUpdatesEnabled: true,
  externalCarrierApiEnabled: false,
  savedAtUtc: null
};

@Component({
  selector: 'app-admin-settings',
  standalone: true,
  imports: [CommonModule, FormsModule, ToastComponent],
  template: `
    <section class="dashboard-header">
      <div>
        <span class="eyebrow">Configuration</span>
        <h1>Marketplace settings</h1>
        <p>Control platform defaults, operational thresholds, and V1 payment/shipping configuration.</p>
      </div>
      <button class="ghost-light" (click)="resetToDefaults()">Reset defaults</button>
    </section>

    <app-toast [message]="message()"></app-toast>

    <section class="metric-grid">
      <article class="metric-card"><span>Commission</span><strong>{{ form.commissionPercentage }}%</strong></article>
      <article class="metric-card"><span>Currency</span><strong>{{ form.defaultCurrency }}</strong></article>
      <article class="metric-card"><span>Return window</span><strong>{{ form.returnWindowDays }} days</strong></article>
      <article class="metric-card"><span>Low stock</span><strong>{{ form.lowStockThreshold }} units</strong></article>
    </section>

    <section class="settings-grid">
      <form class="surface checkout-form settings-form" (ngSubmit)="save()">
        <h2>Marketplace defaults</h2>
        <label>
          Commission percentage
          <input [(ngModel)]="form.commissionPercentage" name="commissionPercentage" type="number" min="0" max="100" step="0.1" required>
        </label>
        <label>
          Default currency
          <select [(ngModel)]="form.defaultCurrency" name="defaultCurrency" required>
            <option *ngFor="let currency of currencies" [value]="currency">{{ currency }}</option>
          </select>
        </label>
        <label>
          Support email
          <input [(ngModel)]="form.supportEmail" name="supportEmail" type="email" required>
        </label>
        <label>
          Return window days
          <input [(ngModel)]="form.returnWindowDays" name="returnWindowDays" type="number" min="0" max="90" required>
        </label>
        <label>
          Low stock threshold
          <input [(ngModel)]="form.lowStockThreshold" name="lowStockThreshold" type="number" min="0" max="1000" required>
        </label>

        <div class="action-row">
          <button type="submit">Save settings</button>
          <button type="button" class="ghost-light" (click)="load()">Undo changes</button>
        </div>
      </form>

      <section class="surface dashboard-panel settings-summary">
        <h2>Current configuration</h2>
        <div class="seller-detail-grid">
          <div><span>Commission rate</span><strong>{{ form.commissionPercentage }}%</strong></div>
          <div><span>Currency</span><strong>{{ form.defaultCurrency }}</strong></div>
          <div><span>Support contact</span><strong>{{ form.supportEmail }}</strong></div>
          <div><span>Return policy</span><strong>{{ form.returnWindowDays }} days</strong></div>
          <div><span>Stock alert</span><strong>{{ form.lowStockThreshold }} units</strong></div>
          <div><span>Status</span><strong>{{ savedAt() ? 'Saved to backend' : 'Backend defaults' }}</strong></div>
        </div>
        <p class="muted-line" *ngIf="savedAt()">Last saved {{ savedAt() | date:'medium' }}</p>
      </section>
    </section>

    <section class="settings-grid">
      <section class="surface dashboard-panel">
        <div class="settings-section-heading">
          <div>
            <h2>Payment settings</h2>
          </div>
          <span class="status-pill status-muted">Backend saved</span>
        </div>
        <div class="settings-placeholder-grid">
          <label>
            Payment mode
            <select [(ngModel)]="form.paymentMode" name="paymentMode">
              <option>Simulation</option>
              <option>Manual verification</option>
              <option>Real provider later</option>
            </select>
          </label>
          <label>
            Provider
            <input [(ngModel)]="form.paymentProvider" name="paymentProvider">
          </label>
          <label class="settings-toggle">
            <input type="checkbox" [(ngModel)]="form.paymentSuccessCaptureEnabled" name="paymentSuccessCaptureEnabled">
            Capture payment success/failure in admin flows
          </label>
          <label class="settings-toggle">
            <input type="checkbox" [(ngModel)]="form.livePaymentGatewayEnabled" name="livePaymentGatewayEnabled">
            Enable live payment gateway
          </label>
        </div>
      </section>

      <section class="surface dashboard-panel">
        <div class="settings-section-heading">
          <div>
            <h2>Shipping settings</h2>
          </div>
          <span class="status-pill status-muted">Backend saved</span>
        </div>
        <div class="settings-placeholder-grid">
          <label>
            Shipping mode
            <select [(ngModel)]="form.shippingMode" name="shippingMode">
              <option>Manual operations</option>
              <option>Warehouse assignment</option>
              <option>Carrier integration later</option>
            </select>
          </label>
          <label>
            Default warehouse
            <input [(ngModel)]="form.defaultWarehouse" name="defaultWarehouse">
          </label>
          <label class="settings-toggle">
            <input type="checkbox" [(ngModel)]="form.adminDeliveryStatusUpdatesEnabled" name="adminDeliveryStatusUpdatesEnabled">
            Allow admin delivery status updates
          </label>
          <label class="settings-toggle">
            <input type="checkbox" [(ngModel)]="form.externalCarrierApiEnabled" name="externalCarrierApiEnabled">
            Enable external carrier API
          </label>
        </div>
      </section>
    </section>
  `
})
export class AdminSettingsComponent implements OnInit {
  readonly currencies = ['INR', 'USD', 'EUR', 'GBP', 'AED'];
  readonly message = signal('');
  readonly savedAt = signal<string | null>(null);
  form: MarketplaceSettings = { ...DEFAULT_SETTINGS };

  constructor(
    private readonly http: HttpClient,
    private readonly errors: ErrorMessageService
  ) {}

  ngOnInit(): void {
    this.load();
  }

  load(): void {
    this.http.get<ApiResult<MarketplaceSettings>>('/api/settings/marketplace')
      .pipe(map((result) => result.value ?? DEFAULT_SETTINGS))
      .subscribe({
        next: (settings) => {
          this.form = { ...DEFAULT_SETTINGS, ...settings };
          this.savedAt.set(settings.savedAtUtc ?? null);
        },
        error: (error) => {
          this.form = { ...DEFAULT_SETTINGS };
          this.savedAt.set(null);
          this.message.set(this.errors.from(error));
        }
      });
  }

  save(): void {
    const validation = this.validationMessage();
    if (validation) {
      this.message.set(validation);
      return;
    }

    this.http.put<ApiResult<MarketplaceSettings>>('/api/settings/marketplace', this.form)
      .pipe(map((result) => result.value ?? this.form))
      .subscribe({
        next: (settings) => {
          this.form = { ...DEFAULT_SETTINGS, ...settings };
          this.savedAt.set(settings.savedAtUtc ?? null);
          this.message.set('Marketplace settings saved to backend.');
        },
        error: (error) => this.message.set(this.errors.from(error))
      });
  }

  resetToDefaults(): void {
    this.form = { ...DEFAULT_SETTINGS };
    this.save();
  }

  private validationMessage(): string {
    if (this.form.commissionPercentage < 0 || this.form.commissionPercentage > 100) {
      return 'Commission percentage must be between 0 and 100.';
    }

    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(this.form.supportEmail)) {
      return 'Support email must be valid.';
    }

    if (this.form.returnWindowDays < 0 || this.form.returnWindowDays > 90) {
      return 'Return window must be between 0 and 90 days.';
    }

    if (this.form.lowStockThreshold < 0 || this.form.lowStockThreshold > 1000) {
      return 'Low stock threshold must be between 0 and 1000.';
    }

    return '';
  }
}
