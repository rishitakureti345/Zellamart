import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { AdminApiService } from '../services/admin-api.service';
import { ReturnRequest } from '../../customer/models/support.model';
import { ErrorMessageService } from '../../core/services/error-message.service';
import { MoneyPipe } from '../../shared/pipes/money.pipe';
import { EmptyStateComponent } from '../../shared/components/empty-state/empty-state.component';
import { StatusBadgeComponent } from '../../shared/components/status-badge/status-badge.component';
import { ToastComponent } from '../../shared/components/toast/toast.component';

@Component({
  selector: 'app-admin-returns',
  standalone: true,
  imports: [CommonModule, FormsModule, MoneyPipe, EmptyStateComponent, StatusBadgeComponent, ToastComponent],
  template: `
    <section class="dashboard-header">
      <div>
        <span class="eyebrow">Returns</span>
        <h1>Returns and refunds</h1>
        <p>Approve returns, track pickup, and control refund outcomes.</p>
      </div>
      <button (click)="load()">Refresh</button>
    </section>

    <app-toast [message]="message()"></app-toast>

    <section class="metric-grid">
      <article class="metric-card"><span>Return requests</span><strong>{{ returns().length }}</strong></article>
      <article class="metric-card"><span>Requested</span><strong>{{ countByStatus('Requested') }}</strong></article>
      <article class="metric-card"><span>Picked up</span><strong>{{ countByStatus('Picked up') }}</strong></article>
      <article class="metric-card"><span>Refunded</span><strong>{{ countByStatus('Refunded') }}</strong></article>
    </section>

    <section class="seller-toolbar users-toolbar">
      <label>Search<input [(ngModel)]="search" placeholder="Order, customer, product, reason"></label>
      <label>Status
        <select [(ngModel)]="statusFilter">
          <option value="all">All statuses</option>
          <option *ngFor="let status of statusFilters" [value]="status">{{ status }}</option>
        </select>
      </label>
      <label>Reject reason<input [(ngModel)]="rejectReason"></label>
    </section>

    <section class="seller-toolbar users-toolbar">
      <label>Refund reject reason<input [(ngModel)]="refundRejectReason"></label>
      <span></span>
      <span></span>
    </section>

    <section class="seller-admin-grid">
      <section class="surface dashboard-panel">
        <table *ngIf="filteredReturns().length">
          <tr><th>Return</th><th>Order</th><th>Status</th><th>Refund</th><th>Actions</th></tr>
          <tr *ngFor="let item of filteredReturns()" [class.selected-row]="selectedReturn()?.id === item.id">
            <td><button class="table-link" (click)="selectReturn(item)"><strong>{{ item.id }}</strong><br><span class="muted-line">{{ item.reason }}</span></button></td>
            <td>{{ item.orderId }}</td>
            <td><app-status-badge kind="return" [status]="item.status"></app-status-badge></td>
            <td>{{ item.refundAmount | money }}</td>
            <td class="action-row">
              <button *ngIf="isStatus(item, 'Requested')" (click)="approve(item.id)">Approve</button>
              <button *ngIf="isStatus(item, 'Requested')" class="ghost-light" (click)="reject(item.id)">Reject</button>
              <button *ngIf="isStatus(item, 'Approved') || isStatus(item, 'Pickup scheduled')" (click)="pickedUp(item.id)">Picked up</button>
              <button *ngIf="isStatus(item, 'Picked up') || isStatus(item, 'Refund initiated')" (click)="approveRefund(item.id)">Approve refund</button>
              <button *ngIf="isStatus(item, 'Picked up') || isStatus(item, 'Refund initiated')" class="text-danger" (click)="rejectRefund(item.id)">Reject refund</button>
            </td>
          </tr>
        </table>
        <app-empty-state *ngIf="!filteredReturns().length" title="No returns found" message="Try another status or search term."></app-empty-state>
      </section>

      <aside class="surface seller-detail-pane" *ngIf="selectedReturn() as item">
        <div class="seller-detail-heading">
          <span class="eyebrow">Return detail</span>
          <h2>{{ item.id }}</h2>
          <app-status-badge kind="return" [status]="item.status"></app-status-badge>
        </div>

        <div class="seller-detail-grid">
          <div><span>Order</span><strong>{{ item.orderId }}</strong></div>
          <div><span>Customer</span><strong>{{ item.customerId }}</strong></div>
          <div><span>Product</span><strong>{{ item.productId }}</strong></div>
          <div><span>Order item</span><strong>{{ item.orderItemId }}</strong></div>
          <div><span>Refund amount</span><strong>{{ item.refundAmount | money }}</strong></div>
          <div><span>Created</span><strong>{{ item.createdAtUtc | date:'medium' }}</strong></div>
        </div>

        <p class="muted">{{ item.reason }}</p>

        <div class="action-row detail-actions">
          <button *ngIf="isStatus(item, 'Requested')" (click)="approve(item.id)">Approve return</button>
          <button *ngIf="isStatus(item, 'Requested')" class="ghost-light" (click)="reject(item.id)">Reject return</button>
          <button *ngIf="isStatus(item, 'Approved') || isStatus(item, 'Pickup scheduled')" (click)="pickedUp(item.id)">Mark picked up</button>
          <button *ngIf="isStatus(item, 'Picked up') || isStatus(item, 'Refund initiated')" (click)="approveRefund(item.id)">Approve refund</button>
          <button *ngIf="isStatus(item, 'Picked up') || isStatus(item, 'Refund initiated')" class="text-danger" (click)="rejectRefund(item.id)">Reject refund</button>
        </div>

        <section>
          <h3>Refund status history</h3>
          <table>
            <tr><th>Status</th><th>Note</th><th>Changed by</th><th>Changed</th></tr>
            <tr *ngFor="let entry of item.statusHistory">
              <td><app-status-badge kind="return" [status]="entry.status"></app-status-badge></td>
              <td>{{ entry.note }}</td>
              <td>{{ entry.changedByUserId || '-' }}</td>
              <td>{{ entry.changedAtUtc | date:'medium' }}</td>
            </tr>
          </table>
        </section>
      </aside>
    </section>
  `
})
export class AdminReturnsComponent implements OnInit {
  search = '';
  statusFilter = 'all';
  rejectReason = 'Return request rejected by admin.';
  refundRejectReason = 'Refund rejected after review.';
  readonly statusFilters = ['Requested', 'Approved', 'Rejected', 'Pickup scheduled', 'Picked up', 'Refund initiated', 'Refunded', 'Closed'];
  readonly returns = signal<ReturnRequest[]>([]);
  readonly selectedReturn = signal<ReturnRequest | null>(null);
  readonly message = signal('');

  constructor(private readonly api: AdminApiService, private readonly errors: ErrorMessageService) {}

  ngOnInit(): void {
    this.load();
  }

  load(): void {
    this.api.returns().subscribe({
      next: (returns) => {
        this.returns.set(returns);
        this.selectedReturn.set(returns.find((item) => item.id === this.selectedReturn()?.id) ?? returns[0] ?? null);
      },
      error: (error) => this.message.set(this.errors.from(error))
    });
  }

  filteredReturns(): ReturnRequest[] {
    const term = this.search.trim().toLowerCase();
    return this.returns().filter((item) => {
      const statusMatches = this.statusFilter === 'all' || this.returnStatusLabel(item.status) === this.statusFilter;
      const searchable = [item.id, item.orderId, item.customerId, item.productId, item.reason].join(' ').toLowerCase();
      return statusMatches && (!term || searchable.includes(term));
    });
  }

  selectReturn(item: ReturnRequest): void {
    this.selectedReturn.set(item);
  }

  approve(id: string): void {
    this.api.approveReturn(id).subscribe({ next: () => { this.message.set('Return approved.'); this.load(); }, error: (error) => this.message.set(this.errors.from(error)) });
  }

  reject(id: string): void {
    this.api.rejectReturn(id, this.rejectReason || 'Return rejected.').subscribe({ next: () => { this.message.set('Return rejected.'); this.load(); }, error: (error) => this.message.set(this.errors.from(error)) });
  }

  pickedUp(id: string): void {
    this.api.markReturnPickedUp(id).subscribe({ next: () => { this.message.set('Return picked up.'); this.load(); }, error: (error) => this.message.set(this.errors.from(error)) });
  }

  approveRefund(id: string): void {
    this.api.approveRefund(id).subscribe({ next: () => { this.message.set('Refund approved.'); this.load(); }, error: (error) => this.message.set(this.errors.from(error)) });
  }

  rejectRefund(id: string): void {
    this.api.rejectRefund(id, this.refundRejectReason || 'Refund rejected.').subscribe({ next: () => { this.message.set('Refund rejected.'); this.load(); }, error: (error) => this.message.set(this.errors.from(error)) });
  }

  countByStatus(status: string): number {
    return this.returns().filter((item) => this.returnStatusLabel(item.status) === status).length;
  }

  isStatus(item: ReturnRequest, status: string): boolean {
    return this.returnStatusLabel(item.status) === status;
  }

  returnStatusLabel(status: string | number): string {
    const map: Record<string, string> = {
      '1': 'Requested',
      Requested: 'Requested',
      '2': 'Approved',
      Approved: 'Approved',
      '3': 'Rejected',
      Rejected: 'Rejected',
      '4': 'Pickup scheduled',
      PickupScheduled: 'Pickup scheduled',
      '5': 'Picked up',
      PickedUp: 'Picked up',
      '6': 'Refund initiated',
      RefundInitiated: 'Refund initiated',
      '7': 'Refunded',
      Refunded: 'Refunded',
      '8': 'Closed',
      Closed: 'Closed'
    };
    return map[String(status)] ?? String(status);
  }
}
