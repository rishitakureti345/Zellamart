import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { forkJoin, catchError, of } from 'rxjs';
import { AdminApiService } from '../services/admin-api.service';
import { AdminFinanceSummary, AdminProduct, AdminSeller, AdminUser } from '../models/admin.model';
import { OperationsStaffApiService } from '../../operations/services/operations-staff-api.service';
import { SupportStaffApiService } from '../../support/services/support-staff-api.service';
import { Order } from '../../customer/models/order.model';
import { ReturnRequest, SupportTicket } from '../../customer/models/support.model';
import { MoneyPipe } from '../../shared/pipes/money.pipe';
import { ToastComponent } from '../../shared/components/toast/toast.component';

@Component({
  selector: 'app-admin-dashboard',
  standalone: true,
  imports: [CommonModule, RouterLink, MoneyPipe, ToastComponent],
  template: `
    <section class="dashboard-header">
      <div>
        <span class="eyebrow">Admin</span>
        <h1>Marketplace control room</h1>
        <p>Business health, urgent approvals, operations, refunds, and support in one view.</p>
      </div>
      <button (click)="load()">Refresh</button>
    </section>
    <app-toast [message]="message()"></app-toast>

    <section class="control-metrics">
      <article class="metric"><span>Total users</span><strong>{{ totalUsers() }}</strong></article>
      <article class="metric"><span>Total sellers</span><strong>{{ totalSellers() }}</strong></article>
      <article class="metric"><span>Pending sellers</span><strong>{{ sellers().length }}</strong></article>
      <article class="metric"><span>Pending products</span><strong>{{ products().length }}</strong></article>
      <article class="metric"><span>Total orders</span><strong>{{ orders().length }}</strong></article>
      <article class="metric"><span>Revenue</span><strong>{{ (summary()?.totalSales || orderRevenue()) | money }}</strong></article>
      <article class="metric"><span>Refunds</span><strong>{{ (summary()?.totalRefunds || refundTotal()) | money }}</strong></article>
      <article class="metric"><span>Open tickets</span><strong>{{ openTickets() }}</strong></article>
    </section>

    <section class="quick-actions">
      <a class="surface quick-action" routerLink="/admin/sellers">
        <span>Approve sellers</span>
        <strong>{{ sellers().length }} pending</strong>
        <p>Review applications and approve or reject new sellers.</p>
      </a>
      <a class="surface quick-action" routerLink="/admin/products">
        <span>Review products</span>
        <strong>{{ products().length }} pending</strong>
        <p>Approve or reject submitted catalog items.</p>
      </a>
      <a class="surface quick-action" routerLink="/admin/categories">
        <span>Manage categories</span>
        <strong>Manage categories</strong>
        <p>Create, edit, and deactivate storefront categories.</p>
      </a>
      <a class="surface quick-action" routerLink="/admin/orders">
        <span>View orders</span>
        <strong>{{ orders().length }} orders</strong>
        <p>Monitor order status, payment state, and fulfilment progress.</p>
      </a>
      <a class="surface quick-action" routerLink="/admin/returns">
        <span>Returns/refunds</span>
        <strong>{{ returns().length }} requests</strong>
        <p>Review return requests and refund outcomes.</p>
      </a>
      <a class="surface quick-action" routerLink="/admin/reports">
        <span>Finance reports</span>
        <strong>{{ (summary()?.totalCommission || 0) | money }}</strong>
        <p>Track revenue, commission, refunds, payouts, and seller balances.</p>
      </a>
    </section>

    <section class="activity-grid">
      <article class="surface dashboard-panel activity-panel">
        <h2>New seller applications</h2>
        <div class="activity-list" *ngIf="sellers().length; else noSellers">
          <a *ngFor="let seller of sellers().slice(0, 5)" routerLink="/admin/sellers">
            <strong>{{ seller.businessName }}</strong>
            <span>{{ seller.ownerName }} &middot; {{ seller.contactEmail }}</span>
          </a>
        </div>
        <ng-template #noSellers><p class="muted-line">No seller applications need review.</p></ng-template>
      </article>

      <article class="surface dashboard-panel activity-panel">
        <h2>New product submissions</h2>
        <div class="activity-list" *ngIf="products().length; else noProducts">
          <a *ngFor="let product of products().slice(0, 5)" routerLink="/admin/products">
            <strong>{{ product.name }}</strong>
            <span>{{ product.price | money:product.currency }} &middot; {{ product.status }}</span>
          </a>
        </div>
        <ng-template #noProducts><p class="muted-line">No product submissions need review.</p></ng-template>
      </article>

      <article class="surface dashboard-panel activity-panel">
        <h2>Recent orders</h2>
        <div class="activity-list" *ngIf="recentOrders().length; else noOrders">
          <a *ngFor="let order of recentOrders()" routerLink="/admin/orders">
            <strong>{{ order.orderNumber || order.id }}</strong>
            <span>{{ order.status }} &middot; {{ order.subtotal | money:order.currency }}</span>
          </a>
        </div>
        <ng-template #noOrders><p class="muted-line">No recent orders are available yet.</p></ng-template>
      </article>

      <article class="surface dashboard-panel activity-panel">
        <h2>Recent refund requests</h2>
        <div class="activity-list" *ngIf="recentReturns().length; else noReturns">
          <a *ngFor="let item of recentReturns()" routerLink="/admin/returns">
            <strong>{{ item.status }}</strong>
            <span>{{ item.refundAmount | money }} &middot; Order {{ item.orderId }}</span>
          </a>
        </div>
        <ng-template #noReturns><p class="muted-line">No return or refund requests are waiting.</p></ng-template>
      </article>

      <article class="surface dashboard-panel activity-panel wide-panel">
        <h2>Recent support tickets</h2>
        <div class="activity-list compact" *ngIf="recentTickets().length; else noTickets">
          <a *ngFor="let ticket of recentTickets()" routerLink="/admin/support">
            <strong>{{ ticket.subject }}</strong>
            <span>{{ ticket.status }} &middot; {{ ticket.type }}</span>
          </a>
        </div>
        <ng-template #noTickets><p class="muted-line">No support tickets are open right now.</p></ng-template>
      </article>
    </section>
  `
})
export class AdminDashboardComponent implements OnInit {
  readonly users = signal<AdminUser[]>([]);
  readonly allSellers = signal<AdminSeller[]>([]);
  readonly sellers = signal<AdminSeller[]>([]);
  readonly products = signal<AdminProduct[]>([]);
  readonly orders = signal<Order[]>([]);
  readonly tickets = signal<SupportTicket[]>([]);
  readonly returns = signal<ReturnRequest[]>([]);
  readonly summary = signal<AdminFinanceSummary | null>(null);
  readonly message = signal('');

  constructor(
    private readonly api: AdminApiService,
    private readonly operations: OperationsStaffApiService,
    private readonly support: SupportStaffApiService
  ) {}

  ngOnInit(): void { this.load(); }

  load(): void {
    forkJoin({
      users: this.api.users().pipe(catchError(() => of([]))),
      allSellers: this.api.sellers().pipe(catchError(() => of([]))),
      sellers: this.api.pendingSellers().pipe(catchError(() => of([]))),
      products: this.api.pendingProducts().pipe(catchError(() => of([]))),
      orders: this.operations.orders().pipe(catchError(() => of([]))),
      tickets: this.support.tickets().pipe(catchError(() => of([]))),
      returns: this.support.returns().pipe(catchError(() => of([]))),
      summary: this.api.financeSummary().pipe(catchError(() => of(null)))
    }).subscribe((data) => {
      this.users.set(data.users);
      this.allSellers.set(data.allSellers);
      this.sellers.set(data.sellers);
      this.products.set(data.products);
      this.orders.set(data.orders);
      this.tickets.set(data.tickets);
      this.returns.set(data.returns);
      this.summary.set(data.summary);
    });
  }

  totalUsers(): number {
    return this.users().length;
  }

  totalSellers(): number {
    return this.allSellers().length;
  }

  openTickets(): number {
    return this.tickets().filter((ticket) => !['resolved', 'closed', 'rejected'].includes(this.statusText(ticket.status))).length;
  }

  orderRevenue(): number {
    return this.orders().reduce((total, order) => total + order.subtotal, 0);
  }

  refundTotal(): number {
    return this.returns().reduce((total, item) => total + item.refundAmount, 0);
  }

  recentOrders(): Order[] {
    return this.latest(this.orders()).slice(0, 5);
  }

  recentReturns(): ReturnRequest[] {
    return this.latest(this.returns()).slice(0, 5);
  }

  recentTickets(): SupportTicket[] {
    return this.latest(this.tickets()).slice(0, 6);
  }

  private latest<T extends { createdAtUtc: string }>(items: T[]): T[] {
    return [...items].sort((left, right) => Date.parse(right.createdAtUtc) - Date.parse(left.createdAtUtc));
  }

  private statusText(status: string | number): string {
    return String(status).toLowerCase();
  }
}
