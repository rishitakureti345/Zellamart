import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { AuthService } from '../../core/services/auth.service';
import { StatusBadgeComponent } from '../../shared/components/status-badge/status-badge.component';
import { WorkspaceSwitcherComponent } from '../../shared/components/workspace-switcher/workspace-switcher.component';

@Component({
  selector: 'app-admin-profile',
  standalone: true,
  imports: [CommonModule, StatusBadgeComponent, WorkspaceSwitcherComponent],
  template: `
    <section class="dashboard-header">
      <div>
        <span class="eyebrow">Account</span>
        <h1>Admin profile</h1>
        <p>Your signed-in admin identity, role access, and permissions.</p>
      </div>
      <button type="button" (click)="logout()">Logout</button>
    </section>

    <app-workspace-switcher></app-workspace-switcher>

    <section class="surface profile-card" *ngIf="auth.session() as session">
      <div><span>Full name</span><strong>{{ session.fullName }}</strong></div>
      <div><span>Email</span><strong>{{ session.email }}</strong></div>
      <div><span>User ID</span><strong>{{ session.userId }}</strong></div>
      <div>
        <span>Roles</span>
        <p class="badge-row">
          <app-status-badge *ngFor="let role of session.roles" [status]="role"></app-status-badge>
        </p>
      </div>
      <div>
        <span>Permissions</span>
        <p>{{ session.permissions.join(', ') || 'No explicit permissions' }}</p>
      </div>
    </section>
  `
})
export class AdminProfileComponent {
  constructor(
    readonly auth: AuthService,
    private readonly router: Router
  ) {}

  logout(): void {
    this.auth.logout();
    void this.router.navigateByUrl('/');
  }
}
