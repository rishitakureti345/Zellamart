import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { AdminApiService } from '../services/admin-api.service';
import { SupportTicket } from '../../customer/models/support.model';
import { ErrorMessageService } from '../../core/services/error-message.service';
import { AuthService } from '../../core/services/auth.service';
import { EmptyStateComponent } from '../../shared/components/empty-state/empty-state.component';
import { StatusBadgeComponent } from '../../shared/components/status-badge/status-badge.component';
import { ToastComponent } from '../../shared/components/toast/toast.component';

@Component({
  selector: 'app-admin-support',
  standalone: true,
  imports: [CommonModule, FormsModule, EmptyStateComponent, StatusBadgeComponent, ToastComponent],
  template: `
    <section class="dashboard-header">
      <div>
        <span class="eyebrow">Support</span>
        <h1>Support management</h1>
        <p>Assign tickets, reply to customers, and close the loop on complaints.</p>
      </div>
      <button (click)="load()">Refresh</button>
    </section>

    <app-toast [message]="message()"></app-toast>

    <section class="metric-grid">
      <article class="metric-card"><span>Tickets</span><strong>{{ tickets().length }}</strong></article>
      <article class="metric-card"><span>Open</span><strong>{{ countByStatus('Open') }}</strong></article>
      <article class="metric-card"><span>In progress</span><strong>{{ countByStatus('In progress') }}</strong></article>
      <article class="metric-card"><span>Resolved</span><strong>{{ countByStatus('Resolved') }}</strong></article>
    </section>

    <section class="seller-toolbar users-toolbar">
      <label>Search<input [(ngModel)]="search" placeholder="Subject, order, customer"></label>
      <label>Status
        <select [(ngModel)]="statusFilter">
          <option value="all">All statuses</option>
          <option value="Open">Open</option>
          <option value="In progress">In progress</option>
          <option value="Resolved">Resolved</option>
          <option value="Closed">Closed</option>
        </select>
      </label>
      <label>Agent ID<input [(ngModel)]="agentId"></label>
    </section>

    <section class="seller-admin-grid">
      <section class="surface dashboard-panel">
        <table *ngIf="filteredTickets().length">
          <tr><th>Ticket</th><th>Customer</th><th>Order</th><th>Status</th><th>Actions</th></tr>
          <tr *ngFor="let ticket of filteredTickets()" [class.selected-row]="selectedTicket()?.id === ticket.id">
            <td><button class="table-link" (click)="selectTicket(ticket)"><strong>{{ ticket.subject }}</strong><br><span class="muted-line">{{ ticket.description }}</span></button></td>
            <td>{{ ticket.customerId }}</td>
            <td>{{ ticket.orderId }}</td>
            <td><app-status-badge kind="ticket" [status]="ticket.status"></app-status-badge></td>
            <td class="action-row">
              <button (click)="assign(ticket.id)">Assign</button>
              <button (click)="resolve(ticket.id)">Resolve</button>
              <button class="ghost-light" (click)="close(ticket.id)">Close</button>
            </td>
          </tr>
        </table>
        <app-empty-state *ngIf="!filteredTickets().length" title="No tickets found" message="Try another status or search term."></app-empty-state>
      </section>

      <aside class="surface seller-detail-pane" *ngIf="selectedTicket() as ticket">
        <div class="seller-detail-heading">
          <span class="eyebrow">Ticket detail</span>
          <h2>{{ ticket.subject }}</h2>
          <app-status-badge kind="ticket" [status]="ticket.status"></app-status-badge>
        </div>

        <div class="seller-detail-grid">
          <div><span>Customer</span><strong>{{ ticket.customerId }}</strong></div>
          <div><span>Order</span><strong>{{ ticket.orderId }}</strong></div>
          <div><span>Assigned agent</span><strong>{{ ticket.assignedAgentId || 'Unassigned' }}</strong></div>
          <div><span>Created</span><strong>{{ ticket.createdAtUtc | date:'medium' }}</strong></div>
        </div>

        <form class="stock-update-form" (ngSubmit)="reply(ticket.id)">
          <h3>Reply to ticket</h3>
          <label>Message<textarea [(ngModel)]="replyMessage" name="replyMessage" rows="4"></textarea></label>
          <button type="submit">Send reply</button>
        </form>

        <div class="action-row detail-actions">
          <button (click)="assign(ticket.id)">Assign agent</button>
          <button (click)="resolve(ticket.id)">Resolve</button>
          <button class="ghost-light" (click)="close(ticket.id)">Close</button>
        </div>

        <section>
          <h3>Complaint history</h3>
          <table>
            <tr><th>Type</th><th>Details</th><th>When</th></tr>
            <tr *ngFor="let entry of complaintHistory(ticket)">
              <td>{{ entry.type }}</td>
              <td>{{ entry.details }}</td>
              <td>{{ entry.when | date:'medium' }}</td>
            </tr>
          </table>
        </section>
      </aside>
    </section>
  `
})
export class AdminSupportComponent implements OnInit {
  search = '';
  statusFilter = 'all';
  agentId = '';
  replyMessage = 'Thanks for contacting Zellamart support. We are reviewing this issue.';
  readonly tickets = signal<SupportTicket[]>([]);
  readonly selectedTicket = signal<SupportTicket | null>(null);
  readonly message = signal('');

  constructor(private readonly api: AdminApiService, private readonly errors: ErrorMessageService, auth: AuthService) {
    this.agentId = auth.session()?.userId ?? '';
  }

  ngOnInit(): void {
    this.load();
  }

  load(): void {
    this.api.supportTickets().subscribe({
      next: (tickets) => {
        this.tickets.set(tickets);
        this.selectedTicket.set(tickets.find((ticket) => ticket.id === this.selectedTicket()?.id) ?? tickets[0] ?? null);
      },
      error: (error) => this.message.set(this.errors.from(error))
    });
  }

  filteredTickets(): SupportTicket[] {
    const term = this.search.trim().toLowerCase();
    return this.tickets().filter((ticket) => {
      const statusMatches = this.statusFilter === 'all' || this.ticketStatusLabel(ticket.status) === this.statusFilter;
      const searchable = [ticket.subject, ticket.description, ticket.customerId, ticket.orderId, ticket.assignedAgentId ?? '']
        .join(' ')
        .toLowerCase();
      return statusMatches && (!term || searchable.includes(term));
    });
  }

  selectTicket(ticket: SupportTicket): void {
    this.selectedTicket.set(ticket);
  }

  assign(ticketId: string): void {
    if (!this.agentId.trim()) {
      this.message.set('Agent ID is required.');
      return;
    }

    this.api.assignSupportTicket(ticketId, this.agentId.trim()).subscribe({
      next: () => { this.message.set('Ticket assigned.'); this.load(); },
      error: (error) => this.message.set(this.errors.from(error))
    });
  }

  reply(ticketId: string): void {
    if (!this.replyMessage.trim()) {
      this.message.set('Reply message is required.');
      return;
    }

    this.api.replySupportTicket(ticketId, this.replyMessage.trim()).subscribe({
      next: () => { this.message.set('Reply sent.'); this.replyMessage = ''; this.load(); },
      error: (error) => this.message.set(this.errors.from(error))
    });
  }

  resolve(ticketId: string): void {
    this.api.resolveSupportTicket(ticketId).subscribe({
      next: () => { this.message.set('Ticket resolved.'); this.load(); },
      error: (error) => this.message.set(this.errors.from(error))
    });
  }

  close(ticketId: string): void {
    this.api.closeSupportTicket(ticketId).subscribe({
      next: () => { this.message.set('Ticket closed.'); this.load(); },
      error: (error) => this.message.set(this.errors.from(error))
    });
  }

  countByStatus(status: string): number {
    return this.tickets().filter((ticket) => this.ticketStatusLabel(ticket.status) === status).length;
  }

  complaintHistory(ticket: SupportTicket): Array<{ type: string; details: string; when: string }> {
    return [
      ...ticket.statusHistory.map((entry) => ({
        type: this.ticketStatusLabel(entry.status),
        details: entry.note,
        when: entry.changedAtUtc
      })),
      ...ticket.messages.map((entry) => ({
        type: 'Message',
        details: entry.message,
        when: entry.createdAtUtc
      }))
    ].sort((a, b) => new Date(b.when).getTime() - new Date(a.when).getTime());
  }

  ticketStatusLabel(status: string | number): string {
    const map: Record<string, string> = {
      '1': 'Open',
      Open: 'Open',
      '2': 'In progress',
      InProgress: 'In progress',
      '3': 'Resolved',
      Resolved: 'Resolved',
      '4': 'Rejected',
      Rejected: 'Rejected',
      '5': 'Closed',
      Closed: 'Closed'
    };
    return map[String(status)] ?? String(status);
  }
}
