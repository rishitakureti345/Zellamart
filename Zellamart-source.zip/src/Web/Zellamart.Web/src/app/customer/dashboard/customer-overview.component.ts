import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { forkJoin } from 'rxjs';
import { OperationsApiService } from '../../core/services/operations-api.service';
import { ErrorMessageService } from '../../core/services/error-message.service';
import { CartApiService } from '../services/cart-api.service';
import { NotificationApiService } from '../services/notification-api.service';
import { Cart } from '../models/cart.model';
import { OrderSummary, ReturnSummary, ShipmentSummary, SupportTicketSummary } from '../../core/models/operations.model';
import { NotificationItem } from '../models/support.model';
import { MoneyPipe } from '../../shared/pipes/money.pipe';
import { StatusBadgeComponent } from '../../shared/components/status-badge/status-badge.component';
import { EmptyStateComponent } from '../../shared/components/empty-state/empty-state.component';
import { ToastComponent } from '../../shared/components/toast/toast.component';

@Component({
  selector: 'app-customer-overview',
  standalone: true,
  imports: [CommonModule, MoneyPipe, StatusBadgeComponent, EmptyStateComponent, ToastComponent],
  template: `
    <section class="dashboard-header">
      <div>
        <span class="eyebrow">Customer</span>
        <h1>Dashboard</h1>
        <p>Track cart, orders, shipments, support, returns, and notifications.</p>
      </div>
      <button type="button" (click)="refresh()" [disabled]="busy()">Refresh</button>
    </section>

    <app-toast [message]="message()"></app-toast>

    <section class="metric-grid">
      <article class="metric"><span>Cart items</span><strong>{{ cart()?.totalItems || 0 }}</strong></article>
      <article class="metric"><span>Total orders</span><strong>{{ orders().length }}</strong></article>
      <article class="metric"><span>Active shipments</span><strong>{{ activeShipments().length }}</strong></article>
      <article class="metric"><span>Open support tickets</span><strong>{{ openTickets().length }}</strong></article>
      <article class="metric"><span>Return requests</span><strong>{{ returns().length }}</strong></article>
      <article class="metric"><span>Unread notifications</span><strong>{{ unreadNotifications().length }}</strong></article>
    </section>

    <section class="dashboard-grid">
      <article class="surface dashboard-panel">
        <h2>Recent orders</h2>
        <table *ngIf="orders().length">
          <tr><th>Order</th><th>Status</th><th>Total</th><th>Created</th></tr>
          <tr *ngFor="let order of recentOrders()">
            <td>{{ order.id }}</td>
            <td><app-status-badge kind="order" [status]="order.status"></app-status-badge></td>
            <td>{{ order.subtotal | money: order.currency }}</td>
            <td>{{ order.createdAtUtc | date: 'mediumDate' }}</td>
          </tr>
        </table>
        <app-empty-state *ngIf="!orders().length" title="No orders yet" message="Checkout orders will show here."></app-empty-state>
      </article>

      <article class="surface dashboard-panel">
        <h2>Recent shipments</h2>
        <table *ngIf="shipments().length">
          <tr><th>Tracking</th><th>Status</th><th>Order</th><th>Created</th></tr>
          <tr *ngFor="let shipment of recentShipments()">
            <td>{{ shipment.trackingNumber }}</td>
            <td><app-status-badge kind="shipping" [status]="shipment.status"></app-status-badge></td>
            <td>{{ shipment.orderId }}</td>
            <td>{{ shipment.createdAtUtc | date: 'mediumDate' }}</td>
          </tr>
        </table>
        <app-empty-state *ngIf="!shipments().length" title="No shipments yet" message="Shipments appear after confirmed orders enter operations."></app-empty-state>
      </article>

      <article class="surface dashboard-panel">
        <h2>Recent support tickets</h2>
        <table *ngIf="tickets().length">
          <tr><th>Subject</th><th>Status</th><th>Created</th></tr>
          <tr *ngFor="let ticket of recentTickets()">
            <td>{{ ticket.subject }}</td>
            <td><app-status-badge kind="ticket" [status]="ticket.status"></app-status-badge></td>
            <td>{{ ticket.createdAtUtc | date: 'mediumDate' }}</td>
          </tr>
        </table>
        <app-empty-state *ngIf="!tickets().length" title="No support tickets" message="Support issues will show here."></app-empty-state>
      </article>

      <article class="surface dashboard-panel">
        <h2>Recent notifications</h2>
        <table *ngIf="notifications().length">
          <tr><th>Title</th><th>Type</th><th>Status</th></tr>
          <tr *ngFor="let item of recentNotifications()">
            <td>{{ item.title }}</td>
            <td>{{ item.type }}</td>
            <td><app-status-badge [status]="item.isRead ? 'Read' : 'Unread'"></app-status-badge></td>
          </tr>
        </table>
        <app-empty-state *ngIf="!notifications().length" title="No notifications" message="Order, delivery, and support updates will show here."></app-empty-state>
      </article>

      <article class="surface dashboard-panel">
        <h2>Return requests</h2>
        <table *ngIf="returns().length">
          <tr><th>Return</th><th>Status</th><th>Refund</th><th>Created</th></tr>
          <tr *ngFor="let item of recentReturns()">
            <td>{{ item.id }}</td>
            <td><app-status-badge kind="return" [status]="item.status"></app-status-badge></td>
            <td>{{ item.refundAmount | money }}</td>
            <td>{{ item.createdAtUtc | date: 'mediumDate' }}</td>
          </tr>
        </table>
        <app-empty-state *ngIf="!returns().length" title="No return requests" message="Return requests will show here."></app-empty-state>
      </article>
    </section>
  `
})
export class CustomerOverviewComponent implements OnInit {
  readonly cart = signal<Cart | null>(null);
  readonly orders = signal<OrderSummary[]>([]);
  readonly shipments = signal<ShipmentSummary[]>([]);
  readonly tickets = signal<SupportTicketSummary[]>([]);
  readonly returns = signal<ReturnSummary[]>([]);
  readonly notifications = signal<NotificationItem[]>([]);
  readonly busy = signal(false);
  readonly message = signal('');

  constructor(
    private readonly cartApi: CartApiService,
    private readonly notificationsApi: NotificationApiService,
    private readonly operations: OperationsApiService,
    private readonly errors: ErrorMessageService
  ) {}

  ngOnInit(): void {
    this.refresh();
  }

  openTickets(): SupportTicketSummary[] {
    return this.tickets().filter((ticket) => !['3', '4', '5', 'Resolved', 'Rejected', 'Closed'].includes(String(ticket.status)));
  }

  activeReturns(): ReturnSummary[] {
    return this.returns().filter((item) => !['3', '7', '8', 'Refunded', 'Rejected', 'Closed'].includes(String(item.status)));
  }

  activeShipments(): ShipmentSummary[] {
    return this.shipments().filter((shipment) => !['4', '5', '6', 'Delivered', 'DeliveryFailed', 'Cancelled'].includes(String(shipment.status)));
  }

  unreadNotifications(): NotificationItem[] {
    return this.notifications().filter((item) => !item.isRead);
  }

  recentOrders(): OrderSummary[] {
    return this.byNewest(this.orders()).slice(0, 5);
  }

  recentShipments(): ShipmentSummary[] {
    return this.byNewest(this.shipments()).slice(0, 5);
  }

  recentTickets(): SupportTicketSummary[] {
    return this.byNewest(this.tickets()).slice(0, 5);
  }

  recentReturns(): ReturnSummary[] {
    return this.byNewest(this.returns()).slice(0, 5);
  }

  recentNotifications(): NotificationItem[] {
    return this.byNewest(this.notifications()).slice(0, 5);
  }

  refresh(): void {
    this.busy.set(true);
    this.message.set('');
    forkJoin({
      cart: this.cartApi.getMine(),
      orders: this.operations.myOrders(),
      shipments: this.operations.myShipments(),
      tickets: this.operations.myTickets(),
      returns: this.operations.myReturns(),
      notifications: this.notificationsApi.getMine()
    }).subscribe({
      next: (data) => {
        this.cart.set(data.cart);
        this.orders.set(data.orders.value ?? []);
        this.shipments.set(data.shipments.value ?? []);
        this.tickets.set(data.tickets.value ?? []);
        this.returns.set(data.returns.value ?? []);
        this.notifications.set(data.notifications ?? []);
        this.busy.set(false);
      },
      error: (error) => {
        this.busy.set(false);
        this.message.set(this.errors.from(error));
      }
    });
  }

  private byNewest<T extends { createdAtUtc: string }>(items: T[]): T[] {
    return [...items].sort((first, second) =>
      new Date(second.createdAtUtc).getTime() - new Date(first.createdAtUtc).getTime()
    );
  }
}
