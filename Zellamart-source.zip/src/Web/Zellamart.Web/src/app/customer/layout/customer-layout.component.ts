import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterOutlet } from '@angular/router';
import { StoreNavbarComponent } from '../../shared/components/store-navbar/store-navbar.component';
import { DashboardSidebarComponent, DashboardNavItem } from '../../shared/components/dashboard-sidebar/dashboard-sidebar.component';
import { AuthService } from '../../core/services/auth.service';
import { StatusBadgeComponent } from '../../shared/components/status-badge/status-badge.component';

@Component({
  selector: 'app-customer-layout',
  standalone: true,
  imports: [CommonModule, RouterOutlet, StoreNavbarComponent, DashboardSidebarComponent, StatusBadgeComponent],
  template: `
    <app-store-navbar></app-store-navbar>
    <main class="customer-shell">
      <aside class="admin-sidebar">
        <section class="admin-identity" *ngIf="auth.session() as session">
          <span>Customer workspace</span>
          <strong>{{ session.fullName }}</strong>
          <small>{{ session.email }}</small>
          <p><app-status-badge status="Active" label="Active"></app-status-badge></p>
        </section>
        <app-dashboard-sidebar [items]="items"></app-dashboard-sidebar>
      </aside>

      <section class="admin-workspace">
        <header class="admin-topbar" *ngIf="auth.session() as session">
          <div>
            <span class="eyebrow">Customer center</span>
            <strong>{{ session.email }}</strong>
          </div>
          <button type="button" class="ghost-light" (click)="logout()">Logout</button>
        </header>

        <section class="seller-status-banner customer-status-banner" *ngIf="auth.session() as session">
          <div>
            <strong>Account active</strong>
            <p>{{ session.fullName }} can browse, buy, track orders, raise support tickets, request returns, and receive notifications.</p>
          </div>
          <app-status-badge status="Customer" label="Customer"></app-status-badge>
        </section>

        <section class="dashboard-content">
          <router-outlet></router-outlet>
        </section>
      </section>
    </main>
  `
})
export class CustomerLayoutComponent {
  readonly items: DashboardNavItem[] = [
    { label: 'Overview', path: '/customer/dashboard' },
    { label: 'Orders', path: '/customer/orders' },
    { label: 'Shipments', path: '/customer/shipments' },
    { label: 'Support', path: '/customer/support' },
    { label: 'Returns', path: '/customer/returns' },
    { label: 'Notifications', path: '/customer/notifications' },
    { label: 'Profile', path: '/customer/profile' },
    { label: 'Cart', path: '/cart' }
  ];

  constructor(
    readonly auth: AuthService,
    private readonly router: Router
  ) {}

  logout(): void {
    this.auth.logout();
    void this.router.navigateByUrl('/');
  }
}
