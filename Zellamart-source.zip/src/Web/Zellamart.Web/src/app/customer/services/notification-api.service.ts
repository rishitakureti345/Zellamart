import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { map, Observable } from 'rxjs';
import { ApiResult } from '../../core/models/api-result.model';
import { NotificationItem } from '../models/support.model';

@Injectable({ providedIn: 'root' })
export class NotificationApiService {
  constructor(private readonly http: HttpClient) {}

  getMine(): Observable<NotificationItem[]> {
    return this.http
      .get<ApiResult<NotificationItem[]>>('/api/notifications/me')
      .pipe(map((result) => result.value ?? []));
  }

  markRead(notificationId: string): Observable<NotificationItem> {
    return this.http
      .post<ApiResult<NotificationItem>>(`/api/notifications/${notificationId}/read`, {})
      .pipe(map((result) => result.value));
  }
}
