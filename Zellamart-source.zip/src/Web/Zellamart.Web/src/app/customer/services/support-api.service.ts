import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { map, Observable } from 'rxjs';
import { ApiResult } from '../../core/models/api-result.model';
import { ReturnRequest, SupportTicket } from '../models/support.model';

@Injectable({ providedIn: 'root' })
export class SupportApiService {
  constructor(private readonly http: HttpClient) {}

  getTickets(): Observable<SupportTicket[]> {
    return this.http
      .get<ApiResult<SupportTicket[]>>('/api/support/tickets/me')
      .pipe(map((result) => result.value ?? []));
  }

  getTicket(ticketId: string): Observable<SupportTicket> {
    return this.http
      .get<ApiResult<SupportTicket>>(`/api/support/tickets/${ticketId}`)
      .pipe(map((result) => result.value));
  }

  createTicket(orderId: string, type: number, subject: string, description: string): Observable<SupportTicket> {
    return this.http.post<ApiResult<SupportTicket>>('/api/support/tickets', {
      orderId,
      type,
      subject,
      description
    }).pipe(map((result) => result.value));
  }

  addMessage(ticketId: string, message: string): Observable<SupportTicket> {
    return this.http
      .post<ApiResult<SupportTicket>>(`/api/support/tickets/${ticketId}/messages`, { message })
      .pipe(map((result) => result.value));
  }

  closeTicket(ticketId: string): Observable<SupportTicket> {
    return this.http
      .post<ApiResult<SupportTicket>>(`/api/support/tickets/${ticketId}/close`, {})
      .pipe(map((result) => result.value));
  }

  getReturns(): Observable<ReturnRequest[]> {
    return this.http
      .get<ApiResult<ReturnRequest[]>>('/api/support/returns/me')
      .pipe(map((result) => result.value ?? []));
  }

  getReturn(returnId: string): Observable<ReturnRequest> {
    return this.http
      .get<ApiResult<ReturnRequest>>(`/api/support/returns/${returnId}`)
      .pipe(map((result) => result.value));
  }

  createReturn(orderId: string, orderItemId: string, productId: string, reason: string): Observable<ReturnRequest> {
    return this.http.post<ApiResult<ReturnRequest>>('/api/support/returns', {
      orderId,
      orderItemId,
      productId,
      reason
    }).pipe(map((result) => result.value));
  }
}
