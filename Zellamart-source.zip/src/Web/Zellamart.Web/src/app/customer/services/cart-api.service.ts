import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { map, Observable } from 'rxjs';
import { ApiResult } from '../../core/models/api-result.model';
import { Product } from '../../public/models/catalog.model';
import { Cart } from '../models/cart.model';

@Injectable({ providedIn: 'root' })
export class CartApiService {
  constructor(private readonly http: HttpClient) {}

  getMine(): Observable<Cart> {
    return this.http
      .get<ApiResult<Cart>>('/api/cart/me')
      .pipe(map((result) => result.value));
  }

  addProduct(product: Product, quantity = 1): Observable<Cart> {
    return this.http.post<ApiResult<Cart>>('/api/cart/items', {
      productId: product.id,
      sellerId: product.sellerId,
      productName: product.name,
      unitPrice: product.price,
      quantity,
      currency: product.currency
    }).pipe(map((result) => result.value));
  }

  updateItem(itemId: string, quantity: number): Observable<Cart> {
    return this.http
      .put<ApiResult<Cart>>(`/api/cart/items/${itemId}`, { quantity })
      .pipe(map((result) => result.value));
  }

  removeItem(itemId: string): Observable<Cart> {
    return this.http
      .delete<ApiResult<Cart>>(`/api/cart/items/${itemId}`)
      .pipe(map((result) => result.value));
  }

  clear(): Observable<Cart> {
    return this.http
      .delete<ApiResult<Cart>>('/api/cart/clear')
      .pipe(map((result) => result.value));
  }
}
