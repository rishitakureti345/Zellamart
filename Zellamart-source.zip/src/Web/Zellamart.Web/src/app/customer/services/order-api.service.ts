import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { map, Observable } from 'rxjs';
import { ApiResult } from '../../core/models/api-result.model';
import { Order, Payment, Shipment } from '../models/order.model';

@Injectable({ providedIn: 'root' })
export class OrderApiService {
  constructor(private readonly http: HttpClient) {}

  createFromCart(shippingAddress: string, deliveryNote?: string | null): Observable<Order> {
    return this.http.post<ApiResult<Order>>('/api/orders/from-cart', {
      shippingAddress,
      deliveryNote
    }).pipe(map((result) => result.value));
  }

  getMine(): Observable<Order[]> {
    return this.http
      .get<ApiResult<Order[]>>('/api/orders/me')
      .pipe(map((result) => result.value ?? []));
  }

  getById(orderId: string): Observable<Order> {
    return this.http
      .get<ApiResult<Order>>(`/api/orders/${orderId}`)
      .pipe(map((result) => result.value));
  }

  cancel(orderId: string): Observable<Order> {
    return this.http
      .post<ApiResult<Order>>(`/api/orders/${orderId}/cancel`, {})
      .pipe(map((result) => result.value));
  }

  startPayment(orderId: string): Observable<Payment> {
    return this.http
      .post<ApiResult<Payment>>('/api/payments/start', { orderId })
      .pipe(map((result) => result.value));
  }

  getPayments(orderId: string): Observable<Payment[]> {
    return this.http
      .get<ApiResult<Payment[]>>(`/api/payments/order/${orderId}`)
      .pipe(map((result) => result.value ?? []));
  }

  markPaymentSuccess(paymentId: string): Observable<Payment> {
    return this.http
      .post<ApiResult<Payment>>(`/api/payments/${paymentId}/success`, {})
      .pipe(map((result) => result.value));
  }

  markPaymentFailed(paymentId: string, reason = 'Customer selected payment failure.'): Observable<Payment> {
    return this.http
      .post<ApiResult<Payment>>(`/api/payments/${paymentId}/fail`, { reason })
      .pipe(map((result) => result.value));
  }

  getShipment(orderId: string): Observable<Shipment> {
    return this.http
      .get<ApiResult<Shipment>>(`/api/shipping/order/${orderId}`)
      .pipe(map((result) => result.value));
  }
}
