import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { finalize } from 'rxjs';
import { CartApiService } from '../services/cart-api.service';
import { OrderApiService } from '../services/order-api.service';
import { ErrorMessageService } from '../../core/services/error-message.service';
import { Cart } from '../models/cart.model';
import { MoneyPipe } from '../../shared/pipes/money.pipe';
import { EmptyStateComponent } from '../../shared/components/empty-state/empty-state.component';
import { LoadingSkeletonComponent } from '../../shared/components/loading-skeleton/loading-skeleton.component';
import { ToastComponent } from '../../shared/components/toast/toast.component';

@Component({
  selector: 'app-checkout-page',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink, MoneyPipe, EmptyStateComponent, LoadingSkeletonComponent, ToastComponent],
  template: `
    <section class="checkout-page">
      <div class="cart-heading">
        <div>
          <span class="eyebrow">Checkout</span>
          <h1>Place your order</h1>
          <p>Add a shipping address and review your cart before payment.</p>
        </div>
      </div>

      <app-toast [message]="message()"></app-toast>
      <app-loading-skeleton *ngIf="loading()" [rows]="4"></app-loading-skeleton>

      <div class="checkout-layout" *ngIf="!loading() && cart() as currentCart">
        <form class="surface checkout-form" (ngSubmit)="placeOrder()" *ngIf="currentCart.items.length; else emptyCart">
          <h2>Shipping address</h2>
          <label>Full address<textarea [(ngModel)]="shippingAddress" name="shippingAddress" rows="5" maxlength="600" required></textarea></label>
          <label>Delivery note<input [(ngModel)]="deliveryNote" name="deliveryNote" maxlength="240" placeholder="Apartment, landmark, preferred time"></label>
          <button type="submit" [disabled]="busy()">{{ busy() ? 'Placing order...' : 'Place order' }}</button>
        </form>

        <ng-template #emptyCart>
          <app-empty-state title="Your cart is empty" message="Add products before checkout."></app-empty-state>
        </ng-template>

        <aside class="surface price-summary">
          <h2>Order summary</h2>
          <div *ngFor="let item of currentCart.items">
            <span>{{ item.productName }} x {{ item.quantity }}</span>
            <strong>{{ item.lineTotal | money: item.currency }}</strong>
          </div>
          <hr>
          <div class="summary-total"><span>Total</span><strong>{{ currentCart.subtotal | money: currentCart.currency }}</strong></div>
          <a routerLink="/cart">Edit cart</a>
        </aside>
      </div>
    </section>
  `
})
export class CheckoutPageComponent implements OnInit {
  shippingAddress = '';
  deliveryNote = '';
  readonly cart = signal<Cart | null>(null);
  readonly loading = signal(true);
  readonly busy = signal(false);
  readonly message = signal('');

  constructor(
    private readonly cartApi: CartApiService,
    private readonly orders: OrderApiService,
    private readonly errors: ErrorMessageService,
    private readonly router: Router
  ) {}

  ngOnInit(): void {
    this.cartApi.getMine()
      .pipe(finalize(() => this.loading.set(false)))
      .subscribe({
        next: (cart) => this.cart.set(cart),
        error: (error) => this.message.set(this.errors.from(error))
      });
  }

  placeOrder(): void {
    const cart = this.cart();
    if (!cart?.items.length) {
      this.message.set('Cart is empty.');
      return;
    }

    if (!this.shippingAddress.trim()) {
      this.message.set('Shipping address is required.');
      return;
    }

    if (this.shippingAddress.trim().length > 600) {
      this.message.set('Shipping address must be 600 characters or fewer.');
      return;
    }

    if (this.deliveryNote.trim().length > 240) {
      this.message.set('Delivery note must be 240 characters or fewer.');
      return;
    }

    this.busy.set(true);
    this.message.set('');
    sessionStorage.setItem('zellamart_shipping_address', this.shippingAddress.trim());
    this.orders.createFromCart(this.shippingAddress.trim(), this.deliveryNote.trim() || null).subscribe({
      next: (order) => {
        this.busy.set(false);
        void this.router.navigate(['/payment', order.id]);
      },
      error: (error) => {
        this.busy.set(false);
        this.message.set(this.errors.from(error));
      }
    });
  }
}
