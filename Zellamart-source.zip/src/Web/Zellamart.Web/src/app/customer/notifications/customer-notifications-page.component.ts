import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { NotificationApiService } from '../services/notification-api.service';
import { ErrorMessageService } from '../../core/services/error-message.service';
import { NotificationItem } from '../models/support.model';
import { EmptyStateComponent } from '../../shared/components/empty-state/empty-state.component';
import { ToastComponent } from '../../shared/components/toast/toast.component';

@Component({
  selector: 'app-customer-notifications-page',
  standalone: true,
  imports: [CommonModule, FormsModule, EmptyStateComponent, ToastComponent],
  template: `
    <section class="dashboard-header">
      <div>
        <span class="eyebrow">Notifications</span>
        <h1>Notifications</h1>
        <p>Read order, shipment, refund, support, and announcement updates.</p>
      </div>
      <div class="action-row">
        <button type="button" class="ghost-light" (click)="markAllRead()" [disabled]="!unreadCount()">Mark all read</button>
        <button type="button" (click)="load()">Refresh</button>
      </div>
    </section>

    <app-toast [message]="message()"></app-toast>

    <section class="metric-grid">
      <article class="metric-card"><span>Total</span><strong>{{ notifications().length }}</strong></article>
      <article class="metric-card"><span>Unread</span><strong>{{ unreadCount() }}</strong></article>
      <article class="metric-card"><span>Order updates</span><strong>{{ countByGroup('Order update') }}</strong></article>
      <article class="metric-card"><span>Support/refunds</span><strong>{{ supportAndRefundCount() }}</strong></article>
    </section>

    <section class="seller-toolbar users-toolbar">
      <label>Search<input [(ngModel)]="search" placeholder="Title, message, type"></label>
      <label>Status
        <select [(ngModel)]="readFilter">
          <option value="all">All</option>
          <option value="unread">Unread</option>
          <option value="read">Read</option>
        </select>
      </label>
      <label>Type
        <select [(ngModel)]="typeFilter">
          <option value="all">All types</option>
          <option value="Order update">Order update</option>
          <option value="Shipment update">Shipment update</option>
          <option value="Refund update">Refund update</option>
          <option value="Support reply">Support reply</option>
          <option value="Announcement">Announcement</option>
        </select>
      </label>
    </section>

    <section class="notification-list" *ngIf="filteredNotifications().length">
      <article class="surface notification-card" *ngFor="let item of filteredNotifications()" [class.unread]="!item.isRead">
        <div>
          <strong>{{ item.title }}</strong>
          <span>{{ item.createdAtUtc | date: 'medium' }}</span>
        </div>
        <div>
          <span>{{ notificationGroup(item.type) }}</span>
          <span>{{ item.isRead ? 'Read' : 'Unread' }}</span>
        </div>
        <p>{{ item.message }}</p>
        <button type="button" *ngIf="!item.isRead" (click)="markRead(item)" [disabled]="isBusy(item.id)">
          {{ isBusy(item.id) ? 'Saving...' : 'Mark read' }}
        </button>
      </article>
    </section>

    <app-empty-state *ngIf="!filteredNotifications().length" title="No notifications found" message="Updates will show here as your order moves through the flow."></app-empty-state>
  `
})
export class CustomerNotificationsPageComponent implements OnInit {
  search = '';
  readFilter = 'all';
  typeFilter = 'all';
  readonly notifications = signal<NotificationItem[]>([]);
  readonly message = signal('');
  readonly busyIds = signal<Set<string>>(new Set<string>());

  constructor(private readonly api: NotificationApiService, private readonly errors: ErrorMessageService) {}

  ngOnInit(): void { this.load(); }

  load(): void {
    this.api.getMine().subscribe({
      next: (items) => this.notifications.set(this.byNewest(items)),
      error: (error) => this.message.set(this.errors.from(error))
    });
  }

  markRead(item: NotificationItem): void {
    if (item.isRead || this.busyIds().has(item.id)) {
      return;
    }

    this.trackBusy(item.id, true);
    this.api.markRead(item.id).subscribe({
      next: (updated) => {
        this.trackBusy(item.id, false);
        this.notifications.set(this.notifications().map((entry) => entry.id === updated.id ? updated : entry));
      },
      error: (error) => {
        this.trackBusy(item.id, false);
        this.message.set(this.errors.from(error));
      }
    });
  }

  markAllRead(): void {
    this.filteredNotifications().filter((item) => !item.isRead).forEach((item) => this.markRead(item));
  }

  isBusy(notificationId: string): boolean {
    return this.busyIds().has(notificationId);
  }

  filteredNotifications(): NotificationItem[] {
    const term = this.search.trim().toLowerCase();
    return this.notifications().filter((item) => {
      const statusMatches = this.readFilter === 'all'
        || (this.readFilter === 'read' && item.isRead)
        || (this.readFilter === 'unread' && !item.isRead);
      const typeMatches = this.typeFilter === 'all' || this.notificationGroup(item.type) === this.typeFilter;
      const searchable = [item.type, item.title, item.message].join(' ').toLowerCase();
      return statusMatches && typeMatches && (!term || searchable.includes(term));
    });
  }

  unreadCount(): number {
    return this.notifications().filter((item) => !item.isRead).length;
  }

  countByGroup(group: string): number {
    return this.notifications().filter((item) => this.notificationGroup(item.type) === group).length;
  }

  supportAndRefundCount(): number {
    return this.countByGroup('Support reply') + this.countByGroup('Refund update');
  }

  notificationGroup(type: string): string {
    const normalized = type.replace(/[\s_-]/g, '').toLowerCase();
    if (normalized.includes('shipment') || normalized.includes('delivery') || normalized.includes('shipping')) {
      return 'Shipment update';
    }
    if (normalized.includes('refund') || normalized.includes('return')) {
      return 'Refund update';
    }
    if (normalized.includes('support') || normalized.includes('ticket') || normalized.includes('reply')) {
      return 'Support reply';
    }
    if (normalized.includes('announcement') || normalized.includes('general')) {
      return 'Announcement';
    }
    return 'Order update';
  }

  private byNewest(items: NotificationItem[]): NotificationItem[] {
    return [...items].sort((left, right) => Date.parse(right.createdAtUtc) - Date.parse(left.createdAtUtc));
  }

  private trackBusy(notificationId: string, busy: boolean): void {
    const next = new Set(this.busyIds());
    if (busy) {
      next.add(notificationId);
    } else {
      next.delete(notificationId);
    }

    this.busyIds.set(next);
  }
}
