import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { catchError, finalize, forkJoin, of } from 'rxjs';
import { OrderApiService } from '../services/order-api.service';
import { Order, Payment, Shipment } from '../models/order.model';
import { ErrorMessageService } from '../../core/services/error-message.service';
import { MoneyPipe } from '../../shared/pipes/money.pipe';
import { StatusBadgeComponent } from '../../shared/components/status-badge/status-badge.component';
import { LoadingSkeletonComponent } from '../../shared/components/loading-skeleton/loading-skeleton.component';
import { ToastComponent } from '../../shared/components/toast/toast.component';

@Component({
  selector: 'app-order-detail-page',
  standalone: true,
  imports: [CommonModule, RouterLink, MoneyPipe, StatusBadgeComponent, LoadingSkeletonComponent, ToastComponent],
  template: `
    <section class="dashboard-header">
      <div>
        <a routerLink="/customer/orders" class="back-link">Back to orders</a>
        <span class="eyebrow">Order detail</span>
        <h1>{{ order()?.orderNumber || 'Order' }}</h1>
        <p>Payment and shipping details for this order.</p>
      </div>
      <div class="action-row">
        <a *ngIf="order()?.status === 'PendingPayment'" [routerLink]="['/payment', order()?.id]">Pay now</a>
        <button type="button" class="ghost-light" *ngIf="order() && canCancel(order()!)" [disabled]="busy()" (click)="cancel()">Cancel order</button>
      </div>
    </section>

    <app-toast [message]="message()"></app-toast>
    <app-loading-skeleton *ngIf="loading()" [rows]="4"></app-loading-skeleton>

    <section class="order-detail-grid" *ngIf="!loading() && order() as currentOrder">
      <article class="surface dashboard-panel wide-panel">
        <h2>Items</h2>
        <table>
          <tr><th>Product</th><th>Qty</th><th>Unit</th><th>Total</th></tr>
          <tr *ngFor="let item of currentOrder.items">
            <td>{{ item.productName }}</td>
            <td>{{ item.quantity }}</td>
            <td>{{ item.unitPrice | money: currentOrder.currency }}</td>
            <td>{{ item.lineTotal | money: currentOrder.currency }}</td>
          </tr>
        </table>
      </article>

      <article class="surface dashboard-panel">
        <h2>Order</h2>
        <p><app-status-badge kind="order" [status]="currentOrder.status"></app-status-badge></p>
        <p><strong>Total:</strong> {{ currentOrder.subtotal | money: currentOrder.currency }}</p>
        <p><strong>Created:</strong> {{ currentOrder.createdAtUtc | date: 'medium' }}</p>
        <p><strong>Shipping address:</strong> {{ currentOrder.shippingAddress }}</p>
        <p *ngIf="currentOrder.deliveryNote"><strong>Delivery note:</strong> {{ currentOrder.deliveryNote }}</p>
      </article>

      <article class="surface dashboard-panel">
        <h2>Payments</h2>
        <table *ngIf="payments().length">
          <tr><th>Provider</th><th>Status</th><th>Amount</th><th>Reason</th></tr>
          <tr *ngFor="let payment of payments()">
            <td>{{ payment.provider }}</td>
            <td><app-status-badge kind="payment" [status]="payment.status"></app-status-badge></td>
            <td>{{ payment.amount | money: payment.currency }}</td>
            <td>{{ payment.failureReason || '-' }}</td>
          </tr>
        </table>
        <p *ngIf="!payments().length">No payment session yet.</p>
      </article>

      <article class="surface dashboard-panel">
        <h2>Shipping</h2>
        <ng-container *ngIf="shipment(); else noShipment">
          <p><strong>Tracking:</strong> {{ shipment()?.trackingNumber }}</p>
          <p><app-status-badge kind="shipping" [status]="shipment()?.status || ''"></app-status-badge></p>
          <p>{{ shipment()?.shippingAddress }}</p>
        </ng-container>
        <ng-template #noShipment><p>Shipment will appear after operations creates it.</p></ng-template>
      </article>

      <article class="surface dashboard-panel wide-panel">
        <h2>Status history</h2>
        <table>
          <tr><th>Status</th><th>Note</th><th>Changed</th></tr>
          <tr *ngFor="let history of currentOrder.statusHistory">
            <td><app-status-badge kind="order" [status]="history.status"></app-status-badge></td>
            <td>{{ history.note }}</td>
            <td>{{ history.changedAtUtc | date: 'medium' }}</td>
          </tr>
        </table>
      </article>
    </section>
  `
})
export class OrderDetailPageComponent implements OnInit {
  readonly order = signal<Order | null>(null);
  readonly payments = signal<Payment[]>([]);
  readonly shipment = signal<Shipment | null>(null);
  readonly loading = signal(true);
  readonly busy = signal(false);
  readonly message = signal('');
  private orderId = '';

  constructor(
    private readonly orders: OrderApiService,
    private readonly errors: ErrorMessageService,
    private readonly route: ActivatedRoute,
    private readonly router: Router
  ) {}

  ngOnInit(): void {
    this.orderId = this.route.snapshot.paramMap.get('orderId') ?? '';
    if (!this.orderId) {
      this.loading.set(false);
      this.message.set('Order id is missing.');
      return;
    }

    forkJoin({
      order: this.orders.getById(this.orderId),
      payments: this.orders.getPayments(this.orderId).pipe(catchError(() => of([] as Payment[]))),
      shipment: this.orders.getShipment(this.orderId).pipe(catchError(() => of(null)))
    }).pipe(finalize(() => this.loading.set(false))).subscribe({
      next: ({ order, payments, shipment }) => {
        this.order.set(order);
        this.payments.set(payments);
        this.shipment.set(shipment);
      },
      error: (error) => this.message.set(this.errors.from(error))
    });
  }

  canCancel(order: Order): boolean {
    const status = String(order.status).toLowerCase();
    return !['cancelled', 'delivered', 'refunded', '5', '6', '9'].includes(status);
  }

  cancel(): void {
    if (!this.orderId) {
      return;
    }

    this.busy.set(true);
    this.message.set('');
    this.orders.cancel(this.orderId).subscribe({
      next: (order) => {
        this.order.set(order);
        this.busy.set(false);
        this.message.set('Order cancelled.');
        void this.router.navigate(['/customer/orders', order.id]);
      },
      error: (error) => {
        this.busy.set(false);
        this.message.set(this.errors.from(error));
      }
    });
  }
}
