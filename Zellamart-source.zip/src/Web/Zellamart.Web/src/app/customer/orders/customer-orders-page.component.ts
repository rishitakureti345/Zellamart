import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { catchError, finalize, forkJoin, of } from 'rxjs';
import { OrderApiService } from '../services/order-api.service';
import { Order, Payment, Shipment } from '../models/order.model';
import { ErrorMessageService } from '../../core/services/error-message.service';
import { MoneyPipe } from '../../shared/pipes/money.pipe';
import { StatusBadgeComponent } from '../../shared/components/status-badge/status-badge.component';
import { EmptyStateComponent } from '../../shared/components/empty-state/empty-state.component';
import { LoadingSkeletonComponent } from '../../shared/components/loading-skeleton/loading-skeleton.component';
import { ToastComponent } from '../../shared/components/toast/toast.component';

@Component({
  selector: 'app-customer-orders-page',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink, MoneyPipe, StatusBadgeComponent, EmptyStateComponent, LoadingSkeletonComponent, ToastComponent],
  template: `
    <section class="dashboard-header">
      <div>
        <span class="eyebrow">Orders</span>
        <h1>My orders</h1>
        <p>Track payment and fulfillment state for each order.</p>
      </div>
      <button type="button" (click)="load()">Refresh</button>
    </section>

    <app-toast [message]="message()"></app-toast>
    <app-loading-skeleton *ngIf="loading()" [rows]="4"></app-loading-skeleton>

    <section class="surface table-toolbar" *ngIf="!loading() && orders().length">
      <label>Status
        <select [(ngModel)]="statusFilter">
          <option value="all">All statuses</option>
          <option *ngFor="let status of statuses()" [value]="status">{{ status }}</option>
        </select>
      </label>
    </section>

    <section class="surface dashboard-panel" *ngIf="!loading() && orders().length">
      <table>
        <tr><th>Order</th><th>Status</th><th>Payment</th><th>Shipping</th><th>Total</th><th>Created</th><th></th></tr>
        <tr *ngFor="let order of filteredOrders()">
          <td>{{ order.orderNumber }}</td>
          <td><app-status-badge kind="order" [status]="order.status"></app-status-badge></td>
          <td><app-status-badge kind="payment" [status]="paymentStatus(order.id)"></app-status-badge></td>
          <td><app-status-badge kind="shipping" [status]="shippingStatus(order.id)"></app-status-badge></td>
          <td>{{ order.subtotal | money: order.currency }}</td>
          <td>{{ order.createdAtUtc | date: 'medium' }}</td>
          <td class="action-row">
            <a [routerLink]="['/customer/orders', order.id]">View</a>
            <button type="button" class="ghost-light" *ngIf="canCancel(order)" [disabled]="busy()" (click)="cancel(order)">Cancel</button>
          </td>
        </tr>
      </table>
      <app-empty-state *ngIf="!filteredOrders().length" title="No orders match this filter" message="Choose another status."></app-empty-state>
    </section>

    <app-empty-state *ngIf="!loading() && !orders().length" title="No orders yet" message="Checkout your cart to create the first order."></app-empty-state>
  `
})
export class CustomerOrdersPageComponent implements OnInit {
  readonly orders = signal<Order[]>([]);
  readonly paymentsByOrder = signal<Record<string, Payment[]>>({});
  readonly shipmentsByOrder = signal<Record<string, Shipment | null>>({});
  readonly loading = signal(true);
  readonly busy = signal(false);
  readonly message = signal('');
  statusFilter = 'all';

  constructor(
    private readonly orderApi: OrderApiService,
    private readonly errors: ErrorMessageService
  ) {}

  ngOnInit(): void {
    this.load();
  }

  load(): void {
    this.loading.set(true);
    this.orderApi.getMine()
      .pipe(finalize(() => this.loading.set(false)))
      .subscribe({
        next: (orders) => {
          this.orders.set(this.byNewest(orders));
          this.loadOrderSignals(orders);
        },
        error: (error) => this.message.set(this.errors.from(error))
      });
  }

  statuses(): string[] {
    return [...new Set(this.orders().map((order) => String(order.status)))].sort();
  }

  filteredOrders(): Order[] {
    return this.statusFilter === 'all'
      ? this.orders()
      : this.orders().filter((order) => String(order.status) === this.statusFilter);
  }

  paymentStatus(orderId: string): string | number {
    return this.paymentsByOrder()[orderId]?.[0]?.status ?? 'No payment';
  }

  shippingStatus(orderId: string): string | number {
    return this.shipmentsByOrder()[orderId]?.status ?? 'No shipment';
  }

  canCancel(order: Order): boolean {
    const status = String(order.status).toLowerCase();
    return !['cancelled', 'delivered', 'refunded', '5', '6', '9'].includes(status);
  }

  cancel(order: Order): void {
    this.busy.set(true);
    this.message.set('');
    this.orderApi.cancel(order.id).subscribe({
      next: (updated) => {
        this.orders.set(this.orders().map((item) => item.id === updated.id ? updated : item));
        this.busy.set(false);
        this.message.set('Order cancelled.');
      },
      error: (error) => {
        this.busy.set(false);
        this.message.set(this.errors.from(error));
      }
    });
  }

  private loadOrderSignals(orders: Order[]): void {
    this.paymentsByOrder.set({});
    this.shipmentsByOrder.set({});
    if (!orders.length) {
      return;
    }

    forkJoin(orders.map((order) =>
      forkJoin({
        payments: this.orderApi.getPayments(order.id).pipe(catchError(() => of([] as Payment[]))),
        shipment: this.orderApi.getShipment(order.id).pipe(catchError(() => of(null)))
      })
    )).subscribe((results) => {
      const paymentsByOrder: Record<string, Payment[]> = {};
      const shipmentsByOrder: Record<string, Shipment | null> = {};
      orders.forEach((order, index) => {
        paymentsByOrder[order.id] = results[index].payments;
        shipmentsByOrder[order.id] = results[index].shipment;
      });
      this.paymentsByOrder.set(paymentsByOrder);
      this.shipmentsByOrder.set(shipmentsByOrder);
    });
  }

  private byNewest(orders: Order[]): Order[] {
    return [...orders].sort((first, second) =>
      new Date(second.createdAtUtc).getTime() - new Date(first.createdAtUtc).getTime()
    );
  }
}
