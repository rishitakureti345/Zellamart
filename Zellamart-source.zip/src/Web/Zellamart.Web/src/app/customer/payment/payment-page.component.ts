import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { catchError, finalize, forkJoin, of } from 'rxjs';
import { OrderApiService } from '../services/order-api.service';
import { Order, Payment } from '../models/order.model';
import { ErrorMessageService } from '../../core/services/error-message.service';
import { MoneyPipe } from '../../shared/pipes/money.pipe';
import { StatusBadgeComponent } from '../../shared/components/status-badge/status-badge.component';
import { LoadingSkeletonComponent } from '../../shared/components/loading-skeleton/loading-skeleton.component';
import { ToastComponent } from '../../shared/components/toast/toast.component';

@Component({
  selector: 'app-payment-page',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink, MoneyPipe, StatusBadgeComponent, LoadingSkeletonComponent, ToastComponent],
  template: `
    <section class="payment-page">
      <div class="cart-heading">
        <div>
          <span class="eyebrow">FakePay</span>
          <h1>Payment simulation</h1>
          <p>Approve or fail this V1 payment session.</p>
        </div>
      </div>

      <app-toast [message]="message()"></app-toast>
      <app-loading-skeleton *ngIf="loading()" [rows]="3"></app-loading-skeleton>

      <section class="payment-layout" *ngIf="!loading() && order() as currentOrder">
        <article class="surface payment-card">
          <h2>{{ currentOrder.orderNumber }}</h2>
          <app-status-badge kind="order" [status]="currentOrder.status"></app-status-badge>
          <strong class="detail-price">{{ currentOrder.subtotal | money: currentOrder.currency }}</strong>
          <p>Provider: {{ payment()?.provider || 'FakePay' }}</p>
          <p>Session: {{ payment()?.fakeSessionId || 'Not started' }}</p>
          <p>
            Payment status:
            <app-status-badge kind="payment" [status]="paymentStatus()"></app-status-badge>
          </p>
          <label class="payment-failure-reason">
            Failure reason
            <input [(ngModel)]="failureReason" name="failureReason" maxlength="240" placeholder="Card declined, insufficient balance, bank timeout">
          </label>
          <p class="cart-stock-warning" *ngIf="payment()?.failureReason">{{ payment()?.failureReason }}</p>
          <div class="detail-actions">
            <button type="button" (click)="paySuccess()" [disabled]="busy() || !isPendingPayment()">Simulate success</button>
            <button type="button" class="ghost-light" (click)="payFail()" [disabled]="busy() || !isPendingPayment()">Simulate failure</button>
            <a [routerLink]="['/customer/orders', currentOrder.id]">View order</a>
          </div>
        </article>

        <aside class="surface price-summary">
          <h2>Items</h2>
          <div *ngFor="let item of currentOrder.items">
            <span>{{ item.productName }} x {{ item.quantity }}</span>
            <strong>{{ item.lineTotal | money: currentOrder.currency }}</strong>
          </div>
        </aside>
      </section>
    </section>
  `
})
export class PaymentPageComponent implements OnInit {
  readonly order = signal<Order | null>(null);
  readonly payment = signal<Payment | null>(null);
  readonly loading = signal(true);
  readonly busy = signal(false);
  readonly message = signal('');
  failureReason = 'Customer selected payment failure.';

  private orderId = '';

  constructor(
    private readonly orders: OrderApiService,
    private readonly errors: ErrorMessageService,
    private readonly route: ActivatedRoute,
    private readonly router: Router
  ) {}

  ngOnInit(): void {
    this.orderId = this.route.snapshot.paramMap.get('orderId') ?? '';
    if (!this.orderId) {
      this.loading.set(false);
      this.message.set('Order id is missing.');
      return;
    }

    forkJoin({
      order: this.orders.getById(this.orderId),
      payments: this.orders.getPayments(this.orderId).pipe(catchError(() => of([] as Payment[])))
    }).pipe(finalize(() => this.loading.set(false))).subscribe({
      next: ({ order, payments }) => {
        this.order.set(order);
        const pending = payments.find((item) => this.isPendingStatus(item.status));
        if (pending) {
          this.payment.set(pending);
          return;
        }

        if (order.status === 'PendingPayment') {
          this.startPayment();
        } else {
          this.payment.set(payments[0] ?? null);
        }
      },
      error: (error) => this.message.set(this.errors.from(error))
    });
  }

  paySuccess(): void {
    const payment = this.payment();
    if (!payment) {
      return;
    }

    this.busy.set(true);
    this.orders.markPaymentSuccess(payment.id).subscribe({
      next: () => {
        this.busy.set(false);
        void this.router.navigate(['/customer/orders', this.orderId]);
      },
      error: (error) => {
        this.busy.set(false);
        this.message.set(this.errors.from(error));
      }
    });
  }

  payFail(): void {
    const payment = this.payment();
    if (!payment) {
      return;
    }

    this.busy.set(true);
    if (!this.failureReason.trim()) {
      this.message.set('Failure reason is required.');
      return;
    }

    this.orders.markPaymentFailed(payment.id, this.failureReason.trim()).subscribe({
      next: (updated) => {
        this.payment.set(updated);
        this.busy.set(false);
        void this.router.navigate(['/customer/orders', this.orderId]);
      },
      error: (error) => {
        this.busy.set(false);
        this.message.set(this.errors.from(error));
      }
    });
  }

  paymentStatus(): string | number {
    return this.payment()?.status ?? 'Not started';
  }

  isPendingPayment(): boolean {
    const payment = this.payment();
    return Boolean(payment && this.isPendingStatus(payment.status));
  }

  private isPendingStatus(status: string | number): boolean {
    return String(status).toLowerCase() === 'pending' || String(status) === '1';
  }

  private startPayment(): void {
    this.busy.set(true);
    this.orders.startPayment(this.orderId).subscribe({
      next: (payment) => {
        this.payment.set(payment);
        this.busy.set(false);
      },
      error: (error) => {
        this.busy.set(false);
        this.message.set(this.errors.from(error));
      }
    });
  }
}
