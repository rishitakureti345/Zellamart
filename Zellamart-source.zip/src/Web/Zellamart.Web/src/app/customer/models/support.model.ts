export interface SupportTicketMessage {
  id: string;
  senderUserId: string;
  message: string;
  createdAtUtc: string;
}

export interface SupportTicket {
  id: string;
  customerId: string;
  orderId: string;
  type: string | number;
  subject: string;
  description: string;
  status: string | number;
  assignedAgentId?: string | null;
  messages: SupportTicketMessage[];
  statusHistory: SupportTicketStatusHistory[];
  createdAtUtc: string;
}

export interface SupportTicketStatusHistory {
  id: string;
  status: string | number;
  note: string;
  changedByUserId?: string | null;
  changedAtUtc: string;
}

export interface ReturnRequest {
  id: string;
  orderId: string;
  orderItemId: string;
  customerId: string;
  productId: string;
  reason: string;
  status: string | number;
  refundAmount: number;
  statusHistory: ReturnStatusHistory[];
  createdAtUtc: string;
}

export interface ReturnStatusHistory {
  id: string;
  status: string | number;
  note: string;
  changedByUserId?: string | null;
  changedAtUtc: string;
}

export interface NotificationItem {
  id: string;
  userId: string;
  type: string;
  title: string;
  message: string;
  isRead: boolean;
  createdAtUtc: string;
  readAtUtc?: string | null;
}
