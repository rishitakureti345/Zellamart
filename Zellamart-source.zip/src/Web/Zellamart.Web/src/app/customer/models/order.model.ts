export interface OrderItem {
  id: string;
  productId: string;
  sellerId: string;
  productName: string;
  unitPrice: number;
  quantity: number;
  lineTotal: number;
}

export interface OrderStatusHistory {
  id: string;
  status: string;
  note: string;
  changedByUserId?: string | null;
  changedAtUtc: string;
}

export interface Order {
  id: string;
  customerId: string;
  orderNumber: string;
  status: string;
  subtotal: number;
  currency: string;
  shippingAddress: string;
  deliveryNote?: string | null;
  items: OrderItem[];
  statusHistory: OrderStatusHistory[];
  createdAtUtc: string;
}

export interface Payment {
  id: string;
  orderId: string;
  customerId: string;
  amount: number;
  currency: string;
  provider: string;
  fakeSessionId: string;
  status: string;
  failureReason?: string | null;
  createdAtUtc: string;
  completedAtUtc?: string | null;
}

export interface Shipment {
  id: string;
  orderId: string;
  customerId: string;
  deliveryPartnerId?: string | null;
  status: string;
  shippingAddress: string;
  trackingNumber: string;
  statusHistory: ShipmentStatusHistory[];
  createdAtUtc: string;
}

export interface ShipmentStatusHistory {
  id: string;
  status: string;
  note: string;
  changedByUserId?: string | null;
  changedAtUtc: string;
}
