export interface CartItem {
  id: string;
  productId: string;
  sellerId: string;
  productName: string;
  unitPrice: number;
  quantity: number;
  currency: string;
  lineTotal: number;
}

export interface Cart {
  id: string;
  customerId: string;
  status: string;
  items: CartItem[];
  subtotal: number;
  totalItems: number;
  currency: string;
}
