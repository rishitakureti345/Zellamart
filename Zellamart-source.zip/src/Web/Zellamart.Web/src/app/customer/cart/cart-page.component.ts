import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { catchError, finalize, forkJoin, of } from 'rxjs';
import { CartApiService } from '../services/cart-api.service';
import { Cart, CartItem } from '../models/cart.model';
import { InventoryItem } from '../../public/models/inventory.model';
import { InventoryReadApiService } from '../../public/services/inventory-read-api.service';
import { ErrorMessageService } from '../../core/services/error-message.service';
import { MoneyPipe } from '../../shared/pipes/money.pipe';
import { EmptyStateComponent } from '../../shared/components/empty-state/empty-state.component';
import { LoadingSkeletonComponent } from '../../shared/components/loading-skeleton/loading-skeleton.component';
import { ToastComponent } from '../../shared/components/toast/toast.component';

@Component({
  selector: 'app-cart-page',
  standalone: true,
  imports: [CommonModule, RouterLink, MoneyPipe, EmptyStateComponent, LoadingSkeletonComponent, ToastComponent],
  template: `
    <section class="cart-page">
      <div class="cart-heading">
        <div>
          <span class="eyebrow">Shopping cart</span>
          <h1>Your cart</h1>
          <p>Review quantities, remove items, or clear the cart before checkout.</p>
        </div>
        <button type="button" class="ghost-light" (click)="clearCart()" [disabled]="busy() || !cart()?.items?.length">Clear cart</button>
      </div>

      <app-toast [message]="message()"></app-toast>
      <app-loading-skeleton *ngIf="loading()" [rows]="4"></app-loading-skeleton>

      <div class="cart-layout" *ngIf="!loading() && cart() as currentCart">
        <section class="surface cart-items" *ngIf="currentCart.items.length; else emptyCart">
          <article class="cart-item" *ngFor="let item of currentCart.items">
            <div>
              <strong>{{ item.productName }}</strong>
              <span>{{ item.unitPrice | money: item.currency }} each</span>
              <span class="cart-stock-warning" *ngIf="stockWarning(item)">{{ stockWarning(item) }}</span>
              <span class="muted-line" *ngIf="!stockWarning(item)">{{ stockLabel(item) }}</span>
            </div>
            <div class="quantity-stepper" aria-label="Quantity">
              <button type="button" (click)="changeQuantity(item, item.quantity - 1)" [disabled]="busy() || item.quantity <= 1">-</button>
              <input [value]="item.quantity" readonly>
              <button type="button" (click)="changeQuantity(item, item.quantity + 1)" [disabled]="busy() || !canIncrease(item)">+</button>
            </div>
            <strong>{{ item.lineTotal | money: item.currency }}</strong>
            <button type="button" class="text-danger" (click)="removeItem(item)" [disabled]="busy()">Remove</button>
          </article>
        </section>

        <ng-template #emptyCart>
          <app-empty-state title="Your cart is empty" message="Browse products and add something you like."></app-empty-state>
        </ng-template>

        <aside class="surface price-summary">
          <h2>Price summary</h2>
          <div><span>Items</span><strong>{{ currentCart.totalItems }}</strong></div>
          <div><span>Subtotal</span><strong>{{ currentCart.subtotal | money: currentCart.currency }}</strong></div>
          <div><span>Shipping</span><strong>Calculated later</strong></div>
          <hr>
          <div class="summary-total"><span>Total</span><strong>{{ currentCart.subtotal | money: currentCart.currency }}</strong></div>
          <p class="cart-stock-warning" *ngIf="hasStockWarnings()">Fix stock warnings before checkout.</p>
          <a class="button-link" routerLink="/checkout" [class.disabled]="busy() || !currentCart.items.length || hasStockWarnings()">Checkout</a>
          <a routerLink="/products">Continue shopping</a>
        </aside>
      </div>
    </section>
  `
})
export class CartPageComponent implements OnInit {
  readonly cart = signal<Cart | null>(null);
  readonly loading = signal(true);
  readonly busy = signal(false);
  readonly message = signal('');
  readonly stockByProduct = signal<Record<string, InventoryItem | null>>({});

  constructor(
    private readonly cartApi: CartApiService,
    private readonly inventory: InventoryReadApiService,
    private readonly errors: ErrorMessageService
  ) {}

  ngOnInit(): void {
    this.refresh();
  }

  refresh(): void {
    this.loading.set(true);
    this.message.set('');
    this.cartApi.getMine()
      .pipe(finalize(() => this.loading.set(false)))
      .subscribe({
        next: (cart) => {
          this.cart.set(cart);
          this.loadStock(cart.items);
        },
        error: (error) => this.message.set(this.errors.from(error))
      });
  }

  changeQuantity(item: CartItem, quantity: number): void {
    if (quantity < 1) {
      return;
    }

    this.busy.set(true);
    this.message.set('');
    this.cartApi.updateItem(item.id, quantity).subscribe({
      next: (cart) => this.finish(cart, 'Cart updated.'),
      error: (error) => this.fail(error)
    });
  }

  removeItem(item: CartItem): void {
    this.busy.set(true);
    this.message.set('');
    this.cartApi.removeItem(item.id).subscribe({
      next: (cart) => this.finish(cart, 'Item removed.'),
      error: (error) => this.fail(error)
    });
  }

  clearCart(): void {
    this.busy.set(true);
    this.message.set('');
    this.cartApi.clear().subscribe({
      next: (cart) => this.finish(cart, 'Cart cleared.'),
      error: (error) => this.fail(error)
    });
  }

  private finish(cart: Cart, message: string): void {
    this.cart.set(cart);
    this.busy.set(false);
    this.message.set(message);
    this.loadStock(cart.items);
  }

  private fail(error: unknown): void {
    this.busy.set(false);
    this.message.set(this.errors.from(error));
  }

  private loadStock(items: CartItem[]): void {
    this.stockByProduct.set({});
    if (!items.length) {
      return;
    }

    forkJoin(items.map((item) =>
      this.inventory.getByProduct(item.productId).pipe(catchError(() => of(null)))
    )).subscribe((stockItems) => {
      const nextStock = items.reduce<Record<string, InventoryItem | null>>((acc, item, index) => {
        acc[item.productId] = stockItems[index];
        return acc;
      }, {});

      this.stockByProduct.set(nextStock);
    });
  }

  private stockFor(item: CartItem): InventoryItem | null | undefined {
    return this.stockByProduct()[item.productId];
  }

  stockLabel(item: CartItem): string {
    const stock = this.stockFor(item);
    return stock ? `${stock.availableQuantity} available` : 'Checking stock';
  }

  stockWarning(item: CartItem): string {
    const stock = this.stockFor(item);
    if (!stock) {
      return '';
    }

    if (stock.availableQuantity <= 0) {
      return 'Out of stock';
    }

    if (item.quantity > stock.availableQuantity) {
      return `Only ${stock.availableQuantity} available`;
    }

    return '';
  }

  canIncrease(item: CartItem): boolean {
    const stock = this.stockFor(item);
    return !stock || item.quantity < stock.availableQuantity;
  }

  hasStockWarnings(): boolean {
    return this.cart()?.items.some((item) => Boolean(this.stockWarning(item))) ?? false;
  }
}
