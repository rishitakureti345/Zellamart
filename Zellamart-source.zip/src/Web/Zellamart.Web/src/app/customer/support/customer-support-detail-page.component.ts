import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { finalize } from 'rxjs';
import { SupportApiService } from '../services/support-api.service';
import { ErrorMessageService } from '../../core/services/error-message.service';
import { SupportTicket } from '../models/support.model';
import { StatusBadgeComponent } from '../../shared/components/status-badge/status-badge.component';
import { ToastComponent } from '../../shared/components/toast/toast.component';
import { LoadingSkeletonComponent } from '../../shared/components/loading-skeleton/loading-skeleton.component';
import { EmptyStateComponent } from '../../shared/components/empty-state/empty-state.component';

@Component({
  selector: 'app-customer-support-detail-page',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink, StatusBadgeComponent, ToastComponent, LoadingSkeletonComponent, EmptyStateComponent],
  template: `
    <section class="dashboard-header">
      <div>
        <a routerLink="/customer/support" class="back-link">Back to support</a>
        <span class="eyebrow">Ticket</span>
        <h1>{{ ticket()?.subject || 'Support ticket' }}</h1>
        <p>{{ ticket()?.description }}</p>
      </div>
      <button type="button" class="ghost-light" *ngIf="ticket() && canClose(ticket()!)" [disabled]="busy()" (click)="closeTicket()">Close ticket</button>
    </section>
    <app-toast [message]="message()"></app-toast>
    <app-loading-skeleton *ngIf="loading()" [rows]="4"></app-loading-skeleton>

    <section class="order-detail-grid" *ngIf="!loading() && ticket() as item">
      <article class="surface dashboard-panel">
        <h2>Ticket</h2>
        <p><app-status-badge kind="ticket" [status]="item.status"></app-status-badge></p>
        <p><strong>Order:</strong> <a [routerLink]="['/customer/orders', item.orderId]">{{ item.orderId }}</a></p>
        <p><strong>Type:</strong> {{ item.type }}</p>
        <p><strong>Created:</strong> {{ item.createdAtUtc | date: 'medium' }}</p>
        <p *ngIf="item.assignedAgentId"><strong>Agent:</strong> {{ item.assignedAgentId }}</p>
      </article>

      <article class="surface dashboard-panel wide-panel">
        <h2>Messages</h2>
        <div class="message-thread" *ngIf="item.messages.length">
          <article *ngFor="let msg of item.messages">
            <strong>{{ msg.createdAtUtc | date: 'medium' }}</strong>
            <p>{{ msg.message }}</p>
          </article>
        </div>
        <p *ngIf="!item.messages.length">No replies yet.</p>
        <form class="inline-message" (ngSubmit)="sendMessage()" *ngIf="canReply(item)">
          <input [(ngModel)]="messageText" name="messageText" maxlength="1200" placeholder="Write a reply">
          <button type="submit" [disabled]="busy()">Send</button>
        </form>
      </article>

      <article class="surface dashboard-panel wide-panel">
        <h2>Status tracking</h2>
        <table *ngIf="item.statusHistory.length">
          <tr><th>Status</th><th>Note</th><th>Changed</th></tr>
          <tr *ngFor="let history of item.statusHistory">
            <td><app-status-badge kind="ticket" [status]="history.status"></app-status-badge></td>
            <td>{{ history.note }}</td>
            <td>{{ history.changedAtUtc | date: 'medium' }}</td>
          </tr>
        </table>
      </article>
    </section>
    <app-empty-state *ngIf="!loading() && !ticket()" title="Ticket not found" message="This ticket may not exist or may belong to another customer."></app-empty-state>
  `
})
export class CustomerSupportDetailPageComponent implements OnInit {
  messageText = '';
  readonly ticket = signal<SupportTicket | null>(null);
  readonly message = signal('');
  readonly loading = signal(true);
  readonly busy = signal(false);
  private ticketId = '';

  constructor(private readonly support: SupportApiService, private readonly route: ActivatedRoute, private readonly errors: ErrorMessageService) {}

  ngOnInit(): void {
    this.ticketId = this.route.snapshot.paramMap.get('ticketId') ?? '';
    this.load();
  }

  load(): void {
    this.loading.set(true);
    this.support.getTicket(this.ticketId).pipe(finalize(() => this.loading.set(false))).subscribe({
      next: (ticket) => this.ticket.set(ticket),
      error: (error) => this.message.set(this.errors.from(error))
    });
  }

  sendMessage(): void {
    if (!this.messageText.trim()) {
      this.message.set('Reply is required.');
      return;
    }

    this.busy.set(true);
    this.support.addMessage(this.ticketId, this.messageText.trim()).pipe(finalize(() => this.busy.set(false))).subscribe({
      next: (ticket) => {
        this.ticket.set(ticket);
        this.messageText = '';
        this.message.set('Reply sent.');
      },
      error: (error) => this.message.set(this.errors.from(error))
    });
  }

  closeTicket(): void {
    this.busy.set(true);
    this.support.closeTicket(this.ticketId).pipe(finalize(() => this.busy.set(false))).subscribe({
      next: (ticket) => {
        this.ticket.set(ticket);
        this.message.set('Ticket closed.');
      },
      error: (error) => this.message.set(this.errors.from(error))
    });
  }

  canReply(ticket: SupportTicket): boolean {
    const status = String(ticket.status).toLowerCase();
    return !['closed', 'rejected', '5', '4'].includes(status);
  }

  canClose(ticket: SupportTicket): boolean {
    const status = String(ticket.status).toLowerCase();
    return !['closed', '5'].includes(status);
  }
}
