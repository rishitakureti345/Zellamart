import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { finalize, forkJoin } from 'rxjs';
import { OrderApiService } from '../services/order-api.service';
import { SupportApiService } from '../services/support-api.service';
import { ErrorMessageService } from '../../core/services/error-message.service';
import { Order } from '../models/order.model';
import { SupportTicket } from '../models/support.model';
import { StatusBadgeComponent } from '../../shared/components/status-badge/status-badge.component';
import { EmptyStateComponent } from '../../shared/components/empty-state/empty-state.component';
import { ToastComponent } from '../../shared/components/toast/toast.component';

@Component({
  selector: 'app-customer-support-page',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink, StatusBadgeComponent, EmptyStateComponent, ToastComponent],
  template: `
    <section class="dashboard-header">
      <div><span class="eyebrow">Support</span><h1>Support tickets</h1><p>Create, reply to, and track customer complaints.</p></div>
      <button type="button" (click)="load()" [disabled]="loading()">Refresh</button>
    </section>
    <app-toast [message]="message()"></app-toast>
    <section class="ops-form-grid">
      <form class="surface checkout-form" (ngSubmit)="createTicket()">
        <h2>New ticket</h2>
        <label>Order<select [(ngModel)]="orderId" name="orderId" required><option value="">Select order</option><option *ngFor="let order of orders()" [value]="order.id">{{ order.orderNumber }} - {{ order.status }}</option></select></label>
        <label>Type<select [(ngModel)]="type" name="type"><option [ngValue]="1">Order issue</option><option [ngValue]="2">Payment issue</option><option [ngValue]="3">Delivery issue</option><option [ngValue]="4">Return request</option><option [ngValue]="5">Refund request</option><option [ngValue]="6">Product issue</option><option [ngValue]="7">Other</option></select></label>
        <label>Subject<input [(ngModel)]="subject" name="subject" required></label>
        <label>Description<textarea [(ngModel)]="description" name="description" rows="4" required></textarea></label>
        <button type="submit" [disabled]="busy()">Create ticket</button>
      </form>
      <section class="surface dashboard-panel">
        <h2>My tickets</h2>
        <div class="table-toolbar" *ngIf="tickets().length">
          <label>Status
            <select [(ngModel)]="statusFilter" name="statusFilter">
              <option value="all">All statuses</option>
              <option *ngFor="let status of statuses()" [value]="status">{{ status }}</option>
            </select>
          </label>
        </div>
        <table *ngIf="filteredTickets().length">
          <tr><th>Subject</th><th>Order</th><th>Status</th><th>Created</th><th></th></tr>
          <tr *ngFor="let ticket of filteredTickets()">
            <td>{{ ticket.subject }}</td>
            <td><a [routerLink]="['/customer/orders', ticket.orderId]">{{ ticket.orderId }}</a></td>
            <td><app-status-badge kind="ticket" [status]="ticket.status"></app-status-badge></td>
            <td>{{ ticket.createdAtUtc | date: 'medium' }}</td>
            <td><a [routerLink]="['/customer/support', ticket.id]">Open</a></td>
          </tr>
        </table>
        <app-empty-state *ngIf="!tickets().length" title="No tickets yet" message="Create a ticket for an order issue."></app-empty-state>
        <app-empty-state *ngIf="tickets().length && !filteredTickets().length" title="No tickets match this filter" message="Choose another status."></app-empty-state>
      </section>
    </section>
  `
})
export class CustomerSupportPageComponent implements OnInit {
  orderId = '';
  type = 1;
  subject = '';
  description = '';
  readonly orders = signal<Order[]>([]);
  readonly tickets = signal<SupportTicket[]>([]);
  readonly busy = signal(false);
  readonly loading = signal(false);
  readonly message = signal('');
  statusFilter = 'all';

  constructor(private readonly orderApi: OrderApiService, private readonly support: SupportApiService, private readonly errors: ErrorMessageService, private readonly router: Router) {}

  ngOnInit(): void { this.load(); }

  load(): void {
    this.loading.set(true);
    forkJoin({
      orders: this.orderApi.getMine(),
      tickets: this.support.getTickets()
    }).pipe(finalize(() => this.loading.set(false))).subscribe({
      next: ({ orders, tickets }) => {
        this.orders.set(orders);
        this.tickets.set(this.byNewest(tickets));
      },
      error: (error) => this.message.set(this.errors.from(error))
    });
  }

  createTicket(): void {
    if (!this.orderId || !this.subject.trim() || !this.description.trim()) {
      this.message.set('Order, subject, and description are required.');
      return;
    }
    this.busy.set(true);
    this.support.createTicket(this.orderId, Number(this.type), this.subject, this.description)
      .pipe(finalize(() => this.busy.set(false)))
      .subscribe({
        next: (ticket) => void this.router.navigate(['/customer/support', ticket.id]),
        error: (error) => this.message.set(this.errors.from(error))
      });
  }

  statuses(): string[] {
    return [...new Set(this.tickets().map((ticket) => String(ticket.status)))].sort();
  }

  filteredTickets(): SupportTicket[] {
    return this.statusFilter === 'all'
      ? this.tickets()
      : this.tickets().filter((ticket) => String(ticket.status) === this.statusFilter);
  }

  private byNewest(tickets: SupportTicket[]): SupportTicket[] {
    return [...tickets].sort((first, second) =>
      new Date(second.createdAtUtc).getTime() - new Date(first.createdAtUtc).getTime()
    );
  }
}
