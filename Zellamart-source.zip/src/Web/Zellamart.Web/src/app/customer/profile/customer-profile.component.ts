import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../../core/services/auth.service';
import { StatusBadgeComponent } from '../../shared/components/status-badge/status-badge.component';
import { ToastComponent } from '../../shared/components/toast/toast.component';
import { WorkspaceSwitcherComponent } from '../../shared/components/workspace-switcher/workspace-switcher.component';

interface CustomerContactProfile {
  phone: string;
  defaultShippingAddress: string;
}

@Component({
  selector: 'app-customer-profile',
  standalone: true,
  imports: [CommonModule, FormsModule, StatusBadgeComponent, ToastComponent, WorkspaceSwitcherComponent],
  template: `
    <section class="dashboard-header">
      <div>
        <span class="eyebrow">Account</span>
        <h1>Customer profile</h1>
        <p>Your Zellamart identity, access status, and default delivery contact details.</p>
      </div>
      <button type="button" class="ghost-light" (click)="logout()">Logout</button>
    </section>

    <app-toast [message]="message()"></app-toast>

    <app-workspace-switcher></app-workspace-switcher>

    <section class="metric-grid" *ngIf="auth.session() as session">
      <article class="metric-card"><span>Account status</span><strong>{{ session.isActive === false ? 'Inactive' : 'Active' }}</strong></article>
      <article class="metric-card"><span>Primary role</span><strong>{{ session.roles[0] || 'Customer' }}</strong></article>
      <article class="metric-card"><span>Permissions</span><strong>{{ session.permissions.length }}</strong></article>
      <article class="metric-card"><span>Saved address</span><strong>{{ contact.defaultShippingAddress ? 'Yes' : 'No' }}</strong></article>
    </section>

    <section class="settings-grid" *ngIf="auth.session() as session">
      <section class="surface profile-card">
        <div><span>Account status</span><strong><span class="status-pill">{{ session.isActive === false ? 'Inactive' : 'Active' }}</span></strong></div>
        <div><span>Full name</span><strong>{{ session.fullName }}</strong></div>
        <div><span>Email</span><strong>{{ session.email }}</strong></div>
        <div><span>User ID</span><strong>{{ session.userId }}</strong></div>
        <div>
          <span>Roles</span>
          <p class="badge-row">
            <app-status-badge *ngFor="let role of session.roles" [status]="role"></app-status-badge>
          </p>
        </div>
        <div>
          <span>Permissions</span>
          <p>{{ session.permissions.join(', ') || 'No explicit permissions' }}</p>
        </div>
      </section>

      <form class="surface checkout-form settings-form" (ngSubmit)="saveContact()">
        <h2>Contact and delivery</h2>
        <label>Phone
          <input [(ngModel)]="contact.phone" name="phone" maxlength="40" placeholder="Customer phone number">
        </label>
        <label>Default shipping address
          <textarea [(ngModel)]="contact.defaultShippingAddress" name="defaultShippingAddress" rows="5" maxlength="600" placeholder="House, street, city, state, PIN"></textarea>
        </label>
        <div class="action-row">
          <button type="submit" [disabled]="loading()">{{ loading() ? 'Saving...' : 'Save profile' }}</button>
          <button type="button" class="ghost-light" [disabled]="loading()" (click)="resetContact()">Reset</button>
        </div>
        <p class="muted-line">Phone and address are saved to your Identity profile.</p>
      </form>
    </section>
  `
})
export class CustomerProfileComponent implements OnInit {
  readonly message = signal('');
  readonly loading = signal(false);
  contact: CustomerContactProfile = {
    phone: '',
    defaultShippingAddress: ''
  };

  constructor(
    readonly auth: AuthService,
    private readonly router: Router
  ) {}

  ngOnInit(): void {
    this.loadProfile();
  }

  saveContact(): void {
    this.loading.set(true);
    this.message.set('');
    this.auth.updateProfile({
      phone: this.contact.phone,
      defaultShippingAddress: this.contact.defaultShippingAddress
    }).subscribe({
      next: (result) => {
        this.contact = {
          phone: result.value.phone ?? '',
          defaultShippingAddress: result.value.defaultShippingAddress ?? ''
        };
        this.message.set('Customer profile saved.');
        this.loading.set(false);
      },
      error: () => {
        this.message.set('Could not save customer profile.');
        this.loading.set(false);
      }
    });
  }

  resetContact(): void {
    this.contact = { phone: '', defaultShippingAddress: '' };
    this.saveContact();
  }

  logout(): void {
    this.auth.logout();
    void this.router.navigateByUrl('/');
  }

  private loadProfile(): void {
    const session = this.auth.session();
    this.contact = {
      phone: session?.phone ?? '',
      defaultShippingAddress: session?.defaultShippingAddress ?? ''
    };

    this.loading.set(true);
    this.auth.profile().subscribe({
      next: (result) => {
        this.contact = {
          phone: result.value.phone ?? '',
          defaultShippingAddress: result.value.defaultShippingAddress ?? ''
        };
        this.loading.set(false);
      },
      error: () => {
        this.message.set('Could not refresh customer profile.');
        this.loading.set(false);
      }
    });
  }
}
