import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { SupportApiService } from '../services/support-api.service';
import { ErrorMessageService } from '../../core/services/error-message.service';
import { ReturnRequest } from '../models/support.model';
import { MoneyPipe } from '../../shared/pipes/money.pipe';
import { StatusBadgeComponent } from '../../shared/components/status-badge/status-badge.component';
import { ToastComponent } from '../../shared/components/toast/toast.component';

@Component({
  selector: 'app-return-detail-page',
  standalone: true,
  imports: [CommonModule, RouterLink, MoneyPipe, StatusBadgeComponent, ToastComponent],
  template: `
    <section class="dashboard-header">
      <div>
        <a routerLink="/customer/returns" class="back-link">Back to returns</a>
        <span class="eyebrow">Return</span>
        <h1>{{ shortId(returnRequest()?.id) || 'Return request' }}</h1>
        <p>Follow pickup review, refund approval, and finance completion.</p>
      </div>
      <a class="button-link" routerLink="/customer/returns/new">Request another return</a>
    </section>

    <app-toast [message]="message()"></app-toast>

    <section class="metric-grid" *ngIf="returnRequest() as item">
      <article class="metric-card"><span>Return status</span><strong>{{ returnStatusLabel(item.status) }}</strong></article>
      <article class="metric-card"><span>Refund status</span><strong>{{ refundStatus(item.status) }}</strong></article>
      <article class="metric-card"><span>Refund amount</span><strong>{{ item.refundAmount | money }}</strong></article>
      <article class="metric-card"><span>Created</span><strong>{{ item.createdAtUtc | date:'mediumDate' }}</strong></article>
    </section>

    <section class="seller-admin-grid" *ngIf="returnRequest() as item">
      <section class="surface profile-card">
        <div><span>Status</span><strong><app-status-badge kind="return" [status]="item.status"></app-status-badge></strong></div>
        <div><span>Refund status</span><strong>{{ refundStatus(item.status) }}</strong></div>
        <div><span>Refund amount</span><strong>{{ item.refundAmount | money }}</strong></div>
        <div><span>Order</span><strong><a [routerLink]="['/customer/orders', item.orderId]">{{ shortId(item.orderId) }}</a></strong></div>
        <div><span>Order item</span><strong>{{ shortId(item.orderItemId) }}</strong></div>
        <div><span>Product</span><strong>{{ shortId(item.productId) }}</strong></div>
        <div class="profile-wide"><span>Reason</span><p>{{ item.reason }}</p></div>
      </section>

      <aside class="surface seller-detail-pane">
        <div class="seller-detail-heading">
          <span class="eyebrow">Status history</span>
          <h2>Return timeline</h2>
        </div>

        <table *ngIf="item.statusHistory.length">
          <tr><th>Status</th><th>Note</th><th>Date</th></tr>
          <tr *ngFor="let entry of orderedHistory(item)">
            <td><app-status-badge kind="return" [status]="entry.status"></app-status-badge></td>
            <td>{{ entry.note }}</td>
            <td>{{ entry.changedAtUtc | date:'medium' }}</td>
          </tr>
        </table>
      </aside>
    </section>
  `
})
export class ReturnDetailPageComponent implements OnInit {
  readonly returnRequest = signal<ReturnRequest | null>(null);
  readonly message = signal('');

  constructor(private readonly support: SupportApiService, private readonly route: ActivatedRoute, private readonly errors: ErrorMessageService) {}

  ngOnInit(): void {
    const returnId = this.route.snapshot.paramMap.get('returnId') ?? '';
    this.support.getReturn(returnId).subscribe({
      next: (item) => this.returnRequest.set(item),
      error: (error) => this.message.set(this.errors.from(error))
    });
  }

  orderedHistory(item: ReturnRequest) {
    return [...item.statusHistory].sort((left, right) => Date.parse(left.changedAtUtc) - Date.parse(right.changedAtUtc));
  }

  refundStatus(status: string | number): string {
    const label = this.returnStatusLabel(status);
    if (label === 'Refunded') {
      return 'Refund complete';
    }
    if (label === 'Refund initiated') {
      return 'Finance review';
    }
    if (label === 'Picked up') {
      return 'Ready for refund';
    }
    if (label === 'Rejected' || label === 'Closed') {
      return 'Not refundable';
    }
    return 'Waiting for return approval';
  }

  returnStatusLabel(status: string | number): string {
    const map: Record<string, string> = {
      '1': 'Requested',
      Requested: 'Requested',
      '2': 'Approved',
      Approved: 'Approved',
      '3': 'Rejected',
      Rejected: 'Rejected',
      '4': 'Pickup scheduled',
      PickupScheduled: 'Pickup scheduled',
      '5': 'Picked up',
      PickedUp: 'Picked up',
      '6': 'Refund initiated',
      RefundInitiated: 'Refund initiated',
      '7': 'Refunded',
      Refunded: 'Refunded',
      '8': 'Closed',
      Closed: 'Closed'
    };
    return map[String(status)] ?? String(status);
  }

  shortId(id?: string): string {
    return id ? id.slice(0, 8) : '';
  }
}
