import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { OrderApiService } from '../services/order-api.service';
import { SupportApiService } from '../services/support-api.service';
import { ErrorMessageService } from '../../core/services/error-message.service';
import { Order, OrderItem } from '../models/order.model';
import { ToastComponent } from '../../shared/components/toast/toast.component';
import { MoneyPipe } from '../../shared/pipes/money.pipe';
import { EmptyStateComponent } from '../../shared/components/empty-state/empty-state.component';

@Component({
  selector: 'app-new-return-page',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink, ToastComponent, MoneyPipe, EmptyStateComponent],
  template: `
    <section class="dashboard-header">
      <div>
        <a routerLink="/customer/returns" class="back-link">Back to returns</a>
        <span class="eyebrow">Returns</span>
        <h1>Request return</h1>
        <p>Select a delivered order item and explain the problem.</p>
      </div>
    </section>

    <app-toast [message]="message()"></app-toast>

    <section class="seller-admin-grid" *ngIf="deliveredOrders().length; else noDeliveredOrders">
      <form class="surface checkout-form" (ngSubmit)="createReturn()">
        <label>Delivered order
          <select [(ngModel)]="orderId" name="orderId" (change)="syncItems()" required>
            <option value="">Select order</option>
            <option *ngFor="let order of deliveredOrders()" [value]="order.id">
              {{ order.orderNumber }} - {{ order.createdAtUtc | date:'mediumDate' }}
            </option>
          </select>
        </label>

        <label>Item
          <select [(ngModel)]="orderItemId" name="orderItemId" required>
            <option value="">Select item</option>
            <option *ngFor="let item of selectedItems()" [value]="item.id">
              {{ item.productName }} x {{ item.quantity }} - {{ item.lineTotal | money }}
            </option>
          </select>
        </label>

        <label>Reason
          <textarea [(ngModel)]="reason" name="reason" rows="5" maxlength="500" required placeholder="Describe damage, wrong item, missing parts, or another issue."></textarea>
        </label>

        <p class="muted-line">{{ reason.trim().length }}/500 characters</p>
        <button type="submit" [disabled]="busy() || !canSubmit()">{{ busy() ? 'Submitting...' : 'Submit return' }}</button>
      </form>

      <aside class="surface seller-detail-pane">
        <div class="seller-detail-heading">
          <span class="eyebrow">Refund preview</span>
          <h2>{{ refundAmount() | money }}</h2>
        </div>

        <div class="seller-detail-grid">
          <div><span>Order</span><strong>{{ selectedOrder()?.orderNumber || '-' }}</strong></div>
          <div><span>Order status</span><strong>{{ selectedOrder()?.status || '-' }}</strong></div>
          <div><span>Product</span><strong>{{ selectedItem()?.productName || '-' }}</strong></div>
          <div><span>Quantity</span><strong>{{ selectedItem()?.quantity || '-' }}</strong></div>
          <div><span>Unit price</span><strong>{{ unitPrice() | money }}</strong></div>
          <div><span>Refund amount</span><strong>{{ refundAmount() | money }}</strong></div>
        </div>

        <p class="muted">Only delivered order items can be returned. After submission, admin/support reviews the request before pickup and finance refund.</p>
      </aside>
    </section>

    <ng-template #noDeliveredOrders>
      <app-empty-state title="No delivered orders" message="Returns can be requested only after an order has been delivered."></app-empty-state>
    </ng-template>
  `
})
export class NewReturnPageComponent implements OnInit {
  orderId = '';
  orderItemId = '';
  reason = '';
  readonly orders = signal<Order[]>([]);
  readonly selectedItems = signal<OrderItem[]>([]);
  readonly busy = signal(false);
  readonly message = signal('');

  constructor(private readonly orderApi: OrderApiService, private readonly support: SupportApiService, private readonly errors: ErrorMessageService, private readonly router: Router) {}

  ngOnInit(): void {
    this.orderApi.getMine().subscribe({
      next: (orders) => this.orders.set(orders),
      error: (error) => this.message.set(this.errors.from(error))
    });
  }

  deliveredOrders(): Order[] {
    return this.orders().filter((order) => ['6', 'Delivered'].includes(String(order.status)));
  }

  syncItems(): void {
    this.orderItemId = '';
    this.selectedItems.set(this.orders().find((order) => order.id === this.orderId)?.items ?? []);
  }

  selectedOrder(): Order | undefined {
    return this.orders().find((order) => order.id === this.orderId);
  }

  selectedItem(): OrderItem | undefined {
    return this.selectedItems().find((entry) => entry.id === this.orderItemId);
  }

  unitPrice(): number {
    return this.selectedItem()?.unitPrice ?? 0;
  }

  refundAmount(): number {
    return this.selectedItem()?.lineTotal ?? 0;
  }

  canSubmit(): boolean {
    return Boolean(this.orderId && this.selectedItem() && this.reason.trim());
  }

  createReturn(): void {
    const order = this.selectedOrder();
    const item = this.selectedItem();
    if (!this.orderId || !item || !this.reason.trim()) {
      this.message.set('Order, item, and reason are required.');
      return;
    }
    if (!order || !['6', 'Delivered'].includes(String(order.status))) {
      this.message.set('Only delivered orders can be returned.');
      return;
    }
    this.busy.set(true);
    this.support.createReturn(this.orderId, item.id, item.productId, this.reason).subscribe({
      next: (returnRequest) => void this.router.navigate(['/customer/returns', returnRequest.id]),
      error: (error) => { this.busy.set(false); this.message.set(this.errors.from(error)); }
    });
  }
}
