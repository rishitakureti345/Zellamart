import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { SupportApiService } from '../services/support-api.service';
import { ErrorMessageService } from '../../core/services/error-message.service';
import { ReturnRequest } from '../models/support.model';
import { MoneyPipe } from '../../shared/pipes/money.pipe';
import { StatusBadgeComponent } from '../../shared/components/status-badge/status-badge.component';
import { EmptyStateComponent } from '../../shared/components/empty-state/empty-state.component';
import { ToastComponent } from '../../shared/components/toast/toast.component';

@Component({
  selector: 'app-customer-returns-page',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink, MoneyPipe, StatusBadgeComponent, EmptyStateComponent, ToastComponent],
  template: `
    <section class="dashboard-header">
      <div>
        <span class="eyebrow">Returns</span>
        <h1>Return requests</h1>
        <p>Track return pickup, refund status, and support decisions.</p>
      </div>
      <a class="button-link" routerLink="/customer/returns/new">Request return</a>
    </section>

    <app-toast [message]="message()"></app-toast>

    <section class="metric-grid">
      <article class="metric-card"><span>Total returns</span><strong>{{ returns().length }}</strong></article>
      <article class="metric-card"><span>Requested</span><strong>{{ countByStatus('Requested') }}</strong></article>
      <article class="metric-card"><span>In progress</span><strong>{{ inProgressCount() }}</strong></article>
      <article class="metric-card"><span>Refunded</span><strong>{{ countByStatus('Refunded') }}</strong></article>
    </section>

    <section class="seller-toolbar users-toolbar">
      <label>Search<input [(ngModel)]="search" placeholder="Order, product, reason"></label>
      <label>Status
        <select [(ngModel)]="statusFilter">
          <option value="all">All statuses</option>
          <option *ngFor="let status of statusFilters" [value]="status">{{ status }}</option>
        </select>
      </label>
      <span></span>
    </section>

    <section class="surface dashboard-panel" *ngIf="filteredReturns().length">
      <table>
        <tr><th>Return</th><th>Order</th><th>Status</th><th>Refund</th><th>Refund status</th><th></th></tr>
        <tr *ngFor="let item of filteredReturns()">
          <td>
            <strong>{{ shortId(item.id) }}</strong>
            <br>
            <span class="muted-line">{{ item.reason }}</span>
          </td>
          <td><a [routerLink]="['/customer/orders', item.orderId]">{{ shortId(item.orderId) }}</a></td>
          <td><app-status-badge kind="return" [status]="item.status"></app-status-badge></td>
          <td>{{ item.refundAmount | money }}</td>
          <td>{{ refundStatus(item.status) }}</td>
          <td><a class="button-link small-link" [routerLink]="['/customer/returns', item.id]">Open</a></td>
        </tr>
      </table>
    </section>
    <app-empty-state *ngIf="!filteredReturns().length" title="No returns found" message="Delivered order item return requests will show here."></app-empty-state>
  `
})
export class CustomerReturnsPageComponent implements OnInit {
  search = '';
  statusFilter = 'all';
  readonly statusFilters = ['Requested', 'Approved', 'Rejected', 'Pickup scheduled', 'Picked up', 'Refund initiated', 'Refunded', 'Closed'];
  readonly returns = signal<ReturnRequest[]>([]);
  readonly message = signal('');

  constructor(private readonly support: SupportApiService, private readonly errors: ErrorMessageService) {}

  ngOnInit(): void {
    this.support.getReturns().subscribe({
      next: (returns) => this.returns.set(returns),
      error: (error) => this.message.set(this.errors.from(error))
    });
  }

  filteredReturns(): ReturnRequest[] {
    const term = this.search.trim().toLowerCase();
    return [...this.returns()]
      .sort((left, right) => Date.parse(right.createdAtUtc) - Date.parse(left.createdAtUtc))
      .filter((item) => {
        const statusMatches = this.statusFilter === 'all' || this.returnStatusLabel(item.status) === this.statusFilter;
        const searchable = [item.id, item.orderId, item.orderItemId, item.productId, item.reason].join(' ').toLowerCase();
        return statusMatches && (!term || searchable.includes(term));
      });
  }

  countByStatus(status: string): number {
    return this.returns().filter((item) => this.returnStatusLabel(item.status) === status).length;
  }

  inProgressCount(): number {
    return this.returns().filter((item) => ['Approved', 'Pickup scheduled', 'Picked up', 'Refund initiated'].includes(this.returnStatusLabel(item.status))).length;
  }

  refundStatus(status: string | number): string {
    const label = this.returnStatusLabel(status);
    if (label === 'Refunded') {
      return 'Refund complete';
    }
    if (label === 'Refund initiated') {
      return 'Finance review';
    }
    if (label === 'Picked up') {
      return 'Ready for refund';
    }
    if (label === 'Rejected' || label === 'Closed') {
      return 'Not refundable';
    }
    return 'Waiting for return approval';
  }

  returnStatusLabel(status: string | number): string {
    const map: Record<string, string> = {
      '1': 'Requested',
      Requested: 'Requested',
      '2': 'Approved',
      Approved: 'Approved',
      '3': 'Rejected',
      Rejected: 'Rejected',
      '4': 'Pickup scheduled',
      PickupScheduled: 'Pickup scheduled',
      '5': 'Picked up',
      PickedUp: 'Picked up',
      '6': 'Refund initiated',
      RefundInitiated: 'Refund initiated',
      '7': 'Refunded',
      Refunded: 'Refunded',
      '8': 'Closed',
      Closed: 'Closed'
    };
    return map[String(status)] ?? String(status);
  }

  shortId(id: string): string {
    return id ? id.slice(0, 8) : '-';
  }
}
