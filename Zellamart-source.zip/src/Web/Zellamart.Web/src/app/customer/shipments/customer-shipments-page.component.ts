import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { finalize } from 'rxjs';
import { OperationsApiService } from '../../core/services/operations-api.service';
import { ErrorMessageService } from '../../core/services/error-message.service';
import { ShipmentSummary } from '../../core/models/operations.model';
import { StatusBadgeComponent } from '../../shared/components/status-badge/status-badge.component';
import { EmptyStateComponent } from '../../shared/components/empty-state/empty-state.component';
import { LoadingSkeletonComponent } from '../../shared/components/loading-skeleton/loading-skeleton.component';
import { ToastComponent } from '../../shared/components/toast/toast.component';

@Component({
  selector: 'app-customer-shipments-page',
  standalone: true,
  imports: [CommonModule, RouterLink, StatusBadgeComponent, EmptyStateComponent, LoadingSkeletonComponent, ToastComponent],
  template: `
    <section class="dashboard-header">
      <div>
        <span class="eyebrow">Delivery</span>
        <h1>Shipment tracking</h1>
        <p>Track packing, shipping, delivery, and failed delivery states.</p>
      </div>
      <button type="button" (click)="load()">Refresh</button>
    </section>
    <app-toast [message]="message()"></app-toast>
    <app-loading-skeleton *ngIf="loading()" [rows]="4"></app-loading-skeleton>
    <section class="surface dashboard-panel" *ngIf="!loading() && shipments().length">
      <table>
        <tr><th>Tracking</th><th>Status</th><th>Address</th><th>Order</th><th></th></tr>
        <tr *ngFor="let shipment of shipments()">
          <td>{{ shipment.trackingNumber }}</td>
          <td><app-status-badge kind="shipping" [status]="shipment.status"></app-status-badge></td>
          <td>{{ shipment.shippingAddress }}</td>
          <td><a [routerLink]="['/customer/orders', shipment.orderId]">{{ shipment.orderId }}</a></td>
          <td><a [routerLink]="['/customer/shipments', shipment.orderId]">Track</a></td>
        </tr>
      </table>
    </section>
    <app-empty-state *ngIf="!loading() && !shipments().length" title="No shipments yet" message="Shipments appear after operations creates them for confirmed orders."></app-empty-state>
  `
})
export class CustomerShipmentsPageComponent implements OnInit {
  readonly shipments = signal<ShipmentSummary[]>([]);
  readonly loading = signal(true);
  readonly message = signal('');

  constructor(private readonly operations: OperationsApiService, private readonly errors: ErrorMessageService) {}

  ngOnInit(): void { this.load(); }

  load(): void {
    this.loading.set(true);
    this.operations.myShipments().pipe(finalize(() => this.loading.set(false))).subscribe({
      next: (result) => this.shipments.set(this.byNewest(result.value ?? [])),
      error: (error) => this.message.set(this.errors.from(error))
    });
  }

  private byNewest(shipments: ShipmentSummary[]): ShipmentSummary[] {
    return [...shipments].sort((first, second) =>
      new Date(second.createdAtUtc).getTime() - new Date(first.createdAtUtc).getTime()
    );
  }
}
