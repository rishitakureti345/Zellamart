import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { finalize } from 'rxjs';
import { OrderApiService } from '../services/order-api.service';
import { Shipment } from '../models/order.model';
import { ErrorMessageService } from '../../core/services/error-message.service';
import { StatusBadgeComponent } from '../../shared/components/status-badge/status-badge.component';
import { LoadingSkeletonComponent } from '../../shared/components/loading-skeleton/loading-skeleton.component';
import { ToastComponent } from '../../shared/components/toast/toast.component';
import { EmptyStateComponent } from '../../shared/components/empty-state/empty-state.component';

@Component({
  selector: 'app-customer-shipment-detail-page',
  standalone: true,
  imports: [CommonModule, RouterLink, StatusBadgeComponent, LoadingSkeletonComponent, ToastComponent, EmptyStateComponent],
  template: `
    <section class="dashboard-header">
      <div>
        <a routerLink="/customer/shipments" class="back-link">Back to shipments</a>
        <span class="eyebrow">Shipment tracking</span>
        <h1>{{ shipment()?.trackingNumber || 'Shipment' }}</h1>
        <p>Follow delivery status updates from operations.</p>
      </div>
      <a *ngIf="shipment()" [routerLink]="['/customer/orders', shipment()?.orderId]">View order</a>
    </section>

    <app-toast [message]="message()"></app-toast>
    <app-loading-skeleton *ngIf="loading()" [rows]="4"></app-loading-skeleton>

    <section class="order-detail-grid" *ngIf="!loading() && shipment() as item">
      <article class="surface dashboard-panel">
        <h2>Shipment</h2>
        <p><strong>Tracking:</strong> {{ item.trackingNumber }}</p>
        <p><app-status-badge kind="shipping" [status]="item.status"></app-status-badge></p>
        <p><strong>Order:</strong> <a [routerLink]="['/customer/orders', item.orderId]">{{ item.orderId }}</a></p>
        <p><strong>Created:</strong> {{ item.createdAtUtc | date: 'medium' }}</p>
      </article>

      <article class="surface dashboard-panel">
        <h2>Address</h2>
        <p>{{ item.shippingAddress }}</p>
      </article>

      <article class="surface dashboard-panel wide-panel">
        <h2>Status timeline</h2>
        <table *ngIf="item.statusHistory.length">
          <tr><th>Status</th><th>Note</th><th>Changed</th></tr>
          <tr *ngFor="let history of item.statusHistory">
            <td><app-status-badge kind="shipping" [status]="history.status"></app-status-badge></td>
            <td>{{ history.note }}</td>
            <td>{{ history.changedAtUtc | date: 'medium' }}</td>
          </tr>
        </table>
        <p *ngIf="!item.statusHistory.length">No delivery updates yet.</p>
      </article>
    </section>

    <app-empty-state
      *ngIf="!loading() && !shipment()"
      title="Shipment not found"
      message="This shipment may not exist yet or may belong to another customer.">
    </app-empty-state>
  `
})
export class CustomerShipmentDetailPageComponent implements OnInit {
  readonly shipment = signal<Shipment | null>(null);
  readonly loading = signal(true);
  readonly message = signal('');

  constructor(
    private readonly orders: OrderApiService,
    private readonly errors: ErrorMessageService,
    private readonly route: ActivatedRoute
  ) {}

  ngOnInit(): void {
    const orderId = this.route.snapshot.paramMap.get('orderId') ?? '';
    if (!orderId) {
      this.loading.set(false);
      this.message.set('Order id is missing.');
      return;
    }

    this.orders.getShipment(orderId)
      .pipe(finalize(() => this.loading.set(false)))
      .subscribe({
        next: (shipment) => this.shipment.set(shipment),
        error: (error) => this.message.set(this.errors.from(error))
      });
  }
}
