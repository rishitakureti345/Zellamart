import { Component, OnDestroy, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { map, Observable, of, switchMap } from 'rxjs';
import { SellerApiService } from '../services/seller-api.service';
import { Category } from '../../public/models/catalog.model';
import { SellerProfile } from '../models/seller.model';
import { ErrorMessageService } from '../../core/services/error-message.service';
import { ToastComponent } from '../../shared/components/toast/toast.component';
import { StatusBadgeComponent } from '../../shared/components/status-badge/status-badge.component';

@Component({
  selector: 'app-seller-product-new',
  standalone: true,
  imports: [CommonModule, FormsModule, ToastComponent, StatusBadgeComponent],
  template: `
    <section class="dashboard-header">
      <div>
        <span class="eyebrow">Catalog</span>
        <h1>Submit product</h1>
        <p>New products go to admin approval before appearing in the store.</p>
      </div>
    </section>
    <app-toast [message]="message()"></app-toast>

    <section class="surface dashboard-panel seller-approval-card" *ngIf="profile() as seller">
      <div>
        <span class="eyebrow">Seller status</span>
        <h2>{{ seller.businessName }}</h2>
        <p>{{ isApproved() ? 'Products submitted here will appear in Admin Products for approval.' : 'Admin must approve your seller account before product submission.' }}</p>
      </div>
      <app-status-badge kind="seller" [status]="seller.status"></app-status-badge>
    </section>

    <form class="surface checkout-form seller-form" (ngSubmit)="submit()" *ngIf="isApproved()">
      <label>Category
        <select [(ngModel)]="categoryId" name="categoryId" required>
          <option value="">Select category</option>
          <option *ngFor="let c of categories()" [value]="c.id">{{ c.name }}</option>
        </select>
      </label>
      <label>Name<input [(ngModel)]="name" name="name" required></label>
      <label>Description<textarea [(ngModel)]="description" name="description" rows="4" required></textarea></label>
      <label>Price<input [(ngModel)]="price" name="price" type="number" min="1" required></label>
      <label>Currency
        <select [(ngModel)]="currency" name="currency" required>
          <option *ngFor="let item of currencies" [value]="item">{{ item }}</option>
        </select>
      </label>
      <label>Product image<input type="file" accept="image/*" (change)="chooseImage($event)"></label>
      <div class="product-detail-media" *ngIf="imagePreviewUrl()">
        <img [src]="imagePreviewUrl()" [alt]="name || 'Product image preview'">
      </div>
      <button type="button" class="ghost-light" *ngIf="imagePreviewUrl()" (click)="clearImage()">Remove image</button>
      <button type="submit" [disabled]="busy()">Submit product</button>
    </form>
  `
})
export class SellerProductNewComponent implements OnInit, OnDestroy {
  categoryId = ''; name = ''; description = ''; price = 0; currency = 'INR';
  readonly currencies = ['INR', 'USD', 'EUR', 'GBP', 'AED'];
  readonly categories = signal<Category[]>([]);
  readonly profile = signal<SellerProfile | null>(null);
  readonly busy = signal(false);
  readonly message = signal('');
  readonly imagePreviewUrl = signal<string | null>(null);
  private selectedImage: File | null = null;

  constructor(private readonly api: SellerApiService, private readonly errors: ErrorMessageService, private readonly router: Router) {}

  ngOnInit(): void {
    this.api.getCategories().subscribe((c) => this.categories.set(c));
    this.api.getProfile().subscribe({
      next: (p) => this.profile.set(p),
      error: () => this.message.set('Seller profile was not found. Apply before submitting products.')
    });
  }

  ngOnDestroy(): void {
    this.revokePreviewUrl();
  }

  chooseImage(event: Event): void {
    const input = event.target as HTMLInputElement;
    const file = input.files?.[0] ?? null;
    if (!file) {
      return;
    }

    if (!file.type.startsWith('image/')) {
      this.message.set('Choose an image file.');
      input.value = '';
      return;
    }

    if (file.size > 5 * 1024 * 1024) {
      this.message.set('Image must be 5 MB or smaller.');
      input.value = '';
      return;
    }

    this.revokePreviewUrl();
    this.selectedImage = file;
    this.imagePreviewUrl.set(URL.createObjectURL(file));
  }

  clearImage(): void {
    this.selectedImage = null;
    this.revokePreviewUrl();
  }

  submit(): void {
    if (!this.isApproved()) {
      this.message.set('Seller must be approved before submitting products.');
      return;
    }

    this.busy.set(true);
    const imageUrl$: Observable<string | null> = this.selectedImage
      ? this.api.uploadProductImage(this.selectedImage).pipe(map((upload) => upload.imageUrl))
      : of(null);

    imageUrl$.pipe(
      switchMap((imageUrl) => this.api.submitProduct({
        sellerId: this.profile()?.id,
        categoryId: this.categoryId,
        name: this.name,
        description: this.description,
        price: Number(this.price),
        currency: this.currency || 'INR',
        imageUrl
      }))
    ).subscribe({
      next: () => void this.router.navigateByUrl('/seller/products'),
      error: (error: unknown) => { this.busy.set(false); this.message.set(this.errors.from(error)); }
    });
  }

  isApproved(): boolean {
    return this.statusText(this.profile()?.status ?? '') === 'approved';
  }

  private statusText(status: string | number): string {
    const value = String(status).toLowerCase();
    return value === '4' ? 'suspended' : value === '3' ? 'rejected' : value === '2' ? 'approved' : value === '1' ? 'pending' : value;
  }

  private revokePreviewUrl(): void {
    const previewUrl = this.imagePreviewUrl();
    if (previewUrl) {
      URL.revokeObjectURL(previewUrl);
      this.imagePreviewUrl.set(null);
    }
  }
}
