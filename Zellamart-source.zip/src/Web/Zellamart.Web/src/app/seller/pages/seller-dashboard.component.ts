import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { catchError, forkJoin, of } from 'rxjs';
import { RouterLink } from '@angular/router';
import { SellerApiService } from '../services/seller-api.service';
import {
  InventoryItem,
  SellerBalance,
  SellerEarning,
  SellerOrder,
  SellerPayout,
  SellerProduct,
  SellerProfile
} from '../models/seller.model';
import { MoneyPipe } from '../../shared/pipes/money.pipe';
import { StatusBadgeComponent } from '../../shared/components/status-badge/status-badge.component';
import { EmptyStateComponent } from '../../shared/components/empty-state/empty-state.component';
import { ToastComponent } from '../../shared/components/toast/toast.component';

@Component({
  selector: 'app-seller-dashboard',
  standalone: true,
  imports: [CommonModule, RouterLink, MoneyPipe, StatusBadgeComponent, EmptyStateComponent, ToastComponent],
  template: `
    <section class="dashboard-header">
      <div>
        <span class="eyebrow">Seller</span>
        <h1>Dashboard</h1>
        <p>Business status, catalog approvals, inventory health, orders, earnings, and payouts.</p>
      </div>
      <button (click)="load()">Refresh</button>
    </section>

    <app-toast [message]="message()"></app-toast>

    <section class="surface dashboard-panel seller-approval-card" *ngIf="profile() as seller">
      <div>
        <span class="eyebrow">Profile status</span>
        <h2>{{ seller.businessName }}</h2>
        <p>{{ statusMessage(seller.status) }}</p>
      </div>
      <app-status-badge kind="seller" [status]="seller.status"></app-status-badge>
    </section>

    <section class="quick-actions seller-actions">
      <a class="surface quick-action" routerLink="/seller/apply">
        <span>Onboarding</span>
        <strong>Application</strong>
        <p>Submit or check your seller approval status.</p>
      </a>
      <a class="surface quick-action" routerLink="/seller/products/new">
        <span>Catalog</span>
        <strong>Submit product</strong>
        <p>Add products for admin approval.</p>
      </a>
      <a class="surface quick-action" routerLink="/seller/inventory">
        <span>Stock</span>
        <strong>Inventory</strong>
        <p>Monitor available, reserved, and low-stock products.</p>
      </a>
      <a class="surface quick-action" routerLink="/seller/payouts">
        <span>Finance</span>
        <strong>Request payout</strong>
        <p>Review balances and payout history.</p>
      </a>
    </section>

    <section class="metric-grid">
      <article class="metric-card"><span>Profile status</span><strong>{{ profile()?.status || 'Missing' }}</strong></article>
      <article class="metric-card"><span>Total products</span><strong>{{ products().length }}</strong></article>
      <article class="metric-card"><span>Pending products</span><strong>{{ productCount('pending') }}</strong></article>
      <article class="metric-card"><span>Approved products</span><strong>{{ productCount('approved') }}</strong></article>
      <article class="metric-card"><span>Rejected products</span><strong>{{ productCount('rejected') }}</strong></article>
      <article class="metric-card"><span>Total orders</span><strong>{{ orders().length }}</strong></article>
      <article class="metric-card"><span>Available stock</span><strong>{{ availableStock() }}</strong></article>
      <article class="metric-card"><span>Low stock</span><strong>{{ lowStockCount() }}</strong></article>
      <article class="metric-card"><span>Available balance</span><strong>{{ (balance()?.availableBalance || 0) | money }}</strong></article>
      <article class="metric-card"><span>Pending earnings</span><strong>{{ (balance()?.pendingEarnings || 0) | money }}</strong></article>
    </section>

    <section class="dashboard-grid">
      <article class="surface dashboard-panel">
        <h2>Recent product submissions</h2>
        <table *ngIf="products().length">
          <tr><th>Product</th><th>Status</th><th>Price</th></tr>
          <tr *ngFor="let product of products().slice(0, 6)">
            <td>{{ product.name }}</td>
            <td><app-status-badge kind="product" [status]="product.status"></app-status-badge></td>
            <td>{{ product.price | money:product.currency }}</td>
          </tr>
        </table>
        <app-empty-state *ngIf="!products().length" title="No products yet" message="Submit a product so admin can review it for the storefront."></app-empty-state>
      </article>

      <article class="surface dashboard-panel">
        <h2>Recent orders</h2>
        <table *ngIf="orders().length">
          <tr><th>Order</th><th>Status</th><th>Product</th><th>Line total</th></tr>
          <tr *ngFor="let order of orders().slice(0, 6)">
            <td>{{ order.orderNumber }}</td>
            <td><app-status-badge kind="order" [status]="order.status"></app-status-badge></td>
            <td>{{ order.productName }}</td>
            <td>{{ order.lineTotal | money }}</td>
          </tr>
        </table>
        <app-empty-state *ngIf="!orders().length" title="No seller orders yet" message="Orders appear here after customers buy your approved products."></app-empty-state>
      </article>

      <article class="surface dashboard-panel">
        <h2>Inventory alerts</h2>
        <table *ngIf="inventory().length">
          <tr><th>SKU</th><th>Available</th><th>Reserved</th></tr>
          <tr *ngFor="let item of lowStockItems().slice(0, 6)">
            <td>{{ item.sku }}</td>
            <td>{{ item.availableQuantity }}</td>
            <td>{{ item.reservedQuantity }}</td>
          </tr>
        </table>
        <app-empty-state *ngIf="!inventory().length" title="No inventory yet" message="Inventory appears after approved products are stocked."></app-empty-state>
      </article>

      <article class="surface dashboard-panel">
        <h2>Recent payouts</h2>
        <table *ngIf="payouts().length">
          <tr><th>Reference</th><th>Amount</th><th>Status</th></tr>
          <tr *ngFor="let payout of payouts().slice(0, 6)">
            <td>{{ payout.referenceNumber }}</td>
            <td>{{ payout.amount | money }}</td>
            <td><app-status-badge [status]="payout.status"></app-status-badge></td>
          </tr>
        </table>
        <app-empty-state *ngIf="!payouts().length" title="No payouts yet" message="Request a payout after earnings become available."></app-empty-state>
      </article>
    </section>
  `
})
export class SellerDashboardComponent implements OnInit {
  readonly profile = signal<SellerProfile | null>(null);
  readonly products = signal<SellerProduct[]>([]);
  readonly inventory = signal<InventoryItem[]>([]);
  readonly orders = signal<SellerOrder[]>([]);
  readonly earnings = signal<SellerEarning[]>([]);
  readonly payouts = signal<SellerPayout[]>([]);
  readonly balance = signal<SellerBalance | null>(null);
  readonly message = signal('');

  constructor(private readonly api: SellerApiService) {}

  ngOnInit(): void {
    this.load();
  }

  load(): void {
    this.message.set('');
    this.api.getProfile().subscribe({
      next: (profile) => {
        this.profile.set(profile);
        forkJoin({
          products: this.api.getProducts(profile.id).pipe(catchError(() => of([]))),
          inventory: this.api.getInventory(profile.id).pipe(catchError(() => of([]))),
          orders: this.api.getOrders(profile.id).pipe(catchError(() => of([]))),
          earnings: this.api.getEarnings().pipe(catchError(() => of([]))),
          payouts: this.api.getPayouts().pipe(catchError(() => of([]))),
          balance: this.api.getBalance().pipe(catchError(() => of(null)))
        }).subscribe((data) => {
          this.products.set(data.products);
          this.inventory.set(data.inventory);
          this.orders.set(data.orders);
          this.earnings.set(data.earnings);
          this.payouts.set(data.payouts);
          this.balance.set(data.balance);
        });
      },
      error: () => {
        this.profile.set(null);
        this.message.set('Seller profile was not found. Submit your application first.');
      }
    });
  }

  productCount(status: string): number {
    return this.products().filter((product) => this.productStatusText(product.status) === status).length;
  }

  availableStock(): number {
    return this.inventory().reduce((total, item) => total + item.availableQuantity, 0);
  }

  lowStockItems(): InventoryItem[] {
    return this.inventory().filter((item) => item.availableQuantity <= 5);
  }

  lowStockCount(): number {
    return this.lowStockItems().length;
  }

  statusMessage(status: string | number): string {
    const value = this.sellerStatusText(status);
    if (value === 'approved') {
      return 'Admin approved this seller account. You can operate products, orders, inventory, earnings, and payouts.';
    }
    if (value === 'rejected') {
      return 'Admin rejected this seller application. Review your details before continuing.';
    }
    if (value === 'suspended') {
      return 'Admin suspended this seller account. Operational actions should remain paused.';
    }
    return 'Your seller application is pending admin approval.';
  }

  private sellerStatusText(status: string | number): string {
    const value = String(status).toLowerCase();
    return value === '4' ? 'suspended' : value === '3' ? 'rejected' : value === '2' ? 'approved' : value === '1' ? 'pending' : value;
  }

  private productStatusText(status: string | number): string {
    const value = String(status).toLowerCase();
    return value === '4' ? 'disabled' : value === '3' ? 'rejected' : value === '2' ? 'approved' : value === '1' ? 'pending' : value;
  }
}
