import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { SellerApiService } from '../services/seller-api.service';
import { SellerProfile } from '../models/seller.model';
import { ErrorMessageService } from '../../core/services/error-message.service';
import { ToastComponent } from '../../shared/components/toast/toast.component';
import { StatusBadgeComponent } from '../../shared/components/status-badge/status-badge.component';

@Component({
  selector: 'app-seller-apply',
  standalone: true,
  imports: [CommonModule, FormsModule, ToastComponent, StatusBadgeComponent],
  template: `
    <section class="dashboard-header">
      <div>
        <span class="eyebrow">Onboarding</span>
        <h1>Apply as seller</h1>
        <p>Submit your business profile for admin approval.</p>
      </div>
      <button class="ghost-light" (click)="loadProfile()">Check status</button>
    </section>
    <app-toast [message]="message()"></app-toast>

    <section class="surface dashboard-panel seller-approval-card" *ngIf="existingProfile() as seller">
      <div>
        <span class="eyebrow">Current application</span>
        <h2>{{ seller.businessName }}</h2>
        <p>{{ existingProfileMessage(seller.status) }}</p>
      </div>
      <app-status-badge kind="seller" [status]="seller.status"></app-status-badge>
    </section>

    <form class="surface checkout-form seller-form" (ngSubmit)="apply()" *ngIf="!existingProfile()">
      <label>Business name<input [(ngModel)]="businessName" name="businessName" required></label>
      <label>Owner name<input [(ngModel)]="ownerName" name="ownerName" required></label>
      <label>Contact email<input [(ngModel)]="contactEmail" name="contactEmail" type="email" required></label>
      <label>Phone<input [(ngModel)]="phone" name="phone"></label>
      <label>Address<textarea [(ngModel)]="address" name="address" rows="4"></textarea></label>
      <label>GST number<input [(ngModel)]="gstNumber" name="gstNumber"></label>
      <button type="submit" [disabled]="busy()">Submit application</button>
    </form>
  `
})
export class SellerApplyComponent implements OnInit {
  businessName = '';
  ownerName = '';
  contactEmail = '';
  phone = '';
  address = '';
  gstNumber = '';
  readonly busy = signal(false);
  readonly message = signal('');
  readonly existingProfile = signal<SellerProfile | null>(null);

  constructor(private readonly api: SellerApiService, private readonly errors: ErrorMessageService, private readonly router: Router) {}

  ngOnInit(): void {
    this.loadProfile();
  }

  loadProfile(): void {
    this.api.getProfile().subscribe({
      next: (profile) => this.existingProfile.set(profile),
      error: () => this.existingProfile.set(null)
    });
  }

  apply(): void {
    this.busy.set(true);
    this.api.apply({
      businessName: this.businessName,
      ownerName: this.ownerName,
      contactEmail: this.contactEmail,
      phone: this.phone,
      address: this.address,
      gstNumber: this.gstNumber || null
    }).subscribe({
      next: () => void this.router.navigateByUrl('/seller/profile'),
      error: (error) => { this.busy.set(false); this.message.set(this.errors.from(error)); }
    });
  }

  existingProfileMessage(status: string | number): string {
    const value = this.statusText(status);
    if (value === 'approved') {
      return 'Admin approved your seller account. You can now operate from the seller dashboard.';
    }
    if (value === 'rejected') {
      return 'Admin rejected this seller application. Contact support or admin before submitting another profile.';
    }
    if (value === 'suspended') {
      return 'This seller account is suspended. Marketplace actions are paused until admin reactivates it.';
    }
    return 'Your seller application is waiting for admin approval.';
  }

  private statusText(status: string | number): string {
    const value = String(status).toLowerCase();
    return value === '4' ? 'suspended' : value === '3' ? 'rejected' : value === '2' ? 'approved' : value === '1' ? 'pending' : value;
  }
}
