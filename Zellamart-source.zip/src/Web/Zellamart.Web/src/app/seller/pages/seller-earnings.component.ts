import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { catchError, forkJoin, of } from 'rxjs';
import { SellerApiService } from '../services/seller-api.service';
import { FinanceTransaction, SellerBalance, SellerEarning, SellerProduct } from '../models/seller.model';
import { MoneyPipe } from '../../shared/pipes/money.pipe';
import { StatusBadgeComponent } from '../../shared/components/status-badge/status-badge.component';
import { EmptyStateComponent } from '../../shared/components/empty-state/empty-state.component';

@Component({
  selector: 'app-seller-earnings',
  standalone: true,
  imports: [CommonModule, FormsModule, MoneyPipe, StatusBadgeComponent, EmptyStateComponent],
  template: `
    <section class="dashboard-header">
      <div>
        <span class="eyebrow">Finance</span>
        <h1>Earnings</h1>
        <p>Available balance, pending earnings, paid out totals, refund deductions, adjustments, and transactions.</p>
      </div>
      <button (click)="load()">Refresh</button>
    </section>

    <section class="metric-grid">
      <article class="metric-card"><span>Available balance</span><strong>{{ (balance()?.availableBalance || 0) | money }}</strong></article>
      <article class="metric-card"><span>Pending earnings</span><strong>{{ (balance()?.pendingEarnings || 0) | money }}</strong></article>
      <article class="metric-card"><span>Total paid out</span><strong>{{ (balance()?.totalPaidOut || 0) | money }}</strong></article>
      <article class="metric-card"><span>Refund deductions</span><strong>{{ (balance()?.refundDeductions || 0) | money }}</strong></article>
      <article class="metric-card"><span>Adjustments</span><strong>{{ (balance()?.adjustmentBalance || 0) | money }}</strong></article>
    </section>

    <section class="surface dashboard-panel">
      <div class="seller-toolbar users-toolbar">
        <label>Search<input [(ngModel)]="search" placeholder="Order, product, status"></label>
        <label>Status
          <select [(ngModel)]="statusFilter">
            <option value="all">All statuses</option>
            <option *ngFor="let status of earningStatusOptions()" [value]="status">{{ status }}</option>
          </select>
        </label>
      </div>

      <h2>Earnings table</h2>
      <table *ngIf="filteredEarnings().length">
        <tr><th>Order</th><th>Product</th><th>Gross</th><th>Commission</th><th>Net</th><th>Status</th><th>Created</th></tr>
        <tr *ngFor="let item of filteredEarnings()">
          <td>{{ item.orderId }}</td>
          <td>{{ productName(item.productId) }}</td>
          <td>{{ item.grossAmount | money }}</td>
          <td>{{ item.commissionAmount | money }}</td>
          <td>{{ item.netAmount | money }}</td>
          <td><app-status-badge kind="earning" [status]="item.status"></app-status-badge></td>
          <td>{{ item.createdAtUtc | date:'medium' }}</td>
        </tr>
      </table>
      <app-empty-state *ngIf="!filteredEarnings().length" title="No earnings found" message="Delivered orders create seller earnings."></app-empty-state>
    </section>

    <section class="surface dashboard-panel">
      <h2>Finance transactions</h2>
      <table *ngIf="transactions().length">
        <tr><th>Type</th><th>Amount</th><th>Description</th><th>Reference</th><th>Created</th></tr>
        <tr *ngFor="let tx of transactions()">
          <td><app-status-badge kind="transaction" [status]="tx.type"></app-status-badge></td>
          <td>{{ tx.amount | money }}</td>
          <td>{{ tx.description }}</td>
          <td>{{ tx.referenceId || '-' }}</td>
          <td>{{ tx.createdAtUtc | date:'medium' }}</td>
        </tr>
      </table>
      <app-empty-state *ngIf="!transactions().length" title="No transactions yet" message="Earnings, commissions, payouts, and refunds will appear here."></app-empty-state>
    </section>
  `
})
export class SellerEarningsComponent implements OnInit {
  readonly balance = signal<SellerBalance | null>(null);
  readonly earnings = signal<SellerEarning[]>([]);
  readonly transactions = signal<FinanceTransaction[]>([]);
  readonly products = signal<SellerProduct[]>([]);
  search = '';
  statusFilter = 'all';

  constructor(private readonly api: SellerApiService) {}

  ngOnInit(): void {
    this.load();
  }

  load(): void {
    this.api.getProfile().subscribe((profile) => {
      forkJoin({
        balance: this.api.getBalance().pipe(catchError(() => of(null))),
        earnings: this.api.getEarnings().pipe(catchError(() => of([]))),
        transactions: this.api.getTransactions().pipe(catchError(() => of([]))),
        products: this.api.getProducts(profile.id).pipe(catchError(() => of([])))
      }).subscribe((data) => {
        this.balance.set(data.balance);
        this.earnings.set(data.earnings);
        this.transactions.set(data.transactions);
        this.products.set(data.products);
      });
    });
  }

  filteredEarnings(): SellerEarning[] {
    const term = this.search.trim().toLowerCase();
    return this.earnings().filter((item) => {
      const statusMatches = this.statusFilter === 'all' || String(item.status) === this.statusFilter;
      const searchable = [item.orderId, item.productId, item.status, this.productName(item.productId)].join(' ').toLowerCase();
      return statusMatches && (!term || searchable.includes(term));
    });
  }

  earningStatusOptions(): string[] {
    return Array.from(new Set(this.earnings().map((item) => String(item.status)))).sort();
  }

  productName(productId: string): string {
    return this.products().find((product) => product.id === productId)?.name ?? productId;
  }
}
