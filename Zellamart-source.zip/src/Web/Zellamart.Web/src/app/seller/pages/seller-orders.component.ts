import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { SellerApiService } from '../services/seller-api.service';
import { SellerOrder, SellerProfile } from '../models/seller.model';
import { MoneyPipe } from '../../shared/pipes/money.pipe';
import { StatusBadgeComponent } from '../../shared/components/status-badge/status-badge.component';
import { EmptyStateComponent } from '../../shared/components/empty-state/empty-state.component';
import { ToastComponent } from '../../shared/components/toast/toast.component';

@Component({
  selector: 'app-seller-orders',
  standalone: true,
  imports: [CommonModule, FormsModule, MoneyPipe, StatusBadgeComponent, EmptyStateComponent, ToastComponent],
  template: `
    <section class="dashboard-header">
      <div>
        <span class="eyebrow">Sales</span>
        <h1>Seller orders</h1>
        <p>Orders containing your products, filtered to your seller-owned line items.</p>
      </div>
      <button (click)="load()">Refresh</button>
    </section>

    <app-toast [message]="message()"></app-toast>

    <section class="metric-grid">
      <article class="metric-card"><span>Order items</span><strong>{{ orders().length }}</strong></article>
      <article class="metric-card"><span>Unique orders</span><strong>{{ uniqueOrderCount() }}</strong></article>
      <article class="metric-card"><span>Units sold</span><strong>{{ totalUnits() }}</strong></article>
      <article class="metric-card"><span>Seller item total</span><strong>{{ itemTotal() | money }}</strong></article>
    </section>

    <section class="seller-admin-grid">
      <section class="surface dashboard-panel">
        <div class="seller-toolbar users-toolbar">
          <label>Search<input [(ngModel)]="search" placeholder="Order, product, customer"></label>
          <label>Status
            <select [(ngModel)]="statusFilter">
              <option value="all">All statuses</option>
              <option *ngFor="let status of statusOptions()" [value]="status">{{ statusLabel(status) }}</option>
            </select>
          </label>
        </div>

        <table *ngIf="filteredOrders().length">
          <tr><th>Order</th><th>Status</th><th>Product</th><th>Qty</th><th>Line total</th><th>Created</th></tr>
          <tr *ngFor="let order of filteredOrders()" [class.selected-row]="selectedOrder()?.orderItemId === order.orderItemId">
            <td><button class="table-link" (click)="selectOrder(order)">{{ order.orderNumber }}</button></td>
            <td><app-status-badge kind="order" [status]="order.status"></app-status-badge></td>
            <td>{{ order.productName }}</td>
            <td>{{ order.quantity }}</td>
            <td>{{ order.lineTotal | money }}</td>
            <td>{{ order.createdAtUtc | date:'medium' }}</td>
          </tr>
        </table>

        <app-empty-state *ngIf="!filteredOrders().length" title="No seller orders found" message="Customer purchases of your approved products will appear here."></app-empty-state>
      </section>

      <aside class="surface seller-detail-pane" *ngIf="selectedOrder() as order">
        <div class="seller-detail-heading">
          <span class="eyebrow">Order detail</span>
          <h2>{{ order.orderNumber }}</h2>
          <p class="muted-line">Customer {{ order.customerId }}</p>
        </div>

        <div class="seller-detail-grid">
          <div><span>Order status</span><strong><app-status-badge kind="order" [status]="order.status"></app-status-badge></strong></div>
          <div><span>Payment status</span><strong>{{ paymentStatus(order.status) }}</strong></div>
          <div><span>Shipping status</span><strong>{{ shippingStatus(order.status) }}</strong></div>
          <div><span>Product</span><strong>{{ order.productName }}</strong></div>
          <div><span>Quantity</span><strong>{{ order.quantity }}</strong></div>
          <div><span>Unit price</span><strong>{{ order.unitPrice | money }}</strong></div>
          <div><span>Line total</span><strong>{{ order.lineTotal | money }}</strong></div>
          <div><span>Order item ID</span><strong>{{ order.orderItemId }}</strong></div>
        </div>
      </aside>
    </section>
  `
})
export class SellerOrdersComponent implements OnInit {
  readonly profile = signal<SellerProfile | null>(null);
  readonly orders = signal<SellerOrder[]>([]);
  readonly selectedOrder = signal<SellerOrder | null>(null);
  readonly message = signal('');
  search = '';
  statusFilter = 'all';

  constructor(private readonly api: SellerApiService) {}

  ngOnInit(): void {
    this.load();
  }

  load(): void {
    this.api.getProfile().subscribe({
      next: (profile) => {
        this.profile.set(profile);
        if (!this.isApproved()) {
          this.message.set('Seller must be approved before order operations are available.');
        }
        this.api.getOrders(profile.id).subscribe({
          next: (orders) => {
            this.orders.set(orders);
            this.selectedOrder.set(orders[0] ?? null);
          },
          error: () => this.message.set('Could not load seller orders.')
        });
      },
      error: () => this.message.set('Seller profile was not found.')
    });
  }

  filteredOrders(): SellerOrder[] {
    const term = this.search.trim().toLowerCase();
    return this.orders().filter((order) => {
      const statusMatches = this.statusFilter === 'all' || String(order.status) === this.statusFilter;
      const searchable = [order.orderNumber, order.customerId, order.productName, order.productId, order.status].join(' ').toLowerCase();
      return statusMatches && (!term || searchable.includes(term));
    });
  }

  selectOrder(order: SellerOrder): void {
    this.selectedOrder.set(order);
  }

  statusOptions(): string[] {
    return Array.from(new Set(this.orders().map((order) => String(order.status)))).sort();
  }

  uniqueOrderCount(): number {
    return new Set(this.orders().map((order) => order.orderId)).size;
  }

  totalUnits(): number {
    return this.orders().reduce((total, order) => total + order.quantity, 0);
  }

  itemTotal(): number {
    return this.orders().reduce((total, order) => total + order.lineTotal, 0);
  }

  paymentStatus(status: string | number): string {
    const value = String(status).toLowerCase();
    return ['paymentsucceeded', 'confirmed', 'delivered', 'packed', 'shipped', 'refunded', '2', '4', '6', '7', '8', '9'].includes(value)
      ? 'Paid'
      : value === 'paymentfailed' || value === '3'
        ? 'Failed'
        : 'Pending';
  }

  shippingStatus(status: string | number): string {
    const value = String(status).toLowerCase();
    if (['delivered', '6'].includes(value)) {
      return 'Delivered';
    }
    if (['shipped', '8'].includes(value)) {
      return 'Shipped';
    }
    if (['packed', '7'].includes(value)) {
      return 'Packed';
    }
    return ['confirmed', '4'].includes(value) ? 'Ready for operations' : 'Not started';
  }

  statusLabel(status: string): string {
    const labels: Record<string, string> = {
      '1': 'Pending payment',
      '2': 'Payment succeeded',
      '3': 'Payment failed',
      '4': 'Confirmed',
      '5': 'Cancelled',
      '6': 'Delivered',
      '7': 'Packed',
      '8': 'Shipped',
      '9': 'Refunded'
    };
    return labels[status] ?? status;
  }

  isApproved(): boolean {
    return this.statusText(this.profile()?.status ?? '') === 'approved';
  }

  private statusText(status: string | number): string {
    const value = String(status).toLowerCase();
    return value === '4' ? 'suspended' : value === '3' ? 'rejected' : value === '2' ? 'approved' : value === '1' ? 'pending' : value;
  }
}
