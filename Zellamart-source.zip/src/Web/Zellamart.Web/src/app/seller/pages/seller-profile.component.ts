import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { SellerApiService } from '../services/seller-api.service';
import { SellerProfile } from '../models/seller.model';
import { AuthService } from '../../core/services/auth.service';
import { StatusBadgeComponent } from '../../shared/components/status-badge/status-badge.component';
import { ToastComponent } from '../../shared/components/toast/toast.component';
import { EmptyStateComponent } from '../../shared/components/empty-state/empty-state.component';
import { WorkspaceSwitcherComponent } from '../../shared/components/workspace-switcher/workspace-switcher.component';

@Component({
  selector: 'app-seller-profile',
  standalone: true,
  imports: [CommonModule, RouterLink, StatusBadgeComponent, ToastComponent, EmptyStateComponent, WorkspaceSwitcherComponent],
  template: `
    <section class="dashboard-header">
      <div>
        <span class="eyebrow">Profile</span>
        <h1>Seller profile</h1>
        <p>Your seller onboarding status and business information.</p>
      </div>
      <button (click)="load()">Refresh</button>
    </section>
    <app-toast [message]="message()"></app-toast>

    <app-workspace-switcher></app-workspace-switcher>

    <section class="surface dashboard-panel seller-approval-card" *ngIf="profile() as p">
      <div>
        <span class="eyebrow">Admin approval</span>
        <h2>{{ statusHeadline(p.status) }}</h2>
        <p>{{ statusMessage(p.status) }}</p>
      </div>
      <app-status-badge kind="seller" [status]="p.status"></app-status-badge>
    </section>

    <section class="surface profile-card" *ngIf="profile() as p">
      <div><span>Status</span><strong><app-status-badge kind="seller" [status]="p.status"></app-status-badge></strong></div>
      <div><span>Business name</span><strong>{{ p.businessName }}</strong></div>
      <div><span>Owner name</span><strong>{{ p.ownerName }}</strong></div>
      <div><span>Contact email</span><strong>{{ p.contactEmail }}</strong></div>
      <div><span>Phone</span><strong>{{ p.phone || 'Not provided' }}</strong></div>
      <div><span>GST number</span><strong>{{ p.gstNumber || 'Not provided' }}</strong></div>
      <div><span>Address</span><p>{{ p.address || 'Not provided' }}</p></div>
      <div><span>Seller ID</span><strong>{{ p.id }}</strong></div>
      <div><span>User ID</span><strong>{{ p.userId }}</strong></div>
    </section>

    <app-empty-state
      *ngIf="!profile()"
      title="No seller profile"
      message="Submit your seller application so admin can approve your marketplace access.">
    </app-empty-state>
  `
})
export class SellerProfileComponent implements OnInit {
  readonly profile = signal<SellerProfile | null>(null);
  readonly message = signal('');
  constructor(
    private readonly api: SellerApiService,
    readonly auth: AuthService
  ) {}
  ngOnInit(): void { this.load(); }

  load(): void {
    this.api.getProfile().subscribe({
      next: (p) => {
        this.profile.set(p);
        this.message.set('');
      },
      error: () => {
        this.profile.set(null);
        this.message.set('Seller profile was not found.');
      }
    });
  }

  statusHeadline(status: string | number): string {
    const value = this.statusText(status);
    if (value === 'approved') {
      return 'Approved seller account';
    }
    if (value === 'rejected') {
      return 'Application rejected';
    }
    if (value === 'suspended') {
      return 'Seller account suspended';
    }
    return 'Application pending';
  }

  statusMessage(status: string | number): string {
    const value = this.statusText(status);
    if (value === 'approved') {
      return 'Admin approved this profile. Products, inventory, orders, earnings, and payouts can now be managed.';
    }
    if (value === 'rejected') {
      return 'Admin rejected this profile. Review the business details and contact support before retrying.';
    }
    if (value === 'suspended') {
      return 'Admin suspended this seller account. Operational actions should remain paused until reactivation.';
    }
    return 'Admin has not approved this profile yet. Product and payout work should wait until approval.';
  }

  private statusText(status: string | number): string {
    const value = String(status).toLowerCase();
    return value === '4' ? 'suspended' : value === '3' ? 'rejected' : value === '2' ? 'approved' : value === '1' ? 'pending' : value;
  }
}
