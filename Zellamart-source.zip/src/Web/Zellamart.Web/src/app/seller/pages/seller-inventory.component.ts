import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { catchError, forkJoin, of } from 'rxjs';
import { SellerApiService } from '../services/seller-api.service';
import { InventoryItem, SellerProduct, SellerProfile, SellerStockMovement } from '../models/seller.model';
import { ErrorMessageService } from '../../core/services/error-message.service';
import { EmptyStateComponent } from '../../shared/components/empty-state/empty-state.component';
import { ToastComponent } from '../../shared/components/toast/toast.component';

@Component({
  selector: 'app-seller-inventory',
  standalone: true,
  imports: [CommonModule, FormsModule, EmptyStateComponent, ToastComponent],
  template: `
    <section class="dashboard-header">
      <div>
        <span class="eyebrow">Stock</span>
        <h1>Inventory</h1>
        <p>View product stock, low-stock alerts, available/reserved/on-hand quantities, and movement history.</p>
      </div>
      <button (click)="load()">Refresh</button>
    </section>

    <app-toast [message]="message()"></app-toast>

    <section class="metric-grid">
      <article class="metric-card"><span>Stock records</span><strong>{{ items().length }}</strong></article>
      <article class="metric-card"><span>Available units</span><strong>{{ availableUnits() }}</strong></article>
      <article class="metric-card"><span>Reserved units</span><strong>{{ reservedUnits() }}</strong></article>
      <article class="metric-card"><span>Low stock</span><strong>{{ lowStockItems().length }}</strong></article>
      <article class="metric-card"><span>Out of stock</span><strong>{{ outOfStockItems().length }}</strong></article>
    </section>

    <section class="seller-admin-grid">
      <section class="surface dashboard-panel">
        <div class="seller-toolbar users-toolbar">
          <label>Search<input [(ngModel)]="search" placeholder="SKU, product, ID"></label>
          <label>Stock view
            <select [(ngModel)]="stockFilter">
              <option value="all">All stock</option>
              <option value="low">Low stock</option>
              <option value="out">Out of stock</option>
            </select>
          </label>
          <label>Low threshold<input [(ngModel)]="lowThreshold" type="number" min="1"></label>
        </div>

        <table *ngIf="filteredItems().length">
          <tr><th>Product</th><th>SKU</th><th>On hand</th><th>Reserved</th><th>Available</th><th>Status</th></tr>
          <tr *ngFor="let item of filteredItems()" [class.selected-row]="selectedItem()?.id === item.id" [class.warning-row]="isLowStock(item)" [class.danger-row]="isOutOfStock(item)">
            <td><button class="table-link" (click)="selectItem(item)">{{ productName(item.productId) }}</button></td>
            <td>{{ item.sku }}</td>
            <td>{{ item.quantityOnHand }}</td>
            <td>{{ item.reservedQuantity }}</td>
            <td><strong>{{ item.availableQuantity }}</strong></td>
            <td>{{ stockStatus(item) }}</td>
          </tr>
        </table>

        <app-empty-state *ngIf="!filteredItems().length" title="No inventory records" message="Inventory appears after admin creates stock for approved products."></app-empty-state>
      </section>

      <aside class="surface seller-detail-pane" *ngIf="selectedItem() as item">
        <div class="seller-detail-heading">
          <span class="eyebrow">Stock detail</span>
          <h2>{{ productName(item.productId) }}</h2>
          <p class="muted-line">{{ item.sku }}</p>
        </div>

        <div class="seller-detail-grid">
          <div><span>On hand</span><strong>{{ item.quantityOnHand }}</strong></div>
          <div><span>Reserved</span><strong>{{ item.reservedQuantity }}</strong></div>
          <div><span>Available</span><strong>{{ item.availableQuantity }}</strong></div>
          <div><span>Status</span><strong>{{ stockStatus(item) }}</strong></div>
          <div><span>Inventory ID</span><strong>{{ item.id }}</strong></div>
          <div><span>Product ID</span><strong>{{ item.productId }}</strong></div>
        </div>

        <form class="stock-update-form" (ngSubmit)="addStock(item.id)" *ngIf="isApproved()">
          <h3>Add stock manually</h3>
          <label>Quantity<input [(ngModel)]="stockQuantity" name="stockQuantity" type="number" min="1" required></label>
          <label>Reason<input [(ngModel)]="stockReason" name="stockReason"></label>
          <button type="submit">Add stock</button>
        </form>

        <form class="stock-update-form" (ngSubmit)="setStock(item.id)" *ngIf="isApproved()">
          <h3>Set stock count</h3>
          <label>On-hand count<input [(ngModel)]="setQuantityOnHand" name="setQuantityOnHand" type="number" [min]="item.reservedQuantity" required></label>
          <label>Reason<input [(ngModel)]="setStockReason" name="setStockReason"></label>
          <button type="submit">Set stock count</button>
          <p class="muted-line">Count cannot be lower than reserved stock: {{ item.reservedQuantity }}.</p>
        </form>

        <p class="muted-line" *ngIf="!isApproved()">Stock updates are available only after seller approval.</p>

        <section>
          <h3>Movement history</h3>
          <table *ngIf="movements().length">
            <tr><th>Type</th><th>Change</th><th>After</th><th>Reason</th><th>Changed</th></tr>
            <tr *ngFor="let movement of movements()">
              <td>{{ movementTypeLabel(movement.type) }}</td>
              <td>{{ movement.quantityChange }}</td>
              <td>{{ movement.quantityAfter }}</td>
              <td>{{ movement.reason }}</td>
              <td>{{ movement.changedAtUtc | date:'medium' }}</td>
            </tr>
          </table>
          <app-empty-state *ngIf="!movements().length" title="No movements" message="Stock changes will appear here."></app-empty-state>
        </section>
      </aside>
    </section>
  `
})
export class SellerInventoryComponent implements OnInit {
  search = '';
  stockFilter = 'all';
  lowThreshold = 5;
  stockQuantity = 10;
  stockReason = 'Manual stock update by seller.';
  setQuantityOnHand = 0;
  setStockReason = 'Stock count adjusted by seller.';
  readonly profile = signal<SellerProfile | null>(null);
  readonly items = signal<InventoryItem[]>([]);
  readonly products = signal<SellerProduct[]>([]);
  readonly selectedItem = signal<InventoryItem | null>(null);
  readonly movements = signal<SellerStockMovement[]>([]);
  readonly message = signal('');

  constructor(private readonly api: SellerApiService, private readonly errors: ErrorMessageService) {}

  ngOnInit(): void {
    this.load();
  }

  load(): void {
    this.api.getProfile().subscribe({
      next: (profile) => {
        this.profile.set(profile);
        forkJoin({
          items: this.api.getInventory(profile.id).pipe(catchError(() => of([]))),
          products: this.api.getProducts(profile.id).pipe(catchError(() => of([])))
        }).subscribe(({ items, products }) => {
          this.items.set(items);
          this.products.set(products);
          this.selectItem(items.find((item) => item.id === this.selectedItem()?.id) ?? items[0] ?? null);
        });
      },
      error: (error) => this.message.set(this.errors.from(error))
    });
  }

  filteredItems(): InventoryItem[] {
    const term = this.search.trim().toLowerCase();
    return this.items().filter((item) => {
      const stockMatches =
        this.stockFilter === 'all' ||
        (this.stockFilter === 'low' && this.isLowStock(item)) ||
        (this.stockFilter === 'out' && this.isOutOfStock(item));
      const searchable = [item.sku, item.productId, this.productName(item.productId)].join(' ').toLowerCase();
      return stockMatches && (!term || searchable.includes(term));
    });
  }

  selectItem(item: InventoryItem | null): void {
    this.selectedItem.set(item);
    this.movements.set([]);
    if (!item) {
      return;
    }

    this.setQuantityOnHand = item.quantityOnHand;

    this.api.stockMovements(item.id).subscribe({
      next: (movements) => this.movements.set(movements),
      error: (error) => this.message.set(this.errors.from(error))
    });
  }

  addStock(inventoryItemId: string): void {
    if (!this.isApproved()) {
      this.message.set('Seller must be approved before updating stock.');
      return;
    }

    this.api.addStock(inventoryItemId, Number(this.stockQuantity), this.stockReason || 'Manual stock update by seller.').subscribe({
      next: () => {
        this.message.set('Stock updated.');
        this.load();
      },
      error: (error) => this.message.set(this.errors.from(error))
    });
  }

  setStock(inventoryItemId: string): void {
    if (!this.isApproved()) {
      this.message.set('Seller must be approved before updating stock.');
      return;
    }

    this.api.setStock(inventoryItemId, Number(this.setQuantityOnHand), this.setStockReason || 'Stock count adjusted by seller.').subscribe({
      next: () => {
        this.message.set('Stock count updated.');
        this.load();
      },
      error: (error) => this.message.set(this.errors.from(error))
    });
  }

  availableUnits(): number {
    return this.items().reduce((total, item) => total + item.availableQuantity, 0);
  }

  reservedUnits(): number {
    return this.items().reduce((total, item) => total + item.reservedQuantity, 0);
  }

  lowStockItems(): InventoryItem[] {
    return this.items().filter((item) => this.isLowStock(item));
  }

  outOfStockItems(): InventoryItem[] {
    return this.items().filter((item) => this.isOutOfStock(item));
  }

  isLowStock(item: InventoryItem): boolean {
    return item.availableQuantity > 0 && item.availableQuantity <= Number(this.lowThreshold || 5);
  }

  isOutOfStock(item: InventoryItem): boolean {
    return item.availableQuantity <= 0;
  }

  stockStatus(item: InventoryItem): string {
    if (this.isOutOfStock(item)) {
      return 'Out of stock';
    }
    return this.isLowStock(item) ? 'Low stock' : 'Healthy';
  }

  productName(productId: string): string {
    return this.products().find((product) => product.id === productId)?.name ?? productId;
  }

  movementTypeLabel(type: string | number): string {
    const map: Record<string, string> = {
      '1': 'Inventory created',
      InventoryCreated: 'Inventory created',
      '2': 'Stock added',
      StockAdded: 'Stock added',
      '3': 'Stock adjusted',
      StockAdjusted: 'Stock adjusted',
      '4': 'Stock reserved',
      StockReserved: 'Stock reserved',
      '5': 'Stock released',
      StockReleased: 'Stock released',
      '6': 'Stock deducted',
      StockDeducted: 'Stock deducted'
    };
    return map[String(type)] ?? String(type);
  }

  isApproved(): boolean {
    return this.statusText(this.profile()?.status ?? '') === 'approved';
  }

  private statusText(status: string | number): string {
    const value = String(status).toLowerCase();
    return value === '4' ? 'suspended' : value === '3' ? 'rejected' : value === '2' ? 'approved' : value === '1' ? 'pending' : value;
  }
}
