import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SellerApiService } from '../services/seller-api.service';
import { SellerBalance, SellerPayout, SellerProfile } from '../models/seller.model';
import { MoneyPipe } from '../../shared/pipes/money.pipe';
import { StatusBadgeComponent } from '../../shared/components/status-badge/status-badge.component';
import { ToastComponent } from '../../shared/components/toast/toast.component';
import { EmptyStateComponent } from '../../shared/components/empty-state/empty-state.component';
import { ErrorMessageService } from '../../core/services/error-message.service';

@Component({
  selector: 'app-seller-payouts',
  standalone: true,
  imports: [CommonModule, MoneyPipe, StatusBadgeComponent, ToastComponent, EmptyStateComponent],
  template: `
    <section class="dashboard-header">
      <div>
        <span class="eyebrow">Payouts</span>
        <h1>Payout requests</h1>
        <p>Request available seller earnings payout and track payout status.</p>
      </div>
      <button (click)="requestPayout()" [disabled]="!canRequestPayout() || busy()">
        Request payout
      </button>
    </section>

    <app-toast [message]="message()"></app-toast>

    <section class="metric-grid">
      <article class="metric-card"><span>Available balance</span><strong>{{ (balance()?.availableBalance || 0) | money }}</strong></article>
      <article class="metric-card"><span>Pending earnings</span><strong>{{ (balance()?.pendingEarnings || 0) | money }}</strong></article>
      <article class="metric-card"><span>Total paid out</span><strong>{{ (balance()?.totalPaidOut || 0) | money }}</strong></article>
      <article class="metric-card"><span>Payout records</span><strong>{{ payouts().length }}</strong></article>
    </section>

    <section class="surface dashboard-panel" *ngIf="!canRequestPayout()">
      <p class="muted-line">{{ payoutBlockReason() }}</p>
    </section>

    <section class="surface dashboard-panel">
      <table *ngIf="payouts().length">
        <tr><th>Reference</th><th>Amount</th><th>Status</th><th>Requested</th><th>Paid</th></tr>
        <tr *ngFor="let payout of payouts()">
          <td>{{ payout.referenceNumber }}</td>
          <td>{{ payout.amount | money }}</td>
          <td><app-status-badge kind="payout" [status]="payout.status"></app-status-badge></td>
          <td>{{ payout.requestedAtUtc | date:'medium' }}</td>
          <td>{{ payout.paidAtUtc ? (payout.paidAtUtc | date:'medium') : '-' }}</td>
        </tr>
      </table>
      <app-empty-state *ngIf="!payouts().length" title="No payout requests" message="Request payout after earnings become available."></app-empty-state>
    </section>
  `
})
export class SellerPayoutsComponent implements OnInit {
  readonly profile = signal<SellerProfile | null>(null);
  readonly balance = signal<SellerBalance | null>(null);
  readonly payouts = signal<SellerPayout[]>([]);
  readonly busy = signal(false);
  readonly message = signal('');

  constructor(private readonly api: SellerApiService, private readonly errors: ErrorMessageService) {}

  ngOnInit(): void {
    this.load();
  }

  load(): void {
    this.api.getProfile().subscribe({
      next: (profile) => {
        this.profile.set(profile);
        this.api.getBalance().subscribe({ next: (balance) => this.balance.set(balance), error: () => this.balance.set(null) });
        this.api.getPayouts().subscribe({ next: (payouts) => this.payouts.set(payouts), error: () => this.payouts.set([]) });
      },
      error: (error) => this.message.set(this.errors.from(error))
    });
  }

  requestPayout(): void {
    const sellerId = this.profile()?.id;
    if (!sellerId) {
      this.message.set('Seller profile is required.');
      return;
    }

    if (!this.canRequestPayout()) {
      this.message.set(this.payoutBlockReason());
      return;
    }

    this.busy.set(true);
    this.api.requestPayout(sellerId).subscribe({
      next: () => {
        this.busy.set(false);
        this.message.set('Payout requested.');
        this.load();
      },
      error: (error) => {
        this.busy.set(false);
        this.message.set(this.errors.from(error));
      }
    });
  }

  canRequestPayout(): boolean {
    return this.isApproved() && Number(this.balance()?.availableBalance || 0) > 0;
  }

  payoutBlockReason(): string {
    if (!this.isApproved()) {
      return 'Seller must be approved before requesting payouts.';
    }

    return 'No available balance to request payout.';
  }

  private isApproved(): boolean {
    return this.statusText(this.profile()?.status ?? '') === 'approved';
  }

  private statusText(status: string | number): string {
    const value = String(status).toLowerCase();
    return value === '4' ? 'suspended' : value === '3' ? 'rejected' : value === '2' ? 'approved' : value === '1' ? 'pending' : value;
  }
}
