import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { catchError, forkJoin, of } from 'rxjs';
import { SellerApiService } from '../services/seller-api.service';
import { InventoryItem, SellerProduct, SellerProfile } from '../models/seller.model';
import { Category } from '../../public/models/catalog.model';
import { MoneyPipe } from '../../shared/pipes/money.pipe';
import { StatusBadgeComponent } from '../../shared/components/status-badge/status-badge.component';
import { EmptyStateComponent } from '../../shared/components/empty-state/empty-state.component';
import { ToastComponent } from '../../shared/components/toast/toast.component';

@Component({
  selector: 'app-seller-products',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink, MoneyPipe, StatusBadgeComponent, EmptyStateComponent, ToastComponent],
  template: `
    <section class="dashboard-header">
      <div>
        <span class="eyebrow">Catalog</span>
        <h1>Products</h1>
        <p>Track product approval status, rejection reasons, category, price, and stock summary.</p>
      </div>
      <a class="button-link" routerLink="/seller/products/new">Submit another product</a>
    </section>

    <app-toast [message]="message()"></app-toast>

    <section class="metric-grid">
      <article class="metric-card"><span>Total</span><strong>{{ products().length }}</strong></article>
      <article class="metric-card"><span>Pending</span><strong>{{ countByStatus('pending') }}</strong></article>
      <article class="metric-card"><span>Approved</span><strong>{{ countByStatus('approved') }}</strong></article>
      <article class="metric-card"><span>Rejected</span><strong>{{ countByStatus('rejected') }}</strong></article>
      <article class="metric-card"><span>Disabled</span><strong>{{ countByStatus('disabled') }}</strong></article>
    </section>

    <section class="seller-admin-grid">
      <section class="seller-list-pane">
        <section class="surface dashboard-panel">
          <div class="seller-toolbar product-tracking-toolbar">
            <label>Search<input [(ngModel)]="search" placeholder="Product, category, status, reason"></label>
            <label>Status
              <select [(ngModel)]="statusFilter">
                <option value="all">All statuses</option>
                <option value="pending">Pending</option>
                <option value="approved">Approved</option>
                <option value="rejected">Rejected</option>
                <option value="disabled">Disabled</option>
              </select>
            </label>
          </div>

          <table *ngIf="filteredProducts().length">
            <tr><th>Product</th><th>Category</th><th>Status</th><th>Price</th><th>Stock</th></tr>
            <tr *ngFor="let product of filteredProducts()" [class.selected-row]="selectedProduct()?.id === product.id">
              <td>
                <button class="table-link" (click)="selectProduct(product)">
                  <strong>{{ product.name }}</strong><br>
                  <span class="muted-line">{{ product.id }}</span>
                </button>
              </td>
              <td>{{ categoryName(product.categoryId) }}</td>
              <td><app-status-badge kind="product" [status]="product.status"></app-status-badge></td>
              <td>{{ product.price | money:product.currency }}</td>
              <td>{{ stockFor(product.id)?.availableQuantity ?? 0 }} available</td>
            </tr>
          </table>

          <app-empty-state *ngIf="!filteredProducts().length" title="No products found" message="Try another search or status filter."></app-empty-state>
        </section>
      </section>

      <aside class="surface seller-detail-pane" *ngIf="selectedProduct() as product">
        <div class="seller-detail-heading">
          <span class="eyebrow">Product detail</span>
          <h2>{{ product.name }}</h2>
          <p class="muted-line">{{ product.description }}</p>
        </div>

        <div class="product-detail-media" *ngIf="product.imageUrl; else emptyImage">
          <img [src]="product.imageUrl" [alt]="product.name">
        </div>
        <ng-template #emptyImage>
          <div class="detail-media empty-media">No image URL</div>
        </ng-template>

        <div class="seller-detail-grid">
          <div><span>Status</span><strong><app-status-badge kind="product" [status]="product.status"></app-status-badge></strong></div>
          <div><span>Category</span><strong>{{ categoryName(product.categoryId) }}</strong></div>
          <div><span>Price</span><strong>{{ product.price | money:product.currency }}</strong></div>
          <div><span>Seller ID</span><strong>{{ product.sellerId }}</strong></div>
          <div><span>Product ID</span><strong>{{ product.id }}</strong></div>
          <div><span>Stock</span><strong>{{ stockLabel(product.id) }}</strong></div>
        </div>

        <section class="surface dashboard-panel rejection-panel" *ngIf="product.rejectionReason">
          <span class="eyebrow">{{ isDisabled(product) ? 'Disable reason' : 'Rejection reason' }}</span>
          <p>{{ product.rejectionReason }}</p>
        </section>

        <form class="stock-update-form" (ngSubmit)="saveProduct(product.id)">
          <h3>Edit product details</h3>
          <label>Category
            <select [(ngModel)]="editCategoryId" name="editCategoryId" required>
              <option *ngFor="let category of categories()" [value]="category.id">{{ category.name }}</option>
            </select>
          </label>
          <label>Name<input [(ngModel)]="editName" name="editName" required></label>
          <label>Slug<input [(ngModel)]="editSlug" name="editSlug" placeholder="Auto-generated when empty"></label>
          <label>Description<textarea [(ngModel)]="editDescription" name="editDescription" rows="4" required></textarea></label>
          <label>Price<input [(ngModel)]="editPrice" name="editPrice" type="number" min="1" required></label>
          <label>Currency
            <select [(ngModel)]="editCurrency" name="editCurrency" required>
              <option *ngFor="let item of currencies" [value]="item">{{ item }}</option>
            </select>
          </label>
          <label>Image URL<input [(ngModel)]="editImageUrl" name="editImageUrl"></label>
          <button type="submit" [disabled]="busy()">Save product details</button>
        </form>

        <div class="action-row detail-actions">
          <a class="button-link" routerLink="/seller/products/new">Submit another product</a>
          <a class="button-link ghost-light" routerLink="/seller/inventory">View inventory</a>
        </div>
      </aside>
    </section>
  `
})
export class SellerProductsComponent implements OnInit {
  readonly profile = signal<SellerProfile | null>(null);
  readonly products = signal<SellerProduct[]>([]);
  readonly categories = signal<Category[]>([]);
  readonly inventory = signal<InventoryItem[]>([]);
  readonly selectedProduct = signal<SellerProduct | null>(null);
  readonly message = signal('');
  search = '';
  statusFilter = 'all';
  readonly currencies = ['INR', 'USD', 'EUR', 'GBP', 'AED'];
  readonly busy = signal(false);
  editCategoryId = '';
  editName = '';
  editSlug = '';
  editDescription = '';
  editPrice = 0;
  editCurrency = 'INR';
  editImageUrl = '';

  constructor(private readonly api: SellerApiService) {}

  ngOnInit(): void {
    this.load();
  }

  load(): void {
    this.api.getProfile().subscribe({
      next: (profile) => {
        this.profile.set(profile);
        forkJoin({
          products: this.api.getProducts(profile.id).pipe(catchError(() => of([]))),
          categories: this.api.getCategories().pipe(catchError(() => of([]))),
          inventory: this.api.getInventory(profile.id).pipe(catchError(() => of([])))
        }).subscribe((data) => {
          this.products.set(data.products);
          this.categories.set(data.categories);
          this.inventory.set(data.inventory);
          if (data.products[0]) {
            this.selectProduct(data.products[0]);
          } else {
            this.selectedProduct.set(null);
          }
        });
      },
      error: () => this.message.set('Seller profile was not found. Apply before tracking products.')
    });
  }

  filteredProducts(): SellerProduct[] {
    const term = this.search.trim().toLowerCase();
    return this.products().filter((product) => {
      const statusMatches = this.statusFilter === 'all' || this.statusText(product.status) === this.statusFilter;
      const searchable = [
        product.name,
        product.description,
        product.status,
        product.rejectionReason,
        this.categoryName(product.categoryId)
      ].join(' ').toLowerCase();
      return statusMatches && (!term || searchable.includes(term));
    });
  }

  selectProduct(product: SellerProduct): void {
    this.selectedProduct.set(product);
    this.fillEditForm(product);
  }

  saveProduct(productId: string): void {
    this.busy.set(true);
    this.api.updateProduct(productId, {
      categoryId: this.editCategoryId,
      name: this.editName,
      slug: this.editSlug || null,
      description: this.editDescription,
      price: Number(this.editPrice),
      currency: this.editCurrency || 'INR',
      imageUrl: this.editImageUrl || null
    }).subscribe({
      next: (product) => {
        this.busy.set(false);
        this.message.set('Product details updated.');
        this.products.set(this.products().map((item) => item.id === product.id ? product : item));
        this.selectProduct(product);
      },
      error: () => {
        this.busy.set(false);
        this.message.set('Could not update product details.');
      }
    });
  }

  countByStatus(status: string): number {
    return this.products().filter((product) => this.statusText(product.status) === status).length;
  }

  categoryName(categoryId: string): string {
    return this.categories().find((category) => category.id === categoryId)?.name ?? categoryId;
  }

  stockFor(productId: string): InventoryItem | undefined {
    return this.inventory().find((item) => item.productId === productId);
  }

  stockLabel(productId: string): string {
    const stock = this.stockFor(productId);
    return stock
      ? `${stock.availableQuantity} available, ${stock.reservedQuantity} reserved, ${stock.quantityOnHand} on hand`
      : 'No stock record yet';
  }

  isDisabled(product: SellerProduct): boolean {
    return this.statusText(product.status) === 'disabled';
  }

  private statusText(status: string | number): string {
    const value = String(status).toLowerCase();
    return value === '4' ? 'disabled' : value === '3' ? 'rejected' : value === '2' ? 'approved' : value === '1' ? 'pending' : value;
  }

  private fillEditForm(product: SellerProduct): void {
    this.editCategoryId = product.categoryId;
    this.editName = product.name;
    this.editSlug = product.slug;
    this.editDescription = product.description;
    this.editPrice = product.price;
    this.editCurrency = product.currency;
    this.editImageUrl = product.imageUrl ?? '';
  }
}
