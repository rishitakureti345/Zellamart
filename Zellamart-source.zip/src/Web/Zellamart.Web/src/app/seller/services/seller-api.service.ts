import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { map, Observable } from 'rxjs';
import { ApiResult } from '../../core/models/api-result.model';
import { Category, Product } from '../../public/models/catalog.model';
import {
  FinanceTransaction,
  InventoryItem,
  SellerBalance,
  SellerEarning,
  SellerOrder,
  SellerPayout,
  SellerProfile,
  SellerStockMovement
} from '../models/seller.model';

@Injectable({ providedIn: 'root' })
export class SellerApiService {
  constructor(private readonly http: HttpClient) {}

  getProfile(): Observable<SellerProfile> {
    return this.http.get<ApiResult<SellerProfile>>('/api/sellers/me').pipe(map((result) => result.value));
  }

  apply(request: Omit<SellerProfile, 'id' | 'userId' | 'status'>): Observable<SellerProfile> {
    return this.http.post<ApiResult<SellerProfile>>('/api/sellers/apply', request).pipe(map((result) => result.value));
  }

  getCategories(): Observable<Category[]> {
    return this.http.get<ApiResult<Category[]>>('/api/categories').pipe(map((result) => result.value ?? []));
  }

  submitProduct(request: {
    sellerId?: string;
    categoryId: string;
    name: string;
    slug?: string | null;
    description: string;
    price: number;
    currency: string;
    imageUrl?: string | null;
  }): Observable<Product> {
    return this.http.post<ApiResult<Product>>('/api/products/submit', request).pipe(map((result) => result.value));
  }

  updateProduct(productId: string, request: {
    categoryId: string;
    name: string;
    slug?: string | null;
    description: string;
    price: number;
    currency: string;
    imageUrl?: string | null;
  }): Observable<Product> {
    return this.http.put<ApiResult<Product>>(`/api/products/${productId}`, request).pipe(map((result) => result.value));
  }

  uploadProductImage(file: File): Observable<{ imageUrl: string; fileName: string }> {
    const formData = new FormData();
    formData.append('image', file);
    return this.http.post<ApiResult<{ imageUrl: string; fileName: string }>>('/api/products/images', formData)
      .pipe(map((result) => result.value));
  }

  getProducts(sellerId: string): Observable<Product[]> {
    return this.http.get<ApiResult<Product[]>>(`/api/products/seller/${sellerId}`).pipe(map((result) => result.value ?? []));
  }

  getInventory(sellerId: string): Observable<InventoryItem[]> {
    return this.http.get<ApiResult<InventoryItem[]>>(`/api/inventory/seller/${sellerId}`).pipe(map((result) => result.value ?? []));
  }

  addStock(inventoryItemId: string, quantity: number, reason: string): Observable<InventoryItem> {
    return this.http.post<ApiResult<InventoryItem>>(`/api/inventory/${inventoryItemId}/stock/add`, {
      quantity,
      reason,
      referenceId: null
    }).pipe(map((result) => result.value));
  }

  setStock(inventoryItemId: string, quantityOnHand: number, reason: string): Observable<InventoryItem> {
    return this.http.post<ApiResult<InventoryItem>>(`/api/inventory/${inventoryItemId}/stock/set`, {
      quantityOnHand,
      reason,
      referenceId: null
    }).pipe(map((result) => result.value));
  }

  stockMovements(inventoryItemId: string): Observable<SellerStockMovement[]> {
    return this.http.get<ApiResult<SellerStockMovement[]>>(`/api/inventory/${inventoryItemId}/movements`)
      .pipe(map((result) => result.value ?? []));
  }

  getOrders(sellerId: string): Observable<SellerOrder[]> {
    return this.http.get<ApiResult<SellerOrder[]>>(`/api/orders/seller/${sellerId}`).pipe(map((result) => result.value ?? []));
  }

  getBalance(): Observable<SellerBalance> {
    return this.http.get<ApiResult<SellerBalance>>('/api/finance/me/balance').pipe(map((result) => result.value));
  }

  getEarnings(): Observable<SellerEarning[]> {
    return this.http.get<ApiResult<SellerEarning[]>>('/api/finance/me/earnings').pipe(map((result) => result.value ?? []));
  }

  getPayouts(): Observable<SellerPayout[]> {
    return this.http.get<ApiResult<SellerPayout[]>>('/api/finance/me/payouts').pipe(map((result) => result.value ?? []));
  }

  getTransactions(): Observable<FinanceTransaction[]> {
    return this.http.get<ApiResult<FinanceTransaction[]>>('/api/finance/me/transactions').pipe(map((result) => result.value ?? []));
  }

  requestPayout(sellerId: string): Observable<SellerPayout> {
    return this.http.post<ApiResult<SellerPayout>>(`/api/finance/sellers/${sellerId}/payouts/request`, {})
      .pipe(map((result) => result.value));
  }
}
