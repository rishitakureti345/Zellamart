import { Product } from '../../public/models/catalog.model';
export interface SellerProfile {
  id: string;
  userId: string;
  businessName: string;
  ownerName: string;
  contactEmail: string;
  phone: string;
  address: string;
  gstNumber?: string | null;
  status: string | number;
}

export interface InventoryItem {
  id: string;
  productId: string;
  sellerId: string;
  sku: string;
  quantityOnHand: number;
  reservedQuantity: number;
  availableQuantity: number;
}

export interface SellerStockMovement {
  id: string;
  inventoryItemId: string;
  productId: string;
  sellerId: string;
  type: string | number;
  quantityChange: number;
  quantityAfter: number;
  reason: string;
  referenceId?: string | null;
  changedByUserId?: string | null;
  changedAtUtc: string;
}

export interface SellerBalance {
  sellerId: string;
  availableBalance: number;
  pendingEarnings: number;
  totalPaidOut: number;
  refundDeductions: number;
  adjustmentBalance: number;
}

export interface SellerEarning {
  id: string;
  sellerId: string;
  orderId: string;
  orderItemId: string;
  productId: string;
  grossAmount: number;
  commissionAmount: number;
  netAmount: number;
  status: string | number;
  createdAtUtc: string;
}

export interface SellerPayout {
  id: string;
  sellerId: string;
  amount: number;
  status: string | number;
  requestedAtUtc: string;
  paidAtUtc?: string | null;
  referenceNumber: string;
}

export interface FinanceTransaction {
  id: string;
  sellerId: string;
  orderId?: string | null;
  type: string | number;
  amount: number;
  description: string;
  referenceId?: string | null;
  createdAtUtc: string;
}

export type SellerProduct = Product;

export interface SellerOrder {
  orderId: string;
  orderNumber: string;
  customerId: string;
  status: string | number;
  orderItemId: string;
  productId: string;
  sellerId: string;
  productName: string;
  unitPrice: number;
  quantity: number;
  lineTotal: number;
  createdAtUtc: string;
}
