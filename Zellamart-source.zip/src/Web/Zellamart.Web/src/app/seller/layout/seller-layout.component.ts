import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterOutlet } from '@angular/router';
import { StoreNavbarComponent } from '../../shared/components/store-navbar/store-navbar.component';
import { DashboardNavItem, DashboardSidebarComponent } from '../../shared/components/dashboard-sidebar/dashboard-sidebar.component';
import { SellerApiService } from '../services/seller-api.service';
import { SellerProfile } from '../models/seller.model';
import { AuthService } from '../../core/services/auth.service';
import { StatusBadgeComponent } from '../../shared/components/status-badge/status-badge.component';

@Component({
  selector: 'app-seller-layout',
  standalone: true,
  imports: [CommonModule, RouterOutlet, StoreNavbarComponent, DashboardSidebarComponent, StatusBadgeComponent],
  template: `
    <app-store-navbar></app-store-navbar>
    <main class="seller-shell">
      <aside class="admin-sidebar">
        <section class="admin-identity">
          <span>Seller workspace</span>
          <strong>{{ profile()?.businessName || auth.session()?.fullName || 'Seller' }}</strong>
          <small>{{ profile()?.contactEmail || auth.session()?.email }}</small>
          <p *ngIf="profile() as seller"><app-status-badge kind="seller" [status]="seller.status"></app-status-badge></p>
          <p *ngIf="!profile()">Application required</p>
        </section>
        <app-dashboard-sidebar [items]="items"></app-dashboard-sidebar>
      </aside>

      <section class="admin-workspace">
        <header class="admin-topbar">
          <div>
            <span class="eyebrow">Seller center</span>
            <strong>{{ auth.session()?.email }}</strong>
          </div>
          <button type="button" class="ghost-light" (click)="logout()">Logout</button>
        </header>

        <section class="seller-status-banner" [class.status-muted]="!isApproved()" *ngIf="profile() as seller">
          <div>
            <strong>{{ statusHeadline(seller.status) }}</strong>
            <p>{{ statusMessage(seller.status) }}</p>
          </div>
          <app-status-badge kind="seller" [status]="seller.status"></app-status-badge>
        </section>

        <section class="seller-status-banner status-muted" *ngIf="!profile()">
          <div>
            <strong>Seller application not found</strong>
            <p>Submit your seller application before products, orders, inventory, earnings, and payouts become available.</p>
          </div>
        </section>

        <section class="dashboard-content"><router-outlet></router-outlet></section>
      </section>
    </main>
  `
})
export class SellerLayoutComponent implements OnInit {
  readonly items: DashboardNavItem[] = [
    { label: 'Dashboard', path: '/seller/dashboard' },
    { label: 'Apply', path: '/seller/apply' },
    { label: 'Profile', path: '/seller/profile' },
    { label: 'Products', path: '/seller/products' },
    { label: 'Inventory', path: '/seller/inventory' },
    { label: 'Orders', path: '/seller/orders' },
    { label: 'Earnings', path: '/seller/earnings' },
    { label: 'Payouts', path: '/seller/payouts' }
  ];
  readonly profile = signal<SellerProfile | null>(null);

  constructor(
    readonly auth: AuthService,
    private readonly api: SellerApiService,
    private readonly router: Router
  ) {}

  ngOnInit(): void {
    this.api.getProfile().subscribe({
      next: (profile) => this.profile.set(profile),
      error: () => this.profile.set(null)
    });
  }

  isApproved(): boolean {
    return this.statusText(this.profile()?.status ?? '') === 'approved';
  }

  statusHeadline(status: string | number): string {
    const value = this.statusText(status);
    if (value === 'approved') {
      return 'Seller account approved';
    }
    if (value === 'rejected') {
      return 'Seller application rejected';
    }
    if (value === 'suspended') {
      return 'Seller account suspended';
    }
    return 'Seller application pending';
  }

  statusMessage(status: string | number): string {
    const value = this.statusText(status);
    if (value === 'approved') {
      return 'You can submit products, monitor inventory, view orders, and request payouts.';
    }
    if (value === 'rejected') {
      return 'Admin rejected this seller application. Review your profile details before applying again later.';
    }
    if (value === 'suspended') {
      return 'Admin suspended this seller account. Product and payout actions should stay paused.';
    }
    return 'Admin must approve this seller account before full marketplace operations are available.';
  }

  logout(): void {
    this.auth.logout();
    void this.router.navigateByUrl('/');
  }

  private statusText(status: string | number): string {
    const value = String(status).toLowerCase();
    return value === '4' ? 'suspended' : value === '3' ? 'rejected' : value === '2' ? 'approved' : value === '1' ? 'pending' : value;
  }
}
