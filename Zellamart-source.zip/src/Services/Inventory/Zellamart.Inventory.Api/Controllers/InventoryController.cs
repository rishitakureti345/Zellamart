using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Zellamart.Inventory.Application.Abstractions;
using Zellamart.Inventory.Application.Inventory;

namespace Zellamart.Inventory.Api.Controllers;

[ApiController]
[Route("api/inventory")]
public sealed class InventoryController : ControllerBase
{
    private readonly IInventoryService _inventoryService;
    private readonly ISellerProfileGateway _sellerProfileGateway;

    public InventoryController(
        IInventoryService inventoryService,
        ISellerProfileGateway sellerProfileGateway)
    {
        _inventoryService = inventoryService;
        _sellerProfileGateway = sellerProfileGateway;
    }

    [Authorize(Roles = "SuperAdmin,Admin,InventoryStaff")]
    [HttpPost("from-product-approved")]
    public async Task<IActionResult> CreateFromProductApproved(
        CreateInventoryFromProductApprovedRequest request,
        CancellationToken cancellationToken)
    {
        var result = await _inventoryService.CreateFromProductApprovedAsync(request, cancellationToken);
        return result.Success ? Ok(result) : BadRequest(result);
    }

    [Authorize(Roles = "SuperAdmin,Admin,Seller,InventoryStaff,WarehouseManager")]
    [HttpPost("{inventoryItemId:guid}/stock/add")]
    public async Task<IActionResult> AddStock(
        Guid inventoryItemId,
        AddStockRequest request,
        CancellationToken cancellationToken)
    {
        var userId = GetCurrentUserId();
        if (userId is null)
        {
            return Unauthorized();
        }

        if (User.IsInRole("Seller") && !await CanAccessInventoryItemAsync(inventoryItemId, cancellationToken))
        {
            return Forbid();
        }

        var result = await _inventoryService.AddStockAsync(inventoryItemId, userId.Value, request, cancellationToken);
        return result.Success ? Ok(result) : BadRequest(result);
    }

    [Authorize(Roles = "SuperAdmin,Admin,Seller,InventoryStaff,WarehouseManager")]
    [HttpPost("{inventoryItemId:guid}/stock/set")]
    public async Task<IActionResult> SetStock(
        Guid inventoryItemId,
        SetStockRequest request,
        CancellationToken cancellationToken)
    {
        var userId = GetCurrentUserId();
        if (userId is null)
        {
            return Unauthorized();
        }

        if (User.IsInRole("Seller") && !await CanAccessInventoryItemAsync(inventoryItemId, cancellationToken))
        {
            return Forbid();
        }

        var result = await _inventoryService.SetStockAsync(inventoryItemId, userId.Value, request, cancellationToken);
        return result.Success ? Ok(result) : BadRequest(result);
    }

    [Authorize(Roles = "SuperAdmin,Admin,Customer,OrderManager")]
    [HttpPost("product/{productId:guid}/stock/reserve")]
    public async Task<IActionResult> ReserveStockByProduct(
        Guid productId,
        ReserveStockRequest request,
        CancellationToken cancellationToken)
    {
        var userId = GetCurrentUserId();
        if (userId is null)
        {
            return Unauthorized();
        }

        var result = await _inventoryService.ReserveStockByProductIdAsync(productId, userId.Value, request, cancellationToken);
        return result.Success ? Ok(result) : ToFailureResult(result);
    }

    [Authorize(Roles = "SuperAdmin,Admin,Customer,OrderManager")]
    [HttpPost("product/{productId:guid}/stock/release")]
    public async Task<IActionResult> ReleaseStockByProduct(
        Guid productId,
        ReleaseStockRequest request,
        CancellationToken cancellationToken)
    {
        var userId = GetCurrentUserId();
        if (userId is null)
        {
            return Unauthorized();
        }

        var result = await _inventoryService.ReleaseStockByProductIdAsync(productId, userId.Value, request, cancellationToken);
        return result.Success ? Ok(result) : ToFailureResult(result);
    }

    [Authorize(Roles = "SuperAdmin,Admin,Customer,OrderManager,PaymentTeam")]
    [HttpPost("product/{productId:guid}/stock/deduct")]
    public async Task<IActionResult> DeductStockByProduct(
        Guid productId,
        DeductStockRequest request,
        CancellationToken cancellationToken)
    {
        var userId = GetCurrentUserId();
        if (userId is null)
        {
            return Unauthorized();
        }

        var result = await _inventoryService.DeductStockByProductIdAsync(productId, userId.Value, request, cancellationToken);
        return result.Success ? Ok(result) : ToFailureResult(result);
    }

    [Authorize(Roles = "SuperAdmin,Admin,Seller,Customer,InventoryStaff,OrderManager,WarehouseManager")]
    [HttpGet("product/{productId:guid}")]
    public async Task<IActionResult> GetByProduct(Guid productId, CancellationToken cancellationToken)
    {
        var result = await _inventoryService.GetByProductIdAsync(productId, cancellationToken);
        if (result.Success && result.Value is not null && User.IsInRole("Seller") && !await IsCurrentSellerAsync(result.Value.SellerId, cancellationToken))
        {
            return Forbid();
        }

        return result.Success ? Ok(result) : NotFound(result);
    }

    [Authorize(Roles = "SuperAdmin,Admin,Seller,InventoryStaff,WarehouseManager")]
    [HttpGet("seller/{sellerId:guid}")]
    public async Task<IActionResult> GetBySeller(Guid sellerId, CancellationToken cancellationToken)
    {
        if (User.IsInRole("Seller") && !await IsCurrentSellerAsync(sellerId, cancellationToken))
        {
            return Forbid();
        }

        var result = await _inventoryService.GetBySellerIdAsync(sellerId, cancellationToken);
        return Ok(result);
    }

    [Authorize(Roles = "SuperAdmin,Admin,InventoryStaff,WarehouseManager")]
    [HttpGet("admin/all")]
    public async Task<IActionResult> GetAllForStaff(CancellationToken cancellationToken)
    {
        var result = await _inventoryService.GetAllForStaffAsync(cancellationToken);
        return Ok(result);
    }

    [Authorize(Roles = "SuperAdmin,Admin,Seller,InventoryStaff,WarehouseManager")]
    [HttpGet("{inventoryItemId:guid}/movements")]
    public async Task<IActionResult> GetMovements(Guid inventoryItemId, CancellationToken cancellationToken)
    {
        if (User.IsInRole("Seller") && !await CanAccessInventoryItemAsync(inventoryItemId, cancellationToken))
        {
            return Forbid();
        }

        var result = await _inventoryService.GetMovementsAsync(inventoryItemId, cancellationToken);
        return result.Success ? Ok(result) : NotFound(result);
    }

    private Guid? GetCurrentUserId()
    {
        var userIdValue = User.FindFirstValue(ClaimTypes.NameIdentifier)
            ?? User.FindFirst(JwtRegisteredClaimNames.Sub)?.Value;

        return Guid.TryParse(userIdValue, out var userId) ? userId : null;
    }

    private async Task<bool> CanAccessInventoryItemAsync(Guid inventoryItemId, CancellationToken cancellationToken)
    {
        var inventoryResult = await _inventoryService.GetByIdAsync(inventoryItemId, cancellationToken);
        return inventoryResult.Success
            && inventoryResult.Value is not null
            && await IsCurrentSellerAsync(inventoryResult.Value.SellerId, cancellationToken);
    }

    private async Task<bool> IsCurrentSellerAsync(Guid sellerId, CancellationToken cancellationToken)
    {
        var seller = await GetCurrentSellerAsync(cancellationToken);
        return seller?.Id == sellerId;
    }

    private async Task<SellerProfileSnapshot?> GetCurrentSellerAsync(CancellationToken cancellationToken)
    {
        var bearerToken = GetBearerToken();
        return string.IsNullOrWhiteSpace(bearerToken)
            ? null
            : await _sellerProfileGateway.GetMineAsync(bearerToken, cancellationToken);
    }

    private string? GetBearerToken()
    {
        var authorization = Request.Headers.Authorization.ToString();
        return authorization.StartsWith("Bearer ", StringComparison.OrdinalIgnoreCase)
            ? authorization["Bearer ".Length..].Trim()
            : null;
    }

    private IActionResult ToFailureResult<T>(Zellamart.SharedKernel.Results.Result<T> result)
    {
        return result.Error.Code == "NotFound" ? NotFound(result) : BadRequest(result);
    }
}
