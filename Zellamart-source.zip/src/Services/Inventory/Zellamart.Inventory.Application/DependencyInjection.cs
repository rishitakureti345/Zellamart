using Microsoft.Extensions.DependencyInjection;
using Zellamart.Inventory.Application.Inventory;

namespace Zellamart.Inventory.Application;

public static class DependencyInjection
{
    public static IServiceCollection AddInventoryApplication(this IServiceCollection services)
    {
        services.AddScoped<IInventoryService, InventoryService>();

        return services;
    }
}
