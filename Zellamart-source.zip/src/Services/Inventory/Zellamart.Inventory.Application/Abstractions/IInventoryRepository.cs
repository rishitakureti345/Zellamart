using Zellamart.Inventory.Domain.Inventory;

namespace Zellamart.Inventory.Application.Abstractions;

public interface IInventoryRepository
{
    Task<InventoryItem?> GetByIdAsync(Guid inventoryItemId, CancellationToken cancellationToken);

    Task<InventoryItem?> GetByProductIdAsync(Guid productId, CancellationToken cancellationToken);

    Task<IReadOnlyList<InventoryItem>> GetBySellerIdAsync(Guid sellerId, CancellationToken cancellationToken);

    Task<IReadOnlyList<InventoryItem>> GetAllAsync(CancellationToken cancellationToken);

    Task<IReadOnlyList<StockMovement>> GetMovementsAsync(Guid inventoryItemId, CancellationToken cancellationToken);

    Task AddAsync(InventoryItem inventoryItem, CancellationToken cancellationToken);

    Task SaveChangesAsync(CancellationToken cancellationToken);
}
