using Zellamart.Inventory.Domain.Inventory;

namespace Zellamart.Inventory.Application.Abstractions;

public interface IInventoryEventPublisher
{
    Task PublishCreatedAsync(InventoryItem inventoryItem, CancellationToken cancellationToken);
}
