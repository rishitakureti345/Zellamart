using Zellamart.SharedKernel.Results;

namespace Zellamart.Inventory.Application.Inventory;

public interface IInventoryService
{
    Task<Result<InventoryItemResponse>> CreateFromProductApprovedAsync(
        CreateInventoryFromProductApprovedRequest request,
        CancellationToken cancellationToken);

    Task<Result<InventoryItemResponse>> AddStockAsync(
        Guid inventoryItemId,
        Guid changedByUserId,
        AddStockRequest request,
        CancellationToken cancellationToken);

    Task<Result<InventoryItemResponse>> SetStockAsync(
        Guid inventoryItemId,
        Guid changedByUserId,
        SetStockRequest request,
        CancellationToken cancellationToken);

    Task<Result<InventoryItemResponse>> DeductStockByProductIdAsync(
        Guid productId,
        Guid changedByUserId,
        DeductStockRequest request,
        CancellationToken cancellationToken);

    Task<Result<InventoryItemResponse>> ReserveStockByProductIdAsync(
        Guid productId,
        Guid changedByUserId,
        ReserveStockRequest request,
        CancellationToken cancellationToken);

    Task<Result<InventoryItemResponse>> ReleaseStockByProductIdAsync(
        Guid productId,
        Guid changedByUserId,
        ReleaseStockRequest request,
        CancellationToken cancellationToken);

    Task<Result<InventoryItemResponse>> GetByProductIdAsync(Guid productId, CancellationToken cancellationToken);

    Task<Result<InventoryItemResponse>> GetByIdAsync(Guid inventoryItemId, CancellationToken cancellationToken);

    Task<Result<IReadOnlyList<InventoryItemResponse>>> GetBySellerIdAsync(Guid sellerId, CancellationToken cancellationToken);

    Task<Result<IReadOnlyList<InventoryItemResponse>>> GetAllForStaffAsync(CancellationToken cancellationToken);

    Task<Result<IReadOnlyList<StockMovementResponse>>> GetMovementsAsync(Guid inventoryItemId, CancellationToken cancellationToken);
}
