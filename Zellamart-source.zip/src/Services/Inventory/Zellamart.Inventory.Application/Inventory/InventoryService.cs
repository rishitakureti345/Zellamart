using Zellamart.Inventory.Application.Abstractions;
using Zellamart.Inventory.Domain.Inventory;
using Zellamart.SharedKernel.Results;

namespace Zellamart.Inventory.Application.Inventory;

public sealed class InventoryService : IInventoryService
{
    private readonly IInventoryRepository _repository;
    private readonly IInventoryEventPublisher _eventPublisher;

    public InventoryService(IInventoryRepository repository, IInventoryEventPublisher eventPublisher)
    {
        _repository = repository;
        _eventPublisher = eventPublisher;
    }

    public async Task<Result<InventoryItemResponse>> CreateFromProductApprovedAsync(
        CreateInventoryFromProductApprovedRequest request,
        CancellationToken cancellationToken)
    {
        if (request.ProductId == Guid.Empty)
        {
            return Result.Fail<InventoryItemResponse>(Error.Validation("Product id is required."));
        }

        if (request.SellerId == Guid.Empty)
        {
            return Result.Fail<InventoryItemResponse>(Error.Validation("Seller id is required."));
        }

        var existing = await _repository.GetByProductIdAsync(request.ProductId, cancellationToken);
        if (existing is not null)
        {
            return Result.Fail<InventoryItemResponse>(Error.Conflict("Inventory already exists for this product."));
        }

        var inventoryItem = new InventoryItem(
            request.ProductId,
            request.SellerId,
            BuildSku(request));

        await _repository.AddAsync(inventoryItem, cancellationToken);
        await _repository.SaveChangesAsync(cancellationToken);
        await _eventPublisher.PublishCreatedAsync(inventoryItem, cancellationToken);

        return Result.Ok(ToResponse(inventoryItem));
    }

    public async Task<Result<InventoryItemResponse>> AddStockAsync(
        Guid inventoryItemId,
        Guid changedByUserId,
        AddStockRequest request,
        CancellationToken cancellationToken)
    {
        if (request.Quantity <= 0)
        {
            return Result.Fail<InventoryItemResponse>(Error.Validation("Stock quantity must be greater than zero."));
        }

        var inventoryItem = await _repository.GetByIdAsync(inventoryItemId, cancellationToken);
        if (inventoryItem is null)
        {
            return Result.Fail<InventoryItemResponse>(Error.NotFound("Inventory item was not found."));
        }

        var reason = string.IsNullOrWhiteSpace(request.Reason) ? "Stock added." : request.Reason;
        inventoryItem.AddStock(request.Quantity, reason, request.ReferenceId, changedByUserId);
        await _repository.SaveChangesAsync(cancellationToken);

        return Result.Ok(ToResponse(inventoryItem));
    }

    public async Task<Result<InventoryItemResponse>> SetStockAsync(
        Guid inventoryItemId,
        Guid changedByUserId,
        SetStockRequest request,
        CancellationToken cancellationToken)
    {
        if (request.QuantityOnHand < 0)
        {
            return Result.Fail<InventoryItemResponse>(Error.Validation("Stock quantity cannot be negative."));
        }

        var inventoryItem = await _repository.GetByIdAsync(inventoryItemId, cancellationToken);
        if (inventoryItem is null)
        {
            return Result.Fail<InventoryItemResponse>(Error.NotFound("Inventory item was not found."));
        }

        if (request.QuantityOnHand < inventoryItem.ReservedQuantity)
        {
            return Result.Fail<InventoryItemResponse>(Error.Validation("Stock count cannot be lower than reserved stock."));
        }

        var reason = string.IsNullOrWhiteSpace(request.Reason) ? "Stock count adjusted." : request.Reason;
        inventoryItem.SetStock(request.QuantityOnHand, reason, request.ReferenceId, changedByUserId);
        await _repository.SaveChangesAsync(cancellationToken);

        return Result.Ok(ToResponse(inventoryItem));
    }

    public async Task<Result<InventoryItemResponse>> DeductStockByProductIdAsync(
        Guid productId,
        Guid changedByUserId,
        DeductStockRequest request,
        CancellationToken cancellationToken)
    {
        if (request.Quantity <= 0)
        {
            return Result.Fail<InventoryItemResponse>(Error.Validation("Stock quantity must be greater than zero."));
        }

        var inventoryItem = await _repository.GetByProductIdAsync(productId, cancellationToken);
        if (inventoryItem is null)
        {
            return Result.Fail<InventoryItemResponse>(Error.NotFound("Inventory item was not found."));
        }

        if (inventoryItem.AvailableQuantity < request.Quantity)
        {
            return Result.Fail<InventoryItemResponse>(Error.Validation("Insufficient available stock."));
        }

        var reason = string.IsNullOrWhiteSpace(request.Reason) ? "Stock deducted." : request.Reason;
        inventoryItem.DeductStock(request.Quantity, reason, request.ReferenceId, changedByUserId);
        await _repository.SaveChangesAsync(cancellationToken);

        return Result.Ok(ToResponse(inventoryItem));
    }

    public async Task<Result<InventoryItemResponse>> ReserveStockByProductIdAsync(
        Guid productId,
        Guid changedByUserId,
        ReserveStockRequest request,
        CancellationToken cancellationToken)
    {
        if (request.Quantity <= 0)
        {
            return Result.Fail<InventoryItemResponse>(Error.Validation("Stock quantity must be greater than zero."));
        }

        var inventoryItem = await _repository.GetByProductIdAsync(productId, cancellationToken);
        if (inventoryItem is null)
        {
            return Result.Fail<InventoryItemResponse>(Error.NotFound("Inventory item was not found."));
        }

        if (inventoryItem.AvailableQuantity < request.Quantity)
        {
            return Result.Fail<InventoryItemResponse>(Error.Validation("Insufficient available stock."));
        }

        var reason = string.IsNullOrWhiteSpace(request.Reason) ? "Stock reserved." : request.Reason;
        inventoryItem.ReserveStock(request.Quantity, reason, request.ReferenceId, changedByUserId);
        await _repository.SaveChangesAsync(cancellationToken);

        return Result.Ok(ToResponse(inventoryItem));
    }

    public async Task<Result<InventoryItemResponse>> ReleaseStockByProductIdAsync(
        Guid productId,
        Guid changedByUserId,
        ReleaseStockRequest request,
        CancellationToken cancellationToken)
    {
        if (request.Quantity <= 0)
        {
            return Result.Fail<InventoryItemResponse>(Error.Validation("Stock quantity must be greater than zero."));
        }

        var inventoryItem = await _repository.GetByProductIdAsync(productId, cancellationToken);
        if (inventoryItem is null)
        {
            return Result.Fail<InventoryItemResponse>(Error.NotFound("Inventory item was not found."));
        }

        if (inventoryItem.ReservedQuantity < request.Quantity)
        {
            return Result.Fail<InventoryItemResponse>(Error.Validation("Reserved stock is lower than release quantity."));
        }

        var reason = string.IsNullOrWhiteSpace(request.Reason) ? "Stock released." : request.Reason;
        inventoryItem.ReleaseStock(request.Quantity, reason, request.ReferenceId, changedByUserId);
        await _repository.SaveChangesAsync(cancellationToken);

        return Result.Ok(ToResponse(inventoryItem));
    }

    public async Task<Result<InventoryItemResponse>> GetByProductIdAsync(Guid productId, CancellationToken cancellationToken)
    {
        var inventoryItem = await _repository.GetByProductIdAsync(productId, cancellationToken);
        return inventoryItem is null
            ? Result.Fail<InventoryItemResponse>(Error.NotFound("Inventory item was not found."))
            : Result.Ok(ToResponse(inventoryItem));
    }

    public async Task<Result<InventoryItemResponse>> GetByIdAsync(Guid inventoryItemId, CancellationToken cancellationToken)
    {
        var inventoryItem = await _repository.GetByIdAsync(inventoryItemId, cancellationToken);
        return inventoryItem is null
            ? Result.Fail<InventoryItemResponse>(Error.NotFound("Inventory item was not found."))
            : Result.Ok(ToResponse(inventoryItem));
    }

    public async Task<Result<IReadOnlyList<InventoryItemResponse>>> GetBySellerIdAsync(Guid sellerId, CancellationToken cancellationToken)
    {
        var inventoryItems = await _repository.GetBySellerIdAsync(sellerId, cancellationToken);
        return Result.Ok<IReadOnlyList<InventoryItemResponse>>(inventoryItems.Select(ToResponse).ToArray());
    }

    public async Task<Result<IReadOnlyList<InventoryItemResponse>>> GetAllForStaffAsync(CancellationToken cancellationToken)
    {
        var inventoryItems = await _repository.GetAllAsync(cancellationToken);
        return Result.Ok<IReadOnlyList<InventoryItemResponse>>(inventoryItems.Select(ToResponse).ToArray());
    }

    public async Task<Result<IReadOnlyList<StockMovementResponse>>> GetMovementsAsync(
        Guid inventoryItemId,
        CancellationToken cancellationToken)
    {
        if (await _repository.GetByIdAsync(inventoryItemId, cancellationToken) is null)
        {
            return Result.Fail<IReadOnlyList<StockMovementResponse>>(Error.NotFound("Inventory item was not found."));
        }

        var movements = await _repository.GetMovementsAsync(inventoryItemId, cancellationToken);
        return Result.Ok<IReadOnlyList<StockMovementResponse>>(movements.Select(ToResponse).ToArray());
    }

    private static string BuildSku(CreateInventoryFromProductApprovedRequest request)
    {
        return string.IsNullOrWhiteSpace(request.Sku)
            ? $"SKU-{request.ProductId.ToString()[..8]}"
            : request.Sku;
    }

    private static InventoryItemResponse ToResponse(InventoryItem inventoryItem)
    {
        return new InventoryItemResponse(
            inventoryItem.Id,
            inventoryItem.ProductId,
            inventoryItem.SellerId,
            inventoryItem.Sku,
            inventoryItem.QuantityOnHand,
            inventoryItem.ReservedQuantity,
            inventoryItem.AvailableQuantity);
    }

    private static StockMovementResponse ToResponse(StockMovement movement)
    {
        return new StockMovementResponse(
            movement.Id,
            movement.InventoryItemId,
            movement.ProductId,
            movement.SellerId,
            movement.Type,
            movement.QuantityChange,
            movement.QuantityAfter,
            movement.Reason,
            movement.ReferenceId,
            movement.ChangedByUserId,
            movement.ChangedAtUtc);
    }
}
