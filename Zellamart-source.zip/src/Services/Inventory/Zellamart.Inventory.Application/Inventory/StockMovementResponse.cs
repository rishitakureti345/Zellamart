using Zellamart.Inventory.Domain.Inventory;

namespace Zellamart.Inventory.Application.Inventory;

public sealed record StockMovementResponse(
    Guid Id,
    Guid InventoryItemId,
    Guid ProductId,
    Guid SellerId,
    StockMovementType Type,
    int QuantityChange,
    int QuantityAfter,
    string Reason,
    Guid? ReferenceId,
    Guid? ChangedByUserId,
    DateTimeOffset ChangedAtUtc);
