namespace Zellamart.Inventory.Application.Inventory;

public sealed record SetStockRequest(
    int QuantityOnHand,
    string? Reason,
    Guid? ReferenceId);
