namespace Zellamart.Inventory.Application.Inventory;

public sealed record ReserveStockRequest(
    int Quantity,
    string? Reason,
    Guid? ReferenceId);
