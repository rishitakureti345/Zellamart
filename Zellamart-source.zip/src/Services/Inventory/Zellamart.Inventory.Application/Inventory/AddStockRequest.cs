namespace Zellamart.Inventory.Application.Inventory;

public sealed record AddStockRequest(
    int Quantity,
    string? Reason,
    Guid? ReferenceId);
