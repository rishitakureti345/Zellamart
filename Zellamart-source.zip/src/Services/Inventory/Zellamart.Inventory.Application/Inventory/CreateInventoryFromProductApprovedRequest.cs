namespace Zellamart.Inventory.Application.Inventory;

public sealed record CreateInventoryFromProductApprovedRequest(
    Guid ProductId,
    Guid SellerId,
    string? Sku);
