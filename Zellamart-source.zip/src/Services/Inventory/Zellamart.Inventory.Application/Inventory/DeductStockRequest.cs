namespace Zellamart.Inventory.Application.Inventory;

public sealed record DeductStockRequest(
    int Quantity,
    string? Reason,
    Guid? ReferenceId);
