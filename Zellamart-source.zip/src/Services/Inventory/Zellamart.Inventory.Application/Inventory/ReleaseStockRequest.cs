namespace Zellamart.Inventory.Application.Inventory;

public sealed record ReleaseStockRequest(
    int Quantity,
    string? Reason,
    Guid? ReferenceId);
