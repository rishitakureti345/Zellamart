namespace Zellamart.Inventory.Application.Inventory;

public sealed record InventoryItemResponse(
    Guid Id,
    Guid ProductId,
    Guid SellerId,
    string Sku,
    int QuantityOnHand,
    int ReservedQuantity,
    int AvailableQuantity);
