using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Zellamart.Inventory.Application.Abstractions;
using Zellamart.Inventory.Infrastructure.Events;
using Zellamart.Inventory.Infrastructure.Persistence;
using Zellamart.Inventory.Infrastructure.Services;

namespace Zellamart.Inventory.Infrastructure;

public static class DependencyInjection
{
    public static IServiceCollection AddInventoryInfrastructure(
        this IServiceCollection services,
        IConfiguration configuration)
    {
        services.AddDbContext<InventoryDbContext>(options =>
            options.UseNpgsql(configuration.GetConnectionString("Inventory")));

        services.AddScoped<IInventoryRepository, InventoryRepository>();
        services.AddScoped<IInventoryEventPublisher, LoggingInventoryEventPublisher>();
        services.AddHttpClient<ISellerProfileGateway, SellerProfileGateway>(client =>
        {
            client.BaseAddress = new Uri(configuration["Services:Seller"] ?? "http://localhost:5102");
        });

        return services;
    }
}
