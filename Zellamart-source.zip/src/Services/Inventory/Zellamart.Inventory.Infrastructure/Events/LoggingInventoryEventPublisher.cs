using Microsoft.Extensions.Logging;
using Zellamart.Contracts.Events.Inventory;
using Zellamart.Inventory.Application.Abstractions;
using Zellamart.Inventory.Domain.Inventory;

namespace Zellamart.Inventory.Infrastructure.Events;

public sealed class LoggingInventoryEventPublisher : IInventoryEventPublisher
{
    private readonly ILogger<LoggingInventoryEventPublisher> _logger;

    public LoggingInventoryEventPublisher(ILogger<LoggingInventoryEventPublisher> logger)
    {
        _logger = logger;
    }

    public Task PublishCreatedAsync(InventoryItem inventoryItem, CancellationToken cancellationToken)
    {
        var integrationEvent = new InventoryCreatedEvent(
            Guid.NewGuid(),
            DateTimeOffset.UtcNow,
            inventoryItem.Id,
            inventoryItem.ProductId,
            inventoryItem.SellerId);

        _logger.LogInformation(
            "Integration event ready: {EventType} {@IntegrationEvent}",
            nameof(InventoryCreatedEvent),
            integrationEvent);

        return Task.CompletedTask;
    }
}
