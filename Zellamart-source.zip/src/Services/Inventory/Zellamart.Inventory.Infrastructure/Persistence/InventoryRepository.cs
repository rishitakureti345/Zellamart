using Microsoft.EntityFrameworkCore;
using Zellamart.Inventory.Application.Abstractions;
using Zellamart.Inventory.Domain.Inventory;

namespace Zellamart.Inventory.Infrastructure.Persistence;

public sealed class InventoryRepository : IInventoryRepository
{
    private readonly InventoryDbContext _dbContext;

    public InventoryRepository(InventoryDbContext dbContext)
    {
        _dbContext = dbContext;
    }

    public Task<InventoryItem?> GetByIdAsync(Guid inventoryItemId, CancellationToken cancellationToken)
    {
        return InventoryQuery().FirstOrDefaultAsync(item => item.Id == inventoryItemId, cancellationToken);
    }

    public Task<InventoryItem?> GetByProductIdAsync(Guid productId, CancellationToken cancellationToken)
    {
        return InventoryQuery().FirstOrDefaultAsync(item => item.ProductId == productId, cancellationToken);
    }

    public async Task<IReadOnlyList<InventoryItem>> GetBySellerIdAsync(Guid sellerId, CancellationToken cancellationToken)
    {
        return await InventoryQuery()
            .Where(item => item.SellerId == sellerId)
            .OrderBy(item => item.Sku)
            .ToArrayAsync(cancellationToken);
    }

    public async Task<IReadOnlyList<InventoryItem>> GetAllAsync(CancellationToken cancellationToken)
    {
        return await InventoryQuery()
            .OrderBy(item => item.Sku)
            .ToArrayAsync(cancellationToken);
    }

    public async Task<IReadOnlyList<StockMovement>> GetMovementsAsync(Guid inventoryItemId, CancellationToken cancellationToken)
    {
        return await _dbContext.StockMovements
            .Where(movement => movement.InventoryItemId == inventoryItemId)
            .OrderBy(movement => movement.ChangedAtUtc)
            .ToArrayAsync(cancellationToken);
    }

    public async Task AddAsync(InventoryItem inventoryItem, CancellationToken cancellationToken)
    {
        await _dbContext.InventoryItems.AddAsync(inventoryItem, cancellationToken);
    }

    public Task SaveChangesAsync(CancellationToken cancellationToken)
    {
        return _dbContext.SaveChangesAsync(cancellationToken);
    }

    private IQueryable<InventoryItem> InventoryQuery()
    {
        return _dbContext.InventoryItems.Include(item => item.StockMovements);
    }
}
