using Microsoft.EntityFrameworkCore;
using Zellamart.Inventory.Domain.Inventory;

namespace Zellamart.Inventory.Infrastructure.Persistence;

public sealed class InventoryDbContext : DbContext
{
    public InventoryDbContext(DbContextOptions<InventoryDbContext> options)
        : base(options)
    {
    }

    public DbSet<InventoryItem> InventoryItems => Set<InventoryItem>();

    public DbSet<StockMovement> StockMovements => Set<StockMovement>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<InventoryItem>(builder =>
        {
            builder.ToTable("inventory_items");
            builder.HasKey(item => item.Id);
            builder.Property(item => item.Id).ValueGeneratedNever();
            builder.Property(item => item.Sku).HasMaxLength(80).IsRequired();
            builder.HasIndex(item => item.ProductId).IsUnique();
            builder.HasIndex(item => item.SellerId);
            builder.HasIndex(item => item.Sku);
            builder.Navigation(item => item.StockMovements).UsePropertyAccessMode(PropertyAccessMode.Field);
        });

        modelBuilder.Entity<StockMovement>(builder =>
        {
            builder.ToTable("stock_movements");
            builder.HasKey(movement => movement.Id);
            builder.Property(movement => movement.Id).ValueGeneratedNever();
            builder.Property(movement => movement.Type).HasConversion<string>().HasMaxLength(40).IsRequired();
            builder.Property(movement => movement.Reason).HasMaxLength(600).IsRequired();
            builder.HasOne(movement => movement.InventoryItem)
                .WithMany(item => item.StockMovements)
                .HasForeignKey(movement => movement.InventoryItemId);
            builder.HasIndex(movement => movement.InventoryItemId);
            builder.HasIndex(movement => movement.ProductId);
            builder.HasIndex(movement => movement.SellerId);
        });
    }
}
