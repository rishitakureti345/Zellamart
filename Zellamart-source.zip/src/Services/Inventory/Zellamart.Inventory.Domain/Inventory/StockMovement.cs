using Zellamart.SharedKernel.Entities;

namespace Zellamart.Inventory.Domain.Inventory;

public sealed class StockMovement : BaseEntity
{
    private StockMovement()
    {
    }

    public StockMovement(
        Guid inventoryItemId,
        Guid productId,
        Guid sellerId,
        StockMovementType type,
        int quantityChange,
        int quantityAfter,
        string reason,
        Guid? referenceId,
        Guid? changedByUserId)
    {
        InventoryItemId = inventoryItemId;
        ProductId = productId;
        SellerId = sellerId;
        Type = type;
        QuantityChange = quantityChange;
        QuantityAfter = quantityAfter;
        Reason = reason.Trim();
        ReferenceId = referenceId;
        ChangedByUserId = changedByUserId;
        ChangedAtUtc = DateTimeOffset.UtcNow;
    }

    public Guid InventoryItemId { get; private set; }

    public Guid ProductId { get; private set; }

    public Guid SellerId { get; private set; }

    public StockMovementType Type { get; private set; }

    public int QuantityChange { get; private set; }

    public int QuantityAfter { get; private set; }

    public string Reason { get; private set; } = string.Empty;

    public Guid? ReferenceId { get; private set; }

    public Guid? ChangedByUserId { get; private set; }

    public DateTimeOffset ChangedAtUtc { get; private set; }

    public InventoryItem InventoryItem { get; private set; } = null!;
}
