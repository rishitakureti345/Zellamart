namespace Zellamart.Inventory.Domain.Inventory;

public enum StockMovementType
{
    InventoryCreated = 1,
    StockAdded = 2,
    StockAdjusted = 3,
    StockReserved = 4,
    StockReleased = 5,
    StockDeducted = 6
}
