using Zellamart.SharedKernel.Entities;

namespace Zellamart.Inventory.Domain.Inventory;

public sealed class InventoryItem : AuditableEntity
{
    private readonly List<StockMovement> _stockMovements = [];

    private InventoryItem()
    {
    }

    public InventoryItem(Guid productId, Guid sellerId, string sku)
    {
        ProductId = productId;
        SellerId = sellerId;
        Sku = sku.Trim().ToUpperInvariant();
        QuantityOnHand = 0;
        ReservedQuantity = 0;

        AddMovement(StockMovementType.InventoryCreated, 0, "Inventory created after product approval.", null, null);
    }

    public Guid ProductId { get; private set; }

    public Guid SellerId { get; private set; }

    public string Sku { get; private set; } = string.Empty;

    public int QuantityOnHand { get; private set; }

    public int ReservedQuantity { get; private set; }

    public int AvailableQuantity => QuantityOnHand - ReservedQuantity;

    public IReadOnlyCollection<StockMovement> StockMovements => _stockMovements;

    public void AddStock(int quantity, string reason, Guid? referenceId, Guid? changedByUserId)
    {
        if (quantity <= 0)
        {
            throw new InvalidOperationException("Stock quantity must be greater than zero.");
        }

        QuantityOnHand += quantity;
        UpdatedAtUtc = DateTimeOffset.UtcNow;

        AddMovement(StockMovementType.StockAdded, quantity, reason, referenceId, changedByUserId);
    }

    public void SetStock(int quantityOnHand, string reason, Guid? referenceId, Guid? changedByUserId)
    {
        if (quantityOnHand < 0)
        {
            throw new InvalidOperationException("Stock quantity cannot be negative.");
        }

        if (quantityOnHand < ReservedQuantity)
        {
            throw new InvalidOperationException("Stock quantity cannot be lower than reserved stock.");
        }

        var quantityChange = quantityOnHand - QuantityOnHand;
        QuantityOnHand = quantityOnHand;
        UpdatedAtUtc = DateTimeOffset.UtcNow;

        AddMovement(StockMovementType.StockAdjusted, quantityChange, reason, referenceId, changedByUserId);
    }

    public void DeductStock(int quantity, string reason, Guid? referenceId, Guid? changedByUserId)
    {
        if (quantity <= 0)
        {
            throw new InvalidOperationException("Stock quantity must be greater than zero.");
        }

        if (AvailableQuantity < quantity)
        {
            throw new InvalidOperationException("Insufficient available stock.");
        }

        QuantityOnHand -= quantity;
        UpdatedAtUtc = DateTimeOffset.UtcNow;

        AddMovement(StockMovementType.StockDeducted, -quantity, reason, referenceId, changedByUserId);
    }

    public void ReserveStock(int quantity, string reason, Guid? referenceId, Guid? changedByUserId)
    {
        if (quantity <= 0)
        {
            throw new InvalidOperationException("Stock quantity must be greater than zero.");
        }

        if (AvailableQuantity < quantity)
        {
            throw new InvalidOperationException("Insufficient available stock.");
        }

        ReservedQuantity += quantity;
        UpdatedAtUtc = DateTimeOffset.UtcNow;

        AddMovement(StockMovementType.StockReserved, 0, reason, referenceId, changedByUserId);
    }

    public void ReleaseStock(int quantity, string reason, Guid? referenceId, Guid? changedByUserId)
    {
        if (quantity <= 0)
        {
            throw new InvalidOperationException("Stock quantity must be greater than zero.");
        }

        if (ReservedQuantity < quantity)
        {
            throw new InvalidOperationException("Reserved stock is lower than release quantity.");
        }

        ReservedQuantity -= quantity;
        UpdatedAtUtc = DateTimeOffset.UtcNow;

        AddMovement(StockMovementType.StockReleased, 0, reason, referenceId, changedByUserId);
    }

    private void AddMovement(
        StockMovementType type,
        int quantityChange,
        string reason,
        Guid? referenceId,
        Guid? changedByUserId)
    {
        _stockMovements.Add(new StockMovement(
            Id,
            ProductId,
            SellerId,
            type,
            quantityChange,
            QuantityOnHand,
            reason,
            referenceId,
            changedByUserId));
    }
}
