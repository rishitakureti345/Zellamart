using Microsoft.Extensions.Configuration;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using Zellamart.Payments.Application.Abstractions;

namespace Zellamart.Payments.Infrastructure.Services;

public sealed class NotificationGateway : INotificationGateway
{
    private const string InternalServiceKeyHeader = "X-Internal-Service-Key";

    private readonly HttpClient _httpClient;
    private readonly string? _internalServiceKey;

    public NotificationGateway(HttpClient httpClient, IConfiguration configuration)
    {
        _httpClient = httpClient;
        _internalServiceKey = configuration["InternalService:NotificationKey"];
    }

    public async Task CreateAsync(
        Guid userId,
        string type,
        string title,
        string message,
        string bearerToken,
        CancellationToken cancellationToken)
    {
        using var request = new HttpRequestMessage(HttpMethod.Post, "/api/notifications");
        if (!string.IsNullOrWhiteSpace(bearerToken))
        {
            request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", bearerToken);
        }

        if (!string.IsNullOrWhiteSpace(_internalServiceKey))
        {
            request.Headers.Add(InternalServiceKeyHeader, _internalServiceKey);
        }

        request.Content = JsonContent.Create(new CreateNotificationGatewayRequest(userId, type, title, message));

        try
        {
            using var _ = await _httpClient.SendAsync(request, cancellationToken);
        }
        catch (HttpRequestException)
        {
            // V1 notifications are helpful but should not break checkout.
        }
    }

    private sealed record CreateNotificationGatewayRequest(
        Guid UserId,
        string Type,
        string Title,
        string Message);
}
