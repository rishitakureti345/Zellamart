using System.Net.Http.Headers;
using System.Net.Http.Json;
using Zellamart.Orders.Domain.Orders;
using Zellamart.Payments.Application.Abstractions;

namespace Zellamart.Payments.Infrastructure.Services;

public sealed class OrderGateway : IOrderGateway
{
    private readonly HttpClient _httpClient;

    public OrderGateway(HttpClient httpClient)
    {
        _httpClient = httpClient;
    }

    public async Task<OrderSnapshot?> GetOrderAsync(
        Guid customerId,
        Guid orderId,
        string bearerToken,
        CancellationToken cancellationToken)
    {
        using var request = CreateRequest(HttpMethod.Get, $"/api/orders/{orderId}", bearerToken);
        using var response = await _httpClient.SendAsync(request, cancellationToken);
        if (!response.IsSuccessStatusCode)
        {
            return null;
        }

        var result = await response.Content.ReadFromJsonAsync<GatewayResult<OrderGatewayResponse>>(cancellationToken);
        if (result?.Success != true || result.Value is null || result.Value.CustomerId != customerId)
        {
            return null;
        }

        return new OrderSnapshot(
            result.Value.Id,
            result.Value.CustomerId,
            result.Value.Status,
            result.Value.Subtotal,
            result.Value.Currency,
            result.Value.Items.Select(item => new OrderItemSnapshot(
                item.ProductId,
                item.SellerId,
                item.ProductName,
                item.UnitPrice,
                item.Quantity,
                item.LineTotal)).ToArray());
    }

    public Task<bool> MarkPaymentSucceededAsync(Guid orderId, string bearerToken, CancellationToken cancellationToken)
    {
        return PostAsync($"/api/orders/{orderId}/payment-succeeded", bearerToken, cancellationToken);
    }

    public Task<bool> MarkPaymentFailedAsync(Guid orderId, string bearerToken, CancellationToken cancellationToken)
    {
        return PostAsync($"/api/orders/{orderId}/payment-failed", bearerToken, cancellationToken);
    }

    public Task<bool> ConfirmAsync(Guid orderId, string bearerToken, CancellationToken cancellationToken)
    {
        return PostAsync($"/api/orders/{orderId}/confirm", bearerToken, cancellationToken);
    }

    private async Task<bool> PostAsync(string path, string bearerToken, CancellationToken cancellationToken)
    {
        using var request = CreateRequest(HttpMethod.Post, path, bearerToken);
        using var response = await _httpClient.SendAsync(request, cancellationToken);
        return response.IsSuccessStatusCode;
    }

    private static HttpRequestMessage CreateRequest(HttpMethod method, string path, string bearerToken)
    {
        var request = new HttpRequestMessage(method, path);
        request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", bearerToken);
        return request;
    }

    private sealed record OrderGatewayResponse(
        Guid Id,
        Guid CustomerId,
        OrderStatus Status,
        decimal Subtotal,
        string Currency,
        IReadOnlyList<OrderItemGatewayResponse> Items);

    private sealed record OrderItemGatewayResponse(
        Guid ProductId,
        Guid SellerId,
        string ProductName,
        decimal UnitPrice,
        int Quantity,
        decimal LineTotal);

    private sealed class GatewayResult<T>
    {
        public bool Success { get; set; }

        public T? Value { get; set; }
    }
}
