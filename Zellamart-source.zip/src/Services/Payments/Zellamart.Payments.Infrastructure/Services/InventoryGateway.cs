using System.Net.Http.Headers;
using System.Net.Http.Json;
using Zellamart.Payments.Application.Abstractions;

namespace Zellamart.Payments.Infrastructure.Services;

public sealed class InventoryGateway : IInventoryGateway
{
    private readonly HttpClient _httpClient;

    public InventoryGateway(HttpClient httpClient)
    {
        _httpClient = httpClient;
    }

    public async Task<bool> HasAvailableStockAsync(
        Guid productId,
        int quantity,
        string bearerToken,
        CancellationToken cancellationToken)
    {
        using var request = new HttpRequestMessage(HttpMethod.Get, $"/api/inventory/product/{productId}");
        request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", bearerToken);

        using var response = await _httpClient.SendAsync(request, cancellationToken);
        if (!response.IsSuccessStatusCode)
        {
            return false;
        }

        var result = await response.Content.ReadFromJsonAsync<GatewayResult<InventoryItemGatewayResponse>>(cancellationToken);
        return result?.Success == true && result.Value is not null && result.Value.AvailableQuantity >= quantity;
    }

    public async Task<bool> DeductStockAsync(
        Guid productId,
        int quantity,
        Guid orderId,
        string bearerToken,
        CancellationToken cancellationToken)
    {
        using var request = new HttpRequestMessage(HttpMethod.Post, $"/api/inventory/product/{productId}/stock/deduct");
        request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", bearerToken);
        request.Content = JsonContent.Create(new DeductStockGatewayRequest(quantity, "Payment succeeded.", orderId));

        using var response = await _httpClient.SendAsync(request, cancellationToken);
        return response.IsSuccessStatusCode;
    }

    private sealed record DeductStockGatewayRequest(int Quantity, string? Reason, Guid? ReferenceId);

    private sealed record InventoryItemGatewayResponse(int AvailableQuantity);

    private sealed class GatewayResult<T>
    {
        public bool Success { get; set; }

        public T? Value { get; set; }
    }
}
