using Microsoft.EntityFrameworkCore;
using Zellamart.Payments.Application.Abstractions;
using Zellamart.Payments.Domain.Payments;

namespace Zellamart.Payments.Infrastructure.Persistence;

public sealed class PaymentRepository : IPaymentRepository
{
    private readonly PaymentsDbContext _dbContext;

    public PaymentRepository(PaymentsDbContext dbContext)
    {
        _dbContext = dbContext;
    }

    public Task<Payment?> GetByIdAsync(Guid paymentId, CancellationToken cancellationToken)
    {
        return _dbContext.Payments.FirstOrDefaultAsync(payment => payment.Id == paymentId, cancellationToken);
    }

    public Task<Payment?> GetPendingByOrderIdAsync(Guid orderId, CancellationToken cancellationToken)
    {
        return _dbContext.Payments.FirstOrDefaultAsync(
            payment => payment.OrderId == orderId && payment.Status == PaymentStatus.Pending,
            cancellationToken);
    }

    public async Task<IReadOnlyList<Payment>> GetByOrderIdAsync(Guid orderId, CancellationToken cancellationToken)
    {
        return await _dbContext.Payments
            .Where(payment => payment.OrderId == orderId)
            .OrderByDescending(payment => payment.CreatedAtUtc)
            .ToArrayAsync(cancellationToken);
    }

    public async Task AddAsync(Payment payment, CancellationToken cancellationToken)
    {
        await _dbContext.Payments.AddAsync(payment, cancellationToken);
    }

    public Task SaveChangesAsync(CancellationToken cancellationToken)
    {
        return _dbContext.SaveChangesAsync(cancellationToken);
    }
}
