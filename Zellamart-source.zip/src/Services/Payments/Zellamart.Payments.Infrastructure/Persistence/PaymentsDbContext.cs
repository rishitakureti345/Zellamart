using Microsoft.EntityFrameworkCore;
using Zellamart.Payments.Domain.Payments;

namespace Zellamart.Payments.Infrastructure.Persistence;

public sealed class PaymentsDbContext : DbContext
{
    public PaymentsDbContext(DbContextOptions<PaymentsDbContext> options)
        : base(options)
    {
    }

    public DbSet<Payment> Payments => Set<Payment>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Payment>(builder =>
        {
            builder.ToTable("payments");
            builder.HasKey(payment => payment.Id);
            builder.Property(payment => payment.Id).ValueGeneratedNever();
            builder.Property(payment => payment.Amount).HasPrecision(18, 2);
            builder.Property(payment => payment.Currency).HasMaxLength(3).IsRequired();
            builder.Property(payment => payment.Provider).HasMaxLength(80).IsRequired();
            builder.Property(payment => payment.FakeSessionId).HasMaxLength(120).IsRequired();
            builder.Property(payment => payment.Status).HasConversion<string>().HasMaxLength(40).IsRequired();
            builder.Property(payment => payment.FailureReason).HasMaxLength(600);
            builder.HasIndex(payment => payment.OrderId);
            builder.HasIndex(payment => payment.CustomerId);
            builder.HasIndex(payment => payment.Status);
            builder.HasIndex(payment => payment.FakeSessionId).IsUnique();
        });
    }
}
