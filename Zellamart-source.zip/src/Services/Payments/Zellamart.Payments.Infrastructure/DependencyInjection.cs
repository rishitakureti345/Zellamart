using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Zellamart.Payments.Application.Abstractions;
using Zellamart.Payments.Infrastructure.Persistence;
using Zellamart.Payments.Infrastructure.Services;

namespace Zellamart.Payments.Infrastructure;

public static class DependencyInjection
{
    public static IServiceCollection AddPaymentsInfrastructure(
        this IServiceCollection services,
        IConfiguration configuration)
    {
        services.AddDbContext<PaymentsDbContext>(options =>
            options.UseNpgsql(configuration.GetConnectionString("Payments")));

        services.AddScoped<IPaymentRepository, PaymentRepository>();

        services.AddHttpClient<IOrderGateway, OrderGateway>(client =>
        {
            client.BaseAddress = new Uri(configuration["ServiceUrls:Orders"] ?? "http://localhost:5106");
        });

        services.AddHttpClient<IInventoryGateway, InventoryGateway>(client =>
        {
            client.BaseAddress = new Uri(configuration["ServiceUrls:Inventory"] ?? "http://localhost:5104");
        });

        services.AddHttpClient<INotificationGateway, NotificationGateway>(client =>
        {
            client.BaseAddress = new Uri(configuration["ServiceUrls:Notifications"] ?? "http://localhost:5108");
        });

        return services;
    }
}
