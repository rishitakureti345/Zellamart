using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Zellamart.Payments.Application.Payments;
using Zellamart.SharedKernel.Results;

namespace Zellamart.Payments.Api.Controllers;

[ApiController]
[Authorize]
[Route("api/payments")]
public sealed class PaymentsController : ControllerBase
{
    private readonly IPaymentService _paymentService;

    public PaymentsController(IPaymentService paymentService)
    {
        _paymentService = paymentService;
    }

    [Authorize(Roles = "SuperAdmin,Admin,Customer,PaymentTeam")]
    [HttpPost("start")]
    public async Task<IActionResult> Start(StartPaymentRequest request, CancellationToken cancellationToken)
    {
        var customerId = GetCurrentUserId();
        if (customerId is null)
        {
            return Unauthorized();
        }

        var result = await _paymentService.StartAsync(
            customerId.Value,
            GetBearerToken(),
            request,
            cancellationToken);

        return result.Success ? Ok(result) : ToFailureResult(result);
    }

    [Authorize(Roles = "SuperAdmin,Admin,Customer,PaymentTeam")]
    [HttpPost("{paymentId:guid}/success")]
    public async Task<IActionResult> MarkSucceeded(Guid paymentId, CancellationToken cancellationToken)
    {
        var customerId = GetCurrentUserId();
        if (customerId is null)
        {
            return Unauthorized();
        }

        var result = await _paymentService.MarkSucceededAsync(
            customerId.Value,
            GetBearerToken(),
            paymentId,
            cancellationToken);

        return result.Success ? Ok(result) : ToFailureResult(result);
    }

    [Authorize(Roles = "SuperAdmin,Admin,Customer,PaymentTeam")]
    [HttpPost("{paymentId:guid}/fail")]
    public async Task<IActionResult> MarkFailed(
        Guid paymentId,
        FailPaymentRequest request,
        CancellationToken cancellationToken)
    {
        var customerId = GetCurrentUserId();
        if (customerId is null)
        {
            return Unauthorized();
        }

        var result = await _paymentService.MarkFailedAsync(
            customerId.Value,
            GetBearerToken(),
            paymentId,
            request,
            cancellationToken);

        return result.Success ? Ok(result) : ToFailureResult(result);
    }

    [Authorize(Roles = "SuperAdmin,Admin,Customer,PaymentTeam")]
    [HttpGet("order/{orderId:guid}")]
    public async Task<IActionResult> GetByOrder(Guid orderId, CancellationToken cancellationToken)
    {
        var customerId = GetCurrentUserId();
        if (customerId is null)
        {
            return Unauthorized();
        }

        var result = await _paymentService.GetByOrderIdAsync(
            customerId.Value,
            GetBearerToken(),
            orderId,
            cancellationToken);

        return result.Success ? Ok(result) : ToFailureResult(result);
    }

    [Authorize(Roles = "SuperAdmin,Admin,OrderManager,FinanceManager,PaymentTeam,SupportManager,SupportAgent,WarehouseManager,InventoryStaff,DeliveryManager,DeliveryPartner")]
    [HttpGet("admin/order/{orderId:guid}")]
    public async Task<IActionResult> GetByOrderForStaff(Guid orderId, CancellationToken cancellationToken)
    {
        var result = await _paymentService.GetByOrderIdForStaffAsync(orderId, cancellationToken);
        return Ok(result);
    }

    private Guid? GetCurrentUserId()
    {
        var userIdValue = User.FindFirstValue(ClaimTypes.NameIdentifier)
            ?? User.FindFirst(JwtRegisteredClaimNames.Sub)?.Value;

        return Guid.TryParse(userIdValue, out var userId) ? userId : null;
    }

    private string GetBearerToken()
    {
        const string prefix = "Bearer ";
        var authorization = Request.Headers.Authorization.ToString();
        return authorization.StartsWith(prefix, StringComparison.OrdinalIgnoreCase)
            ? authorization[prefix.Length..].Trim()
            : string.Empty;
    }

    private IActionResult ToFailureResult<T>(Result<T> result)
    {
        return result.Error.Code switch
        {
            "NotFound" => NotFound(result),
            "Conflict" => Conflict(result),
            _ => BadRequest(result)
        };
    }
}
