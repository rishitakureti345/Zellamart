using Zellamart.SharedKernel.Entities;

namespace Zellamart.Payments.Domain.Payments;

public sealed class Payment : AuditableEntity
{
    private Payment()
    {
    }

    public Payment(
        Guid orderId,
        Guid customerId,
        decimal amount,
        string currency,
        string provider,
        string fakeSessionId)
    {
        if (amount <= 0)
        {
            throw new InvalidOperationException("Payment amount must be greater than zero.");
        }

        OrderId = orderId;
        CustomerId = customerId;
        Amount = amount;
        Currency = currency.Trim().ToUpperInvariant();
        Provider = provider.Trim();
        FakeSessionId = fakeSessionId.Trim();
        Status = PaymentStatus.Pending;
    }

    public Guid OrderId { get; private set; }

    public Guid CustomerId { get; private set; }

    public decimal Amount { get; private set; }

    public string Currency { get; private set; } = "INR";

    public string Provider { get; private set; } = "FakePay";

    public string FakeSessionId { get; private set; } = string.Empty;

    public PaymentStatus Status { get; private set; }

    public string? FailureReason { get; private set; }

    public DateTimeOffset? CompletedAtUtc { get; private set; }

    public void MarkSucceeded()
    {
        if (Status != PaymentStatus.Pending)
        {
            throw new InvalidOperationException("Only pending payments can succeed.");
        }

        Status = PaymentStatus.Succeeded;
        FailureReason = null;
        CompletedAtUtc = DateTimeOffset.UtcNow;
        UpdatedAtUtc = DateTimeOffset.UtcNow;
    }

    public void MarkFailed(string reason)
    {
        if (Status != PaymentStatus.Pending)
        {
            throw new InvalidOperationException("Only pending payments can fail.");
        }

        Status = PaymentStatus.Failed;
        FailureReason = string.IsNullOrWhiteSpace(reason) ? "Payment failed." : reason.Trim();
        CompletedAtUtc = DateTimeOffset.UtcNow;
        UpdatedAtUtc = DateTimeOffset.UtcNow;
    }
}
