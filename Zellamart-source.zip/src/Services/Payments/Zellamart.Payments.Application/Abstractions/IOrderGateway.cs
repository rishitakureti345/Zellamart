using Zellamart.Orders.Domain.Orders;

namespace Zellamart.Payments.Application.Abstractions;

public interface IOrderGateway
{
    Task<OrderSnapshot?> GetOrderAsync(Guid customerId, Guid orderId, string bearerToken, CancellationToken cancellationToken);

    Task<bool> MarkPaymentSucceededAsync(Guid orderId, string bearerToken, CancellationToken cancellationToken);

    Task<bool> MarkPaymentFailedAsync(Guid orderId, string bearerToken, CancellationToken cancellationToken);

    Task<bool> ConfirmAsync(Guid orderId, string bearerToken, CancellationToken cancellationToken);
}

public sealed record OrderSnapshot(
    Guid Id,
    Guid CustomerId,
    OrderStatus Status,
    decimal Subtotal,
    string Currency,
    IReadOnlyList<OrderItemSnapshot> Items);

public sealed record OrderItemSnapshot(
    Guid ProductId,
    Guid SellerId,
    string ProductName,
    decimal UnitPrice,
    int Quantity,
    decimal LineTotal);
