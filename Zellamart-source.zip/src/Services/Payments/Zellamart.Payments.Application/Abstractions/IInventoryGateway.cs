namespace Zellamart.Payments.Application.Abstractions;

public interface IInventoryGateway
{
    Task<bool> HasAvailableStockAsync(
        Guid productId,
        int quantity,
        string bearerToken,
        CancellationToken cancellationToken);

    Task<bool> DeductStockAsync(
        Guid productId,
        int quantity,
        Guid orderId,
        string bearerToken,
        CancellationToken cancellationToken);
}
