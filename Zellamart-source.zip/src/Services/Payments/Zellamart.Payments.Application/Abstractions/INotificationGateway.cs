namespace Zellamart.Payments.Application.Abstractions;

public interface INotificationGateway
{
    Task CreateAsync(
        Guid userId,
        string type,
        string title,
        string message,
        string bearerToken,
        CancellationToken cancellationToken);
}
