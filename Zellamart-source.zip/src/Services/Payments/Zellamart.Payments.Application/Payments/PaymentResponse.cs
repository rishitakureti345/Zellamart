using Zellamart.Payments.Domain.Payments;

namespace Zellamart.Payments.Application.Payments;

public sealed record PaymentResponse(
    Guid Id,
    Guid OrderId,
    Guid CustomerId,
    decimal Amount,
    string Currency,
    string Provider,
    string FakeSessionId,
    PaymentStatus Status,
    string? FailureReason,
    DateTimeOffset CreatedAtUtc,
    DateTimeOffset? CompletedAtUtc);
