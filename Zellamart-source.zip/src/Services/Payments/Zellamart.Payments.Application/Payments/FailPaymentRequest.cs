namespace Zellamart.Payments.Application.Payments;

public sealed record FailPaymentRequest(string? Reason);
