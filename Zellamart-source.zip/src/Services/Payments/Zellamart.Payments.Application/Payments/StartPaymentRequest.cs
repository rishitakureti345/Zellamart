namespace Zellamart.Payments.Application.Payments;

public sealed record StartPaymentRequest(Guid OrderId);
