using Zellamart.SharedKernel.Results;

namespace Zellamart.Payments.Application.Payments;

public interface IPaymentService
{
    Task<Result<PaymentResponse>> StartAsync(
        Guid customerId,
        string bearerToken,
        StartPaymentRequest request,
        CancellationToken cancellationToken);

    Task<Result<PaymentResponse>> MarkSucceededAsync(
        Guid customerId,
        string bearerToken,
        Guid paymentId,
        CancellationToken cancellationToken);

    Task<Result<PaymentResponse>> MarkFailedAsync(
        Guid customerId,
        string bearerToken,
        Guid paymentId,
        FailPaymentRequest request,
        CancellationToken cancellationToken);

    Task<Result<IReadOnlyList<PaymentResponse>>> GetByOrderIdAsync(
        Guid customerId,
        string bearerToken,
        Guid orderId,
        CancellationToken cancellationToken);

    Task<Result<IReadOnlyList<PaymentResponse>>> GetByOrderIdForStaffAsync(
        Guid orderId,
        CancellationToken cancellationToken);
}
