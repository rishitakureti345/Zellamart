using Zellamart.Orders.Domain.Orders;
using Zellamart.Payments.Application.Abstractions;
using Zellamart.Payments.Domain.Payments;
using Zellamart.SharedKernel.Results;

namespace Zellamart.Payments.Application.Payments;

public sealed class PaymentService : IPaymentService
{
    private readonly IPaymentRepository _repository;
    private readonly IOrderGateway _orderGateway;
    private readonly IInventoryGateway _inventoryGateway;
    private readonly INotificationGateway _notificationGateway;

    public PaymentService(
        IPaymentRepository repository,
        IOrderGateway orderGateway,
        IInventoryGateway inventoryGateway,
        INotificationGateway notificationGateway)
    {
        _repository = repository;
        _orderGateway = orderGateway;
        _inventoryGateway = inventoryGateway;
        _notificationGateway = notificationGateway;
    }

    public async Task<Result<PaymentResponse>> StartAsync(
        Guid customerId,
        string bearerToken,
        StartPaymentRequest request,
        CancellationToken cancellationToken)
    {
        if (request.OrderId == Guid.Empty)
        {
            return Result.Fail<PaymentResponse>(Error.Validation("Order id is required."));
        }

        var order = await _orderGateway.GetOrderAsync(customerId, request.OrderId, bearerToken, cancellationToken);
        if (order is null)
        {
            return Result.Fail<PaymentResponse>(Error.NotFound("Order was not found."));
        }

        if (order.Status != OrderStatus.PendingPayment)
        {
            return Result.Fail<PaymentResponse>(Error.Validation("Payment can start only for pending payment orders."));
        }

        var existingPendingPayment = await _repository.GetPendingByOrderIdAsync(request.OrderId, cancellationToken);
        if (existingPendingPayment is not null)
        {
            return Result.Fail<PaymentResponse>(Error.Conflict("A pending payment already exists for this order."));
        }

        var payment = new Payment(
            order.Id,
            customerId,
            order.Subtotal,
            order.Currency,
            "FakePay",
            $"fake_{Guid.NewGuid():N}");

        await _repository.AddAsync(payment, cancellationToken);
        await _repository.SaveChangesAsync(cancellationToken);

        return Result.Ok(ToResponse(payment));
    }

    public async Task<Result<PaymentResponse>> MarkSucceededAsync(
        Guid customerId,
        string bearerToken,
        Guid paymentId,
        CancellationToken cancellationToken)
    {
        var paymentResult = await GetOwnedPendingPaymentAsync(customerId, paymentId, cancellationToken);
        if (paymentResult.IsFailure)
        {
            return Result.Fail<PaymentResponse>(paymentResult.Error);
        }

        var payment = paymentResult.Value!;
        var order = await _orderGateway.GetOrderAsync(customerId, payment.OrderId, bearerToken, cancellationToken);
        if (order is null)
        {
            return Result.Fail<PaymentResponse>(Error.NotFound("Order was not found."));
        }

        if (order.Status != OrderStatus.PendingPayment)
        {
            return Result.Fail<PaymentResponse>(Error.Validation("Payment can succeed only for pending payment orders."));
        }

        foreach (var item in order.Items)
        {
            var hasStock = await _inventoryGateway.HasAvailableStockAsync(
                item.ProductId,
                item.Quantity,
                bearerToken,
                cancellationToken);

            if (!hasStock)
            {
                return Result.Fail<PaymentResponse>(Error.Validation($"Insufficient stock for product {item.ProductName}."));
            }
        }

        foreach (var item in order.Items)
        {
            var deducted = await _inventoryGateway.DeductStockAsync(
                item.ProductId,
                item.Quantity,
                payment.OrderId,
                bearerToken,
                cancellationToken);

            if (!deducted)
            {
                return Result.Fail<PaymentResponse>(Error.Validation($"Stock deduction failed for product {item.ProductName}."));
            }
        }

        payment.MarkSucceeded();
        await _repository.SaveChangesAsync(cancellationToken);

        if (!await _orderGateway.MarkPaymentSucceededAsync(payment.OrderId, bearerToken, cancellationToken))
        {
            return Result.Fail<PaymentResponse>(Error.Validation("Order payment success update failed."));
        }

        if (!await _orderGateway.ConfirmAsync(payment.OrderId, bearerToken, cancellationToken))
        {
            return Result.Fail<PaymentResponse>(Error.Validation("Order confirmation failed."));
        }

        await _notificationGateway.CreateAsync(
            customerId,
            "OrderConfirmed",
            "Order confirmed",
            $"Your order {payment.OrderId} has been confirmed.",
            bearerToken,
            cancellationToken);

        return Result.Ok(ToResponse(payment));
    }

    public async Task<Result<PaymentResponse>> MarkFailedAsync(
        Guid customerId,
        string bearerToken,
        Guid paymentId,
        FailPaymentRequest request,
        CancellationToken cancellationToken)
    {
        var paymentResult = await GetOwnedPendingPaymentAsync(customerId, paymentId, cancellationToken);
        if (paymentResult.IsFailure)
        {
            return Result.Fail<PaymentResponse>(paymentResult.Error);
        }

        var payment = paymentResult.Value!;
        payment.MarkFailed(request.Reason ?? "Fake payment failed.");
        await _repository.SaveChangesAsync(cancellationToken);

        if (!await _orderGateway.MarkPaymentFailedAsync(payment.OrderId, bearerToken, cancellationToken))
        {
            return Result.Fail<PaymentResponse>(Error.Validation("Order payment failure update failed."));
        }

        await _notificationGateway.CreateAsync(
            customerId,
            "PaymentFailed",
            "Payment failed",
            $"Payment for order {payment.OrderId} failed.",
            bearerToken,
            cancellationToken);

        return Result.Ok(ToResponse(payment));
    }

    public async Task<Result<IReadOnlyList<PaymentResponse>>> GetByOrderIdAsync(
        Guid customerId,
        string bearerToken,
        Guid orderId,
        CancellationToken cancellationToken)
    {
        var order = await _orderGateway.GetOrderAsync(customerId, orderId, bearerToken, cancellationToken);
        if (order is null)
        {
            return Result.Fail<IReadOnlyList<PaymentResponse>>(Error.NotFound("Order was not found."));
        }

        var payments = await _repository.GetByOrderIdAsync(orderId, cancellationToken);
        return Result.Ok<IReadOnlyList<PaymentResponse>>(payments.Select(ToResponse).ToArray());
    }

    public async Task<Result<IReadOnlyList<PaymentResponse>>> GetByOrderIdForStaffAsync(
        Guid orderId,
        CancellationToken cancellationToken)
    {
        var payments = await _repository.GetByOrderIdAsync(orderId, cancellationToken);
        return Result.Ok<IReadOnlyList<PaymentResponse>>(payments.Select(ToResponse).ToArray());
    }

    private async Task<Result<Payment>> GetOwnedPendingPaymentAsync(
        Guid customerId,
        Guid paymentId,
        CancellationToken cancellationToken)
    {
        var payment = await _repository.GetByIdAsync(paymentId, cancellationToken);
        if (payment is null || payment.CustomerId != customerId)
        {
            return Result.Fail<Payment>(Error.NotFound("Payment was not found."));
        }

        if (payment.Status != PaymentStatus.Pending)
        {
            return Result.Fail<Payment>(Error.Conflict("Payment is no longer pending."));
        }

        return Result.Ok(payment);
    }

    private static PaymentResponse ToResponse(Payment payment)
    {
        return new PaymentResponse(
            payment.Id,
            payment.OrderId,
            payment.CustomerId,
            payment.Amount,
            payment.Currency,
            payment.Provider,
            payment.FakeSessionId,
            payment.Status,
            payment.FailureReason,
            payment.CreatedAtUtc,
            payment.CompletedAtUtc);
    }
}
