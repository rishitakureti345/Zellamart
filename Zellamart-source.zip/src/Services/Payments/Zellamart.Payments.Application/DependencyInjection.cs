using Microsoft.Extensions.DependencyInjection;
using Zellamart.Payments.Application.Payments;

namespace Zellamart.Payments.Application;

public static class DependencyInjection
{
    public static IServiceCollection AddPaymentsApplication(this IServiceCollection services)
    {
        services.AddScoped<IPaymentService, PaymentService>();

        return services;
    }
}
