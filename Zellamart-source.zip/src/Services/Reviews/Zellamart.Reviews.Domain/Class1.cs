﻿namespace Zellamart.Reviews.Domain;

public class Class1
{

}
