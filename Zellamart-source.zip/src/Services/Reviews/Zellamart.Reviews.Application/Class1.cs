﻿namespace Zellamart.Reviews.Application;

public class Class1
{

}
