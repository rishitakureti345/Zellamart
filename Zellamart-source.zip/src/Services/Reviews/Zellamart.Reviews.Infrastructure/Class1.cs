﻿namespace Zellamart.Reviews.Infrastructure;

public class Class1
{

}
