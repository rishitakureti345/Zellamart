using Microsoft.EntityFrameworkCore;
using Zellamart.Notifications.Domain.Notifications;

namespace Zellamart.Notifications.Infrastructure.Persistence;

public sealed class NotificationsDbContext : DbContext
{
    public NotificationsDbContext(DbContextOptions<NotificationsDbContext> options)
        : base(options)
    {
    }

    public DbSet<Notification> Notifications => Set<Notification>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Notification>(builder =>
        {
            builder.ToTable("notifications");
            builder.HasKey(notification => notification.Id);
            builder.Property(notification => notification.Id).ValueGeneratedNever();
            builder.Property(notification => notification.Type).HasMaxLength(80).IsRequired();
            builder.Property(notification => notification.Title).HasMaxLength(160).IsRequired();
            builder.Property(notification => notification.Message).HasMaxLength(800).IsRequired();
            builder.HasIndex(notification => notification.UserId);
            builder.HasIndex(notification => notification.IsRead);
            builder.HasIndex(notification => notification.Type);
        });
    }
}
