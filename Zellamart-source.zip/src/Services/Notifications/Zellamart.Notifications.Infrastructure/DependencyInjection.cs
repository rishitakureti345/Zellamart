using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Zellamart.Notifications.Application.Abstractions;
using Zellamart.Notifications.Infrastructure.Persistence;

namespace Zellamart.Notifications.Infrastructure;

public static class DependencyInjection
{
    public static IServiceCollection AddNotificationsInfrastructure(
        this IServiceCollection services,
        IConfiguration configuration)
    {
        services.AddDbContext<NotificationsDbContext>(options =>
            options.UseNpgsql(configuration.GetConnectionString("Notifications")));

        services.AddScoped<INotificationRepository, NotificationRepository>();

        return services;
    }
}
