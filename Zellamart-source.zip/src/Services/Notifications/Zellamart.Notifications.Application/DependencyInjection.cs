using Microsoft.Extensions.DependencyInjection;
using Zellamart.Notifications.Application.Notifications;

namespace Zellamart.Notifications.Application;

public static class DependencyInjection
{
    public static IServiceCollection AddNotificationsApplication(this IServiceCollection services)
    {
        services.AddScoped<INotificationService, NotificationService>();

        return services;
    }
}
