using Zellamart.SharedKernel.Results;

namespace Zellamart.Notifications.Application.Notifications;

public interface INotificationService
{
    Task<Result<NotificationResponse>> CreateAsync(CreateNotificationRequest request, CancellationToken cancellationToken);

    Task<Result<IReadOnlyList<NotificationResponse>>> GetMineAsync(Guid userId, CancellationToken cancellationToken);

    Task<Result<IReadOnlyList<NotificationResponse>>> GetAllForStaffAsync(CancellationToken cancellationToken);

    Task<Result<NotificationResponse>> MarkReadAsync(Guid userId, Guid notificationId, CancellationToken cancellationToken);
}
