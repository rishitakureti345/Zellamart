using Zellamart.Notifications.Application.Abstractions;
using Zellamart.Notifications.Domain.Notifications;
using Zellamart.SharedKernel.Results;

namespace Zellamart.Notifications.Application.Notifications;

public sealed class NotificationService : INotificationService
{
    private readonly INotificationRepository _repository;

    public NotificationService(INotificationRepository repository)
    {
        _repository = repository;
    }

    public async Task<Result<NotificationResponse>> CreateAsync(
        CreateNotificationRequest request,
        CancellationToken cancellationToken)
    {
        if (request.UserId == Guid.Empty)
        {
            return Result.Fail<NotificationResponse>(Error.Validation("User id is required."));
        }

        if (string.IsNullOrWhiteSpace(request.Type))
        {
            return Result.Fail<NotificationResponse>(Error.Validation("Notification type is required."));
        }

        if (string.IsNullOrWhiteSpace(request.Title))
        {
            return Result.Fail<NotificationResponse>(Error.Validation("Notification title is required."));
        }

        if (string.IsNullOrWhiteSpace(request.Message))
        {
            return Result.Fail<NotificationResponse>(Error.Validation("Notification message is required."));
        }

        var notification = new Notification(request.UserId, request.Type, request.Title, request.Message);
        await _repository.AddAsync(notification, cancellationToken);
        await _repository.SaveChangesAsync(cancellationToken);

        return Result.Ok(ToResponse(notification));
    }

    public async Task<Result<IReadOnlyList<NotificationResponse>>> GetMineAsync(
        Guid userId,
        CancellationToken cancellationToken)
    {
        var notifications = await _repository.GetByUserIdAsync(userId, cancellationToken);
        return Result.Ok<IReadOnlyList<NotificationResponse>>(notifications.Select(ToResponse).ToArray());
    }

    public async Task<Result<IReadOnlyList<NotificationResponse>>> GetAllForStaffAsync(CancellationToken cancellationToken)
    {
        var notifications = await _repository.GetAllAsync(cancellationToken);
        return Result.Ok<IReadOnlyList<NotificationResponse>>(notifications.Select(ToResponse).ToArray());
    }

    public async Task<Result<NotificationResponse>> MarkReadAsync(
        Guid userId,
        Guid notificationId,
        CancellationToken cancellationToken)
    {
        var notification = await _repository.GetByIdAsync(notificationId, cancellationToken);
        if (notification is null || notification.UserId != userId)
        {
            return Result.Fail<NotificationResponse>(Error.NotFound("Notification was not found."));
        }

        notification.MarkRead();
        await _repository.SaveChangesAsync(cancellationToken);

        return Result.Ok(ToResponse(notification));
    }

    private static NotificationResponse ToResponse(Notification notification)
    {
        return new NotificationResponse(
            notification.Id,
            notification.UserId,
            notification.Type,
            notification.Title,
            notification.Message,
            notification.IsRead,
            notification.CreatedAtUtc,
            notification.ReadAtUtc);
    }
}
