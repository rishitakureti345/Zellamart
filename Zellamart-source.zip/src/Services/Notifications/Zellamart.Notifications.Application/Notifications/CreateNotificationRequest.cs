namespace Zellamart.Notifications.Application.Notifications;

public sealed record CreateNotificationRequest(
    Guid UserId,
    string Type,
    string Title,
    string Message);
