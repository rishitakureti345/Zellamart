using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Primitives;
using Zellamart.Notifications.Application.Notifications;
using Zellamart.SharedKernel.Results;

namespace Zellamart.Notifications.Api.Controllers;

[ApiController]
[Authorize]
[Route("api/notifications")]
public sealed class NotificationsController : ControllerBase
{
    private const string InternalServiceKeyHeader = "X-Internal-Service-Key";

    private readonly INotificationService _notificationService;
    private readonly IConfiguration _configuration;

    public NotificationsController(
        INotificationService notificationService,
        IConfiguration configuration)
    {
        _notificationService = notificationService;
        _configuration = configuration;
    }

    [HttpPost]
    [AllowAnonymous]
    public async Task<IActionResult> Create(CreateNotificationRequest request, CancellationToken cancellationToken)
    {
        if (!CanCreateNotification())
        {
            return Forbid();
        }

        var result = await _notificationService.CreateAsync(request, cancellationToken);
        return result.Success ? Ok(result) : ToFailureResult(result);
    }

    [HttpGet("me")]
    public async Task<IActionResult> GetMine(CancellationToken cancellationToken)
    {
        var userId = GetCurrentUserId();
        if (userId is null)
        {
            return Unauthorized();
        }

        var result = await _notificationService.GetMineAsync(userId.Value, cancellationToken);
        return Ok(result);
    }

    [HttpGet("admin/all")]
    [Authorize(Roles = "SuperAdmin,Admin,SupportManager,FinanceManager,OrderManager")]
    public async Task<IActionResult> GetAllForStaff(CancellationToken cancellationToken)
    {
        var result = await _notificationService.GetAllForStaffAsync(cancellationToken);
        return Ok(result);
    }

    [HttpPost("{notificationId:guid}/read")]
    public async Task<IActionResult> MarkRead(Guid notificationId, CancellationToken cancellationToken)
    {
        var userId = GetCurrentUserId();
        if (userId is null)
        {
            return Unauthorized();
        }

        var result = await _notificationService.MarkReadAsync(userId.Value, notificationId, cancellationToken);
        return result.Success ? Ok(result) : ToFailureResult(result);
    }

    private Guid? GetCurrentUserId()
    {
        var userIdValue = User.FindFirstValue(ClaimTypes.NameIdentifier)
            ?? User.FindFirst(JwtRegisteredClaimNames.Sub)?.Value;

        return Guid.TryParse(userIdValue, out var userId) ? userId : null;
    }

    private bool CanCreateNotification()
    {
        if (IsInternalRequest())
        {
            return true;
        }

        return User.Identity?.IsAuthenticated == true
            && (User.IsInRole("SuperAdmin")
                || User.IsInRole("Admin")
                || User.IsInRole("OrderManager")
                || User.IsInRole("SupportManager")
                || User.IsInRole("FinanceManager")
                || User.IsInRole("PaymentTeam"));
    }

    private bool IsInternalRequest()
    {
        var configuredKey = _configuration["InternalService:NotificationKey"];
        if (string.IsNullOrWhiteSpace(configuredKey))
        {
            return false;
        }

        return Request.Headers.TryGetValue(InternalServiceKeyHeader, out StringValues providedKey)
            && StringComparer.Ordinal.Equals(providedKey.ToString(), configuredKey);
    }

    private IActionResult ToFailureResult<T>(Result<T> result)
    {
        return result.Error.Code switch
        {
            "NotFound" => NotFound(result),
            "Unauthorized" => Forbid(),
            _ => BadRequest(result)
        };
    }
}
