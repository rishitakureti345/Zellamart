using Zellamart.SharedKernel.Entities;

namespace Zellamart.Notifications.Domain.Notifications;

public sealed class Notification : AuditableEntity
{
    private Notification()
    {
    }

    public Notification(Guid userId, string type, string title, string message)
    {
        UserId = userId;
        Type = type.Trim();
        Title = title.Trim();
        Message = message.Trim();
        IsRead = false;
    }

    public Guid UserId { get; private set; }

    public string Type { get; private set; } = string.Empty;

    public string Title { get; private set; } = string.Empty;

    public string Message { get; private set; } = string.Empty;

    public bool IsRead { get; private set; }

    public DateTimeOffset? ReadAtUtc { get; private set; }

    public void MarkRead()
    {
        if (IsRead)
        {
            return;
        }

        IsRead = true;
        ReadAtUtc = DateTimeOffset.UtcNow;
        UpdatedAtUtc = DateTimeOffset.UtcNow;
    }
}
