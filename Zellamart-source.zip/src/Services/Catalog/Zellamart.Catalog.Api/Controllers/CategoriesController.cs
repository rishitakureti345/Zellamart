using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Zellamart.Catalog.Application.Categories;

namespace Zellamart.Catalog.Api.Controllers;

[ApiController]
[Route("api/categories")]
public sealed class CategoriesController : ControllerBase
{
    private readonly ICategoryService _categoryService;

    public CategoriesController(ICategoryService categoryService)
    {
        _categoryService = categoryService;
    }

    [AllowAnonymous]
    [HttpGet]
    public async Task<IActionResult> GetActive(CancellationToken cancellationToken)
    {
        var result = await _categoryService.GetActiveAsync(cancellationToken);
        return Ok(result);
    }

    [Authorize(Roles = "SuperAdmin,Admin,ProductManager")]
    [HttpGet("admin/all")]
    public async Task<IActionResult> GetAllForAdmin(CancellationToken cancellationToken)
    {
        var result = await _categoryService.GetAllForAdminAsync(cancellationToken);
        return Ok(result);
    }

    [Authorize(Roles = "SuperAdmin,Admin,ProductManager")]
    [HttpPost]
    public async Task<IActionResult> Create(CategoryRequest request, CancellationToken cancellationToken)
    {
        var result = await _categoryService.CreateAsync(request, cancellationToken);
        return result.Success ? Ok(result) : BadRequest(result);
    }

    [Authorize(Roles = "SuperAdmin,Admin,ProductManager")]
    [HttpPut("{categoryId:guid}")]
    public async Task<IActionResult> Update(Guid categoryId, CategoryRequest request, CancellationToken cancellationToken)
    {
        var result = await _categoryService.UpdateAsync(categoryId, request, cancellationToken);
        return result.Success ? Ok(result) : BadRequest(result);
    }

    [Authorize(Roles = "SuperAdmin,Admin,ProductManager")]
    [HttpDelete("{categoryId:guid}")]
    public async Task<IActionResult> Deactivate(Guid categoryId, CancellationToken cancellationToken)
    {
        var result = await _categoryService.DeactivateAsync(categoryId, cancellationToken);
        return result.Success ? Ok(result) : NotFound(result);
    }

    [Authorize(Roles = "SuperAdmin,Admin,ProductManager")]
    [HttpPost("{categoryId:guid}/activate")]
    public async Task<IActionResult> Activate(Guid categoryId, CancellationToken cancellationToken)
    {
        var result = await _categoryService.ActivateAsync(categoryId, cancellationToken);
        return result.Success ? Ok(result) : NotFound(result);
    }
}
