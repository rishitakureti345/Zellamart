using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Zellamart.Catalog.Application.Abstractions;
using Zellamart.Catalog.Application.Products;
using Zellamart.SharedKernel.Results;

namespace Zellamart.Catalog.Api.Controllers;

[ApiController]
[Route("api/products")]
public sealed class ProductsController : ControllerBase
{
    private readonly IProductService _productService;
    private readonly ISellerProfileGateway _sellerProfileGateway;

    public ProductsController(
        IProductService productService,
        ISellerProfileGateway sellerProfileGateway)
    {
        _productService = productService;
        _sellerProfileGateway = sellerProfileGateway;
    }

    [AllowAnonymous]
    [HttpGet]
    public async Task<IActionResult> GetApproved(
        [FromQuery] Guid? categoryId,
        [FromQuery] string? search,
        CancellationToken cancellationToken)
    {
        var result = await _productService.GetApprovedAsync(categoryId, search, cancellationToken);
        return Ok(result);
    }

    [AllowAnonymous]
    [HttpGet("{productId:guid}")]
    public async Task<IActionResult> GetById(Guid productId, CancellationToken cancellationToken)
    {
        var result = await _productService.GetApprovedByIdAsync(productId, cancellationToken);
        return result.Success ? Ok(result) : NotFound(result);
    }

    [Authorize(Roles = "SuperAdmin,Admin,Seller")]
    [RequestSizeLimit(5 * 1024 * 1024)]
    [HttpPost("images")]
    public async Task<IActionResult> UploadImage([FromForm] IFormFile? image, CancellationToken cancellationToken)
    {
        if (image is null || image.Length == 0)
        {
            return BadRequest(Result.Fail(Error.Validation("Product image is required.")));
        }

        if (image.Length > 5 * 1024 * 1024)
        {
            return BadRequest(Result.Fail(Error.Validation("Product image must be 5 MB or smaller.")));
        }

        var extension = Path.GetExtension(image.FileName).ToLowerInvariant();
        var allowedExtensions = new HashSet<string>(StringComparer.OrdinalIgnoreCase) { ".jpg", ".jpeg", ".png", ".webp", ".gif" };
        if (!allowedExtensions.Contains(extension) || !image.ContentType.StartsWith("image/", StringComparison.OrdinalIgnoreCase))
        {
            return BadRequest(Result.Fail(Error.Validation("Only image files are allowed.")));
        }

        var uploadsPath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "uploads", "products");
        Directory.CreateDirectory(uploadsPath);

        var fileName = $"{Guid.NewGuid():N}{extension}";
        var filePath = Path.Combine(uploadsPath, fileName);
        await using (var stream = System.IO.File.Create(filePath))
        {
            await image.CopyToAsync(stream, cancellationToken);
        }

        var imageUrl = $"/api/products/images/{fileName}";
        return Ok(Result.Ok(new ProductImageUploadResponse(imageUrl, fileName)));
    }

    [AllowAnonymous]
    [HttpGet("images/{fileName}")]
    public IActionResult GetImage(string fileName)
    {
        var safeFileName = Path.GetFileName(fileName);
        var filePath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "uploads", "products", safeFileName);
        if (!System.IO.File.Exists(filePath))
        {
            return NotFound();
        }

        return PhysicalFile(filePath, GetImageContentType(Path.GetExtension(safeFileName)));
    }

    [Authorize(Roles = "SuperAdmin,Admin,Seller")]
    [HttpPost("submit")]
    public async Task<IActionResult> Submit(SubmitProductRequest request, CancellationToken cancellationToken)
    {
        if (User.IsInRole("Seller"))
        {
            var seller = await GetCurrentSellerAsync(cancellationToken);
            if (seller is null)
            {
                return Forbid();
            }

            if (!string.Equals(seller.Status, "Approved", StringComparison.OrdinalIgnoreCase))
            {
                return BadRequest(Zellamart.SharedKernel.Results.Result.Fail<ProductResponse>(
                    Zellamart.SharedKernel.Results.Error.Validation("Seller must be approved before submitting products.")));
            }

            request = request with { SellerId = seller.Id };
        }

        var result = await _productService.SubmitAsync(request, cancellationToken);
        return result.Success ? Ok(result) : BadRequest(result);
    }

    [Authorize(Roles = "SuperAdmin,Admin,Seller")]
    [HttpGet("seller/{sellerId:guid}")]
    public async Task<IActionResult> GetBySeller(Guid sellerId, CancellationToken cancellationToken)
    {
        if (User.IsInRole("Seller"))
        {
            var seller = await GetCurrentSellerAsync(cancellationToken);
            if (seller is null)
            {
                return Forbid();
            }

            if (seller.Id != sellerId)
            {
                return Forbid();
            }
        }

        var result = await _productService.GetBySellerAsync(sellerId, cancellationToken);
        return Ok(result);
    }

    [Authorize(Roles = "SuperAdmin,Admin,Seller,ProductManager")]
    [HttpPut("{productId:guid}")]
    public async Task<IActionResult> Update(Guid productId, UpdateProductRequest request, CancellationToken cancellationToken)
    {
        var userId = GetCurrentUserId();
        if (userId is null)
        {
            return Unauthorized();
        }

        if (User.IsInRole("Seller") && !User.IsInRole("SuperAdmin") && !User.IsInRole("Admin"))
        {
            var existing = await _productService.GetByIdAsync(productId, cancellationToken);
            var seller = await GetCurrentSellerAsync(cancellationToken);
            if (!existing.Success || seller is null || existing.Value?.SellerId != seller.Id)
            {
                return Forbid();
            }
        }

        var result = await _productService.UpdateAsync(productId, userId.Value, request, cancellationToken);
        return result.Success ? Ok(result) : BadRequest(result);
    }

    [Authorize(Roles = "SuperAdmin,Admin,ProductManager,InventoryStaff,WarehouseManager")]
    [HttpGet("pending")]
    public async Task<IActionResult> GetPending(CancellationToken cancellationToken)
    {
        var result = await _productService.GetPendingAsync(cancellationToken);
        return Ok(result);
    }

    [Authorize(Roles = "SuperAdmin,Admin,ProductManager,InventoryStaff,WarehouseManager")]
    [HttpGet("admin/all")]
    public async Task<IActionResult> GetAllForAdmin(CancellationToken cancellationToken)
    {
        var result = await _productService.GetAllForAdminAsync(cancellationToken);
        return Ok(result);
    }

    [Authorize(Roles = "SuperAdmin,Admin,ProductManager")]
    [HttpPost("{productId:guid}/approve")]
    public async Task<IActionResult> Approve(Guid productId, CancellationToken cancellationToken)
    {
        var userId = GetCurrentUserId();
        if (userId is null)
        {
            return Unauthorized();
        }

        var result = await _productService.ApproveAsync(productId, userId.Value, cancellationToken);
        return result.Success ? Ok(result) : NotFound(result);
    }

    [Authorize(Roles = "SuperAdmin,Admin,ProductManager")]
    [HttpPost("{productId:guid}/reject")]
    public async Task<IActionResult> Reject(Guid productId, RejectProductRequest request, CancellationToken cancellationToken)
    {
        var userId = GetCurrentUserId();
        if (userId is null)
        {
            return Unauthorized();
        }

        var result = await _productService.RejectAsync(productId, userId.Value, request, cancellationToken);
        return result.Success ? Ok(result) : NotFound(result);
    }

    [Authorize(Roles = "SuperAdmin,Admin,ProductManager")]
    [HttpPost("{productId:guid}/disable")]
    public async Task<IActionResult> Disable(Guid productId, RejectProductRequest request, CancellationToken cancellationToken)
    {
        var userId = GetCurrentUserId();
        if (userId is null)
        {
            return Unauthorized();
        }

        var result = await _productService.DisableAsync(productId, userId.Value, request, cancellationToken);
        return result.Success ? Ok(result) : NotFound(result);
    }

    private Guid? GetCurrentUserId()
    {
        var userIdValue = User.FindFirstValue(ClaimTypes.NameIdentifier)
            ?? User.FindFirst(JwtRegisteredClaimNames.Sub)?.Value;

        return Guid.TryParse(userIdValue, out var userId) ? userId : null;
    }

    private async Task<SellerProfileSnapshot?> GetCurrentSellerAsync(CancellationToken cancellationToken)
    {
        var bearerToken = GetBearerToken();
        return string.IsNullOrWhiteSpace(bearerToken)
            ? null
            : await _sellerProfileGateway.GetMineAsync(bearerToken, cancellationToken);
    }

    private string? GetBearerToken()
    {
        var authorization = Request.Headers.Authorization.ToString();
        return authorization.StartsWith("Bearer ", StringComparison.OrdinalIgnoreCase)
            ? authorization["Bearer ".Length..].Trim()
            : null;
    }

    private static string GetImageContentType(string extension)
    {
        return extension.ToLowerInvariant() switch
        {
            ".jpg" or ".jpeg" => "image/jpeg",
            ".png" => "image/png",
            ".webp" => "image/webp",
            ".gif" => "image/gif",
            _ => "application/octet-stream"
        };
    }

    private sealed record ProductImageUploadResponse(string ImageUrl, string FileName);
}
