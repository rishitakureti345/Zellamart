using Microsoft.Extensions.Logging;
using Zellamart.Catalog.Application.Abstractions;
using Zellamart.Catalog.Domain.Products;
using Zellamart.Contracts.Events.Catalog;

namespace Zellamart.Catalog.Infrastructure.Events;

public sealed class LoggingCatalogEventPublisher : ICatalogEventPublisher
{
    private readonly ILogger<LoggingCatalogEventPublisher> _logger;

    public LoggingCatalogEventPublisher(ILogger<LoggingCatalogEventPublisher> logger)
    {
        _logger = logger;
    }

    public Task PublishSubmittedAsync(Product product, CancellationToken cancellationToken)
    {
        var integrationEvent = new ProductSubmittedEvent(
            Guid.NewGuid(),
            DateTimeOffset.UtcNow,
            product.Id,
            product.SellerId,
            product.Name);

        LogEvent(integrationEvent);
        return Task.CompletedTask;
    }

    public Task PublishApprovedAsync(Product product, Guid approvedByUserId, CancellationToken cancellationToken)
    {
        var integrationEvent = new ProductApprovedEvent(
            Guid.NewGuid(),
            DateTimeOffset.UtcNow,
            product.Id,
            product.SellerId,
            product.Name,
            approvedByUserId);

        LogEvent(integrationEvent);
        return Task.CompletedTask;
    }

    public Task PublishRejectedAsync(
        Product product,
        Guid rejectedByUserId,
        string reason,
        CancellationToken cancellationToken)
    {
        var integrationEvent = new ProductRejectedEvent(
            Guid.NewGuid(),
            DateTimeOffset.UtcNow,
            product.Id,
            product.SellerId,
            rejectedByUserId,
            reason);

        LogEvent(integrationEvent);
        return Task.CompletedTask;
    }

    private void LogEvent<TEvent>(TEvent integrationEvent)
        where TEvent : class
    {
        _logger.LogInformation(
            "Integration event ready: {EventType} {@IntegrationEvent}",
            typeof(TEvent).Name,
            integrationEvent);
    }
}
