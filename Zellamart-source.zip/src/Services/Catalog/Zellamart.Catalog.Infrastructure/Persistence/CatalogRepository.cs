using Microsoft.EntityFrameworkCore;
using Zellamart.Catalog.Application.Abstractions;
using Zellamart.Catalog.Domain.Categories;
using Zellamart.Catalog.Domain.Products;

namespace Zellamart.Catalog.Infrastructure.Persistence;

public sealed class CatalogRepository : ICatalogRepository
{
    private readonly CatalogDbContext _dbContext;

    public CatalogRepository(CatalogDbContext dbContext)
    {
        _dbContext = dbContext;
    }

    public Task<Category?> GetCategoryByIdAsync(Guid categoryId, CancellationToken cancellationToken)
    {
        return _dbContext.Categories.FirstOrDefaultAsync(category => category.Id == categoryId, cancellationToken);
    }

    public Task<Category?> GetCategoryBySlugAsync(string slug, CancellationToken cancellationToken)
    {
        return _dbContext.Categories.FirstOrDefaultAsync(category => category.Slug == slug, cancellationToken);
    }

    public async Task<IReadOnlyList<Category>> GetActiveCategoriesAsync(CancellationToken cancellationToken)
    {
        return await _dbContext.Categories
            .Where(category => category.IsActive)
            .OrderBy(category => category.Name)
            .ToArrayAsync(cancellationToken);
    }

    public async Task<IReadOnlyList<Category>> GetAllCategoriesAsync(CancellationToken cancellationToken)
    {
        return await _dbContext.Categories
            .OrderBy(category => category.Name)
            .ToArrayAsync(cancellationToken);
    }

    public async Task AddCategoryAsync(Category category, CancellationToken cancellationToken)
    {
        await _dbContext.Categories.AddAsync(category, cancellationToken);
    }

    public Task<Product?> GetProductByIdAsync(Guid productId, CancellationToken cancellationToken)
    {
        return _dbContext.Products.FirstOrDefaultAsync(product => product.Id == productId, cancellationToken);
    }

    public Task<Product?> GetApprovedProductByIdAsync(Guid productId, CancellationToken cancellationToken)
    {
        return _dbContext.Products.FirstOrDefaultAsync(
            product => product.Id == productId && product.Status == ProductStatus.Approved,
            cancellationToken);
    }

    public async Task<IReadOnlyList<Product>> GetPendingProductsAsync(CancellationToken cancellationToken)
    {
        return await _dbContext.Products
            .Where(product => product.Status == ProductStatus.Pending)
            .OrderBy(product => product.CreatedAtUtc)
            .ToArrayAsync(cancellationToken);
    }

    public async Task<IReadOnlyList<Product>> GetAllProductsAsync(CancellationToken cancellationToken)
    {
        return await _dbContext.Products
            .OrderByDescending(product => product.CreatedAtUtc)
            .ToArrayAsync(cancellationToken);
    }

    public async Task<IReadOnlyList<Product>> GetApprovedProductsAsync(
        Guid? categoryId,
        string? search,
        CancellationToken cancellationToken)
    {
        var query = _dbContext.Products
            .Where(product => product.Status == ProductStatus.Approved);

        if (categoryId is not null)
        {
            query = query.Where(product => product.CategoryId == categoryId.Value);
        }

        if (!string.IsNullOrWhiteSpace(search))
        {
            var normalizedSearch = search.Trim().ToLowerInvariant();
            query = query.Where(product =>
                product.Name.ToLower().Contains(normalizedSearch) ||
                product.Description.ToLower().Contains(normalizedSearch));
        }

        return await query
            .OrderBy(product => product.Name)
            .ToArrayAsync(cancellationToken);
    }

    public async Task<IReadOnlyList<Product>> GetProductsBySellerAsync(Guid sellerId, CancellationToken cancellationToken)
    {
        return await _dbContext.Products
            .Where(product => product.SellerId == sellerId)
            .OrderByDescending(product => product.CreatedAtUtc)
            .ToArrayAsync(cancellationToken);
    }

    public async Task AddProductAsync(Product product, CancellationToken cancellationToken)
    {
        await _dbContext.Products.AddAsync(product, cancellationToken);
    }

    public Task SaveChangesAsync(CancellationToken cancellationToken)
    {
        return _dbContext.SaveChangesAsync(cancellationToken);
    }
}
