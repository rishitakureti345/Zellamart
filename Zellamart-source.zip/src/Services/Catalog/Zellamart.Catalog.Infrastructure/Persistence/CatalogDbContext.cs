using Microsoft.EntityFrameworkCore;
using Zellamart.Catalog.Domain.Categories;
using Zellamart.Catalog.Domain.Products;

namespace Zellamart.Catalog.Infrastructure.Persistence;

public sealed class CatalogDbContext : DbContext
{
    public CatalogDbContext(DbContextOptions<CatalogDbContext> options)
        : base(options)
    {
    }

    public DbSet<Category> Categories => Set<Category>();

    public DbSet<Product> Products => Set<Product>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Category>(builder =>
        {
            builder.ToTable("categories");
            builder.HasKey(category => category.Id);
            builder.Property(category => category.Id).ValueGeneratedNever();
            builder.Property(category => category.Name).HasMaxLength(180).IsRequired();
            builder.Property(category => category.Slug).HasMaxLength(220).IsRequired();
            builder.Property(category => category.Description).HasMaxLength(600);
            builder.HasIndex(category => category.Slug).IsUnique();
            builder.HasIndex(category => category.ParentCategoryId);
        });

        modelBuilder.Entity<Product>(builder =>
        {
            builder.ToTable("products");
            builder.HasKey(product => product.Id);
            builder.Property(product => product.Id).ValueGeneratedNever();
            builder.Property(product => product.Name).HasMaxLength(220).IsRequired();
            builder.Property(product => product.Slug).HasMaxLength(260).IsRequired();
            builder.Property(product => product.Description).HasMaxLength(4000).IsRequired();
            builder.Property(product => product.Price).HasPrecision(18, 2);
            builder.Property(product => product.Currency).HasMaxLength(3).IsRequired();
            builder.Property(product => product.ImageUrl).HasMaxLength(1200);
            builder.Property(product => product.Status).HasConversion<string>().HasMaxLength(40).IsRequired();
            builder.Property(product => product.RejectionReason).HasMaxLength(600);
            builder.HasIndex(product => product.CategoryId);
            builder.HasIndex(product => product.SellerId);
            builder.HasIndex(product => product.Status);
            builder.HasIndex(product => product.Slug);
        });
    }
}
