using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text.Json;
using Zellamart.Catalog.Application.Abstractions;

namespace Zellamart.Catalog.Infrastructure.Services;

public sealed class SellerProfileGateway : ISellerProfileGateway
{
    private readonly HttpClient _httpClient;

    public SellerProfileGateway(HttpClient httpClient)
    {
        _httpClient = httpClient;
    }

    public async Task<SellerProfileSnapshot?> GetMineAsync(
        string bearerToken,
        CancellationToken cancellationToken)
    {
        using var request = new HttpRequestMessage(HttpMethod.Get, "/api/sellers/me");
        request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", bearerToken);

        using var response = await _httpClient.SendAsync(request, cancellationToken);
        if (!response.IsSuccessStatusCode)
        {
            return null;
        }

        var result = await response.Content.ReadFromJsonAsync<GatewayResult<SellerGatewayResponse>>(cancellationToken);
        if (result?.Success != true || result.Value is null)
        {
            return null;
        }

        return new SellerProfileSnapshot(
            result.Value.Id,
            result.Value.UserId,
            result.Value.BusinessName,
            ReadStatus(result.Value.Status));
    }

    private static string ReadStatus(JsonElement status)
    {
        if (status.ValueKind == JsonValueKind.String)
        {
            return status.GetString() ?? string.Empty;
        }

        return status.ValueKind == JsonValueKind.Number && status.TryGetInt32(out var statusValue)
            ? statusValue switch
            {
                1 => "Pending",
                2 => "Approved",
                3 => "Rejected",
                4 => "Suspended",
                _ => status.GetRawText()
            }
            : status.GetRawText();
    }

    private sealed record SellerGatewayResponse(
        Guid Id,
        Guid UserId,
        string BusinessName,
        JsonElement Status);

    private sealed class GatewayResult<T>
    {
        public bool Success { get; set; }

        public T? Value { get; set; }
    }
}
