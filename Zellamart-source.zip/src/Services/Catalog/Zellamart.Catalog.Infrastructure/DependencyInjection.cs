using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Zellamart.Catalog.Application.Abstractions;
using Zellamart.Catalog.Infrastructure.Events;
using Zellamart.Catalog.Infrastructure.Persistence;
using Zellamart.Catalog.Infrastructure.Services;

namespace Zellamart.Catalog.Infrastructure;

public static class DependencyInjection
{
    public static IServiceCollection AddCatalogInfrastructure(
        this IServiceCollection services,
        IConfiguration configuration)
    {
        services.AddDbContext<CatalogDbContext>(options =>
            options.UseNpgsql(configuration.GetConnectionString("Catalog")));

        services.AddScoped<ICatalogRepository, CatalogRepository>();
        services.AddScoped<ICatalogEventPublisher, LoggingCatalogEventPublisher>();
        services.AddHttpClient<ISellerProfileGateway, SellerProfileGateway>(client =>
        {
            client.BaseAddress = new Uri(configuration["Services:Seller"] ?? "http://localhost:5102");
        });

        return services;
    }
}
