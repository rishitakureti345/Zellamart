using Zellamart.Catalog.Domain.Categories;
using Zellamart.Catalog.Domain.Products;

namespace Zellamart.Catalog.Application.Abstractions;

public interface ICatalogRepository
{
    Task<Category?> GetCategoryByIdAsync(Guid categoryId, CancellationToken cancellationToken);

    Task<Category?> GetCategoryBySlugAsync(string slug, CancellationToken cancellationToken);

    Task<IReadOnlyList<Category>> GetActiveCategoriesAsync(CancellationToken cancellationToken);

    Task<IReadOnlyList<Category>> GetAllCategoriesAsync(CancellationToken cancellationToken);

    Task AddCategoryAsync(Category category, CancellationToken cancellationToken);

    Task<Product?> GetProductByIdAsync(Guid productId, CancellationToken cancellationToken);

    Task<Product?> GetApprovedProductByIdAsync(Guid productId, CancellationToken cancellationToken);

    Task<IReadOnlyList<Product>> GetPendingProductsAsync(CancellationToken cancellationToken);

    Task<IReadOnlyList<Product>> GetAllProductsAsync(CancellationToken cancellationToken);

    Task<IReadOnlyList<Product>> GetApprovedProductsAsync(Guid? categoryId, string? search, CancellationToken cancellationToken);

    Task<IReadOnlyList<Product>> GetProductsBySellerAsync(Guid sellerId, CancellationToken cancellationToken);

    Task AddProductAsync(Product product, CancellationToken cancellationToken);

    Task SaveChangesAsync(CancellationToken cancellationToken);
}
