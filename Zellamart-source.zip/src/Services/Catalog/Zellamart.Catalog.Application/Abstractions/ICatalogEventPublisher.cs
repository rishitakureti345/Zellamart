using Zellamart.Catalog.Domain.Products;

namespace Zellamart.Catalog.Application.Abstractions;

public interface ICatalogEventPublisher
{
    Task PublishSubmittedAsync(Product product, CancellationToken cancellationToken);

    Task PublishApprovedAsync(Product product, Guid approvedByUserId, CancellationToken cancellationToken);

    Task PublishRejectedAsync(Product product, Guid rejectedByUserId, string reason, CancellationToken cancellationToken);
}
