using Microsoft.Extensions.DependencyInjection;
using Zellamart.Catalog.Application.Categories;
using Zellamart.Catalog.Application.Products;

namespace Zellamart.Catalog.Application;

public static class DependencyInjection
{
    public static IServiceCollection AddCatalogApplication(this IServiceCollection services)
    {
        services.AddScoped<ICategoryService, CategoryService>();
        services.AddScoped<IProductService, ProductService>();

        return services;
    }
}
