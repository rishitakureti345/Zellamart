using Zellamart.SharedKernel.Results;

namespace Zellamart.Catalog.Application.Categories;

public interface ICategoryService
{
    Task<Result<CategoryResponse>> CreateAsync(CategoryRequest request, CancellationToken cancellationToken);

    Task<Result<CategoryResponse>> UpdateAsync(Guid categoryId, CategoryRequest request, CancellationToken cancellationToken);

    Task<Result> DeactivateAsync(Guid categoryId, CancellationToken cancellationToken);

    Task<Result<CategoryResponse>> ActivateAsync(Guid categoryId, CancellationToken cancellationToken);

    Task<Result<IReadOnlyList<CategoryResponse>>> GetActiveAsync(CancellationToken cancellationToken);

    Task<Result<IReadOnlyList<CategoryResponse>>> GetAllForAdminAsync(CancellationToken cancellationToken);
}
