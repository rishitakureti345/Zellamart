using Zellamart.Catalog.Application.Abstractions;
using Zellamart.Catalog.Domain.Categories;
using Zellamart.SharedKernel.Results;

namespace Zellamart.Catalog.Application.Categories;

public sealed class CategoryService : ICategoryService
{
    private readonly ICatalogRepository _repository;

    public CategoryService(ICatalogRepository repository)
    {
        _repository = repository;
    }

    public async Task<Result<CategoryResponse>> CreateAsync(CategoryRequest request, CancellationToken cancellationToken)
    {
        var validation = Validate(request);
        if (validation is not null)
        {
            return Result.Fail<CategoryResponse>(validation);
        }

        var slug = BuildSlug(request);
        if (await _repository.GetCategoryBySlugAsync(slug, cancellationToken) is not null)
        {
            return Result.Fail<CategoryResponse>(Error.Conflict("Category slug already exists."));
        }

        if (request.ParentCategoryId is not null &&
            await _repository.GetCategoryByIdAsync(request.ParentCategoryId.Value, cancellationToken) is null)
        {
            return Result.Fail<CategoryResponse>(Error.NotFound("Parent category was not found."));
        }

        var category = new Category(request.Name, slug, request.Description, request.ParentCategoryId);
        await _repository.AddCategoryAsync(category, cancellationToken);
        await _repository.SaveChangesAsync(cancellationToken);

        return Result.Ok(ToResponse(category));
    }

    public async Task<Result<CategoryResponse>> UpdateAsync(Guid categoryId, CategoryRequest request, CancellationToken cancellationToken)
    {
        var validation = Validate(request);
        if (validation is not null)
        {
            return Result.Fail<CategoryResponse>(validation);
        }

        var category = await _repository.GetCategoryByIdAsync(categoryId, cancellationToken);
        if (category is null)
        {
            return Result.Fail<CategoryResponse>(Error.NotFound("Category was not found."));
        }

        var slug = BuildSlug(request);
        var existing = await _repository.GetCategoryBySlugAsync(slug, cancellationToken);
        if (existing is not null && existing.Id != categoryId)
        {
            return Result.Fail<CategoryResponse>(Error.Conflict("Category slug already exists."));
        }

        category.Update(request.Name, slug, request.Description, request.ParentCategoryId);
        await _repository.SaveChangesAsync(cancellationToken);

        return Result.Ok(ToResponse(category));
    }

    public async Task<Result> DeactivateAsync(Guid categoryId, CancellationToken cancellationToken)
    {
        var category = await _repository.GetCategoryByIdAsync(categoryId, cancellationToken);
        if (category is null)
        {
            return Result.Fail(Error.NotFound("Category was not found."));
        }

        category.Deactivate();
        await _repository.SaveChangesAsync(cancellationToken);

        return Result.Ok();
    }

    public async Task<Result<CategoryResponse>> ActivateAsync(Guid categoryId, CancellationToken cancellationToken)
    {
        var category = await _repository.GetCategoryByIdAsync(categoryId, cancellationToken);
        if (category is null)
        {
            return Result.Fail<CategoryResponse>(Error.NotFound("Category was not found."));
        }

        category.Activate();
        await _repository.SaveChangesAsync(cancellationToken);

        return Result.Ok(ToResponse(category));
    }

    public async Task<Result<IReadOnlyList<CategoryResponse>>> GetActiveAsync(CancellationToken cancellationToken)
    {
        var categories = await _repository.GetActiveCategoriesAsync(cancellationToken);
        return Result.Ok<IReadOnlyList<CategoryResponse>>(categories.Select(ToResponse).ToArray());
    }

    public async Task<Result<IReadOnlyList<CategoryResponse>>> GetAllForAdminAsync(CancellationToken cancellationToken)
    {
        var categories = await _repository.GetAllCategoriesAsync(cancellationToken);
        return Result.Ok<IReadOnlyList<CategoryResponse>>(categories.Select(ToResponse).ToArray());
    }

    private static Error? Validate(CategoryRequest request)
    {
        if (string.IsNullOrWhiteSpace(request.Name))
        {
            return Error.Validation("Category name is required.");
        }

        return null;
    }

    private static string BuildSlug(CategoryRequest request)
    {
        var rawSlug = string.IsNullOrWhiteSpace(request.Slug) ? request.Name : request.Slug;
        return rawSlug.Trim().ToLowerInvariant().Replace(' ', '-');
    }

    private static CategoryResponse ToResponse(Category category)
    {
        return new CategoryResponse(
            category.Id,
            category.Name,
            category.Slug,
            category.Description,
            category.ParentCategoryId,
            category.IsActive);
    }
}
