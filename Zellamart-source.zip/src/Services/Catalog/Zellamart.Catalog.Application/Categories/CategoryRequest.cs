namespace Zellamart.Catalog.Application.Categories;

public sealed record CategoryRequest(
    string Name,
    string? Slug,
    string? Description,
    Guid? ParentCategoryId);
