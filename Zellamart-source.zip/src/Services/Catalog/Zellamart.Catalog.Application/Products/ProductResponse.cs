using Zellamart.Catalog.Domain.Products;

namespace Zellamart.Catalog.Application.Products;

public sealed record ProductResponse(
    Guid Id,
    Guid SellerId,
    Guid CategoryId,
    string Name,
    string Slug,
    string Description,
    decimal Price,
    string Currency,
    string? ImageUrl,
    ProductStatus Status,
    string? RejectionReason);
