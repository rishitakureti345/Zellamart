using Zellamart.SharedKernel.Results;

namespace Zellamart.Catalog.Application.Products;

public interface IProductService
{
    Task<Result<ProductResponse>> SubmitAsync(SubmitProductRequest request, CancellationToken cancellationToken);

    Task<Result<IReadOnlyList<ProductResponse>>> GetApprovedAsync(Guid? categoryId, string? search, CancellationToken cancellationToken);

    Task<Result<ProductResponse>> GetByIdAsync(Guid productId, CancellationToken cancellationToken);

    Task<Result<ProductResponse>> GetApprovedByIdAsync(Guid productId, CancellationToken cancellationToken);

    Task<Result<IReadOnlyList<ProductResponse>>> GetPendingAsync(CancellationToken cancellationToken);

    Task<Result<IReadOnlyList<ProductResponse>>> GetAllForAdminAsync(CancellationToken cancellationToken);

    Task<Result<IReadOnlyList<ProductResponse>>> GetBySellerAsync(Guid sellerId, CancellationToken cancellationToken);

    Task<Result<ProductResponse>> UpdateAsync(
        Guid productId,
        Guid updatedByUserId,
        UpdateProductRequest request,
        CancellationToken cancellationToken);

    Task<Result<ProductResponse>> ApproveAsync(Guid productId, Guid approvedByUserId, CancellationToken cancellationToken);

    Task<Result<ProductResponse>> RejectAsync(Guid productId, Guid rejectedByUserId, RejectProductRequest request, CancellationToken cancellationToken);

    Task<Result<ProductResponse>> DisableAsync(Guid productId, Guid disabledByUserId, RejectProductRequest request, CancellationToken cancellationToken);
}
