namespace Zellamart.Catalog.Application.Products;

public sealed record UpdateProductRequest(
    Guid CategoryId,
    string Name,
    string? Slug,
    string Description,
    decimal Price,
    string Currency,
    string? ImageUrl);
