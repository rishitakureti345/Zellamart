using Zellamart.Catalog.Application.Abstractions;
using Zellamart.Catalog.Domain.Products;
using Zellamart.SharedKernel.Results;

namespace Zellamart.Catalog.Application.Products;

public sealed class ProductService : IProductService
{
    private readonly ICatalogRepository _repository;
    private readonly ICatalogEventPublisher _eventPublisher;

    public ProductService(ICatalogRepository repository, ICatalogEventPublisher eventPublisher)
    {
        _repository = repository;
        _eventPublisher = eventPublisher;
    }

    public async Task<Result<ProductResponse>> SubmitAsync(SubmitProductRequest request, CancellationToken cancellationToken)
    {
        var validation = Validate(request);
        if (validation is not null)
        {
            return Result.Fail<ProductResponse>(validation);
        }

        if (await _repository.GetCategoryByIdAsync(request.CategoryId, cancellationToken) is null)
        {
            return Result.Fail<ProductResponse>(Error.NotFound("Category was not found."));
        }

        var product = new Product(
            request.SellerId,
            request.CategoryId,
            request.Name,
            BuildSlug(request),
            request.Description,
            request.Price,
            request.Currency,
            request.ImageUrl);

        await _repository.AddProductAsync(product, cancellationToken);
        await _repository.SaveChangesAsync(cancellationToken);
        await _eventPublisher.PublishSubmittedAsync(product, cancellationToken);

        return Result.Ok(ToResponse(product));
    }

    public async Task<Result<IReadOnlyList<ProductResponse>>> GetApprovedAsync(
        Guid? categoryId,
        string? search,
        CancellationToken cancellationToken)
    {
        var products = await _repository.GetApprovedProductsAsync(categoryId, search, cancellationToken);
        return Result.Ok<IReadOnlyList<ProductResponse>>(products.Select(ToResponse).ToArray());
    }

    public async Task<Result<ProductResponse>> GetByIdAsync(Guid productId, CancellationToken cancellationToken)
    {
        var product = await _repository.GetProductByIdAsync(productId, cancellationToken);
        if (product is null)
        {
            return Result.Fail<ProductResponse>(Error.NotFound("Product was not found."));
        }

        return Result.Ok(ToResponse(product));
    }

    public async Task<Result<ProductResponse>> GetApprovedByIdAsync(Guid productId, CancellationToken cancellationToken)
    {
        var product = await _repository.GetApprovedProductByIdAsync(productId, cancellationToken);
        if (product is null)
        {
            return Result.Fail<ProductResponse>(Error.NotFound("Approved product was not found."));
        }

        return Result.Ok(ToResponse(product));
    }

    public async Task<Result<IReadOnlyList<ProductResponse>>> GetPendingAsync(CancellationToken cancellationToken)
    {
        var products = await _repository.GetPendingProductsAsync(cancellationToken);
        return Result.Ok<IReadOnlyList<ProductResponse>>(products.Select(ToResponse).ToArray());
    }

    public async Task<Result<IReadOnlyList<ProductResponse>>> GetAllForAdminAsync(CancellationToken cancellationToken)
    {
        var products = await _repository.GetAllProductsAsync(cancellationToken);
        return Result.Ok<IReadOnlyList<ProductResponse>>(products.Select(ToResponse).ToArray());
    }

    public async Task<Result<IReadOnlyList<ProductResponse>>> GetBySellerAsync(Guid sellerId, CancellationToken cancellationToken)
    {
        var products = await _repository.GetProductsBySellerAsync(sellerId, cancellationToken);
        return Result.Ok<IReadOnlyList<ProductResponse>>(products.Select(ToResponse).ToArray());
    }

    public async Task<Result<ProductResponse>> UpdateAsync(
        Guid productId,
        Guid updatedByUserId,
        UpdateProductRequest request,
        CancellationToken cancellationToken)
    {
        var validation = ValidateUpdate(request);
        if (validation is not null)
        {
            return Result.Fail<ProductResponse>(validation);
        }

        var product = await _repository.GetProductByIdAsync(productId, cancellationToken);
        if (product is null)
        {
            return Result.Fail<ProductResponse>(Error.NotFound("Product was not found."));
        }

        if (await _repository.GetCategoryByIdAsync(request.CategoryId, cancellationToken) is null)
        {
            return Result.Fail<ProductResponse>(Error.NotFound("Category was not found."));
        }

        product.UpdateDetails(
            request.CategoryId,
            request.Name,
            BuildSlug(request.Name, request.Slug),
            request.Description,
            request.Price,
            request.Currency,
            request.ImageUrl,
            updatedByUserId);

        await _repository.SaveChangesAsync(cancellationToken);

        return Result.Ok(ToResponse(product));
    }

    public async Task<Result<ProductResponse>> ApproveAsync(
        Guid productId,
        Guid approvedByUserId,
        CancellationToken cancellationToken)
    {
        var product = await _repository.GetProductByIdAsync(productId, cancellationToken);
        if (product is null)
        {
            return Result.Fail<ProductResponse>(Error.NotFound("Product was not found."));
        }

        product.Approve(approvedByUserId);
        await _repository.SaveChangesAsync(cancellationToken);
        await _eventPublisher.PublishApprovedAsync(product, approvedByUserId, cancellationToken);

        return Result.Ok(ToResponse(product));
    }

    public async Task<Result<ProductResponse>> RejectAsync(
        Guid productId,
        Guid rejectedByUserId,
        RejectProductRequest request,
        CancellationToken cancellationToken)
    {
        var product = await _repository.GetProductByIdAsync(productId, cancellationToken);
        if (product is null)
        {
            return Result.Fail<ProductResponse>(Error.NotFound("Product was not found."));
        }

        var reason = string.IsNullOrWhiteSpace(request.Reason) ? "Product rejected." : request.Reason;
        product.Reject(rejectedByUserId, reason);
        await _repository.SaveChangesAsync(cancellationToken);
        await _eventPublisher.PublishRejectedAsync(product, rejectedByUserId, reason, cancellationToken);

        return Result.Ok(ToResponse(product));
    }

    public async Task<Result<ProductResponse>> DisableAsync(
        Guid productId,
        Guid disabledByUserId,
        RejectProductRequest request,
        CancellationToken cancellationToken)
    {
        var product = await _repository.GetProductByIdAsync(productId, cancellationToken);
        if (product is null)
        {
            return Result.Fail<ProductResponse>(Error.NotFound("Product was not found."));
        }

        var reason = string.IsNullOrWhiteSpace(request.Reason) ? "Product disabled by admin." : request.Reason;
        product.Disable(disabledByUserId, reason);
        await _repository.SaveChangesAsync(cancellationToken);
        await _eventPublisher.PublishRejectedAsync(product, disabledByUserId, reason, cancellationToken);

        return Result.Ok(ToResponse(product));
    }

    private static Error? Validate(SubmitProductRequest request)
    {
        if (request.SellerId == Guid.Empty)
        {
            return Error.Validation("Seller id is required.");
        }

        if (request.CategoryId == Guid.Empty)
        {
            return Error.Validation("Category id is required.");
        }

        if (string.IsNullOrWhiteSpace(request.Name))
        {
            return Error.Validation("Product name is required.");
        }

        if (string.IsNullOrWhiteSpace(request.Description))
        {
            return Error.Validation("Product description is required.");
        }

        if (request.Price <= 0)
        {
            return Error.Validation("Product price must be greater than zero.");
        }

        if (string.IsNullOrWhiteSpace(request.Currency))
        {
            return Error.Validation("Currency is required.");
        }

        return null;
    }

    private static Error? ValidateUpdate(UpdateProductRequest request)
    {
        if (request.CategoryId == Guid.Empty)
        {
            return Error.Validation("Category id is required.");
        }

        if (string.IsNullOrWhiteSpace(request.Name))
        {
            return Error.Validation("Product name is required.");
        }

        if (string.IsNullOrWhiteSpace(request.Description))
        {
            return Error.Validation("Product description is required.");
        }

        if (request.Price <= 0)
        {
            return Error.Validation("Product price must be greater than zero.");
        }

        if (string.IsNullOrWhiteSpace(request.Currency))
        {
            return Error.Validation("Currency is required.");
        }

        return null;
    }

    private static string BuildSlug(SubmitProductRequest request)
    {
        return BuildSlug(request.Name, request.Slug);
    }

    private static string BuildSlug(string name, string? slug)
    {
        var rawSlug = string.IsNullOrWhiteSpace(slug) ? name : slug;
        return rawSlug.Trim().ToLowerInvariant().Replace(' ', '-');
    }

    private static ProductResponse ToResponse(Product product)
    {
        return new ProductResponse(
            product.Id,
            product.SellerId,
            product.CategoryId,
            product.Name,
            product.Slug,
            product.Description,
            product.Price,
            product.Currency,
            product.ImageUrl,
            product.Status,
            product.RejectionReason);
    }
}
