namespace Zellamart.Catalog.Application.Products;

public sealed record RejectProductRequest(string Reason);
