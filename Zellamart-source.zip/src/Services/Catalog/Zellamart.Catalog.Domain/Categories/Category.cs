using Zellamart.SharedKernel.Entities;

namespace Zellamart.Catalog.Domain.Categories;

public sealed class Category : AuditableEntity
{
    private Category()
    {
    }

    public Category(string name, string slug, string? description, Guid? parentCategoryId)
    {
        Name = name.Trim();
        Slug = slug.Trim().ToLowerInvariant();
        Description = description?.Trim();
        ParentCategoryId = parentCategoryId;
        IsActive = true;
    }

    public string Name { get; private set; } = string.Empty;

    public string Slug { get; private set; } = string.Empty;

    public string? Description { get; private set; }

    public Guid? ParentCategoryId { get; private set; }

    public bool IsActive { get; private set; }

    public void Update(string name, string slug, string? description, Guid? parentCategoryId)
    {
        Name = name.Trim();
        Slug = slug.Trim().ToLowerInvariant();
        Description = description?.Trim();
        ParentCategoryId = parentCategoryId;
        UpdatedAtUtc = DateTimeOffset.UtcNow;
    }

    public void Deactivate()
    {
        IsActive = false;
        UpdatedAtUtc = DateTimeOffset.UtcNow;
    }

    public void Activate()
    {
        IsActive = true;
        UpdatedAtUtc = DateTimeOffset.UtcNow;
    }
}
