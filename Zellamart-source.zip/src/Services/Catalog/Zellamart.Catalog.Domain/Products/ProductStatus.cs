namespace Zellamart.Catalog.Domain.Products;

public enum ProductStatus
{
    Pending = 1,
    Approved = 2,
    Rejected = 3,
    Disabled = 4
}
