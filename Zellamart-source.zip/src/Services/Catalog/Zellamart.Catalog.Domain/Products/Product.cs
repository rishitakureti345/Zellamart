using Zellamart.SharedKernel.Entities;

namespace Zellamart.Catalog.Domain.Products;

public sealed class Product : AuditableEntity
{
    private Product()
    {
    }

    public Product(
        Guid sellerId,
        Guid categoryId,
        string name,
        string slug,
        string description,
        decimal price,
        string currency,
        string? imageUrl)
    {
        SellerId = sellerId;
        CategoryId = categoryId;
        Name = name.Trim();
        Slug = slug.Trim().ToLowerInvariant();
        Description = description.Trim();
        Price = price;
        Currency = currency.Trim().ToUpperInvariant();
        ImageUrl = imageUrl?.Trim();
        Status = ProductStatus.Pending;
    }

    public Guid SellerId { get; private set; }

    public Guid CategoryId { get; private set; }

    public string Name { get; private set; } = string.Empty;

    public string Slug { get; private set; } = string.Empty;

    public string Description { get; private set; } = string.Empty;

    public decimal Price { get; private set; }

    public string Currency { get; private set; } = "INR";

    public string? ImageUrl { get; private set; }

    public ProductStatus Status { get; private set; }

    public string? RejectionReason { get; private set; }

    public Guid? ApprovedByUserId { get; private set; }

    public DateTimeOffset? ApprovedAtUtc { get; private set; }

    public void UpdateDetails(
        Guid categoryId,
        string name,
        string slug,
        string description,
        decimal price,
        string currency,
        string? imageUrl,
        Guid updatedByUserId)
    {
        CategoryId = categoryId;
        Name = name.Trim();
        Slug = slug.Trim().ToLowerInvariant();
        Description = description.Trim();
        Price = price;
        Currency = currency.Trim().ToUpperInvariant();
        ImageUrl = imageUrl?.Trim();
        UpdatedBy = updatedByUserId.ToString();
        UpdatedAtUtc = DateTimeOffset.UtcNow;
    }

    public void Approve(Guid approvedByUserId)
    {
        Status = ProductStatus.Approved;
        RejectionReason = null;
        ApprovedByUserId = approvedByUserId;
        ApprovedAtUtc = DateTimeOffset.UtcNow;
        UpdatedAtUtc = DateTimeOffset.UtcNow;
    }

    public void Reject(Guid rejectedByUserId, string reason)
    {
        Status = ProductStatus.Rejected;
        RejectionReason = reason.Trim();
        ApprovedByUserId = null;
        ApprovedAtUtc = null;
        UpdatedBy = rejectedByUserId.ToString();
        UpdatedAtUtc = DateTimeOffset.UtcNow;
    }

    public void Disable(Guid disabledByUserId, string reason)
    {
        Status = ProductStatus.Disabled;
        RejectionReason = reason.Trim();
        ApprovedByUserId = null;
        ApprovedAtUtc = null;
        UpdatedBy = disabledByUserId.ToString();
        UpdatedAtUtc = DateTimeOffset.UtcNow;
    }
}
