using Zellamart.Identity.Domain.Users;

namespace Zellamart.Identity.Application.Abstractions;

public interface ITokenService
{
    string CreateAccessToken(User user, IReadOnlyList<string> roles, IReadOnlyList<string> permissions);
}
