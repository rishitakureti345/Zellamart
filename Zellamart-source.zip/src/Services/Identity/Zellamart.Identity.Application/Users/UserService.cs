using Zellamart.Identity.Application.Abstractions;
using Zellamart.Identity.Domain.Users;
using Zellamart.SharedKernel.Results;

namespace Zellamart.Identity.Application.Users;

public sealed class UserService : IUserService
{
    private readonly IIdentityRepository _repository;
    private readonly IPasswordHasher _passwordHasher;

    public UserService(IIdentityRepository repository, IPasswordHasher passwordHasher)
    {
        _repository = repository;
        _passwordHasher = passwordHasher;
    }

    public async Task<Result<IReadOnlyList<UserResponse>>> GetUsersAsync(CancellationToken cancellationToken)
    {
        var users = await _repository.GetUsersAsync(cancellationToken);
        return Result.Ok<IReadOnlyList<UserResponse>>(users.Select(ToResponse).ToArray());
    }

    public async Task<Result<UserResponse>> CreateStaffUserAsync(CreateStaffUserRequest request, CancellationToken cancellationToken)
    {
        if (string.IsNullOrWhiteSpace(request.FullName))
        {
            return Result.Fail<UserResponse>(Error.Validation("Full name is required."));
        }

        if (string.IsNullOrWhiteSpace(request.Email))
        {
            return Result.Fail<UserResponse>(Error.Validation("Email is required."));
        }

        if (string.IsNullOrWhiteSpace(request.Password) || request.Password.Length < 8)
        {
            return Result.Fail<UserResponse>(Error.Validation("Password must be at least 8 characters."));
        }

        var role = await _repository.GetRoleByNameAsync(request.RoleName, cancellationToken);
        if (role is null)
        {
            return Result.Fail<UserResponse>(Error.NotFound("Role was not found."));
        }

        if (string.Equals(role.Name, "Customer", StringComparison.OrdinalIgnoreCase))
        {
            return Result.Fail<UserResponse>(Error.Validation("Use registration for customer accounts."));
        }

        var existingUser = await _repository.GetUserByEmailAsync(request.Email, cancellationToken);
        if (existingUser is not null)
        {
            return Result.Fail<UserResponse>(Error.Conflict("A user with this email already exists."));
        }

        var user = new User(request.FullName, request.Email, _passwordHasher.Hash(request.Password));
        user.AssignRole(role);

        await _repository.AddUserAsync(user, cancellationToken);
        await _repository.SaveChangesAsync(cancellationToken);

        var createdUser = await _repository.GetUserByIdAsync(user.Id, cancellationToken);
        return Result.Ok(ToResponse(createdUser ?? user));
    }

    public async Task<Result<UserResponse>> ActivateAsync(Guid userId, CancellationToken cancellationToken)
    {
        var user = await _repository.GetUserByIdAsync(userId, cancellationToken);
        if (user is null)
        {
            return Result.Fail<UserResponse>(Error.NotFound("User was not found."));
        }

        user.Activate();
        await _repository.SaveChangesAsync(cancellationToken);

        return Result.Ok(ToResponse(user));
    }

    public async Task<Result<UserResponse>> SuspendAsync(Guid userId, CancellationToken cancellationToken)
    {
        return await DeactivateAsync(userId, cancellationToken);
    }

    public async Task<Result<UserResponse>> BlockAsync(Guid userId, CancellationToken cancellationToken)
    {
        return await DeactivateAsync(userId, cancellationToken);
    }

    private async Task<Result<UserResponse>> DeactivateAsync(Guid userId, CancellationToken cancellationToken)
    {
        var user = await _repository.GetUserByIdAsync(userId, cancellationToken);
        if (user is null)
        {
            return Result.Fail<UserResponse>(Error.NotFound("User was not found."));
        }

        user.Deactivate();
        await _repository.SaveChangesAsync(cancellationToken);

        return Result.Ok(ToResponse(user));
    }

    private static UserResponse ToResponse(User user)
    {
        var roles = user.UserRoles
            .Select(userRole => userRole.Role.Name)
            .OrderBy(role => role)
            .ToArray();

        var permissions = user.UserRoles
            .SelectMany(userRole => userRole.Role.RolePermissions)
            .Select(rolePermission => rolePermission.Permission.Code)
            .Distinct()
            .OrderBy(permission => permission)
            .ToArray();

        return new UserResponse(
            user.Id,
            user.FullName,
            user.Email,
            user.IsActive,
            roles,
            permissions);
    }
}
