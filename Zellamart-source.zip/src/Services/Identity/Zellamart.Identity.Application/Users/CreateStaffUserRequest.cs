namespace Zellamart.Identity.Application.Users;

public sealed record CreateStaffUserRequest(string FullName, string Email, string Password, string RoleName);
