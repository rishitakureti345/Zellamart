using Zellamart.SharedKernel.Results;

namespace Zellamart.Identity.Application.Users;

public interface IUserService
{
    Task<Result<IReadOnlyList<UserResponse>>> GetUsersAsync(CancellationToken cancellationToken);

    Task<Result<UserResponse>> CreateStaffUserAsync(CreateStaffUserRequest request, CancellationToken cancellationToken);

    Task<Result<UserResponse>> ActivateAsync(Guid userId, CancellationToken cancellationToken);

    Task<Result<UserResponse>> SuspendAsync(Guid userId, CancellationToken cancellationToken);

    Task<Result<UserResponse>> BlockAsync(Guid userId, CancellationToken cancellationToken);
}
