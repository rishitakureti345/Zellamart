using Microsoft.Extensions.DependencyInjection;
using Zellamart.Identity.Application.Auth;
using Zellamart.Identity.Application.Roles;
using Zellamart.Identity.Application.Users;

namespace Zellamart.Identity.Application;

public static class DependencyInjection
{
    public static IServiceCollection AddIdentityApplication(this IServiceCollection services)
    {
        services.AddScoped<IAuthService, AuthService>();
        services.AddScoped<IRoleService, RoleService>();
        services.AddScoped<IUserService, UserService>();

        return services;
    }
}
