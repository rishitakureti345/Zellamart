using Zellamart.SharedKernel.Results;

namespace Zellamart.Identity.Application.Roles;

public interface IRoleService
{
    Task<Result<IReadOnlyList<RoleResponse>>> GetRolesAsync(CancellationToken cancellationToken);

    Task<Result<RoleResponse>> CreateRoleAsync(CreateRoleRequest request, CancellationToken cancellationToken);

    Task<Result> AssignRoleAsync(AssignRoleRequest request, CancellationToken cancellationToken);
}
