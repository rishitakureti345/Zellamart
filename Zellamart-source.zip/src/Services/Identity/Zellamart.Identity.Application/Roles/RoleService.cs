using Zellamart.Identity.Application.Abstractions;
using Zellamart.Identity.Domain.Users;
using Zellamart.SharedKernel.Results;

namespace Zellamart.Identity.Application.Roles;

public sealed class RoleService : IRoleService
{
    private readonly IIdentityRepository _repository;

    public RoleService(IIdentityRepository repository)
    {
        _repository = repository;
    }

    public async Task<Result<IReadOnlyList<RoleResponse>>> GetRolesAsync(CancellationToken cancellationToken)
    {
        var roles = await _repository.GetRolesAsync(cancellationToken);
        var response = roles
            .Select(role => new RoleResponse(role.Id, role.Name, role.Description))
            .OrderBy(role => role.Name)
            .ToArray();

        return Result.Ok<IReadOnlyList<RoleResponse>>(response);
    }

    public async Task<Result<RoleResponse>> CreateRoleAsync(CreateRoleRequest request, CancellationToken cancellationToken)
    {
        if (string.IsNullOrWhiteSpace(request.Name))
        {
            return Result.Fail<RoleResponse>(Error.Validation("Role name is required."));
        }

        if (request.Name.Trim().Length > 80)
        {
            return Result.Fail<RoleResponse>(Error.Validation("Role name must be 80 characters or fewer."));
        }

        if (string.IsNullOrWhiteSpace(request.Description))
        {
            return Result.Fail<RoleResponse>(Error.Validation("Role description is required."));
        }

        if (request.Description.Trim().Length > 240)
        {
            return Result.Fail<RoleResponse>(Error.Validation("Role description must be 240 characters or fewer."));
        }

        var existingRole = await _repository.GetRoleByNameAsync(request.Name, cancellationToken);
        if (existingRole is not null)
        {
            return Result.Fail<RoleResponse>(Error.Conflict("A role with this name already exists."));
        }

        var role = new Role(request.Name, request.Description);
        await _repository.AddRoleAsync(role, cancellationToken);
        await _repository.SaveChangesAsync(cancellationToken);

        return Result.Ok(new RoleResponse(role.Id, role.Name, role.Description));
    }

    public async Task<Result> AssignRoleAsync(AssignRoleRequest request, CancellationToken cancellationToken)
    {
        var user = await _repository.GetUserByIdAsync(request.UserId, cancellationToken);
        if (user is null)
        {
            return Result.Fail(Error.NotFound("User was not found."));
        }

        var role = await _repository.GetRoleByNameAsync(request.RoleName, cancellationToken);
        if (role is null)
        {
            return Result.Fail(Error.NotFound("Role was not found."));
        }

        user.AssignRole(role);
        await _repository.SaveChangesAsync(cancellationToken);

        return Result.Ok();
    }
}
