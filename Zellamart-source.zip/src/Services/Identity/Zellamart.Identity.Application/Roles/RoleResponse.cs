namespace Zellamart.Identity.Application.Roles;

public sealed record RoleResponse(Guid Id, string Name, string Description);
