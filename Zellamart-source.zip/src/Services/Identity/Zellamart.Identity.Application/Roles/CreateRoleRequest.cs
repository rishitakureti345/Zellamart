namespace Zellamart.Identity.Application.Roles;

public sealed record CreateRoleRequest(string Name, string Description);
