namespace Zellamart.Identity.Application.Roles;

public sealed record AssignRoleRequest(Guid UserId, string RoleName);
