namespace Zellamart.Identity.Application.Auth;

public sealed record UpdateUserProfileRequest(
    string? Phone,
    string? DefaultShippingAddress);
