namespace Zellamart.Identity.Application.Auth;

public sealed record WorkspaceAccessResponse(
    string Key,
    string Label,
    string Path,
    bool IsPrimary);
