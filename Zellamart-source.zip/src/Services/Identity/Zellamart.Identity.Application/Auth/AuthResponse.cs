namespace Zellamart.Identity.Application.Auth;

public sealed record AuthResponse(
    Guid UserId,
    string FullName,
    string Email,
    bool IsActive,
    string? Phone,
    string? DefaultShippingAddress,
    IReadOnlyList<string> Roles,
    IReadOnlyList<string> Permissions,
    IReadOnlyList<WorkspaceAccessResponse> Workspaces,
    string DefaultWorkspaceKey,
    string DefaultDashboardPath,
    string AccessToken);
