using Zellamart.Identity.Application.Abstractions;
using Zellamart.Identity.Domain.Users;
using Zellamart.SharedKernel.Results;

namespace Zellamart.Identity.Application.Auth;

public sealed class AuthService : IAuthService
{
    private readonly IIdentityRepository _repository;
    private readonly IPasswordHasher _passwordHasher;
    private readonly ITokenService _tokenService;

    public AuthService(
        IIdentityRepository repository,
        IPasswordHasher passwordHasher,
        ITokenService tokenService)
    {
        _repository = repository;
        _passwordHasher = passwordHasher;
        _tokenService = tokenService;
    }

    public async Task<Result<AuthResponse>> RegisterAsync(RegisterRequest request, CancellationToken cancellationToken)
    {
        if (string.IsNullOrWhiteSpace(request.FullName))
        {
            return Result.Fail<AuthResponse>(Error.Validation("Full name is required."));
        }

        if (string.IsNullOrWhiteSpace(request.Email))
        {
            return Result.Fail<AuthResponse>(Error.Validation("Email is required."));
        }

        if (string.IsNullOrWhiteSpace(request.Password) || request.Password.Length < 8)
        {
            return Result.Fail<AuthResponse>(Error.Validation("Password must be at least 8 characters."));
        }

        var existingUser = await _repository.GetUserByEmailAsync(request.Email, cancellationToken);
        if (existingUser is not null)
        {
            return Result.Fail<AuthResponse>(Error.Conflict("A user with this email already exists."));
        }

        var passwordHash = _passwordHasher.Hash(request.Password);
        var user = new User(request.FullName, request.Email, passwordHash);

        var customerRole = await _repository.GetRoleByNameAsync("Customer", cancellationToken);
        if (customerRole is not null)
        {
            user.AssignRole(customerRole);
        }

        await _repository.AddUserAsync(user, cancellationToken);
        await _repository.SaveChangesAsync(cancellationToken);

        return Result.Ok(CreateAuthResponse(user));
    }

    public async Task<Result<AuthResponse>> LoginAsync(LoginRequest request, CancellationToken cancellationToken)
    {
        var user = await _repository.GetUserByEmailAsync(request.Email, cancellationToken);
        if (user is null || !user.IsActive)
        {
            return Result.Fail<AuthResponse>(Error.Unauthorized("Invalid email or password."));
        }

        if (!_passwordHasher.Verify(request.Password, user.PasswordHash))
        {
            return Result.Fail<AuthResponse>(Error.Unauthorized("Invalid email or password."));
        }

        return Result.Ok(CreateAuthResponse(user));
    }

    public async Task<Result<UserProfileResponse>> GetProfileAsync(Guid userId, CancellationToken cancellationToken)
    {
        var user = await _repository.GetUserByIdAsync(userId, cancellationToken);
        if (user is null)
        {
            return Result.Fail<UserProfileResponse>(Error.NotFound("User was not found."));
        }

        var roles = GetRoleNames(user);
        var permissions = GetPermissionCodes(user);

        return Result.Ok(ToProfileResponse(user, roles, permissions));
    }

    public async Task<Result<UserProfileResponse>> UpdateProfileAsync(
        Guid userId,
        UpdateUserProfileRequest request,
        CancellationToken cancellationToken)
    {
        var user = await _repository.GetUserByIdAsync(userId, cancellationToken);
        if (user is null)
        {
            return Result.Fail<UserProfileResponse>(Error.NotFound("User was not found."));
        }

        if (!user.IsActive)
        {
            return Result.Fail<UserProfileResponse>(Error.Validation("Inactive users cannot update their profile."));
        }

        if (!string.IsNullOrWhiteSpace(request.Phone) && request.Phone.Trim().Length > 40)
        {
            return Result.Fail<UserProfileResponse>(Error.Validation("Phone must be 40 characters or fewer."));
        }

        if (!string.IsNullOrWhiteSpace(request.DefaultShippingAddress) && request.DefaultShippingAddress.Trim().Length > 600)
        {
            return Result.Fail<UserProfileResponse>(Error.Validation("Default shipping address must be 600 characters or fewer."));
        }

        user.UpdateCustomerProfile(request.Phone, request.DefaultShippingAddress);
        await _repository.SaveChangesAsync(cancellationToken);

        var roles = GetRoleNames(user);
        var permissions = GetPermissionCodes(user);

        return Result.Ok(ToProfileResponse(user, roles, permissions));
    }

    private AuthResponse CreateAuthResponse(User user)
    {
        var roles = GetRoleNames(user);
        var permissions = GetPermissionCodes(user);
        var workspaceAccess = CreateWorkspaceAccess(roles);
        var token = _tokenService.CreateAccessToken(user, roles, permissions);

        return new AuthResponse(
            user.Id,
            user.FullName,
            user.Email,
            user.IsActive,
            user.Phone,
            user.DefaultShippingAddress,
            roles,
            permissions,
            workspaceAccess.Workspaces,
            workspaceAccess.DefaultWorkspaceKey,
            workspaceAccess.DefaultDashboardPath,
            token);
    }

    private static UserProfileResponse ToProfileResponse(
        User user,
        IReadOnlyList<string> roles,
        IReadOnlyList<string> permissions)
    {
        var workspaceAccess = CreateWorkspaceAccess(roles);

        return new UserProfileResponse(
            user.Id,
            user.FullName,
            user.Email,
            user.IsActive,
            user.Phone,
            user.DefaultShippingAddress,
            roles,
            permissions,
            workspaceAccess.Workspaces,
            workspaceAccess.DefaultWorkspaceKey,
            workspaceAccess.DefaultDashboardPath);
    }

    private static WorkspaceAccess CreateWorkspaceAccess(IReadOnlyList<string> roles)
    {
        var roleSet = roles.ToHashSet(StringComparer.OrdinalIgnoreCase);
        var workspaces = new List<WorkspaceAccessResponse>();

        if (roleSet.Contains("SuperAdmin"))
        {
            workspaces.AddRange([
                new WorkspaceAccessResponse("superadmin", "SuperAdmin", "/superadmin/dashboard", true),
                new WorkspaceAccessResponse("admin", "Admin", "/admin/dashboard", false),
                new WorkspaceAccessResponse("operations", "Operations", "/operations/dashboard", false),
                new WorkspaceAccessResponse("support", "Support", "/support/tickets", false),
                new WorkspaceAccessResponse("finance", "Finance", "/finance/dashboard", false)
            ]);

            return new WorkspaceAccess(workspaces, "superadmin", "/superadmin/dashboard");
        }

        if (roleSet.Contains("Admin"))
        {
            workspaces.AddRange([
                new WorkspaceAccessResponse("admin", "Admin", "/admin/dashboard", true),
                new WorkspaceAccessResponse("operations", "Operations", "/operations/dashboard", false),
                new WorkspaceAccessResponse("support", "Support", "/support/tickets", false),
                new WorkspaceAccessResponse("finance", "Finance", "/finance/dashboard", false)
            ]);

            return new WorkspaceAccess(workspaces, "admin", "/admin/dashboard");
        }

        if (roleSet.Contains("Seller"))
        {
            workspaces.Add(new WorkspaceAccessResponse("seller", "Seller", "/seller/dashboard", workspaces.Count == 0));
        }

        if (roleSet.Overlaps(["SupportManager", "SupportAgent"]))
        {
            workspaces.Add(new WorkspaceAccessResponse("support", "Support", "/support/tickets", workspaces.Count == 0));
        }

        if (roleSet.Overlaps(["WarehouseManager", "DeliveryManager", "DeliveryPartner", "InventoryStaff", "OrderManager"]))
        {
            workspaces.Add(new WorkspaceAccessResponse("operations", "Operations", "/operations/dashboard", workspaces.Count == 0));
        }

        if (roleSet.Overlaps(["FinanceManager", "PaymentTeam"]))
        {
            workspaces.Add(new WorkspaceAccessResponse("finance", "Finance", "/finance/dashboard", workspaces.Count == 0));
        }

        if (roleSet.Contains("Customer"))
        {
            workspaces.Add(new WorkspaceAccessResponse("customer", "Customer", "/customer/dashboard", workspaces.Count == 0));
        }

        if (workspaces.Count == 0)
        {
            return new WorkspaceAccess([], "home", "/");
        }

        var primary = workspaces.First(workspace => workspace.IsPrimary);
        return new WorkspaceAccess(workspaces, primary.Key, primary.Path);
    }

    private static IReadOnlyList<string> GetRoleNames(User user)
    {
        return user.UserRoles
            .Select(userRole => userRole.Role?.Name)
            .Where(role => !string.IsNullOrWhiteSpace(role))
            .Select(role => role!)
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .Order()
            .ToArray();
    }

    private static IReadOnlyList<string> GetPermissionCodes(User user)
    {
        return user.UserRoles
            .SelectMany(userRole => userRole.Role?.RolePermissions ?? [])
            .Select(rolePermission => rolePermission.Permission?.Code)
            .Where(permission => !string.IsNullOrWhiteSpace(permission))
            .Select(permission => permission!)
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .Order()
            .ToArray();
    }

    private sealed record WorkspaceAccess(
        IReadOnlyList<WorkspaceAccessResponse> Workspaces,
        string DefaultWorkspaceKey,
        string DefaultDashboardPath);
}
