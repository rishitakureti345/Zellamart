using Zellamart.SharedKernel.Entities;

namespace Zellamart.Identity.Domain.Users;

public sealed class Permission : AuditableEntity
{
    private Permission()
    {
    }

    public Permission(string code, string description)
    {
        Code = code.Trim();
        Description = description.Trim();
    }

    public string Code { get; private set; } = string.Empty;

    public string Description { get; private set; } = string.Empty;
}
