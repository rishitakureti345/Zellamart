using Zellamart.SharedKernel.Entities;

namespace Zellamart.Identity.Domain.Users;

public sealed class Role : AuditableEntity
{
    private readonly List<RolePermission> _rolePermissions = [];

    private Role()
    {
    }

    public Role(string name, string description)
    {
        Name = name.Trim();
        Description = description.Trim();
    }

    public string Name { get; private set; } = string.Empty;

    public string Description { get; private set; } = string.Empty;

    public IReadOnlyCollection<RolePermission> RolePermissions => _rolePermissions;
}
