using Zellamart.SharedKernel.Entities;

namespace Zellamart.Identity.Domain.Users;

public sealed class User : AuditableEntity
{
    private readonly List<UserRole> _userRoles = [];

    private User()
    {
    }

    public User(string fullName, string email, string passwordHash)
    {
        FullName = fullName.Trim();
        Email = email.Trim().ToLowerInvariant();
        PasswordHash = passwordHash;
    }

    public string FullName { get; private set; } = string.Empty;

    public string Email { get; private set; } = string.Empty;

    public string PasswordHash { get; private set; } = string.Empty;

    public bool IsActive { get; private set; } = true;

    public string? Phone { get; private set; }

    public string? DefaultShippingAddress { get; private set; }

    public IReadOnlyCollection<UserRole> UserRoles => _userRoles;

    public void AssignRole(Role role)
    {
        if (_userRoles.Any(userRole => userRole.RoleId == role.Id))
        {
            return;
        }

        _userRoles.Add(new UserRole(Id, role.Id));
    }

    public void Activate() => IsActive = true;

    public void Deactivate() => IsActive = false;

    public void UpdateCustomerProfile(string? phone, string? defaultShippingAddress)
    {
        Phone = string.IsNullOrWhiteSpace(phone) ? null : phone.Trim();
        DefaultShippingAddress = string.IsNullOrWhiteSpace(defaultShippingAddress) ? null : defaultShippingAddress.Trim();
    }
}
