﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Zellamart.Identity.Infrastructure.Persistence.Migrations
{
    /// <inheritdoc />
    public partial class AddMonth4RolesAndPermissions : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
        }
    }
}
