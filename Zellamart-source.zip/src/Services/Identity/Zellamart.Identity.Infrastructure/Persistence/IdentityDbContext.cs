using Microsoft.EntityFrameworkCore;
using Zellamart.Identity.Domain.Users;

namespace Zellamart.Identity.Infrastructure.Persistence;

public sealed class IdentityDbContext : DbContext
{
    public IdentityDbContext(DbContextOptions<IdentityDbContext> options)
        : base(options)
    {
    }

    public DbSet<User> Users => Set<User>();

    public DbSet<Role> Roles => Set<Role>();

    public DbSet<Permission> Permissions => Set<Permission>();

    public DbSet<UserRole> UserRoles => Set<UserRole>();

    public DbSet<RolePermission> RolePermissions => Set<RolePermission>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<User>(builder =>
        {
            builder.ToTable("users");
            builder.HasKey(user => user.Id);
            builder.Property(user => user.FullName).HasMaxLength(160).IsRequired();
            builder.Property(user => user.Email).HasMaxLength(320).IsRequired();
            builder.Property(user => user.PasswordHash).HasMaxLength(512).IsRequired();
            builder.Property(user => user.Phone).HasMaxLength(40);
            builder.Property(user => user.DefaultShippingAddress).HasMaxLength(600);
            builder.HasIndex(user => user.Email).IsUnique();
            builder.Navigation(user => user.UserRoles).UsePropertyAccessMode(PropertyAccessMode.Field);
        });

        modelBuilder.Entity<Role>(builder =>
        {
            builder.ToTable("roles");
            builder.HasKey(role => role.Id);
            builder.Property(role => role.Name).HasMaxLength(80).IsRequired();
            builder.Property(role => role.Description).HasMaxLength(240).IsRequired();
            builder.HasIndex(role => role.Name).IsUnique();
            builder.Navigation(role => role.RolePermissions).UsePropertyAccessMode(PropertyAccessMode.Field);
        });

        modelBuilder.Entity<Permission>(builder =>
        {
            builder.ToTable("permissions");
            builder.HasKey(permission => permission.Id);
            builder.Property(permission => permission.Code).HasMaxLength(120).IsRequired();
            builder.Property(permission => permission.Description).HasMaxLength(240).IsRequired();
            builder.HasIndex(permission => permission.Code).IsUnique();
        });

        modelBuilder.Entity<UserRole>(builder =>
        {
            builder.ToTable("user_roles");
            builder.HasKey(userRole => new { userRole.UserId, userRole.RoleId });
            builder.HasOne(userRole => userRole.User)
                .WithMany(user => user.UserRoles)
                .HasForeignKey(userRole => userRole.UserId);
            builder.HasOne(userRole => userRole.Role)
                .WithMany()
                .HasForeignKey(userRole => userRole.RoleId);
        });

        modelBuilder.Entity<RolePermission>(builder =>
        {
            builder.ToTable("role_permissions");
            builder.HasKey(rolePermission => new { rolePermission.RoleId, rolePermission.PermissionId });
            builder.HasOne(rolePermission => rolePermission.Role)
                .WithMany(role => role.RolePermissions)
                .HasForeignKey(rolePermission => rolePermission.RoleId);
            builder.HasOne(rolePermission => rolePermission.Permission)
                .WithMany()
                .HasForeignKey(rolePermission => rolePermission.PermissionId);
        });
    }
}
