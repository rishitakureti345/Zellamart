using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Zellamart.Identity.Application.Abstractions;
using Zellamart.Identity.Infrastructure.Persistence;
using Zellamart.Identity.Infrastructure.Security;

namespace Zellamart.Identity.Infrastructure;

public static class DependencyInjection
{
    public static IServiceCollection AddIdentityInfrastructure(
        this IServiceCollection services,
        IConfiguration configuration)
    {
        services.Configure<JwtOptions>(options =>
        {
            var section = configuration.GetSection(JwtOptions.SectionName);
            options.Issuer = section[nameof(JwtOptions.Issuer)] ?? options.Issuer;
            options.Audience = section[nameof(JwtOptions.Audience)] ?? options.Audience;
            options.SigningKey = section[nameof(JwtOptions.SigningKey)] ?? options.SigningKey;

            if (int.TryParse(section[nameof(JwtOptions.ExpiryMinutes)], out var expiryMinutes))
            {
                options.ExpiryMinutes = expiryMinutes;
            }
        });

        services.AddDbContext<IdentityDbContext>(options =>
            options.UseNpgsql(configuration.GetConnectionString("Identity")));

        services.AddScoped<IIdentityRepository, IdentityRepository>();
        services.AddSingleton<IPasswordHasher, PasswordHasher>();
        services.AddScoped<ITokenService, TokenService>();

        return services;
    }
}
