using System.Text.Json;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Zellamart.SharedKernel.Results;

namespace Zellamart.Identity.Api.Controllers;

[ApiController]
[Authorize(Roles = "SuperAdmin,Admin")]
[Route("api/settings")]
public sealed class SettingsController : ControllerBase
{
    private static readonly JsonSerializerOptions JsonOptions = new(JsonSerializerDefaults.Web)
    {
        WriteIndented = true
    };

    private readonly string _settingsPath;

    public SettingsController(IWebHostEnvironment environment)
    {
        _settingsPath = Path.Combine(environment.ContentRootPath, "App_Data", "marketplace-settings.json");
    }

    [HttpGet("marketplace")]
    public async Task<IActionResult> GetMarketplaceSettings(CancellationToken cancellationToken)
    {
        var settings = await ReadAsync(cancellationToken);
        return Ok(Result.Ok(settings));
    }

    [HttpPut("marketplace")]
    public async Task<IActionResult> UpdateMarketplaceSettings(
        MarketplaceSettingsRequest request,
        CancellationToken cancellationToken)
    {
        var validation = Validate(request);
        if (validation is not null)
        {
            return BadRequest(Result.Fail<MarketplaceSettingsResponse>(validation));
        }

        var settings = new MarketplaceSettingsResponse(
            request.CommissionPercentage,
            request.DefaultCurrency.Trim().ToUpperInvariant(),
            request.SupportEmail.Trim(),
            request.ReturnWindowDays,
            request.LowStockThreshold,
            request.PaymentMode.Trim(),
            request.PaymentProvider.Trim(),
            request.PaymentSuccessCaptureEnabled,
            request.LivePaymentGatewayEnabled,
            request.ShippingMode.Trim(),
            request.DefaultWarehouse.Trim(),
            request.AdminDeliveryStatusUpdatesEnabled,
            request.ExternalCarrierApiEnabled,
            DateTime.UtcNow);

        Directory.CreateDirectory(Path.GetDirectoryName(_settingsPath)!);
        await System.IO.File.WriteAllTextAsync(
            _settingsPath,
            JsonSerializer.Serialize(settings, JsonOptions),
            cancellationToken);

        return Ok(Result.Ok(settings));
    }

    private async Task<MarketplaceSettingsResponse> ReadAsync(CancellationToken cancellationToken)
    {
        if (!System.IO.File.Exists(_settingsPath))
        {
            return MarketplaceSettingsResponse.Default;
        }

        try
        {
            var json = await System.IO.File.ReadAllTextAsync(_settingsPath, cancellationToken);
            return JsonSerializer.Deserialize<MarketplaceSettingsResponse>(json, JsonOptions)
                ?? MarketplaceSettingsResponse.Default;
        }
        catch (JsonException)
        {
            return MarketplaceSettingsResponse.Default;
        }
    }

    private static Error? Validate(MarketplaceSettingsRequest request)
    {
        if (request.CommissionPercentage is < 0 or > 100)
        {
            return Error.Validation("Commission percentage must be between 0 and 100.");
        }

        if (string.IsNullOrWhiteSpace(request.DefaultCurrency))
        {
            return Error.Validation("Default currency is required.");
        }

        if (string.IsNullOrWhiteSpace(request.SupportEmail) || !request.SupportEmail.Contains('@'))
        {
            return Error.Validation("Support email must be valid.");
        }

        if (request.ReturnWindowDays is < 0 or > 90)
        {
            return Error.Validation("Return window must be between 0 and 90 days.");
        }

        if (request.LowStockThreshold is < 0 or > 1000)
        {
            return Error.Validation("Low stock threshold must be between 0 and 1000.");
        }

        if (string.IsNullOrWhiteSpace(request.PaymentMode)
            || string.IsNullOrWhiteSpace(request.PaymentProvider)
            || string.IsNullOrWhiteSpace(request.ShippingMode)
            || string.IsNullOrWhiteSpace(request.DefaultWarehouse))
        {
            return Error.Validation("Payment and shipping settings are required.");
        }

        return null;
    }
}

public sealed record MarketplaceSettingsRequest(
    decimal CommissionPercentage,
    string DefaultCurrency,
    string SupportEmail,
    int ReturnWindowDays,
    int LowStockThreshold,
    string PaymentMode,
    string PaymentProvider,
    bool PaymentSuccessCaptureEnabled,
    bool LivePaymentGatewayEnabled,
    string ShippingMode,
    string DefaultWarehouse,
    bool AdminDeliveryStatusUpdatesEnabled,
    bool ExternalCarrierApiEnabled);

public sealed record MarketplaceSettingsResponse(
    decimal CommissionPercentage,
    string DefaultCurrency,
    string SupportEmail,
    int ReturnWindowDays,
    int LowStockThreshold,
    string PaymentMode,
    string PaymentProvider,
    bool PaymentSuccessCaptureEnabled,
    bool LivePaymentGatewayEnabled,
    string ShippingMode,
    string DefaultWarehouse,
    bool AdminDeliveryStatusUpdatesEnabled,
    bool ExternalCarrierApiEnabled,
    DateTime? SavedAtUtc)
{
    public static MarketplaceSettingsResponse Default { get; } = new(
        10,
        "INR",
        "support@zellamart.test",
        7,
        5,
        "Simulation",
        "Internal payment simulator",
        true,
        false,
        "Manual operations",
        "Main warehouse",
        true,
        false,
        null);
}
