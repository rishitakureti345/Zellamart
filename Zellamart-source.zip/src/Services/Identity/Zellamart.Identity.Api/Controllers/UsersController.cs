using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Zellamart.Identity.Application.Users;

namespace Zellamart.Identity.Api.Controllers;

[ApiController]
[Route("api/users")]
public sealed class UsersController : ControllerBase
{
    private readonly IUserService _userService;

    public UsersController(IUserService userService)
    {
        _userService = userService;
    }

    [Authorize(Roles = "SuperAdmin,Admin")]
    [HttpGet]
    public async Task<IActionResult> GetUsers(CancellationToken cancellationToken)
    {
        var result = await _userService.GetUsersAsync(cancellationToken);
        return Ok(result);
    }

    [Authorize(Roles = "SuperAdmin,Admin")]
    [HttpPost("staff")]
    public async Task<IActionResult> CreateStaffUser(CreateStaffUserRequest request, CancellationToken cancellationToken)
    {
        var result = await _userService.CreateStaffUserAsync(request, cancellationToken);
        return result.Success ? Ok(result) : BadRequest(result);
    }

    [Authorize(Roles = "SuperAdmin,Admin")]
    [HttpPost("{userId:guid}/activate")]
    public async Task<IActionResult> Activate(Guid userId, CancellationToken cancellationToken)
    {
        var result = await _userService.ActivateAsync(userId, cancellationToken);
        return result.Success ? Ok(result) : NotFound(result);
    }

    [Authorize(Roles = "SuperAdmin,Admin")]
    [HttpPost("{userId:guid}/suspend")]
    public async Task<IActionResult> Suspend(Guid userId, CancellationToken cancellationToken)
    {
        var result = await _userService.SuspendAsync(userId, cancellationToken);
        return result.Success ? Ok(result) : NotFound(result);
    }

    [Authorize(Roles = "SuperAdmin,Admin")]
    [HttpPost("{userId:guid}/block")]
    public async Task<IActionResult> Block(Guid userId, CancellationToken cancellationToken)
    {
        var result = await _userService.BlockAsync(userId, cancellationToken);
        return result.Success ? Ok(result) : NotFound(result);
    }
}
