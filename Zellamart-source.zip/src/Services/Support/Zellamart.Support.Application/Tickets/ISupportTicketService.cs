using Zellamart.SharedKernel.Results;

namespace Zellamart.Support.Application.Tickets;

public interface ISupportTicketService
{
    Task<Result<SupportTicketResponse>> CreateAsync(
        Guid customerId,
        string bearerToken,
        CreateSupportTicketRequest request,
        CancellationToken cancellationToken);

    Task<Result<IReadOnlyList<SupportTicketResponse>>> GetMineAsync(
        Guid customerId,
        CancellationToken cancellationToken);

    Task<Result<IReadOnlyList<SupportTicketResponse>>> GetAllForStaffAsync(CancellationToken cancellationToken);

    Task<Result<SupportTicketResponse>> GetByIdAsync(
        Guid customerId,
        Guid ticketId,
        CancellationToken cancellationToken);

    Task<Result<SupportTicketResponse>> GetByIdForStaffAsync(
        Guid ticketId,
        CancellationToken cancellationToken);

    Task<Result<SupportTicketResponse>> AddMessageAsync(
        Guid currentUserId,
        Guid ticketId,
        AddSupportTicketMessageRequest request,
        CancellationToken cancellationToken);

    Task<Result<SupportTicketResponse>> AddMessageForStaffAsync(
        Guid currentUserId,
        Guid ticketId,
        AddSupportTicketMessageRequest request,
        CancellationToken cancellationToken);

    Task<Result<SupportTicketResponse>> AssignAsync(
        Guid currentUserId,
        Guid ticketId,
        AssignSupportTicketRequest request,
        CancellationToken cancellationToken);

    Task<Result<SupportTicketResponse>> ResolveAsync(
        Guid currentUserId,
        Guid ticketId,
        CancellationToken cancellationToken);

    Task<Result<SupportTicketResponse>> RejectAsync(
        Guid currentUserId,
        Guid ticketId,
        CancellationToken cancellationToken);

    Task<Result<SupportTicketResponse>> CloseAsync(
        Guid currentUserId,
        Guid ticketId,
        CancellationToken cancellationToken);

    Task<Result<SupportTicketResponse>> CloseForStaffAsync(
        Guid currentUserId,
        Guid ticketId,
        CancellationToken cancellationToken);
}
