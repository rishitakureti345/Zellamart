namespace Zellamart.Support.Application.Tickets;

public sealed record AssignSupportTicketRequest(Guid AgentId);
