using Zellamart.Support.Domain.Tickets;

namespace Zellamart.Support.Application.Tickets;

public sealed record SupportTicketResponse(
    Guid Id,
    Guid CustomerId,
    Guid OrderId,
    SupportTicketType Type,
    string Subject,
    string Description,
    SupportTicketStatus Status,
    Guid? AssignedAgentId,
    IReadOnlyList<SupportTicketMessageResponse> Messages,
    IReadOnlyList<SupportTicketStatusHistoryResponse> StatusHistory,
    DateTimeOffset CreatedAtUtc);

public sealed record SupportTicketMessageResponse(
    Guid Id,
    Guid SenderUserId,
    string Message,
    DateTimeOffset CreatedAtUtc);

public sealed record SupportTicketStatusHistoryResponse(
    Guid Id,
    SupportTicketStatus Status,
    string Note,
    Guid? ChangedByUserId,
    DateTimeOffset ChangedAtUtc);
