namespace Zellamart.Support.Application.Tickets;

public sealed record AddSupportTicketMessageRequest(string Message);
