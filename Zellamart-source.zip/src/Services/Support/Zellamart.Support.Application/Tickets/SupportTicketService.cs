using Zellamart.SharedKernel.Results;
using Zellamart.Support.Application.Abstractions;
using Zellamart.Support.Domain.Tickets;

namespace Zellamart.Support.Application.Tickets;

public sealed class SupportTicketService : ISupportTicketService
{
    private readonly ISupportTicketRepository _repository;
    private readonly IOrderGateway _orderGateway;
    private readonly INotificationGateway _notificationGateway;

    public SupportTicketService(
        ISupportTicketRepository repository,
        IOrderGateway orderGateway,
        INotificationGateway notificationGateway)
    {
        _repository = repository;
        _orderGateway = orderGateway;
        _notificationGateway = notificationGateway;
    }

    public async Task<Result<SupportTicketResponse>> CreateAsync(
        Guid customerId,
        string bearerToken,
        CreateSupportTicketRequest request,
        CancellationToken cancellationToken)
    {
        if (customerId == Guid.Empty)
        {
            return Result.Fail<SupportTicketResponse>(Error.Validation("Customer id is required."));
        }

        if (request.OrderId == Guid.Empty)
        {
            return Result.Fail<SupportTicketResponse>(Error.Validation("Order id is invalid."));
        }

        var orderExists = await _orderGateway.ExistsForCustomerAsync(
            customerId,
            request.OrderId,
            bearerToken,
            cancellationToken);

        if (!orderExists)
        {
            return Result.Fail<SupportTicketResponse>(Error.Validation("Order id is invalid."));
        }

        if (string.IsNullOrWhiteSpace(request.Subject))
        {
            return Result.Fail<SupportTicketResponse>(Error.Validation("Subject is required."));
        }

        if (string.IsNullOrWhiteSpace(request.Description))
        {
            return Result.Fail<SupportTicketResponse>(Error.Validation("Description is required."));
        }

        var ticket = new SupportTicket(
            customerId,
            request.OrderId,
            request.Type,
            request.Subject,
            request.Description);

        await _repository.AddAsync(ticket, cancellationToken);
        await _repository.SaveChangesAsync(cancellationToken);
        await NotifyAsync(
            ticket.CustomerId,
            "SupportTicketCreated",
            "Support ticket created",
            ticket.Subject,
            cancellationToken);

        return Result.Ok(ToResponse(ticket));
    }

    public async Task<Result<IReadOnlyList<SupportTicketResponse>>> GetMineAsync(
        Guid customerId,
        CancellationToken cancellationToken)
    {
        var tickets = await _repository.GetByCustomerIdAsync(customerId, cancellationToken);
        return Result.Ok<IReadOnlyList<SupportTicketResponse>>(tickets.Select(ToResponse).ToArray());
    }

    public async Task<Result<IReadOnlyList<SupportTicketResponse>>> GetAllForStaffAsync(CancellationToken cancellationToken)
    {
        var tickets = await _repository.GetAllAsync(cancellationToken);
        return Result.Ok<IReadOnlyList<SupportTicketResponse>>(tickets.Select(ToResponse).ToArray());
    }

    public async Task<Result<SupportTicketResponse>> GetByIdAsync(
        Guid customerId,
        Guid ticketId,
        CancellationToken cancellationToken)
    {
        var ticket = await _repository.GetByIdAsync(ticketId, cancellationToken);
        if (ticket is null || ticket.CustomerId != customerId)
        {
            return Result.Fail<SupportTicketResponse>(Error.NotFound("Support ticket was not found."));
        }

        return Result.Ok(ToResponse(ticket));
    }

    public async Task<Result<SupportTicketResponse>> GetByIdForStaffAsync(
        Guid ticketId,
        CancellationToken cancellationToken)
    {
        var ticket = await _repository.GetByIdAsync(ticketId, cancellationToken);
        return ticket is null
            ? Result.Fail<SupportTicketResponse>(Error.NotFound("Support ticket was not found."))
            : Result.Ok(ToResponse(ticket));
    }

    public async Task<Result<SupportTicketResponse>> AddMessageAsync(
        Guid currentUserId,
        Guid ticketId,
        AddSupportTicketMessageRequest request,
        CancellationToken cancellationToken)
    {
        var ticket = await _repository.GetByIdAsync(ticketId, cancellationToken);
        if (ticket is null || !CanAccessTicket(ticket, currentUserId))
        {
            return Result.Fail<SupportTicketResponse>(Error.NotFound("Support ticket was not found."));
        }

        try
        {
            ticket.AddMessage(currentUserId, request.Message);
        }
        catch (InvalidOperationException ex)
        {
            return Result.Fail<SupportTicketResponse>(Error.Validation(ex.Message));
        }

        await _repository.SaveChangesAsync(cancellationToken);
        await NotifyAsync(
            ticket.CustomerId,
            "SupportTicketMessageAdded",
            "Support ticket updated",
            request.Message,
            cancellationToken);
        return Result.Ok(ToResponse(ticket));
    }

    public async Task<Result<SupportTicketResponse>> AddMessageForStaffAsync(
        Guid currentUserId,
        Guid ticketId,
        AddSupportTicketMessageRequest request,
        CancellationToken cancellationToken)
    {
        var ticket = await _repository.GetByIdAsync(ticketId, cancellationToken);
        if (ticket is null)
        {
            return Result.Fail<SupportTicketResponse>(Error.NotFound("Support ticket was not found."));
        }

        try
        {
            ticket.AddMessage(currentUserId, request.Message);
        }
        catch (InvalidOperationException ex)
        {
            return Result.Fail<SupportTicketResponse>(Error.Validation(ex.Message));
        }

        await _repository.SaveChangesAsync(cancellationToken);
        await NotifyAsync(
            ticket.CustomerId,
            "SupportTicketMessageAdded",
            "Support ticket updated",
            request.Message,
            cancellationToken);
        return Result.Ok(ToResponse(ticket));
    }

    public Task<Result<SupportTicketResponse>> AssignAsync(
        Guid currentUserId,
        Guid ticketId,
        AssignSupportTicketRequest request,
        CancellationToken cancellationToken)
    {
        return ChangeAsync(
            ticketId,
            ticket => ticket.Assign(request.AgentId, currentUserId),
            "SupportTicketAssigned",
            "Support ticket assigned",
            "A support agent has been assigned to your ticket.",
            cancellationToken);
    }

    public Task<Result<SupportTicketResponse>> ResolveAsync(
        Guid currentUserId,
        Guid ticketId,
        CancellationToken cancellationToken)
    {
        return ChangeAsync(
            ticketId,
            ticket => EnsureAssignedAgent(ticket, currentUserId, () => ticket.Resolve(currentUserId)),
            "SupportTicketResolved",
            "Support ticket resolved",
            "Your support ticket has been resolved.",
            cancellationToken);
    }

    public Task<Result<SupportTicketResponse>> RejectAsync(
        Guid currentUserId,
        Guid ticketId,
        CancellationToken cancellationToken)
    {
        return ChangeAsync(
            ticketId,
            ticket => EnsureAssignedAgent(ticket, currentUserId, () => ticket.Reject(currentUserId)),
            "SupportTicketRejected",
            "Support ticket rejected",
            "Your support ticket has been rejected.",
            cancellationToken);
    }

    public Task<Result<SupportTicketResponse>> CloseAsync(
        Guid currentUserId,
        Guid ticketId,
        CancellationToken cancellationToken)
    {
        return ChangeAsync(
            ticketId,
            ticket => EnsureCustomer(ticket, currentUserId, () => ticket.Close(currentUserId)),
            "SupportTicketClosed",
            "Support ticket closed",
            "Your support ticket has been closed.",
            cancellationToken);
    }

    public Task<Result<SupportTicketResponse>> CloseForStaffAsync(
        Guid currentUserId,
        Guid ticketId,
        CancellationToken cancellationToken)
    {
        return ChangeAsync(
            ticketId,
            ticket => ticket.Close(currentUserId),
            "SupportTicketClosed",
            "Support ticket closed",
            "Your support ticket has been closed.",
            cancellationToken);
    }

    private async Task<Result<SupportTicketResponse>> ChangeAsync(
        Guid ticketId,
        Action<SupportTicket> change,
        string notificationType,
        string notificationTitle,
        string notificationMessage,
        CancellationToken cancellationToken)
    {
        var ticket = await _repository.GetByIdAsync(ticketId, cancellationToken);
        if (ticket is null)
        {
            return Result.Fail<SupportTicketResponse>(Error.NotFound("Support ticket was not found."));
        }

        try
        {
            change(ticket);
        }
        catch (UnauthorizedAccessException ex)
        {
            return Result.Fail<SupportTicketResponse>(Error.Unauthorized(ex.Message));
        }
        catch (InvalidOperationException ex)
        {
            return Result.Fail<SupportTicketResponse>(Error.Validation(ex.Message));
        }

        await _repository.SaveChangesAsync(cancellationToken);
        await NotifyAsync(
            ticket.CustomerId,
            notificationType,
            notificationTitle,
            notificationMessage,
            cancellationToken);
        return Result.Ok(ToResponse(ticket));
    }

    private Task NotifyAsync(
        Guid customerId,
        string type,
        string title,
        string message,
        CancellationToken cancellationToken)
    {
        return _notificationGateway.CreateAsync(customerId, type, title, message, cancellationToken);
    }

    private static bool CanAccessTicket(SupportTicket ticket, Guid currentUserId)
    {
        return ticket.CustomerId == currentUserId || ticket.AssignedAgentId == currentUserId;
    }

    private static void EnsureAssignedAgent(SupportTicket ticket, Guid currentUserId, Action action)
    {
        if (ticket.AssignedAgentId != currentUserId)
        {
            throw new UnauthorizedAccessException("Only the assigned support agent can complete this ticket.");
        }

        action();
    }

    private static void EnsureCustomer(SupportTicket ticket, Guid currentUserId, Action action)
    {
        if (ticket.CustomerId != currentUserId)
        {
            throw new UnauthorizedAccessException("Only the customer can close this ticket.");
        }

        action();
    }

    private static SupportTicketResponse ToResponse(SupportTicket ticket)
    {
        return new SupportTicketResponse(
            ticket.Id,
            ticket.CustomerId,
            ticket.OrderId,
            ticket.Type,
            ticket.Subject,
            ticket.Description,
            ticket.Status,
            ticket.AssignedAgentId,
            ticket.Messages.Select(message => new SupportTicketMessageResponse(
                message.Id,
                message.SenderUserId,
                message.Message,
                message.CreatedAtUtc)).ToArray(),
            ticket.StatusHistory.Select(history => new SupportTicketStatusHistoryResponse(
                history.Id,
                history.Status,
                history.Note,
                history.ChangedByUserId,
                history.ChangedAtUtc)).ToArray(),
            ticket.CreatedAtUtc);
    }
}
