using Zellamart.Support.Domain.Tickets;

namespace Zellamart.Support.Application.Tickets;

public sealed record CreateSupportTicketRequest(
    Guid OrderId,
    SupportTicketType Type,
    string Subject,
    string Description);
