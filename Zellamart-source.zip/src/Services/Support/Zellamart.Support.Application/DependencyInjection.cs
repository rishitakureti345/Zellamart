using Microsoft.Extensions.DependencyInjection;
using Zellamart.Support.Application.Returns;
using Zellamart.Support.Application.Tickets;

namespace Zellamart.Support.Application;

public static class DependencyInjection
{
    public static IServiceCollection AddSupportApplication(this IServiceCollection services)
    {
        services.AddScoped<ISupportTicketService, SupportTicketService>();
        services.AddScoped<IReturnRequestService, ReturnRequestService>();
        return services;
    }
}
