namespace Zellamart.Support.Application.Abstractions;

public interface IOrderGateway
{
    Task<bool> ExistsForCustomerAsync(
        Guid customerId,
        Guid orderId,
        string bearerToken,
        CancellationToken cancellationToken);

    Task<OrderSnapshot?> GetOrderAsync(
        Guid customerId,
        Guid orderId,
        string bearerToken,
        CancellationToken cancellationToken);
}

public sealed record OrderSnapshot(
    Guid Id,
    Guid CustomerId,
    string Status,
    IReadOnlyList<OrderItemSnapshot> Items);

public sealed record OrderItemSnapshot(
    Guid Id,
    Guid ProductId,
    decimal LineTotal);
