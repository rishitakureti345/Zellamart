using Zellamart.Support.Domain.Returns;

namespace Zellamart.Support.Application.Abstractions;

public interface IReturnRequestRepository
{
    Task<ReturnRequest?> GetByIdAsync(Guid returnId, CancellationToken cancellationToken);

    Task<ReturnRequest?> GetByOrderItemIdAsync(Guid orderItemId, CancellationToken cancellationToken);

    Task<IReadOnlyList<ReturnRequest>> GetByCustomerIdAsync(Guid customerId, CancellationToken cancellationToken);

    Task<IReadOnlyList<ReturnRequest>> GetAllAsync(CancellationToken cancellationToken);

    Task AddAsync(ReturnRequest returnRequest, CancellationToken cancellationToken);

    Task SaveChangesAsync(CancellationToken cancellationToken);
}
