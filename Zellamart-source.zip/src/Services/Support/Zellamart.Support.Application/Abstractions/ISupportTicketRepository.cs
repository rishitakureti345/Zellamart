using Zellamart.Support.Domain.Tickets;

namespace Zellamart.Support.Application.Abstractions;

public interface ISupportTicketRepository
{
    Task<SupportTicket?> GetByIdAsync(Guid ticketId, CancellationToken cancellationToken);

    Task<IReadOnlyList<SupportTicket>> GetByCustomerIdAsync(Guid customerId, CancellationToken cancellationToken);

    Task<IReadOnlyList<SupportTicket>> GetAllAsync(CancellationToken cancellationToken);

    Task AddAsync(SupportTicket ticket, CancellationToken cancellationToken);

    Task SaveChangesAsync(CancellationToken cancellationToken);
}
