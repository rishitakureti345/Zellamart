namespace Zellamart.Support.Application.Returns;

public sealed record CreateReturnRequestRequest(
    Guid OrderId,
    Guid OrderItemId,
    Guid ProductId,
    string Reason);
