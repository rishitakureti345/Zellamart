using Zellamart.Support.Domain.Returns;

namespace Zellamart.Support.Application.Returns;

public sealed record ReturnRequestResponse(
    Guid Id,
    Guid OrderId,
    Guid OrderItemId,
    Guid CustomerId,
    Guid ProductId,
    string Reason,
    ReturnRequestStatus Status,
    decimal RefundAmount,
    IReadOnlyList<ReturnStatusHistoryResponse> StatusHistory,
    DateTimeOffset CreatedAtUtc);

public sealed record ReturnStatusHistoryResponse(
    Guid Id,
    ReturnRequestStatus Status,
    string Note,
    Guid? ChangedByUserId,
    DateTimeOffset ChangedAtUtc);
