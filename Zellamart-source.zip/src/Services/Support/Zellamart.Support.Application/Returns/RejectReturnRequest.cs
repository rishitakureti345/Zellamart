namespace Zellamart.Support.Application.Returns;

public sealed record RejectReturnRequest(string? Reason);
