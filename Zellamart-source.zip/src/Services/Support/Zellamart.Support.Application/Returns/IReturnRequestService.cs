using Zellamart.SharedKernel.Results;

namespace Zellamart.Support.Application.Returns;

public interface IReturnRequestService
{
    Task<Result<ReturnRequestResponse>> CreateAsync(
        Guid customerId,
        string bearerToken,
        CreateReturnRequestRequest request,
        CancellationToken cancellationToken);

    Task<Result<IReadOnlyList<ReturnRequestResponse>>> GetMineAsync(
        Guid customerId,
        CancellationToken cancellationToken);

    Task<Result<IReadOnlyList<ReturnRequestResponse>>> GetAllForStaffAsync(CancellationToken cancellationToken);

    Task<Result<ReturnRequestResponse>> GetByIdAsync(
        Guid customerId,
        Guid returnId,
        CancellationToken cancellationToken);

    Task<Result<ReturnRequestResponse>> GetByIdForStaffAsync(
        Guid returnId,
        CancellationToken cancellationToken);

    Task<Result<ReturnRequestResponse>> ApproveAsync(
        Guid currentUserId,
        Guid returnId,
        CancellationToken cancellationToken);

    Task<Result<ReturnRequestResponse>> RejectAsync(
        Guid currentUserId,
        Guid returnId,
        CancellationToken cancellationToken);

    Task<Result<ReturnRequestResponse>> RejectAsync(
        Guid currentUserId,
        Guid returnId,
        RejectReturnRequest request,
        CancellationToken cancellationToken);

    Task<Result<ReturnRequestResponse>> MarkPickedUpAsync(
        Guid currentUserId,
        Guid returnId,
        CancellationToken cancellationToken);

    Task<Result<ReturnRequestResponse>> MarkRefundedAsync(
        Guid currentUserId,
        Guid returnId,
        CancellationToken cancellationToken);

    Task<Result<ReturnRequestResponse>> RejectRefundAsync(
        Guid currentUserId,
        Guid returnId,
        RejectRefundRequest request,
        CancellationToken cancellationToken);
}
