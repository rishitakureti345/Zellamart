using Zellamart.SharedKernel.Results;
using Zellamart.Support.Application.Abstractions;
using Zellamart.Support.Domain.Returns;

namespace Zellamart.Support.Application.Returns;

public sealed class ReturnRequestService : IReturnRequestService
{
    private const string DeliveredStatus = "Delivered";

    private readonly IReturnRequestRepository _repository;
    private readonly IOrderGateway _orderGateway;
    private readonly INotificationGateway _notificationGateway;

    public ReturnRequestService(
        IReturnRequestRepository repository,
        IOrderGateway orderGateway,
        INotificationGateway notificationGateway)
    {
        _repository = repository;
        _orderGateway = orderGateway;
        _notificationGateway = notificationGateway;
    }

    public async Task<Result<ReturnRequestResponse>> CreateAsync(
        Guid customerId,
        string bearerToken,
        CreateReturnRequestRequest request,
        CancellationToken cancellationToken)
    {
        if (request.OrderId == Guid.Empty)
        {
            return Result.Fail<ReturnRequestResponse>(Error.Validation("Order id is required."));
        }

        if (request.OrderItemId == Guid.Empty)
        {
            return Result.Fail<ReturnRequestResponse>(Error.Validation("Order item id is required."));
        }

        if (request.ProductId == Guid.Empty)
        {
            return Result.Fail<ReturnRequestResponse>(Error.Validation("Product id is required."));
        }

        if (string.IsNullOrWhiteSpace(request.Reason))
        {
            return Result.Fail<ReturnRequestResponse>(Error.Validation("Reason is required."));
        }

        var existing = await _repository.GetByOrderItemIdAsync(request.OrderItemId, cancellationToken);
        if (existing is not null)
        {
            return Result.Fail<ReturnRequestResponse>(Error.Conflict("Return already requested for this order item."));
        }

        var order = await _orderGateway.GetOrderAsync(customerId, request.OrderId, bearerToken, cancellationToken);
        if (order is null)
        {
            return Result.Fail<ReturnRequestResponse>(Error.Validation("Order is invalid."));
        }

        if (!string.Equals(order.Status, DeliveredStatus, StringComparison.OrdinalIgnoreCase))
        {
            return Result.Fail<ReturnRequestResponse>(Error.Validation("Order must be delivered before requesting a return."));
        }

        var orderItem = order.Items.FirstOrDefault(item => item.Id == request.OrderItemId);
        if (orderItem is null || orderItem.ProductId != request.ProductId)
        {
            return Result.Fail<ReturnRequestResponse>(Error.Validation("Product is invalid for this order."));
        }

        var returnRequest = new ReturnRequest(
            request.OrderId,
            request.OrderItemId,
            customerId,
            request.ProductId,
            request.Reason,
            orderItem.LineTotal);

        await _repository.AddAsync(returnRequest, cancellationToken);
        await _repository.SaveChangesAsync(cancellationToken);
        await NotifyAsync(
            returnRequest.CustomerId,
            "ReturnRequested",
            "Return requested",
            returnRequest.Reason,
            cancellationToken);

        return Result.Ok(ToResponse(returnRequest));
    }

    public async Task<Result<IReadOnlyList<ReturnRequestResponse>>> GetMineAsync(
        Guid customerId,
        CancellationToken cancellationToken)
    {
        var returns = await _repository.GetByCustomerIdAsync(customerId, cancellationToken);
        return Result.Ok<IReadOnlyList<ReturnRequestResponse>>(returns.Select(ToResponse).ToArray());
    }

    public async Task<Result<IReadOnlyList<ReturnRequestResponse>>> GetAllForStaffAsync(CancellationToken cancellationToken)
    {
        var returns = await _repository.GetAllAsync(cancellationToken);
        return Result.Ok<IReadOnlyList<ReturnRequestResponse>>(returns.Select(ToResponse).ToArray());
    }

    public async Task<Result<ReturnRequestResponse>> GetByIdAsync(
        Guid customerId,
        Guid returnId,
        CancellationToken cancellationToken)
    {
        var returnRequest = await _repository.GetByIdAsync(returnId, cancellationToken);
        if (returnRequest is null || returnRequest.CustomerId != customerId)
        {
            return Result.Fail<ReturnRequestResponse>(Error.NotFound("Return request was not found."));
        }

        return Result.Ok(ToResponse(returnRequest));
    }

    public async Task<Result<ReturnRequestResponse>> GetByIdForStaffAsync(
        Guid returnId,
        CancellationToken cancellationToken)
    {
        var returnRequest = await _repository.GetByIdAsync(returnId, cancellationToken);
        if (returnRequest is null)
        {
            return Result.Fail<ReturnRequestResponse>(Error.NotFound("Return request was not found."));
        }

        return Result.Ok(ToResponse(returnRequest));
    }

    public Task<Result<ReturnRequestResponse>> ApproveAsync(
        Guid currentUserId,
        Guid returnId,
        CancellationToken cancellationToken)
    {
        return ChangeAsync(
            returnId,
            returnRequest => returnRequest.Approve(currentUserId),
            "ReturnApproved",
            "Return approved",
            "Your return request has been approved.",
            cancellationToken);
    }

    public Task<Result<ReturnRequestResponse>> RejectAsync(
        Guid currentUserId,
        Guid returnId,
        CancellationToken cancellationToken)
    {
        return ChangeAsync(
            returnId,
            returnRequest => returnRequest.Reject(currentUserId),
            "ReturnRejected",
            "Return rejected",
            "Your return request has been rejected.",
            cancellationToken);
    }

    public Task<Result<ReturnRequestResponse>> RejectAsync(
        Guid currentUserId,
        Guid returnId,
        RejectReturnRequest request,
        CancellationToken cancellationToken)
    {
        var reason = string.IsNullOrWhiteSpace(request.Reason) ? "Return rejected." : request.Reason;
        return ChangeAsync(
            returnId,
            returnRequest => returnRequest.Reject(currentUserId, reason),
            "ReturnRejected",
            "Return rejected",
            reason,
            cancellationToken);
    }

    public Task<Result<ReturnRequestResponse>> MarkPickedUpAsync(
        Guid currentUserId,
        Guid returnId,
        CancellationToken cancellationToken)
    {
        return ChangeAsync(
            returnId,
            returnRequest => returnRequest.MarkPickedUp(currentUserId),
            "ReturnPickedUp",
            "Return picked up",
            "Your return has been picked up.",
            cancellationToken);
    }

    public Task<Result<ReturnRequestResponse>> MarkRefundedAsync(
        Guid currentUserId,
        Guid returnId,
        CancellationToken cancellationToken)
    {
        return ChangeAsync(
            returnId,
            returnRequest => returnRequest.MarkRefunded(currentUserId),
            "ReturnRefunded",
            "Refund completed",
            "Your refund has been completed.",
            cancellationToken);
    }

    public Task<Result<ReturnRequestResponse>> RejectRefundAsync(
        Guid currentUserId,
        Guid returnId,
        RejectRefundRequest request,
        CancellationToken cancellationToken)
    {
        var reason = string.IsNullOrWhiteSpace(request.Reason) ? "Refund rejected." : request.Reason;
        return ChangeAsync(
            returnId,
            returnRequest => returnRequest.RejectRefund(currentUserId, reason),
            "RefundRejected",
            "Refund rejected",
            reason,
            cancellationToken);
    }

    private async Task<Result<ReturnRequestResponse>> ChangeAsync(
        Guid returnId,
        Action<ReturnRequest> change,
        string notificationType,
        string notificationTitle,
        string notificationMessage,
        CancellationToken cancellationToken)
    {
        var returnRequest = await _repository.GetByIdAsync(returnId, cancellationToken);
        if (returnRequest is null)
        {
            return Result.Fail<ReturnRequestResponse>(Error.NotFound("Return request was not found."));
        }

        try
        {
            change(returnRequest);
        }
        catch (InvalidOperationException ex)
        {
            return Result.Fail<ReturnRequestResponse>(Error.Validation(ex.Message));
        }

        await _repository.SaveChangesAsync(cancellationToken);
        await NotifyAsync(
            returnRequest.CustomerId,
            notificationType,
            notificationTitle,
            notificationMessage,
            cancellationToken);
        return Result.Ok(ToResponse(returnRequest));
    }

    private Task NotifyAsync(
        Guid customerId,
        string type,
        string title,
        string message,
        CancellationToken cancellationToken)
    {
        return _notificationGateway.CreateAsync(customerId, type, title, message, cancellationToken);
    }

    private static ReturnRequestResponse ToResponse(ReturnRequest returnRequest)
    {
        return new ReturnRequestResponse(
            returnRequest.Id,
            returnRequest.OrderId,
            returnRequest.OrderItemId,
            returnRequest.CustomerId,
            returnRequest.ProductId,
            returnRequest.Reason,
            returnRequest.Status,
            returnRequest.RefundAmount,
            returnRequest.StatusHistory.Select(history => new ReturnStatusHistoryResponse(
                history.Id,
                history.Status,
                history.Note,
                history.ChangedByUserId,
                history.ChangedAtUtc)).ToArray(),
            returnRequest.CreatedAtUtc);
    }
}
