namespace Zellamart.Support.Application.Returns;

public sealed record RejectRefundRequest(string? Reason);
