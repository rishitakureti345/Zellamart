using Zellamart.SharedKernel.Entities;

namespace Zellamart.Support.Domain.Tickets;

public sealed class SupportTicketMessage : BaseEntity
{
    private SupportTicketMessage()
    {
    }

    public SupportTicketMessage(Guid ticketId, Guid senderUserId, string message)
    {
        if (ticketId == Guid.Empty)
        {
            throw new InvalidOperationException("Ticket id is required.");
        }

        if (senderUserId == Guid.Empty)
        {
            throw new InvalidOperationException("Sender user id is required.");
        }

        if (string.IsNullOrWhiteSpace(message))
        {
            throw new InvalidOperationException("Message is required.");
        }

        TicketId = ticketId;
        SenderUserId = senderUserId;
        Message = message.Trim();
        CreatedAtUtc = DateTimeOffset.UtcNow;
    }

    public Guid TicketId { get; private set; }

    public Guid SenderUserId { get; private set; }

    public string Message { get; private set; } = string.Empty;

    public DateTimeOffset CreatedAtUtc { get; private set; }

    public SupportTicket Ticket { get; private set; } = null!;
}
