using Zellamart.SharedKernel.Entities;

namespace Zellamart.Support.Domain.Tickets;

public sealed class SupportTicket : AuditableEntity
{
    private readonly List<SupportTicketMessage> _messages = [];
    private readonly List<SupportTicketStatusHistory> _statusHistory = [];

    private SupportTicket()
    {
    }

    public SupportTicket(
        Guid customerId,
        Guid orderId,
        SupportTicketType type,
        string subject,
        string description)
    {
        if (customerId == Guid.Empty)
        {
            throw new InvalidOperationException("Customer id is required.");
        }

        if (orderId == Guid.Empty)
        {
            throw new InvalidOperationException("Order id is required.");
        }

        if (string.IsNullOrWhiteSpace(subject))
        {
            throw new InvalidOperationException("Subject is required.");
        }

        if (string.IsNullOrWhiteSpace(description))
        {
            throw new InvalidOperationException("Description is required.");
        }

        CustomerId = customerId;
        OrderId = orderId;
        Type = type;
        Subject = subject.Trim();
        Description = description.Trim();
        Status = SupportTicketStatus.Open;

        AddStatusHistory(SupportTicketStatus.Open, "Support ticket created.", customerId);
    }

    public Guid CustomerId { get; private set; }

    public Guid OrderId { get; private set; }

    public SupportTicketType Type { get; private set; }

    public string Subject { get; private set; } = string.Empty;

    public string Description { get; private set; } = string.Empty;

    public SupportTicketStatus Status { get; private set; }

    public Guid? AssignedAgentId { get; private set; }

    public IReadOnlyCollection<SupportTicketMessage> Messages => _messages;

    public IReadOnlyCollection<SupportTicketStatusHistory> StatusHistory => _statusHistory;

    public void AddMessage(Guid senderUserId, string message)
    {
        if (Status == SupportTicketStatus.Closed)
        {
            throw new InvalidOperationException("Closed tickets cannot receive messages.");
        }

        _messages.Add(new SupportTicketMessage(Id, senderUserId, message));
        UpdatedAtUtc = DateTimeOffset.UtcNow;
    }

    public void Assign(Guid agentId, Guid changedByUserId)
    {
        if (agentId == Guid.Empty)
        {
            throw new InvalidOperationException("Agent id is required.");
        }

        if (Status is SupportTicketStatus.Resolved or SupportTicketStatus.Rejected or SupportTicketStatus.Closed)
        {
            throw new InvalidOperationException("Resolved, rejected, or closed tickets cannot be assigned.");
        }

        AssignedAgentId = agentId;
        ChangeStatus(SupportTicketStatus.InProgress, "Support agent assigned.", changedByUserId);
    }

    public void Resolve(Guid changedByUserId)
    {
        EnsureCanComplete();
        ChangeStatus(SupportTicketStatus.Resolved, "Support ticket resolved.", changedByUserId);
    }

    public void Reject(Guid changedByUserId)
    {
        EnsureCanComplete();
        ChangeStatus(SupportTicketStatus.Rejected, "Support ticket rejected.", changedByUserId);
    }

    public void Close(Guid changedByUserId)
    {
        if (Status is not SupportTicketStatus.Resolved and not SupportTicketStatus.Rejected)
        {
            throw new InvalidOperationException("Only resolved or rejected tickets can be closed.");
        }

        ChangeStatus(SupportTicketStatus.Closed, "Support ticket closed.", changedByUserId);
    }

    private void EnsureCanComplete()
    {
        if (Status != SupportTicketStatus.InProgress)
        {
            throw new InvalidOperationException("Only in-progress tickets can be resolved or rejected.");
        }

        if (AssignedAgentId is null)
        {
            throw new InvalidOperationException("Support ticket must be assigned before completion.");
        }
    }

    private void ChangeStatus(SupportTicketStatus status, string note, Guid changedByUserId)
    {
        Status = status;
        UpdatedAtUtc = DateTimeOffset.UtcNow;
        AddStatusHistory(status, note, changedByUserId);
    }

    private void AddStatusHistory(SupportTicketStatus status, string note, Guid? changedByUserId)
    {
        _statusHistory.Add(new SupportTicketStatusHistory(Id, status, note, changedByUserId));
    }
}
