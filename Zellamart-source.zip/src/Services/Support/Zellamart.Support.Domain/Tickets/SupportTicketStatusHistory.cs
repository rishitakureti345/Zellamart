using Zellamart.SharedKernel.Entities;

namespace Zellamart.Support.Domain.Tickets;

public sealed class SupportTicketStatusHistory : BaseEntity
{
    private SupportTicketStatusHistory()
    {
    }

    public SupportTicketStatusHistory(
        Guid ticketId,
        SupportTicketStatus status,
        string note,
        Guid? changedByUserId)
    {
        TicketId = ticketId;
        Status = status;
        Note = note.Trim();
        ChangedByUserId = changedByUserId;
        ChangedAtUtc = DateTimeOffset.UtcNow;
    }

    public Guid TicketId { get; private set; }

    public SupportTicketStatus Status { get; private set; }

    public string Note { get; private set; } = string.Empty;

    public Guid? ChangedByUserId { get; private set; }

    public DateTimeOffset ChangedAtUtc { get; private set; }

    public SupportTicket Ticket { get; private set; } = null!;
}
