namespace Zellamart.Support.Domain.Tickets;

public enum SupportTicketType
{
    OrderIssue = 1,
    PaymentIssue = 2,
    DeliveryIssue = 3,
    ReturnRequest = 4,
    RefundRequest = 5,
    ProductIssue = 6,
    Other = 7
}
