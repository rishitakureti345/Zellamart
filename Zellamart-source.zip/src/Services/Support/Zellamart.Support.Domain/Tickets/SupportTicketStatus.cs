namespace Zellamart.Support.Domain.Tickets;

public enum SupportTicketStatus
{
    Open = 1,
    InProgress = 2,
    Resolved = 3,
    Rejected = 4,
    Closed = 5
}
