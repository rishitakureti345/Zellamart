namespace Zellamart.Support.Domain.Returns;

public enum ReturnRequestStatus
{
    Requested = 1,
    Approved = 2,
    Rejected = 3,
    PickupScheduled = 4,
    PickedUp = 5,
    RefundInitiated = 6,
    Refunded = 7,
    Closed = 8
}
