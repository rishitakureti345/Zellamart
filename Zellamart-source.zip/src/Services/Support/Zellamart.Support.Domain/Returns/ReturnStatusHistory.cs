using Zellamart.SharedKernel.Entities;

namespace Zellamart.Support.Domain.Returns;

public sealed class ReturnStatusHistory : BaseEntity
{
    private ReturnStatusHistory()
    {
    }

    public ReturnStatusHistory(
        Guid returnRequestId,
        ReturnRequestStatus status,
        string note,
        Guid? changedByUserId)
    {
        ReturnRequestId = returnRequestId;
        Status = status;
        Note = note.Trim();
        ChangedByUserId = changedByUserId;
        ChangedAtUtc = DateTimeOffset.UtcNow;
    }

    public Guid ReturnRequestId { get; private set; }

    public ReturnRequestStatus Status { get; private set; }

    public string Note { get; private set; } = string.Empty;

    public Guid? ChangedByUserId { get; private set; }

    public DateTimeOffset ChangedAtUtc { get; private set; }

    public ReturnRequest ReturnRequest { get; private set; } = null!;
}
