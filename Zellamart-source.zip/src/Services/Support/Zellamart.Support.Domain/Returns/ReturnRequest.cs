using Zellamart.SharedKernel.Entities;

namespace Zellamart.Support.Domain.Returns;

public sealed class ReturnRequest : AuditableEntity
{
    private readonly List<ReturnStatusHistory> _statusHistory = [];

    private ReturnRequest()
    {
    }

    public ReturnRequest(
        Guid orderId,
        Guid orderItemId,
        Guid customerId,
        Guid productId,
        string reason,
        decimal refundAmount)
    {
        if (orderId == Guid.Empty)
        {
            throw new InvalidOperationException("Order id is required.");
        }

        if (orderItemId == Guid.Empty)
        {
            throw new InvalidOperationException("Order item id is required.");
        }

        if (customerId == Guid.Empty)
        {
            throw new InvalidOperationException("Customer id is required.");
        }

        if (productId == Guid.Empty)
        {
            throw new InvalidOperationException("Product id is required.");
        }

        if (string.IsNullOrWhiteSpace(reason))
        {
            throw new InvalidOperationException("Reason is required.");
        }

        if (refundAmount <= 0)
        {
            throw new InvalidOperationException("Refund amount must be greater than zero.");
        }

        OrderId = orderId;
        OrderItemId = orderItemId;
        CustomerId = customerId;
        ProductId = productId;
        Reason = reason.Trim();
        RefundAmount = refundAmount;
        Status = ReturnRequestStatus.Requested;

        AddStatusHistory(ReturnRequestStatus.Requested, "Return requested.", customerId);
    }

    public Guid OrderId { get; private set; }

    public Guid OrderItemId { get; private set; }

    public Guid CustomerId { get; private set; }

    public Guid ProductId { get; private set; }

    public string Reason { get; private set; } = string.Empty;

    public ReturnRequestStatus Status { get; private set; }

    public decimal RefundAmount { get; private set; }

    public IReadOnlyCollection<ReturnStatusHistory> StatusHistory => _statusHistory;

    public void Approve(Guid changedByUserId)
    {
        EnsureStatus(ReturnRequestStatus.Requested, "Only requested returns can be approved.");
        ChangeStatus(ReturnRequestStatus.Approved, "Return approved.", changedByUserId);
    }

    public void Reject(Guid changedByUserId)
    {
        EnsureStatus(ReturnRequestStatus.Requested, "Only requested returns can be rejected.");
        ChangeStatus(ReturnRequestStatus.Rejected, "Return rejected.", changedByUserId);
    }

    public void Reject(Guid changedByUserId, string reason)
    {
        EnsureStatus(ReturnRequestStatus.Requested, "Only requested returns can be rejected.");
        var note = string.IsNullOrWhiteSpace(reason) ? "Return rejected." : reason;
        ChangeStatus(ReturnRequestStatus.Rejected, note, changedByUserId);
    }

    public void SchedulePickup(Guid changedByUserId)
    {
        EnsureStatus(ReturnRequestStatus.Approved, "Only approved returns can schedule pickup.");
        ChangeStatus(ReturnRequestStatus.PickupScheduled, "Return pickup scheduled.", changedByUserId);
    }

    public void MarkPickedUp(Guid changedByUserId)
    {
        if (Status == ReturnRequestStatus.Approved)
        {
            SchedulePickup(changedByUserId);
        }

        EnsureStatus(ReturnRequestStatus.PickupScheduled, "Only scheduled returns can be marked picked up.");
        ChangeStatus(ReturnRequestStatus.PickedUp, "Return picked up.", changedByUserId);
    }

    public void InitiateRefund(Guid changedByUserId)
    {
        EnsureStatus(ReturnRequestStatus.PickedUp, "Only picked up returns can initiate refund.");
        ChangeStatus(ReturnRequestStatus.RefundInitiated, "Refund initiated.", changedByUserId);
    }

    public void MarkRefunded(Guid changedByUserId)
    {
        if (Status == ReturnRequestStatus.PickedUp)
        {
            InitiateRefund(changedByUserId);
        }

        EnsureStatus(ReturnRequestStatus.RefundInitiated, "Only initiated refunds can be marked refunded.");
        ChangeStatus(ReturnRequestStatus.Refunded, "Refund completed.", changedByUserId);
    }

    public void RejectRefund(Guid changedByUserId, string reason)
    {
        if (Status is not ReturnRequestStatus.PickedUp and not ReturnRequestStatus.RefundInitiated)
        {
            throw new InvalidOperationException("Only picked up or initiated refunds can be rejected.");
        }

        var note = string.IsNullOrWhiteSpace(reason) ? "Refund rejected." : reason;
        ChangeStatus(ReturnRequestStatus.Closed, note, changedByUserId);
    }

    public void Close(Guid changedByUserId)
    {
        if (Status is not ReturnRequestStatus.Refunded and not ReturnRequestStatus.Rejected)
        {
            throw new InvalidOperationException("Only refunded or rejected returns can be closed.");
        }

        ChangeStatus(ReturnRequestStatus.Closed, "Return closed.", changedByUserId);
    }

    private void EnsureStatus(ReturnRequestStatus expectedStatus, string message)
    {
        if (Status != expectedStatus)
        {
            throw new InvalidOperationException(message);
        }
    }

    private void ChangeStatus(ReturnRequestStatus status, string note, Guid changedByUserId)
    {
        Status = status;
        UpdatedAtUtc = DateTimeOffset.UtcNow;
        AddStatusHistory(status, note, changedByUserId);
    }

    private void AddStatusHistory(ReturnRequestStatus status, string note, Guid? changedByUserId)
    {
        _statusHistory.Add(new ReturnStatusHistory(Id, status, note, changedByUserId));
    }
}
