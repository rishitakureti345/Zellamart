using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Zellamart.SharedKernel.Results;
using Zellamart.Support.Application.Tickets;

namespace Zellamart.Support.Api.Controllers;

[ApiController]
[Authorize]
[Route("api/support/tickets")]
public sealed class SupportTicketsController : ControllerBase
{
    private readonly ISupportTicketService _ticketService;

    public SupportTicketsController(ISupportTicketService ticketService)
    {
        _ticketService = ticketService;
    }

    [Authorize(Roles = "SuperAdmin,Admin,Customer")]
    [HttpPost]
    public async Task<IActionResult> Create(
        CreateSupportTicketRequest request,
        CancellationToken cancellationToken)
    {
        var userId = GetCurrentUserId();
        if (userId is null)
        {
            return Unauthorized();
        }

        var result = await _ticketService.CreateAsync(userId.Value, GetBearerToken(), request, cancellationToken);
        return result.Success ? Ok(result) : ToFailureResult(result);
    }

    [Authorize(Roles = "SuperAdmin,Admin,Customer")]
    [HttpGet("me")]
    public async Task<IActionResult> GetMine(CancellationToken cancellationToken)
    {
        var userId = GetCurrentUserId();
        if (userId is null)
        {
            return Unauthorized();
        }

        var result = await _ticketService.GetMineAsync(userId.Value, cancellationToken);
        return Ok(result);
    }

    [Authorize(Roles = "SuperAdmin,Admin,SupportManager,SupportAgent")]
    [HttpGet("admin/all")]
    public async Task<IActionResult> GetAllForStaff(CancellationToken cancellationToken)
    {
        var result = await _ticketService.GetAllForStaffAsync(cancellationToken);
        return Ok(result);
    }

    [Authorize(Roles = "SuperAdmin,Admin,Customer,SupportManager,SupportAgent")]
    [HttpGet("{ticketId:guid}")]
    public async Task<IActionResult> GetById(Guid ticketId, CancellationToken cancellationToken)
    {
        var userId = GetCurrentUserId();
        if (userId is null)
        {
            return Unauthorized();
        }

        var result = CanManageTickets()
            ? await _ticketService.GetByIdForStaffAsync(ticketId, cancellationToken)
            : await _ticketService.GetByIdAsync(userId.Value, ticketId, cancellationToken);
        return result.Success ? Ok(result) : ToFailureResult(result);
    }

    [Authorize(Roles = "SuperAdmin,Admin,Customer,SupportManager,SupportAgent")]
    [HttpPost("{ticketId:guid}/messages")]
    public async Task<IActionResult> AddMessage(
        Guid ticketId,
        AddSupportTicketMessageRequest request,
        CancellationToken cancellationToken)
    {
        var userId = GetCurrentUserId();
        if (userId is null)
        {
            return Unauthorized();
        }

        var result = await _ticketService.AddMessageAsync(userId.Value, ticketId, request, cancellationToken);
        return result.Success ? Ok(result) : ToFailureResult(result);
    }

    [Authorize(Roles = "SuperAdmin,Admin,SupportManager,SupportAgent")]
    [HttpPost("admin/{ticketId:guid}/messages")]
    public async Task<IActionResult> AddMessageForStaff(
        Guid ticketId,
        AddSupportTicketMessageRequest request,
        CancellationToken cancellationToken)
    {
        var userId = GetCurrentUserId();
        if (userId is null)
        {
            return Unauthorized();
        }

        var result = await _ticketService.AddMessageForStaffAsync(userId.Value, ticketId, request, cancellationToken);
        return result.Success ? Ok(result) : ToFailureResult(result);
    }

    [Authorize(Roles = "SuperAdmin,Admin,SupportManager")]
    [HttpPost("{ticketId:guid}/assign")]
    public async Task<IActionResult> Assign(
        Guid ticketId,
        AssignSupportTicketRequest request,
        CancellationToken cancellationToken)
    {
        var userId = GetCurrentUserId();
        if (userId is null)
        {
            return Unauthorized();
        }

        var result = await _ticketService.AssignAsync(userId.Value, ticketId, request, cancellationToken);
        return result.Success ? Ok(result) : ToFailureResult(result);
    }

    [Authorize(Roles = "SuperAdmin,Admin,SupportManager,SupportAgent")]
    [HttpPost("{ticketId:guid}/resolve")]
    public async Task<IActionResult> Resolve(Guid ticketId, CancellationToken cancellationToken)
    {
        var userId = GetCurrentUserId();
        if (userId is null)
        {
            return Unauthorized();
        }

        var result = await _ticketService.ResolveAsync(userId.Value, ticketId, cancellationToken);
        return result.Success ? Ok(result) : ToFailureResult(result);
    }

    [Authorize(Roles = "SuperAdmin,Admin,SupportManager,SupportAgent")]
    [HttpPost("{ticketId:guid}/reject")]
    public async Task<IActionResult> Reject(Guid ticketId, CancellationToken cancellationToken)
    {
        var userId = GetCurrentUserId();
        if (userId is null)
        {
            return Unauthorized();
        }

        var result = await _ticketService.RejectAsync(userId.Value, ticketId, cancellationToken);
        return result.Success ? Ok(result) : ToFailureResult(result);
    }

    [Authorize(Roles = "SuperAdmin,Admin,Customer,SupportManager,SupportAgent")]
    [HttpPost("{ticketId:guid}/close")]
    public async Task<IActionResult> Close(Guid ticketId, CancellationToken cancellationToken)
    {
        var userId = GetCurrentUserId();
        if (userId is null)
        {
            return Unauthorized();
        }

        var result = await _ticketService.CloseAsync(userId.Value, ticketId, cancellationToken);
        return result.Success ? Ok(result) : ToFailureResult(result);
    }

    [Authorize(Roles = "SuperAdmin,Admin,SupportManager,SupportAgent")]
    [HttpPost("admin/{ticketId:guid}/close")]
    public async Task<IActionResult> CloseForStaff(Guid ticketId, CancellationToken cancellationToken)
    {
        var userId = GetCurrentUserId();
        if (userId is null)
        {
            return Unauthorized();
        }

        var result = await _ticketService.CloseForStaffAsync(userId.Value, ticketId, cancellationToken);
        return result.Success ? Ok(result) : ToFailureResult(result);
    }

    private Guid? GetCurrentUserId()
    {
        var userIdValue = User.FindFirstValue(ClaimTypes.NameIdentifier)
            ?? User.FindFirst(JwtRegisteredClaimNames.Sub)?.Value;

        return Guid.TryParse(userIdValue, out var userId) ? userId : null;
    }

    private string GetBearerToken()
    {
        var authorization = Request.Headers.Authorization.ToString();
        return authorization.StartsWith("Bearer ", StringComparison.OrdinalIgnoreCase)
            ? authorization["Bearer ".Length..]
            : string.Empty;
    }

    private bool CanManageTickets()
    {
        return User.IsInRole("SuperAdmin")
            || User.IsInRole("Admin")
            || User.IsInRole("SupportManager")
            || User.IsInRole("SupportAgent");
    }

    private IActionResult ToFailureResult<T>(Result<T> result)
    {
        return result.Error.Code switch
        {
            "NotFound" => NotFound(result),
            "Conflict" => Conflict(result),
            "Unauthorized" => Forbid(),
            _ => BadRequest(result)
        };
    }
}
