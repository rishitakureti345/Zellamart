using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Zellamart.SharedKernel.Results;
using Zellamart.Support.Application.Returns;

namespace Zellamart.Support.Api.Controllers;

[ApiController]
[Authorize]
[Route("api/support/returns")]
public sealed class SupportReturnsController : ControllerBase
{
    private readonly IReturnRequestService _returnService;

    public SupportReturnsController(IReturnRequestService returnService)
    {
        _returnService = returnService;
    }

    [Authorize(Roles = "SuperAdmin,Admin,Customer")]
    [HttpPost]
    public async Task<IActionResult> Create(
        CreateReturnRequestRequest request,
        CancellationToken cancellationToken)
    {
        var userId = GetCurrentUserId();
        if (userId is null)
        {
            return Unauthorized();
        }

        var result = await _returnService.CreateAsync(userId.Value, GetBearerToken(), request, cancellationToken);
        return result.Success ? Ok(result) : ToFailureResult(result);
    }

    [Authorize(Roles = "SuperAdmin,Admin,Customer")]
    [HttpGet("me")]
    public async Task<IActionResult> GetMine(CancellationToken cancellationToken)
    {
        var userId = GetCurrentUserId();
        if (userId is null)
        {
            return Unauthorized();
        }

        var result = await _returnService.GetMineAsync(userId.Value, cancellationToken);
        return Ok(result);
    }

    [Authorize(Roles = "SuperAdmin,Admin,SupportManager,SupportAgent,FinanceManager,PaymentTeam")]
    [HttpGet("admin/all")]
    public async Task<IActionResult> GetAllForStaff(CancellationToken cancellationToken)
    {
        var result = await _returnService.GetAllForStaffAsync(cancellationToken);
        return Ok(result);
    }

    [Authorize(Roles = "SuperAdmin,Admin,Customer,SupportManager,SupportAgent,FinanceManager,PaymentTeam")]
    [HttpGet("{returnId:guid}")]
    public async Task<IActionResult> GetById(Guid returnId, CancellationToken cancellationToken)
    {
        var userId = GetCurrentUserId();
        if (userId is null)
        {
            return Unauthorized();
        }

        var result = CanManageReturns()
            ? await _returnService.GetByIdForStaffAsync(returnId, cancellationToken)
            : await _returnService.GetByIdAsync(userId.Value, returnId, cancellationToken);
        return result.Success ? Ok(result) : ToFailureResult(result);
    }

    [Authorize(Roles = "SuperAdmin,Admin,SupportManager,SupportAgent")]
    [HttpPost("{returnId:guid}/approve")]
    public async Task<IActionResult> Approve(Guid returnId, CancellationToken cancellationToken)
    {
        var userId = GetCurrentUserId();
        if (userId is null)
        {
            return Unauthorized();
        }

        var result = await _returnService.ApproveAsync(userId.Value, returnId, cancellationToken);
        return result.Success ? Ok(result) : ToFailureResult(result);
    }

    [Authorize(Roles = "SuperAdmin,Admin,SupportManager,SupportAgent")]
    [HttpPost("{returnId:guid}/reject")]
    public async Task<IActionResult> Reject(
        Guid returnId,
        RejectReturnRequest request,
        CancellationToken cancellationToken)
    {
        var userId = GetCurrentUserId();
        if (userId is null)
        {
            return Unauthorized();
        }

        var result = await _returnService.RejectAsync(userId.Value, returnId, request, cancellationToken);
        return result.Success ? Ok(result) : ToFailureResult(result);
    }

    [Authorize(Roles = "SuperAdmin,Admin,SupportManager,SupportAgent,DeliveryManager,DeliveryPartner")]
    [HttpPost("{returnId:guid}/mark-picked-up")]
    public async Task<IActionResult> MarkPickedUp(Guid returnId, CancellationToken cancellationToken)
    {
        var userId = GetCurrentUserId();
        if (userId is null)
        {
            return Unauthorized();
        }

        var result = await _returnService.MarkPickedUpAsync(userId.Value, returnId, cancellationToken);
        return result.Success ? Ok(result) : ToFailureResult(result);
    }

    [Authorize(Roles = "SuperAdmin,Admin,SupportManager,FinanceManager,PaymentTeam")]
    [HttpPost("{returnId:guid}/refund")]
    public async Task<IActionResult> MarkRefunded(Guid returnId, CancellationToken cancellationToken)
    {
        var userId = GetCurrentUserId();
        if (userId is null)
        {
            return Unauthorized();
        }

        var result = await _returnService.MarkRefundedAsync(userId.Value, returnId, cancellationToken);
        return result.Success ? Ok(result) : ToFailureResult(result);
    }

    [Authorize(Roles = "SuperAdmin,Admin,SupportManager,FinanceManager,PaymentTeam")]
    [HttpPost("{returnId:guid}/refund/reject")]
    public async Task<IActionResult> RejectRefund(
        Guid returnId,
        RejectRefundRequest request,
        CancellationToken cancellationToken)
    {
        var userId = GetCurrentUserId();
        if (userId is null)
        {
            return Unauthorized();
        }

        var result = await _returnService.RejectRefundAsync(userId.Value, returnId, request, cancellationToken);
        return result.Success ? Ok(result) : ToFailureResult(result);
    }

    private Guid? GetCurrentUserId()
    {
        var userIdValue = User.FindFirstValue(ClaimTypes.NameIdentifier)
            ?? User.FindFirst(JwtRegisteredClaimNames.Sub)?.Value;

        return Guid.TryParse(userIdValue, out var userId) ? userId : null;
    }

    private string GetBearerToken()
    {
        var authorization = Request.Headers.Authorization.ToString();
        return authorization.StartsWith("Bearer ", StringComparison.OrdinalIgnoreCase)
            ? authorization["Bearer ".Length..]
            : string.Empty;
    }

    private bool CanManageReturns()
    {
        return User.IsInRole("SuperAdmin")
            || User.IsInRole("Admin")
            || User.IsInRole("SupportManager")
            || User.IsInRole("SupportAgent")
            || User.IsInRole("FinanceManager")
            || User.IsInRole("PaymentTeam");
    }

    private IActionResult ToFailureResult<T>(Result<T> result)
    {
        return result.Error.Code switch
        {
            "NotFound" => NotFound(result),
            "Conflict" => Conflict(result),
            "Unauthorized" => Forbid(),
            _ => BadRequest(result)
        };
    }
}
