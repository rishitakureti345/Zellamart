using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Zellamart.Support.Application.Abstractions;
using Zellamart.Support.Infrastructure.Persistence;
using Zellamart.Support.Infrastructure.Services;

namespace Zellamart.Support.Infrastructure;

public static class DependencyInjection
{
    public static IServiceCollection AddSupportInfrastructure(
        this IServiceCollection services,
        IConfiguration configuration)
    {
        services.AddDbContext<SupportDbContext>(options =>
            options.UseNpgsql(configuration.GetConnectionString("Support")));

        services.AddScoped<ISupportTicketRepository, SupportTicketRepository>();
        services.AddScoped<IReturnRequestRepository, ReturnRequestRepository>();
        services.AddHttpClient<IOrderGateway, OrderGateway>(client =>
        {
            client.BaseAddress = new Uri(configuration["Services:Orders"] ?? "http://localhost:5106");
        });
        services.AddHttpClient<INotificationGateway, NotificationGateway>(client =>
        {
            client.BaseAddress = new Uri(configuration["Services:Notifications"] ?? "http://localhost:5108");
        });

        return services;
    }
}
