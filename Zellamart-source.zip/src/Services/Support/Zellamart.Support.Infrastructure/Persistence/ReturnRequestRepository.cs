using Microsoft.EntityFrameworkCore;
using Zellamart.Support.Application.Abstractions;
using Zellamart.Support.Domain.Returns;

namespace Zellamart.Support.Infrastructure.Persistence;

public sealed class ReturnRequestRepository : IReturnRequestRepository
{
    private readonly SupportDbContext _dbContext;

    public ReturnRequestRepository(SupportDbContext dbContext)
    {
        _dbContext = dbContext;
    }

    public Task<ReturnRequest?> GetByIdAsync(Guid returnId, CancellationToken cancellationToken)
    {
        return ReturnQuery().FirstOrDefaultAsync(returnRequest => returnRequest.Id == returnId, cancellationToken);
    }

    public Task<ReturnRequest?> GetByOrderItemIdAsync(Guid orderItemId, CancellationToken cancellationToken)
    {
        return ReturnQuery().FirstOrDefaultAsync(returnRequest => returnRequest.OrderItemId == orderItemId, cancellationToken);
    }

    public async Task<IReadOnlyList<ReturnRequest>> GetByCustomerIdAsync(
        Guid customerId,
        CancellationToken cancellationToken)
    {
        return await ReturnQuery()
            .Where(returnRequest => returnRequest.CustomerId == customerId)
            .OrderByDescending(returnRequest => returnRequest.CreatedAtUtc)
            .ToArrayAsync(cancellationToken);
    }

    public async Task<IReadOnlyList<ReturnRequest>> GetAllAsync(CancellationToken cancellationToken)
    {
        return await ReturnQuery()
            .OrderByDescending(returnRequest => returnRequest.CreatedAtUtc)
            .ToArrayAsync(cancellationToken);
    }

    public async Task AddAsync(ReturnRequest returnRequest, CancellationToken cancellationToken)
    {
        await _dbContext.ReturnRequests.AddAsync(returnRequest, cancellationToken);
    }

    public Task SaveChangesAsync(CancellationToken cancellationToken)
    {
        return _dbContext.SaveChangesAsync(cancellationToken);
    }

    private IQueryable<ReturnRequest> ReturnQuery()
    {
        return _dbContext.ReturnRequests.Include(returnRequest => returnRequest.StatusHistory);
    }
}
