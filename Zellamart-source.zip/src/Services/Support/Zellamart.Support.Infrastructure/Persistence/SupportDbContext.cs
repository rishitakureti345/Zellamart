using Microsoft.EntityFrameworkCore;
using Zellamart.Support.Domain.Returns;
using Zellamart.Support.Domain.Tickets;

namespace Zellamart.Support.Infrastructure.Persistence;

public sealed class SupportDbContext : DbContext
{
    public SupportDbContext(DbContextOptions<SupportDbContext> options)
        : base(options)
    {
    }

    public DbSet<SupportTicket> SupportTickets => Set<SupportTicket>();

    public DbSet<SupportTicketMessage> SupportTicketMessages => Set<SupportTicketMessage>();

    public DbSet<SupportTicketStatusHistory> SupportTicketStatusHistory => Set<SupportTicketStatusHistory>();

    public DbSet<ReturnRequest> ReturnRequests => Set<ReturnRequest>();

    public DbSet<ReturnStatusHistory> ReturnStatusHistory => Set<ReturnStatusHistory>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<SupportTicket>(builder =>
        {
            builder.ToTable("support_tickets");
            builder.HasKey(ticket => ticket.Id);
            builder.Property(ticket => ticket.Id).ValueGeneratedNever();
            builder.Property(ticket => ticket.Type).HasConversion<string>().HasMaxLength(40).IsRequired();
            builder.Property(ticket => ticket.Subject).HasMaxLength(220).IsRequired();
            builder.Property(ticket => ticket.Description).HasMaxLength(2000).IsRequired();
            builder.Property(ticket => ticket.Status).HasConversion<string>().HasMaxLength(40).IsRequired();
            builder.HasIndex(ticket => ticket.CustomerId);
            builder.HasIndex(ticket => ticket.OrderId);
            builder.HasIndex(ticket => ticket.AssignedAgentId);
            builder.HasIndex(ticket => ticket.Status);
            builder.Navigation(ticket => ticket.Messages).UsePropertyAccessMode(PropertyAccessMode.Field);
            builder.Navigation(ticket => ticket.StatusHistory).UsePropertyAccessMode(PropertyAccessMode.Field);
        });

        modelBuilder.Entity<SupportTicketMessage>(builder =>
        {
            builder.ToTable("support_ticket_messages");
            builder.HasKey(message => message.Id);
            builder.Property(message => message.Id).ValueGeneratedNever();
            builder.Property(message => message.Message).HasMaxLength(2000).IsRequired();
            builder.HasOne(message => message.Ticket)
                .WithMany(ticket => ticket.Messages)
                .HasForeignKey(message => message.TicketId);
            builder.HasIndex(message => message.TicketId);
            builder.HasIndex(message => message.SenderUserId);
        });

        modelBuilder.Entity<SupportTicketStatusHistory>(builder =>
        {
            builder.ToTable("support_ticket_status_history");
            builder.HasKey(history => history.Id);
            builder.Property(history => history.Id).ValueGeneratedNever();
            builder.Property(history => history.Status).HasConversion<string>().HasMaxLength(40).IsRequired();
            builder.Property(history => history.Note).HasMaxLength(600).IsRequired();
            builder.HasOne(history => history.Ticket)
                .WithMany(ticket => ticket.StatusHistory)
                .HasForeignKey(history => history.TicketId);
            builder.HasIndex(history => history.TicketId);
        });

        modelBuilder.Entity<ReturnRequest>(builder =>
        {
            builder.ToTable("return_requests");
            builder.HasKey(returnRequest => returnRequest.Id);
            builder.Property(returnRequest => returnRequest.Id).ValueGeneratedNever();
            builder.Property(returnRequest => returnRequest.Reason).HasMaxLength(1000).IsRequired();
            builder.Property(returnRequest => returnRequest.Status).HasConversion<string>().HasMaxLength(40).IsRequired();
            builder.Property(returnRequest => returnRequest.RefundAmount).HasPrecision(18, 2);
            builder.HasIndex(returnRequest => returnRequest.CustomerId);
            builder.HasIndex(returnRequest => returnRequest.OrderId);
            builder.HasIndex(returnRequest => returnRequest.OrderItemId).IsUnique();
            builder.HasIndex(returnRequest => returnRequest.ProductId);
            builder.HasIndex(returnRequest => returnRequest.Status);
            builder.Navigation(returnRequest => returnRequest.StatusHistory).UsePropertyAccessMode(PropertyAccessMode.Field);
        });

        modelBuilder.Entity<ReturnStatusHistory>(builder =>
        {
            builder.ToTable("return_status_history");
            builder.HasKey(history => history.Id);
            builder.Property(history => history.Id).ValueGeneratedNever();
            builder.Property(history => history.Status).HasConversion<string>().HasMaxLength(40).IsRequired();
            builder.Property(history => history.Note).HasMaxLength(600).IsRequired();
            builder.HasOne(history => history.ReturnRequest)
                .WithMany(returnRequest => returnRequest.StatusHistory)
                .HasForeignKey(history => history.ReturnRequestId);
            builder.HasIndex(history => history.ReturnRequestId);
        });
    }
}
