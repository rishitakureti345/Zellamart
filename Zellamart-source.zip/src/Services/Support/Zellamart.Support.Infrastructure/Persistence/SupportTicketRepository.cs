using Microsoft.EntityFrameworkCore;
using Zellamart.Support.Application.Abstractions;
using Zellamart.Support.Domain.Tickets;

namespace Zellamart.Support.Infrastructure.Persistence;

public sealed class SupportTicketRepository : ISupportTicketRepository
{
    private readonly SupportDbContext _dbContext;

    public SupportTicketRepository(SupportDbContext dbContext)
    {
        _dbContext = dbContext;
    }

    public Task<SupportTicket?> GetByIdAsync(Guid ticketId, CancellationToken cancellationToken)
    {
        return TicketQuery().FirstOrDefaultAsync(ticket => ticket.Id == ticketId, cancellationToken);
    }

    public async Task<IReadOnlyList<SupportTicket>> GetByCustomerIdAsync(
        Guid customerId,
        CancellationToken cancellationToken)
    {
        return await TicketQuery()
            .Where(ticket => ticket.CustomerId == customerId)
            .OrderByDescending(ticket => ticket.CreatedAtUtc)
            .ToArrayAsync(cancellationToken);
    }

    public async Task<IReadOnlyList<SupportTicket>> GetAllAsync(CancellationToken cancellationToken)
    {
        return await TicketQuery()
            .OrderByDescending(ticket => ticket.CreatedAtUtc)
            .ToArrayAsync(cancellationToken);
    }

    public async Task AddAsync(SupportTicket ticket, CancellationToken cancellationToken)
    {
        await _dbContext.SupportTickets.AddAsync(ticket, cancellationToken);
    }

    public Task SaveChangesAsync(CancellationToken cancellationToken)
    {
        return _dbContext.SaveChangesAsync(cancellationToken);
    }

    private IQueryable<SupportTicket> TicketQuery()
    {
        return _dbContext.SupportTickets
            .Include(ticket => ticket.Messages)
            .Include(ticket => ticket.StatusHistory);
    }
}
