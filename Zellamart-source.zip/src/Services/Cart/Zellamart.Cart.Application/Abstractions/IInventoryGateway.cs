namespace Zellamart.Cart.Application.Abstractions;

public interface IInventoryGateway
{
    Task<bool> HasAvailableStockAsync(
        Guid productId,
        int quantity,
        string bearerToken,
        CancellationToken cancellationToken);
}
