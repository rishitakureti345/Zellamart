namespace Zellamart.Cart.Application.Abstractions;

public interface ICartRepository
{
    Task<Domain.Carts.Cart?> GetActiveByCustomerIdAsync(Guid customerId, CancellationToken cancellationToken);

    Task AddAsync(Domain.Carts.Cart cart, CancellationToken cancellationToken);

    Task SaveChangesAsync(CancellationToken cancellationToken);
}
