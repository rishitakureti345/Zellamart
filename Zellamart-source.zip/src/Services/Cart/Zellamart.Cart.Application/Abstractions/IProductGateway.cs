namespace Zellamart.Cart.Application.Abstractions;

public interface IProductGateway
{
    Task<ProductSnapshot?> GetApprovedAsync(Guid productId, CancellationToken cancellationToken);
}

public sealed record ProductSnapshot(
    Guid Id,
    Guid SellerId,
    string Name,
    decimal Price,
    string Currency);
