using Zellamart.SharedKernel.Results;

namespace Zellamart.Cart.Application.Carts;

public interface ICartService
{
    Task<Result<CartResponse>> GetMineAsync(Guid customerId, CancellationToken cancellationToken);

    Task<Result<CartResponse>> AddItemAsync(
        Guid customerId,
        AddCartItemRequest request,
        string bearerToken,
        CancellationToken cancellationToken);

    Task<Result<CartResponse>> UpdateItemAsync(
        Guid customerId,
        Guid itemId,
        UpdateCartItemRequest request,
        string bearerToken,
        CancellationToken cancellationToken);

    Task<Result<CartResponse>> RemoveItemAsync(Guid customerId, Guid itemId, CancellationToken cancellationToken);

    Task<Result<CartResponse>> ClearAsync(Guid customerId, CancellationToken cancellationToken);
}
