namespace Zellamart.Cart.Application.Carts;

public sealed record AddCartItemRequest(
    Guid ProductId,
    Guid SellerId,
    string ProductName,
    decimal UnitPrice,
    int Quantity,
    string Currency);
