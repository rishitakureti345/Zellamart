using Zellamart.Cart.Application.Abstractions;
using Zellamart.Cart.Domain.Carts;
using Zellamart.SharedKernel.Results;

namespace Zellamart.Cart.Application.Carts;

public sealed class CartService : ICartService
{
    private readonly ICartRepository _repository;
    private readonly IProductGateway _productGateway;
    private readonly IInventoryGateway _inventoryGateway;

    public CartService(
        ICartRepository repository,
        IProductGateway productGateway,
        IInventoryGateway inventoryGateway)
    {
        _repository = repository;
        _productGateway = productGateway;
        _inventoryGateway = inventoryGateway;
    }

    public async Task<Result<CartResponse>> GetMineAsync(Guid customerId, CancellationToken cancellationToken)
    {
        var cart = await GetOrCreateCartAsync(customerId, cancellationToken);
        await _repository.SaveChangesAsync(cancellationToken);

        return Result.Ok(ToResponse(cart));
    }

    public async Task<Result<CartResponse>> AddItemAsync(
        Guid customerId,
        AddCartItemRequest request,
        string bearerToken,
        CancellationToken cancellationToken)
    {
        var validation = ValidateAddRequest(request);
        if (validation is not null)
        {
            return Result.Fail<CartResponse>(validation);
        }

        var product = await _productGateway.GetApprovedAsync(request.ProductId, cancellationToken);
        if (product is null)
        {
            return Result.Fail<CartResponse>(Error.Validation("Product is not approved or is unavailable."));
        }

        var hasStock = await _inventoryGateway.HasAvailableStockAsync(
            product.Id,
            request.Quantity,
            bearerToken,
            cancellationToken);
        if (!hasStock)
        {
            return Result.Fail<CartResponse>(Error.Validation("Product does not have enough available stock."));
        }

        var cart = await GetOrCreateCartAsync(customerId, cancellationToken);
        if (cart.Items.Any(item => item.ProductId == request.ProductId))
        {
            return Result.Fail<CartResponse>(Error.Conflict("Product already exists in cart."));
        }

        cart.AddItem(
            product.Id,
            product.SellerId,
            product.Name,
            product.Price,
            request.Quantity,
            product.Currency);

        await _repository.SaveChangesAsync(cancellationToken);
        return Result.Ok(ToResponse(cart));
    }

    public async Task<Result<CartResponse>> UpdateItemAsync(
        Guid customerId,
        Guid itemId,
        UpdateCartItemRequest request,
        string bearerToken,
        CancellationToken cancellationToken)
    {
        if (request.Quantity <= 0)
        {
            return Result.Fail<CartResponse>(Error.Validation("Quantity must be greater than zero."));
        }

        var cart = await GetOrCreateCartAsync(customerId, cancellationToken);
        var item = cart.Items.FirstOrDefault(cartItem => cartItem.Id == itemId);
        if (item is null)
        {
            return Result.Fail<CartResponse>(Error.NotFound("Cart item was not found."));
        }

        var product = await _productGateway.GetApprovedAsync(item.ProductId, cancellationToken);
        if (product is null)
        {
            return Result.Fail<CartResponse>(Error.Validation("Product is not approved or is unavailable."));
        }

        var hasStock = await _inventoryGateway.HasAvailableStockAsync(
            item.ProductId,
            request.Quantity,
            bearerToken,
            cancellationToken);
        if (!hasStock)
        {
            return Result.Fail<CartResponse>(Error.Validation("Product does not have enough available stock."));
        }

        if (!cart.UpdateItem(itemId, request.Quantity))
        {
            return Result.Fail<CartResponse>(Error.NotFound("Cart item was not found."));
        }

        await _repository.SaveChangesAsync(cancellationToken);
        return Result.Ok(ToResponse(cart));
    }

    public async Task<Result<CartResponse>> RemoveItemAsync(Guid customerId, Guid itemId, CancellationToken cancellationToken)
    {
        var cart = await GetOrCreateCartAsync(customerId, cancellationToken);
        if (!cart.RemoveItem(itemId))
        {
            return Result.Fail<CartResponse>(Error.NotFound("Cart item was not found."));
        }

        await _repository.SaveChangesAsync(cancellationToken);
        return Result.Ok(ToResponse(cart));
    }

    public async Task<Result<CartResponse>> ClearAsync(Guid customerId, CancellationToken cancellationToken)
    {
        var cart = await GetOrCreateCartAsync(customerId, cancellationToken);
        cart.Clear();

        await _repository.SaveChangesAsync(cancellationToken);
        return Result.Ok(ToResponse(cart));
    }

    private async Task<Domain.Carts.Cart> GetOrCreateCartAsync(Guid customerId, CancellationToken cancellationToken)
    {
        var cart = await _repository.GetActiveByCustomerIdAsync(customerId, cancellationToken);
        if (cart is not null)
        {
            return cart;
        }

        cart = new Domain.Carts.Cart(customerId);
        await _repository.AddAsync(cart, cancellationToken);
        return cart;
    }

    private static Error? ValidateAddRequest(AddCartItemRequest request)
    {
        if (request.ProductId == Guid.Empty)
        {
            return Error.Validation("Product id is required.");
        }

        if (request.SellerId == Guid.Empty)
        {
            return Error.Validation("Seller id is required.");
        }

        if (string.IsNullOrWhiteSpace(request.ProductName))
        {
            return Error.Validation("Product name is required.");
        }

        if (request.UnitPrice <= 0)
        {
            return Error.Validation("Unit price must be greater than zero.");
        }

        if (request.Quantity <= 0)
        {
            return Error.Validation("Quantity must be greater than zero.");
        }

        if (string.IsNullOrWhiteSpace(request.Currency))
        {
            return Error.Validation("Currency is required.");
        }

        return null;
    }

    private static CartResponse ToResponse(Domain.Carts.Cart cart)
    {
        var items = cart.Items
            .Select(item => new CartItemResponse(
                item.Id,
                item.ProductId,
                item.SellerId,
                item.ProductName,
                item.UnitPrice,
                item.Quantity,
                item.Currency,
                item.LineTotal))
            .ToArray();

        return new CartResponse(
            cart.Id,
            cart.CustomerId,
            cart.Status,
            items,
            cart.Subtotal,
            cart.TotalItems,
            cart.Currency);
    }
}
