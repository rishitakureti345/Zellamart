namespace Zellamart.Cart.Application.Carts;

public sealed record CartItemResponse(
    Guid Id,
    Guid ProductId,
    Guid SellerId,
    string ProductName,
    decimal UnitPrice,
    int Quantity,
    string Currency,
    decimal LineTotal);
