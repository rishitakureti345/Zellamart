using Zellamart.Cart.Domain.Carts;

namespace Zellamart.Cart.Application.Carts;

public sealed record CartResponse(
    Guid Id,
    Guid CustomerId,
    CartStatus Status,
    IReadOnlyList<CartItemResponse> Items,
    decimal Subtotal,
    int TotalItems,
    string Currency);
