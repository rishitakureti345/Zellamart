namespace Zellamart.Cart.Application.Carts;

public sealed record UpdateCartItemRequest(int Quantity);
