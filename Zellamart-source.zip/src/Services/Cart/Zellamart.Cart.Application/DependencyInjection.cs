using Microsoft.Extensions.DependencyInjection;
using Zellamart.Cart.Application.Carts;

namespace Zellamart.Cart.Application;

public static class DependencyInjection
{
    public static IServiceCollection AddCartApplication(this IServiceCollection services)
    {
        services.AddScoped<ICartService, CartService>();

        return services;
    }
}
