using Microsoft.EntityFrameworkCore;
using Zellamart.Cart.Domain.Carts;

namespace Zellamart.Cart.Infrastructure.Persistence;

public sealed class CartDbContext : DbContext
{
    public CartDbContext(DbContextOptions<CartDbContext> options)
        : base(options)
    {
    }

    public DbSet<Domain.Carts.Cart> Carts => Set<Domain.Carts.Cart>();

    public DbSet<CartItem> CartItems => Set<CartItem>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Domain.Carts.Cart>(builder =>
        {
            builder.ToTable("carts");
            builder.HasKey(cart => cart.Id);
            builder.Property(cart => cart.Id).ValueGeneratedNever();
            builder.Property(cart => cart.Status).HasConversion<string>().HasMaxLength(40).IsRequired();
            builder.HasIndex(cart => new { cart.CustomerId, cart.Status });
            builder.Navigation(cart => cart.Items).UsePropertyAccessMode(PropertyAccessMode.Field);
        });

        modelBuilder.Entity<CartItem>(builder =>
        {
            builder.ToTable("cart_items");
            builder.HasKey(item => item.Id);
            builder.Property(item => item.Id).ValueGeneratedNever();
            builder.Property(item => item.ProductName).HasMaxLength(220).IsRequired();
            builder.Property(item => item.UnitPrice).HasPrecision(18, 2);
            builder.Property(item => item.Currency).HasMaxLength(3).IsRequired();
            builder.HasOne(item => item.Cart)
                .WithMany(cart => cart.Items)
                .HasForeignKey(item => item.CartId);
            builder.HasIndex(item => item.CartId);
            builder.HasIndex(item => item.ProductId);
            builder.HasIndex(item => item.SellerId);
        });
    }
}
