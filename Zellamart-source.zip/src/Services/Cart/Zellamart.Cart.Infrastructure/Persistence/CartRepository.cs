using Microsoft.EntityFrameworkCore;
using Zellamart.Cart.Application.Abstractions;
using Zellamart.Cart.Domain.Carts;

namespace Zellamart.Cart.Infrastructure.Persistence;

public sealed class CartRepository : ICartRepository
{
    private readonly CartDbContext _dbContext;

    public CartRepository(CartDbContext dbContext)
    {
        _dbContext = dbContext;
    }

    public Task<Domain.Carts.Cart?> GetActiveByCustomerIdAsync(Guid customerId, CancellationToken cancellationToken)
    {
        return _dbContext.Carts
            .Include(cart => cart.Items)
            .FirstOrDefaultAsync(
                cart => cart.CustomerId == customerId && cart.Status == CartStatus.Active,
                cancellationToken);
    }

    public async Task AddAsync(Domain.Carts.Cart cart, CancellationToken cancellationToken)
    {
        await _dbContext.Carts.AddAsync(cart, cancellationToken);
    }

    public Task SaveChangesAsync(CancellationToken cancellationToken)
    {
        return _dbContext.SaveChangesAsync(cancellationToken);
    }
}
