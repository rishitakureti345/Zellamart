using System.Net.Http.Headers;
using System.Net.Http.Json;
using Zellamart.Cart.Application.Abstractions;

namespace Zellamart.Cart.Infrastructure.Services;

public sealed class InventoryGateway : IInventoryGateway
{
    private readonly HttpClient _httpClient;

    public InventoryGateway(HttpClient httpClient)
    {
        _httpClient = httpClient;
    }

    public async Task<bool> HasAvailableStockAsync(
        Guid productId,
        int quantity,
        string bearerToken,
        CancellationToken cancellationToken)
    {
        if (string.IsNullOrWhiteSpace(bearerToken))
        {
            return false;
        }

        using var request = new HttpRequestMessage(HttpMethod.Get, $"/api/inventory/product/{productId}");
        request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", bearerToken);

        using var response = await _httpClient.SendAsync(request, cancellationToken);
        if (!response.IsSuccessStatusCode)
        {
            return false;
        }

        var result = await response.Content.ReadFromJsonAsync<GatewayResult<InventoryGatewayResponse>>(cancellationToken);
        return result?.Success == true && result.Value is not null && result.Value.AvailableQuantity >= quantity;
    }

    private sealed record InventoryGatewayResponse(int AvailableQuantity);

    private sealed class GatewayResult<T>
    {
        public bool Success { get; set; }

        public T? Value { get; set; }
    }
}
