using System.Net.Http.Json;
using Zellamart.Cart.Application.Abstractions;

namespace Zellamart.Cart.Infrastructure.Services;

public sealed class ProductGateway : IProductGateway
{
    private readonly HttpClient _httpClient;

    public ProductGateway(HttpClient httpClient)
    {
        _httpClient = httpClient;
    }

    public async Task<ProductSnapshot?> GetApprovedAsync(Guid productId, CancellationToken cancellationToken)
    {
        using var response = await _httpClient.GetAsync($"/api/products/{productId}", cancellationToken);
        if (!response.IsSuccessStatusCode)
        {
            return null;
        }

        var result = await response.Content.ReadFromJsonAsync<GatewayResult<ProductGatewayResponse>>(cancellationToken);
        if (result?.Success != true || result.Value is null)
        {
            return null;
        }

        return new ProductSnapshot(
            result.Value.Id,
            result.Value.SellerId,
            result.Value.Name,
            result.Value.Price,
            result.Value.Currency);
    }

    private sealed record ProductGatewayResponse(
        Guid Id,
        Guid SellerId,
        string Name,
        decimal Price,
        string Currency);

    private sealed class GatewayResult<T>
    {
        public bool Success { get; set; }

        public T? Value { get; set; }
    }
}
