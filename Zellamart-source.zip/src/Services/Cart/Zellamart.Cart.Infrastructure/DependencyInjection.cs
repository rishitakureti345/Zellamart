using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Zellamart.Cart.Application.Abstractions;
using Zellamart.Cart.Infrastructure.Persistence;
using Zellamart.Cart.Infrastructure.Services;

namespace Zellamart.Cart.Infrastructure;

public static class DependencyInjection
{
    public static IServiceCollection AddCartInfrastructure(
        this IServiceCollection services,
        IConfiguration configuration)
    {
        services.AddDbContext<CartDbContext>(options =>
            options.UseNpgsql(configuration.GetConnectionString("Cart")));

        services.AddScoped<ICartRepository, CartRepository>();
        services.AddHttpClient<IProductGateway, ProductGateway>(client =>
        {
            client.BaseAddress = new Uri(configuration["Services:Catalog"] ?? "http://localhost:5103");
        });
        services.AddHttpClient<IInventoryGateway, InventoryGateway>(client =>
        {
            client.BaseAddress = new Uri(configuration["Services:Inventory"] ?? "http://localhost:5104");
        });

        return services;
    }
}
