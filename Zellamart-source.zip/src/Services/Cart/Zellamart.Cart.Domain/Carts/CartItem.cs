using Zellamart.SharedKernel.Entities;

namespace Zellamart.Cart.Domain.Carts;

public sealed class CartItem : BaseEntity
{
    private CartItem()
    {
    }

    public CartItem(
        Guid cartId,
        Guid productId,
        Guid sellerId,
        string productName,
        decimal unitPrice,
        int quantity,
        string currency)
    {
        CartId = cartId;
        ProductId = productId;
        SellerId = sellerId;
        ProductName = productName.Trim();
        UnitPrice = unitPrice;
        Quantity = quantity;
        Currency = currency.Trim().ToUpperInvariant();
    }

    public Guid CartId { get; private set; }

    public Guid ProductId { get; private set; }

    public Guid SellerId { get; private set; }

    public string ProductName { get; private set; } = string.Empty;

    public decimal UnitPrice { get; private set; }

    public int Quantity { get; private set; }

    public string Currency { get; private set; } = "INR";

    public decimal LineTotal => UnitPrice * Quantity;

    public Cart Cart { get; private set; } = null!;

    public void UpdateQuantity(int quantity)
    {
        Quantity = quantity;
    }
}
