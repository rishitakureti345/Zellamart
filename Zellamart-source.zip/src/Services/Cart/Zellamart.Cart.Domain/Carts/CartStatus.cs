namespace Zellamart.Cart.Domain.Carts;

public enum CartStatus
{
    Active = 1,
    CheckedOut = 2,
    Cleared = 3
}
