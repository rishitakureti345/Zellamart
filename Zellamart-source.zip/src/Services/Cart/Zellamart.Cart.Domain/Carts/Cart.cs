using Zellamart.SharedKernel.Entities;

namespace Zellamart.Cart.Domain.Carts;

public sealed class Cart : AuditableEntity
{
    private readonly List<CartItem> _items = [];

    private Cart()
    {
    }

    public Cart(Guid customerId)
    {
        CustomerId = customerId;
        Status = CartStatus.Active;
    }

    public Guid CustomerId { get; private set; }

    public CartStatus Status { get; private set; }

    public IReadOnlyCollection<CartItem> Items => _items;

    public decimal Subtotal => _items.Sum(item => item.LineTotal);

    public int TotalItems => _items.Sum(item => item.Quantity);

    public string Currency => _items.FirstOrDefault()?.Currency ?? "INR";

    public void AddItem(
        Guid productId,
        Guid sellerId,
        string productName,
        decimal unitPrice,
        int quantity,
        string currency)
    {
        if (_items.Any(item => item.ProductId == productId))
        {
            throw new InvalidOperationException("Product already exists in cart.");
        }

        _items.Add(new CartItem(Id, productId, sellerId, productName, unitPrice, quantity, currency));
        UpdatedAtUtc = DateTimeOffset.UtcNow;
    }

    public bool UpdateItem(Guid itemId, int quantity)
    {
        var item = _items.FirstOrDefault(cartItem => cartItem.Id == itemId);
        if (item is null)
        {
            return false;
        }

        item.UpdateQuantity(quantity);
        UpdatedAtUtc = DateTimeOffset.UtcNow;
        return true;
    }

    public bool RemoveItem(Guid itemId)
    {
        var item = _items.FirstOrDefault(cartItem => cartItem.Id == itemId);
        if (item is null)
        {
            return false;
        }

        _items.Remove(item);
        UpdatedAtUtc = DateTimeOffset.UtcNow;
        return true;
    }

    public void Clear()
    {
        _items.Clear();
        UpdatedAtUtc = DateTimeOffset.UtcNow;
    }
}
