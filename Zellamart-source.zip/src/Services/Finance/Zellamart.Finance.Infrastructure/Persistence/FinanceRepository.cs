using Microsoft.EntityFrameworkCore;
using Zellamart.Finance.Application.Abstractions;
using Zellamart.Finance.Domain.Audit;
using Zellamart.Finance.Domain.Commissions;
using Zellamart.Finance.Domain.Earnings;
using Zellamart.Finance.Domain.Payouts;
using Zellamart.Finance.Domain.Transactions;

namespace Zellamart.Finance.Infrastructure.Persistence;

public sealed class FinanceRepository : IFinanceRepository
{
    private readonly FinanceDbContext _dbContext;

    public FinanceRepository(FinanceDbContext dbContext)
    {
        _dbContext = dbContext;
    }

    public Task<SellerEarning?> GetEarningByOrderItemIdAsync(Guid orderItemId, CancellationToken cancellationToken)
    {
        return _dbContext.SellerEarnings.FirstOrDefaultAsync(
            earning => earning.OrderItemId == orderItemId,
            cancellationToken);
    }

    public async Task<IReadOnlyList<SellerEarning>> GetEarningsBySellerIdAsync(
        Guid sellerId,
        CancellationToken cancellationToken)
    {
        return await _dbContext.SellerEarnings
            .Where(earning => earning.SellerId == sellerId)
            .OrderByDescending(earning => earning.CreatedAtUtc)
            .ToArrayAsync(cancellationToken);
    }

    public async Task<IReadOnlyList<SellerEarning>> GetAllEarningsAsync(CancellationToken cancellationToken)
    {
        return await _dbContext.SellerEarnings
            .OrderByDescending(earning => earning.CreatedAtUtc)
            .ToArrayAsync(cancellationToken);
    }

    public async Task<IReadOnlyList<SellerEarning>> GetAvailableEarningsBySellerIdAsync(
        Guid sellerId,
        CancellationToken cancellationToken)
    {
        return await _dbContext.SellerEarnings
            .Where(earning => earning.SellerId == sellerId && earning.Status == SellerEarningStatus.EarningAvailable)
            .OrderBy(earning => earning.CreatedAtUtc)
            .ToArrayAsync(cancellationToken);
    }

    public async Task<IReadOnlyList<SellerPayout>> GetAllPayoutsAsync(CancellationToken cancellationToken)
    {
        return await _dbContext.SellerPayouts
            .OrderByDescending(payout => payout.RequestedAtUtc)
            .ToArrayAsync(cancellationToken);
    }

    public async Task<IReadOnlyList<PlatformCommission>> GetAllCommissionsAsync(CancellationToken cancellationToken)
    {
        return await _dbContext.PlatformCommissions
            .OrderByDescending(commission => commission.CreatedAtUtc)
            .ToArrayAsync(cancellationToken);
    }

    public async Task<IReadOnlyList<FinanceTransaction>> GetTransactionsBySellerIdAsync(
        Guid sellerId,
        CancellationToken cancellationToken)
    {
        return await _dbContext.FinanceTransactions
            .Where(transaction => transaction.SellerId == sellerId)
            .OrderByDescending(transaction => transaction.CreatedAtUtc)
            .ToArrayAsync(cancellationToken);
    }

    public async Task<IReadOnlyList<FinanceTransaction>> GetAllTransactionsAsync(CancellationToken cancellationToken)
    {
        return await _dbContext.FinanceTransactions
            .OrderByDescending(transaction => transaction.CreatedAtUtc)
            .ToArrayAsync(cancellationToken);
    }

    public Task<SellerPayout?> GetPayoutByIdAsync(Guid payoutId, CancellationToken cancellationToken)
    {
        return _dbContext.SellerPayouts.FirstOrDefaultAsync(payout => payout.Id == payoutId, cancellationToken);
    }

    public async Task<IReadOnlyList<SellerPayout>> GetPayoutsBySellerIdAsync(
        Guid sellerId,
        CancellationToken cancellationToken)
    {
        return await _dbContext.SellerPayouts
            .Where(payout => payout.SellerId == sellerId)
            .OrderByDescending(payout => payout.RequestedAtUtc)
            .ToArrayAsync(cancellationToken);
    }

    public async Task AddEarningAsync(SellerEarning earning, CancellationToken cancellationToken)
    {
        await _dbContext.SellerEarnings.AddAsync(earning, cancellationToken);
    }

    public async Task AddCommissionAsync(PlatformCommission commission, CancellationToken cancellationToken)
    {
        await _dbContext.PlatformCommissions.AddAsync(commission, cancellationToken);
    }

    public async Task AddTransactionAsync(FinanceTransaction transaction, CancellationToken cancellationToken)
    {
        await _dbContext.FinanceTransactions.AddAsync(transaction, cancellationToken);
    }

    public async Task AddPayoutAsync(SellerPayout payout, CancellationToken cancellationToken)
    {
        await _dbContext.SellerPayouts.AddAsync(payout, cancellationToken);
    }

    public async Task AddAuditLogAsync(AuditLog auditLog, CancellationToken cancellationToken)
    {
        await _dbContext.AuditLogs.AddAsync(auditLog, cancellationToken);
    }

    public Task SaveChangesAsync(CancellationToken cancellationToken)
    {
        return _dbContext.SaveChangesAsync(cancellationToken);
    }
}
