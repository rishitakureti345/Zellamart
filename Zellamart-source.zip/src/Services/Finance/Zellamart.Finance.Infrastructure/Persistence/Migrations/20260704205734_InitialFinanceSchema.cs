﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Zellamart.Finance.Infrastructure.Persistence.Migrations
{
    /// <inheritdoc />
    public partial class InitialFinanceSchema : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "finance_transactions",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uuid", nullable: false),
                    SellerId = table.Column<Guid>(type: "uuid", nullable: false),
                    OrderId = table.Column<Guid>(type: "uuid", nullable: true),
                    Type = table.Column<string>(type: "character varying(40)", maxLength: 40, nullable: false),
                    Amount = table.Column<decimal>(type: "numeric(18,2)", precision: 18, scale: 2, nullable: false),
                    Description = table.Column<string>(type: "character varying(600)", maxLength: 600, nullable: false),
                    ReferenceId = table.Column<Guid>(type: "uuid", nullable: true),
                    CreatedAtUtc = table.Column<DateTimeOffset>(type: "timestamp with time zone", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_finance_transactions", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "platform_commissions",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uuid", nullable: false),
                    SellerEarningId = table.Column<Guid>(type: "uuid", nullable: false),
                    SellerId = table.Column<Guid>(type: "uuid", nullable: false),
                    OrderId = table.Column<Guid>(type: "uuid", nullable: false),
                    Amount = table.Column<decimal>(type: "numeric(18,2)", precision: 18, scale: 2, nullable: false),
                    Rate = table.Column<decimal>(type: "numeric(5,4)", precision: 5, scale: 4, nullable: false),
                    CreatedAtUtc = table.Column<DateTimeOffset>(type: "timestamp with time zone", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_platform_commissions", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "seller_earnings",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uuid", nullable: false),
                    SellerId = table.Column<Guid>(type: "uuid", nullable: false),
                    OrderId = table.Column<Guid>(type: "uuid", nullable: false),
                    OrderItemId = table.Column<Guid>(type: "uuid", nullable: false),
                    ProductId = table.Column<Guid>(type: "uuid", nullable: false),
                    GrossAmount = table.Column<decimal>(type: "numeric(18,2)", precision: 18, scale: 2, nullable: false),
                    CommissionAmount = table.Column<decimal>(type: "numeric(18,2)", precision: 18, scale: 2, nullable: false),
                    NetAmount = table.Column<decimal>(type: "numeric(18,2)", precision: 18, scale: 2, nullable: false),
                    Status = table.Column<string>(type: "character varying(40)", maxLength: 40, nullable: false),
                    CreatedAtUtc = table.Column<DateTimeOffset>(type: "timestamp with time zone", nullable: false),
                    CreatedBy = table.Column<string>(type: "text", nullable: true),
                    UpdatedAtUtc = table.Column<DateTimeOffset>(type: "timestamp with time zone", nullable: true),
                    UpdatedBy = table.Column<string>(type: "text", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_seller_earnings", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "seller_payouts",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uuid", nullable: false),
                    SellerId = table.Column<Guid>(type: "uuid", nullable: false),
                    Amount = table.Column<decimal>(type: "numeric(18,2)", precision: 18, scale: 2, nullable: false),
                    Status = table.Column<string>(type: "character varying(40)", maxLength: 40, nullable: false),
                    RequestedAtUtc = table.Column<DateTimeOffset>(type: "timestamp with time zone", nullable: false),
                    PaidAtUtc = table.Column<DateTimeOffset>(type: "timestamp with time zone", nullable: true),
                    ReferenceNumber = table.Column<string>(type: "character varying(80)", maxLength: 80, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_seller_payouts", x => x.Id);
                });

            migrationBuilder.CreateIndex(
                name: "IX_finance_transactions_OrderId",
                table: "finance_transactions",
                column: "OrderId");

            migrationBuilder.CreateIndex(
                name: "IX_finance_transactions_ReferenceId",
                table: "finance_transactions",
                column: "ReferenceId");

            migrationBuilder.CreateIndex(
                name: "IX_finance_transactions_SellerId",
                table: "finance_transactions",
                column: "SellerId");

            migrationBuilder.CreateIndex(
                name: "IX_finance_transactions_Type",
                table: "finance_transactions",
                column: "Type");

            migrationBuilder.CreateIndex(
                name: "IX_platform_commissions_OrderId",
                table: "platform_commissions",
                column: "OrderId");

            migrationBuilder.CreateIndex(
                name: "IX_platform_commissions_SellerEarningId",
                table: "platform_commissions",
                column: "SellerEarningId",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_platform_commissions_SellerId",
                table: "platform_commissions",
                column: "SellerId");

            migrationBuilder.CreateIndex(
                name: "IX_seller_earnings_OrderId",
                table: "seller_earnings",
                column: "OrderId");

            migrationBuilder.CreateIndex(
                name: "IX_seller_earnings_OrderItemId",
                table: "seller_earnings",
                column: "OrderItemId",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_seller_earnings_ProductId",
                table: "seller_earnings",
                column: "ProductId");

            migrationBuilder.CreateIndex(
                name: "IX_seller_earnings_SellerId",
                table: "seller_earnings",
                column: "SellerId");

            migrationBuilder.CreateIndex(
                name: "IX_seller_earnings_Status",
                table: "seller_earnings",
                column: "Status");

            migrationBuilder.CreateIndex(
                name: "IX_seller_payouts_ReferenceNumber",
                table: "seller_payouts",
                column: "ReferenceNumber",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_seller_payouts_SellerId",
                table: "seller_payouts",
                column: "SellerId");

            migrationBuilder.CreateIndex(
                name: "IX_seller_payouts_Status",
                table: "seller_payouts",
                column: "Status");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "finance_transactions");

            migrationBuilder.DropTable(
                name: "platform_commissions");

            migrationBuilder.DropTable(
                name: "seller_earnings");

            migrationBuilder.DropTable(
                name: "seller_payouts");
        }
    }
}
