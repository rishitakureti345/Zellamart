using Microsoft.EntityFrameworkCore;
using Zellamart.Finance.Domain.Audit;
using Zellamart.Finance.Domain.Commissions;
using Zellamart.Finance.Domain.Earnings;
using Zellamart.Finance.Domain.Payouts;
using Zellamart.Finance.Domain.Transactions;

namespace Zellamart.Finance.Infrastructure.Persistence;

public sealed class FinanceDbContext : DbContext
{
    public FinanceDbContext(DbContextOptions<FinanceDbContext> options)
        : base(options)
    {
    }

    public DbSet<SellerEarning> SellerEarnings => Set<SellerEarning>();

    public DbSet<SellerPayout> SellerPayouts => Set<SellerPayout>();

    public DbSet<PlatformCommission> PlatformCommissions => Set<PlatformCommission>();

    public DbSet<FinanceTransaction> FinanceTransactions => Set<FinanceTransaction>();

    public DbSet<AuditLog> AuditLogs => Set<AuditLog>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<SellerEarning>(builder =>
        {
            builder.ToTable("seller_earnings");
            builder.HasKey(earning => earning.Id);
            builder.Property(earning => earning.Id).ValueGeneratedNever();
            builder.Property(earning => earning.GrossAmount).HasPrecision(18, 2);
            builder.Property(earning => earning.CommissionAmount).HasPrecision(18, 2);
            builder.Property(earning => earning.NetAmount).HasPrecision(18, 2);
            builder.Property(earning => earning.Status).HasConversion<string>().HasMaxLength(40).IsRequired();
            builder.HasIndex(earning => earning.SellerId);
            builder.HasIndex(earning => earning.OrderId);
            builder.HasIndex(earning => earning.OrderItemId).IsUnique();
            builder.HasIndex(earning => earning.ProductId);
            builder.HasIndex(earning => earning.Status);
        });

        modelBuilder.Entity<SellerPayout>(builder =>
        {
            builder.ToTable("seller_payouts");
            builder.HasKey(payout => payout.Id);
            builder.Property(payout => payout.Id).ValueGeneratedNever();
            builder.Property(payout => payout.Amount).HasPrecision(18, 2);
            builder.Property(payout => payout.Status).HasConversion<string>().HasMaxLength(40).IsRequired();
            builder.Property(payout => payout.ReferenceNumber).HasMaxLength(80).IsRequired();
            builder.HasIndex(payout => payout.SellerId);
            builder.HasIndex(payout => payout.Status);
            builder.HasIndex(payout => payout.ReferenceNumber).IsUnique();
        });

        modelBuilder.Entity<PlatformCommission>(builder =>
        {
            builder.ToTable("platform_commissions");
            builder.HasKey(commission => commission.Id);
            builder.Property(commission => commission.Id).ValueGeneratedNever();
            builder.Property(commission => commission.Amount).HasPrecision(18, 2);
            builder.Property(commission => commission.Rate).HasPrecision(5, 4);
            builder.HasIndex(commission => commission.SellerEarningId).IsUnique();
            builder.HasIndex(commission => commission.SellerId);
            builder.HasIndex(commission => commission.OrderId);
        });

        modelBuilder.Entity<FinanceTransaction>(builder =>
        {
            builder.ToTable("finance_transactions");
            builder.HasKey(transaction => transaction.Id);
            builder.Property(transaction => transaction.Id).ValueGeneratedNever();
            builder.Property(transaction => transaction.Type).HasConversion<string>().HasMaxLength(40).IsRequired();
            builder.Property(transaction => transaction.Amount).HasPrecision(18, 2);
            builder.Property(transaction => transaction.Description).HasMaxLength(600).IsRequired();
            builder.HasIndex(transaction => transaction.SellerId);
            builder.HasIndex(transaction => transaction.OrderId);
            builder.HasIndex(transaction => transaction.Type);
            builder.HasIndex(transaction => transaction.ReferenceId);
        });

        modelBuilder.Entity<AuditLog>(builder =>
        {
            builder.ToTable("audit_logs");
            builder.HasKey(auditLog => auditLog.Id);
            builder.Property(auditLog => auditLog.Id).ValueGeneratedNever();
            builder.Property(auditLog => auditLog.Action).HasMaxLength(120).IsRequired();
            builder.Property(auditLog => auditLog.EntityName).HasMaxLength(120).IsRequired();
            builder.Property(auditLog => auditLog.Details).HasMaxLength(1000).IsRequired();
            builder.HasIndex(auditLog => auditLog.UserId);
            builder.HasIndex(auditLog => auditLog.Action);
            builder.HasIndex(auditLog => new { auditLog.EntityName, auditLog.EntityId });
        });
    }
}
