using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text.Json;
using Zellamart.Finance.Application.Abstractions;

namespace Zellamart.Finance.Infrastructure.Services;

public sealed class OrderGateway : IOrderGateway
{
    private readonly HttpClient _httpClient;

    public OrderGateway(HttpClient httpClient)
    {
        _httpClient = httpClient;
    }

    public async Task<OrderSnapshot?> GetOrderAsync(
        Guid orderId,
        string bearerToken,
        CancellationToken cancellationToken)
    {
        using var request = new HttpRequestMessage(HttpMethod.Get, $"/api/orders/{orderId}");
        request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", bearerToken);

        using var response = await _httpClient.SendAsync(request, cancellationToken);
        if (!response.IsSuccessStatusCode)
        {
            return null;
        }

        var result = await response.Content.ReadFromJsonAsync<GatewayResult<OrderGatewayResponse>>(cancellationToken);
        if (result?.Success != true || result.Value is null)
        {
            return null;
        }

        return new OrderSnapshot(
            result.Value.Id,
            result.Value.CustomerId,
            ReadStatus(result.Value.Status),
            result.Value.Items.Select(item => new OrderItemSnapshot(
                item.Id,
                item.ProductId,
                item.SellerId,
                item.LineTotal)).ToArray());
    }

    private static string ReadStatus(JsonElement status)
    {
        if (status.ValueKind == JsonValueKind.String)
        {
            return status.GetString() ?? string.Empty;
        }

        return status.ValueKind == JsonValueKind.Number && status.TryGetInt32(out var statusValue)
            ? statusValue switch
            {
                1 => "PendingPayment",
                2 => "PaymentSucceeded",
                3 => "PaymentFailed",
                4 => "Confirmed",
                5 => "Cancelled",
                6 => "Delivered",
                _ => status.GetRawText()
            }
            : status.GetRawText();
    }

    private sealed record OrderGatewayResponse(
        Guid Id,
        Guid CustomerId,
        JsonElement Status,
        IReadOnlyList<OrderItemGatewayResponse> Items);

    private sealed record OrderItemGatewayResponse(
        Guid Id,
        Guid ProductId,
        Guid SellerId,
        decimal LineTotal);

    private sealed class GatewayResult<T>
    {
        public bool Success { get; set; }

        public T? Value { get; set; }
    }
}
