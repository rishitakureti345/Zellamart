using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text.Json;
using Zellamart.Finance.Application.Abstractions;

namespace Zellamart.Finance.Infrastructure.Services;

public sealed class ReturnGateway : IReturnGateway
{
    private readonly HttpClient _httpClient;

    public ReturnGateway(HttpClient httpClient)
    {
        _httpClient = httpClient;
    }

    public async Task<ReturnSnapshot?> GetReturnAsync(
        Guid returnId,
        string bearerToken,
        CancellationToken cancellationToken)
    {
        using var request = new HttpRequestMessage(HttpMethod.Get, $"/api/support/returns/{returnId}");
        request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", bearerToken);

        using var response = await _httpClient.SendAsync(request, cancellationToken);
        if (!response.IsSuccessStatusCode)
        {
            return null;
        }

        var result = await response.Content.ReadFromJsonAsync<GatewayResult<ReturnGatewayResponse>>(cancellationToken);
        if (result?.Success != true || result.Value is null)
        {
            return null;
        }

        return new ReturnSnapshot(
            result.Value.Id,
            result.Value.OrderId,
            result.Value.OrderItemId,
            result.Value.CustomerId,
            result.Value.ProductId,
            ReadStatus(result.Value.Status),
            result.Value.RefundAmount);
    }

    private static string ReadStatus(JsonElement status)
    {
        if (status.ValueKind == JsonValueKind.String)
        {
            return status.GetString() ?? string.Empty;
        }

        return status.ValueKind == JsonValueKind.Number && status.TryGetInt32(out var statusValue)
            ? statusValue switch
            {
                1 => "Requested",
                2 => "Approved",
                3 => "Rejected",
                4 => "PickupScheduled",
                5 => "PickedUp",
                6 => "RefundInitiated",
                7 => "Refunded",
                8 => "Closed",
                _ => status.GetRawText()
            }
            : status.GetRawText();
    }

    private sealed record ReturnGatewayResponse(
        Guid Id,
        Guid OrderId,
        Guid OrderItemId,
        Guid CustomerId,
        Guid ProductId,
        JsonElement Status,
        decimal RefundAmount);

    private sealed class GatewayResult<T>
    {
        public bool Success { get; set; }

        public T? Value { get; set; }
    }
}
