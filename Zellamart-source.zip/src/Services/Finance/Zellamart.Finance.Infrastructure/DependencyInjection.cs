using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Zellamart.Finance.Application.Abstractions;
using Zellamart.Finance.Infrastructure.Persistence;
using Zellamart.Finance.Infrastructure.Services;

namespace Zellamart.Finance.Infrastructure;

public static class DependencyInjection
{
    public static IServiceCollection AddFinanceInfrastructure(
        this IServiceCollection services,
        IConfiguration configuration)
    {
        services.AddDbContext<FinanceDbContext>(options =>
            options.UseNpgsql(configuration.GetConnectionString("Finance")));

        services.AddScoped<IFinanceRepository, FinanceRepository>();
        services.AddHttpClient<IOrderGateway, OrderGateway>(client =>
        {
            client.BaseAddress = new Uri(configuration["Services:Orders"] ?? "http://localhost:5106");
        });
        services.AddHttpClient<IReturnGateway, ReturnGateway>(client =>
        {
            client.BaseAddress = new Uri(configuration["Services:Support"] ?? "http://localhost:5222");
        });
        services.AddHttpClient<ISellerProfileGateway, SellerProfileGateway>(client =>
        {
            client.BaseAddress = new Uri(configuration["Services:Seller"] ?? "http://localhost:5102");
        });

        return services;
    }
}
