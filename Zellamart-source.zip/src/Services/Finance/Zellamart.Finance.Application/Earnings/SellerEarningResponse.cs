using Zellamart.Finance.Domain.Earnings;

namespace Zellamart.Finance.Application.Earnings;

public sealed record SellerEarningResponse(
    Guid Id,
    Guid SellerId,
    Guid OrderId,
    Guid OrderItemId,
    Guid ProductId,
    decimal GrossAmount,
    decimal CommissionAmount,
    decimal NetAmount,
    SellerEarningStatus Status,
    DateTimeOffset CreatedAtUtc);
