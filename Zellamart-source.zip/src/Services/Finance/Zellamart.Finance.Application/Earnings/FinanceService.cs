using Zellamart.Finance.Application.Abstractions;
using Zellamart.Finance.Application.Payouts;
using Zellamart.Finance.Application.Refunds;
using Zellamart.Finance.Application.Reports;
using Zellamart.Finance.Application.Transactions;
using Zellamart.Finance.Domain.Audit;
using Zellamart.Finance.Domain.Commissions;
using Zellamart.Finance.Domain.Earnings;
using Zellamart.Finance.Domain.Payouts;
using Zellamart.Finance.Domain.Transactions;
using Zellamart.SharedKernel.Results;

namespace Zellamart.Finance.Application.Earnings;

public sealed class FinanceService : IFinanceService
{
    public const decimal DefaultCommissionRate = 0.10m;

    private readonly IFinanceRepository _repository;
    private readonly IOrderGateway _orderGateway;
    private readonly IReturnGateway _returnGateway;

    public FinanceService(
        IFinanceRepository repository,
        IOrderGateway orderGateway,
        IReturnGateway returnGateway)
    {
        _repository = repository;
        _orderGateway = orderGateway;
        _returnGateway = returnGateway;
    }

    public async Task<Result<IReadOnlyList<SellerEarningResponse>>> CreateEarningsForOrderAsync(
        CreateEarningsForOrderRequest request,
        string bearerToken,
        CancellationToken cancellationToken)
    {
        if (request.OrderId == Guid.Empty)
        {
            return Result.Fail<IReadOnlyList<SellerEarningResponse>>(Error.Validation("Order id is required."));
        }

        if (string.IsNullOrWhiteSpace(bearerToken))
        {
            return Result.Fail<IReadOnlyList<SellerEarningResponse>>(Error.Unauthorized("Bearer token is required."));
        }

        var order = await _orderGateway.GetOrderAsync(request.OrderId, bearerToken, cancellationToken);
        if (order is null)
        {
            return Result.Fail<IReadOnlyList<SellerEarningResponse>>(Error.NotFound("Order was not found."));
        }

        if (!string.Equals(order.Status, "Delivered", StringComparison.OrdinalIgnoreCase))
        {
            return Result.Fail<IReadOnlyList<SellerEarningResponse>>(
                Error.Validation("Only delivered orders can create seller earnings."));
        }

        if (order.Items.Count == 0)
        {
            return Result.Fail<IReadOnlyList<SellerEarningResponse>>(Error.Validation("Order has no items."));
        }

        var created = new List<SellerEarning>();
        foreach (var item in order.Items)
        {
            if (item.SellerId == Guid.Empty)
            {
                return Result.Fail<IReadOnlyList<SellerEarningResponse>>(
                    Error.Validation("Order item seller id is required."));
            }

            var existing = await _repository.GetEarningByOrderItemIdAsync(item.Id, cancellationToken);
            if (existing is not null)
            {
                return Result.Fail<IReadOnlyList<SellerEarningResponse>>(
                    Error.Conflict("Seller earning already exists for this order item."));
            }

            var earning = new SellerEarning(
                item.SellerId,
                order.Id,
                item.Id,
                item.ProductId,
                item.LineTotal,
                DefaultCommissionRate);

            var commission = new PlatformCommission(
                earning.Id,
                earning.SellerId,
                earning.OrderId,
                earning.CommissionAmount,
                DefaultCommissionRate);

            await _repository.AddEarningAsync(earning, cancellationToken);
            await _repository.AddCommissionAsync(commission, cancellationToken);
            await _repository.AddTransactionAsync(
                new FinanceTransaction(
                    earning.SellerId,
                    earning.OrderId,
                    FinanceTransactionType.Earning,
                    earning.NetAmount,
                    "Seller earning created.",
                    earning.Id),
                cancellationToken);
            await _repository.AddTransactionAsync(
                new FinanceTransaction(
                    earning.SellerId,
                    earning.OrderId,
                    FinanceTransactionType.Commission,
                    earning.CommissionAmount,
                    "Platform commission recorded.",
                    commission.Id),
                cancellationToken);
            created.Add(earning);
        }

        await _repository.SaveChangesAsync(cancellationToken);

        return Result.Ok<IReadOnlyList<SellerEarningResponse>>(created.Select(ToEarningResponse).ToArray());
    }

    public async Task<Result<IReadOnlyList<SellerEarningResponse>>> GetSellerEarningsAsync(
        Guid sellerId,
        CancellationToken cancellationToken)
    {
        if (sellerId == Guid.Empty)
        {
            return Result.Fail<IReadOnlyList<SellerEarningResponse>>(Error.Validation("Seller id is required."));
        }

        var earnings = await _repository.GetEarningsBySellerIdAsync(sellerId, cancellationToken);
        return Result.Ok<IReadOnlyList<SellerEarningResponse>>(earnings.Select(ToEarningResponse).ToArray());
    }

    public async Task<Result<IReadOnlyList<SellerPayoutResponse>>> GetSellerPayoutsAsync(
        Guid sellerId,
        CancellationToken cancellationToken)
    {
        if (sellerId == Guid.Empty)
        {
            return Result.Fail<IReadOnlyList<SellerPayoutResponse>>(Error.Validation("Seller id is required."));
        }

        var payouts = await _repository.GetPayoutsBySellerIdAsync(sellerId, cancellationToken);
        return Result.Ok<IReadOnlyList<SellerPayoutResponse>>(payouts.Select(ToPayoutResponse).ToArray());
    }

    public async Task<Result<SellerPayoutResponse>> RequestSellerPayoutAsync(
        Guid sellerId,
        CancellationToken cancellationToken)
    {
        if (sellerId == Guid.Empty)
        {
            return Result.Fail<SellerPayoutResponse>(Error.Validation("Seller id is required."));
        }

        var availableEarnings = await _repository.GetAvailableEarningsBySellerIdAsync(sellerId, cancellationToken);
        if (availableEarnings.Count == 0)
        {
            return Result.Fail<SellerPayoutResponse>(Error.NotFound("Seller has no available earnings."));
        }

        var amount = availableEarnings.Sum(earning => earning.NetAmount);
        if (amount <= 0)
        {
            return Result.Fail<SellerPayoutResponse>(Error.Validation("Seller has no available payout balance."));
        }

        var payout = new SellerPayout(sellerId, amount, CreateReferenceNumber());
        await _repository.AddPayoutAsync(payout, cancellationToken);
        await _repository.AddTransactionAsync(
            new FinanceTransaction(
                sellerId,
                null,
                FinanceTransactionType.Payout,
                -amount,
                "Seller payout requested.",
                payout.Id),
            cancellationToken);
        await _repository.SaveChangesAsync(cancellationToken);

        return Result.Ok(ToPayoutResponse(payout));
    }

    public async Task<Result<SellerPayoutResponse>> MarkPayoutPaidAsync(
        Guid? actorUserId,
        Guid payoutId,
        CancellationToken cancellationToken)
    {
        var payout = await _repository.GetPayoutByIdAsync(payoutId, cancellationToken);
        if (payout is null)
        {
            return Result.Fail<SellerPayoutResponse>(Error.NotFound("Payout was not found."));
        }

        var availableEarnings = await _repository.GetAvailableEarningsBySellerIdAsync(payout.SellerId, cancellationToken);
        var availableAmount = availableEarnings.Sum(earning => earning.NetAmount);
        if (availableAmount < payout.Amount)
        {
            return Result.Fail<SellerPayoutResponse>(Error.Validation("Available earnings do not cover this payout."));
        }

        try
        {
            payout.MarkPaid(availableEarnings);
        }
        catch (InvalidOperationException ex)
        {
            return Result.Fail<SellerPayoutResponse>(Error.Validation(ex.Message));
        }

        await _repository.AddAuditLogAsync(
            new AuditLog(
                actorUserId,
                "PayoutPaid",
                nameof(SellerPayout),
                payout.Id,
                $"Payout {payout.ReferenceNumber} marked paid for seller {payout.SellerId}."),
            cancellationToken);
        await _repository.SaveChangesAsync(cancellationToken);
        return Result.Ok(ToPayoutResponse(payout));
    }

    public async Task<Result<FinanceTransactionResponse>> CreateRefundForReturnAsync(
        Guid? actorUserId,
        CreateRefundForReturnRequest request,
        string bearerToken,
        CancellationToken cancellationToken)
    {
        if (request.ReturnId == Guid.Empty)
        {
            return Result.Fail<FinanceTransactionResponse>(Error.Validation("Return id is required."));
        }

        if (string.IsNullOrWhiteSpace(bearerToken))
        {
            return Result.Fail<FinanceTransactionResponse>(Error.Unauthorized("Bearer token is required."));
        }

        var returnRequest = await _returnGateway.GetReturnAsync(request.ReturnId, bearerToken, cancellationToken);
        if (returnRequest is null)
        {
            return Result.Fail<FinanceTransactionResponse>(Error.NotFound("Return request was not found."));
        }

        if (!string.Equals(returnRequest.Status, "Refunded", StringComparison.OrdinalIgnoreCase))
        {
            return Result.Fail<FinanceTransactionResponse>(
                Error.Validation("Only refunded returns can create finance refund records."));
        }

        var earning = await _repository.GetEarningByOrderItemIdAsync(returnRequest.OrderItemId, cancellationToken);
        if (earning is null)
        {
            return Result.Fail<FinanceTransactionResponse>(Error.NotFound("Seller earning was not found for this return."));
        }

        if (earning.ProductId != returnRequest.ProductId || earning.OrderId != returnRequest.OrderId)
        {
            return Result.Fail<FinanceTransactionResponse>(
                Error.Validation("Return request does not match the seller earning."));
        }

        FinanceTransaction transaction;
        if (earning.Status == SellerEarningStatus.EarningAvailable)
        {
            earning.MarkRefunded();
            transaction = new FinanceTransaction(
                earning.SellerId,
                earning.OrderId,
                FinanceTransactionType.Refund,
                -earning.NetAmount,
                "Seller earning refunded before payout.",
                returnRequest.Id);
        }
        else if (earning.Status == SellerEarningStatus.Paid)
        {
            transaction = new FinanceTransaction(
                earning.SellerId,
                earning.OrderId,
                FinanceTransactionType.Adjustment,
                -earning.NetAmount,
                "Refund adjustment created after seller payout.",
                returnRequest.Id);
        }
        else if (earning.Status == SellerEarningStatus.Refunded)
        {
            return Result.Fail<FinanceTransactionResponse>(Error.Conflict("Seller earning is already refunded."));
        }
        else
        {
            return Result.Fail<FinanceTransactionResponse>(
                Error.Validation("Seller earning is not eligible for refund."));
        }

        await _repository.AddTransactionAsync(transaction, cancellationToken);
        await _repository.AddAuditLogAsync(
            new AuditLog(
                actorUserId,
                transaction.Type == FinanceTransactionType.Adjustment ? "RefundAdjustmentCreated" : "RefundRecorded",
                nameof(SellerEarning),
                earning.Id,
                $"Return {returnRequest.Id} recorded against order item {returnRequest.OrderItemId}."),
            cancellationToken);
        await _repository.SaveChangesAsync(cancellationToken);

        return Result.Ok(ToTransactionResponse(transaction));
    }

    public async Task<Result<IReadOnlyList<FinanceTransactionResponse>>> GetSellerTransactionsAsync(
        Guid sellerId,
        CancellationToken cancellationToken)
    {
        if (sellerId == Guid.Empty)
        {
            return Result.Fail<IReadOnlyList<FinanceTransactionResponse>>(Error.Validation("Seller id is required."));
        }

        var transactions = await _repository.GetTransactionsBySellerIdAsync(sellerId, cancellationToken);
        return Result.Ok<IReadOnlyList<FinanceTransactionResponse>>(transactions.Select(ToTransactionResponse).ToArray());
    }

    public async Task<Result<SellerBalanceResponse>> GetSellerBalanceAsync(
        Guid sellerId,
        CancellationToken cancellationToken)
    {
        if (sellerId == Guid.Empty)
        {
            return Result.Fail<SellerBalanceResponse>(Error.Validation("Seller id is required."));
        }

        var earnings = await _repository.GetEarningsBySellerIdAsync(sellerId, cancellationToken);
        var payouts = await _repository.GetPayoutsBySellerIdAsync(sellerId, cancellationToken);
        var transactions = await _repository.GetTransactionsBySellerIdAsync(sellerId, cancellationToken);

        return Result.Ok(ToSellerBalance(sellerId, earnings, payouts, transactions));
    }

    public async Task<Result<AdminFinanceSummaryResponse>> GetAdminSummaryAsync(CancellationToken cancellationToken)
    {
        var earnings = await _repository.GetAllEarningsAsync(cancellationToken);
        var payouts = await _repository.GetAllPayoutsAsync(cancellationToken);
        var transactions = await _repository.GetAllTransactionsAsync(cancellationToken);

        var response = new AdminFinanceSummaryResponse(
            earnings.Sum(earning => earning.GrossAmount),
            earnings.Sum(earning => earning.CommissionAmount),
            earnings.Sum(earning => earning.NetAmount),
            payouts.Where(payout => payout.Status == SellerPayoutStatus.Paid).Sum(payout => payout.Amount),
            Math.Abs(transactions
                .Where(transaction =>
                    transaction.Type is FinanceTransactionType.Refund or FinanceTransactionType.Adjustment)
                .Sum(transaction => transaction.Amount)),
            payouts
                .Where(payout => payout.Status == SellerPayoutStatus.PayoutProcessing)
                .Sum(payout => payout.Amount));

        return Result.Ok(response);
    }

    public async Task<Result<IReadOnlyList<AdminSellerBalanceResponse>>> GetAdminSellerBalancesAsync(
        CancellationToken cancellationToken)
    {
        var earnings = await _repository.GetAllEarningsAsync(cancellationToken);
        var payouts = await _repository.GetAllPayoutsAsync(cancellationToken);
        var transactions = await _repository.GetAllTransactionsAsync(cancellationToken);

        var sellerIds = earnings.Select(earning => earning.SellerId)
            .Concat(payouts.Select(payout => payout.SellerId))
            .Concat(transactions.Select(transaction => transaction.SellerId))
            .Distinct()
            .OrderBy(sellerId => sellerId)
            .ToArray();

        var balances = sellerIds
            .Select(sellerId =>
            {
                var balance = ToSellerBalance(
                    sellerId,
                    earnings.Where(earning => earning.SellerId == sellerId),
                    payouts.Where(payout => payout.SellerId == sellerId),
                    transactions.Where(transaction => transaction.SellerId == sellerId));

                return new AdminSellerBalanceResponse(
                    balance.SellerId,
                    balance.AvailableBalance,
                    balance.PendingEarnings,
                    balance.TotalPaidOut,
                    balance.RefundDeductions,
                    balance.AdjustmentBalance);
            })
            .ToArray();

        return Result.Ok<IReadOnlyList<AdminSellerBalanceResponse>>(balances);
    }

    public async Task<Result<IReadOnlyList<PlatformCommissionResponse>>> GetAdminCommissionsAsync(
        CancellationToken cancellationToken)
    {
        var commissions = await _repository.GetAllCommissionsAsync(cancellationToken);
        return Result.Ok<IReadOnlyList<PlatformCommissionResponse>>(
            commissions.Select(ToCommissionResponse).ToArray());
    }

    public async Task<Result<IReadOnlyList<SellerPayoutResponse>>> GetAdminPayoutsAsync(CancellationToken cancellationToken)
    {
        var payouts = await _repository.GetAllPayoutsAsync(cancellationToken);
        return Result.Ok<IReadOnlyList<SellerPayoutResponse>>(payouts.Select(ToPayoutResponse).ToArray());
    }

    private static string CreateReferenceNumber()
    {
        return $"PO-{DateTimeOffset.UtcNow:yyyyMMddHHmmss}-{Random.Shared.Next(1000, 9999)}";
    }

    private static SellerEarningResponse ToEarningResponse(SellerEarning earning)
    {
        return new SellerEarningResponse(
            earning.Id,
            earning.SellerId,
            earning.OrderId,
            earning.OrderItemId,
            earning.ProductId,
            earning.GrossAmount,
            earning.CommissionAmount,
            earning.NetAmount,
            earning.Status,
            earning.CreatedAtUtc);
    }

    private static SellerPayoutResponse ToPayoutResponse(SellerPayout payout)
    {
        return new SellerPayoutResponse(
            payout.Id,
            payout.SellerId,
            payout.Amount,
            payout.Status,
            payout.RequestedAtUtc,
            payout.PaidAtUtc,
            payout.ReferenceNumber);
    }

    private static FinanceTransactionResponse ToTransactionResponse(FinanceTransaction transaction)
    {
        return new FinanceTransactionResponse(
            transaction.Id,
            transaction.SellerId,
            transaction.OrderId,
            transaction.Type,
            transaction.Amount,
            transaction.Description,
            transaction.ReferenceId,
            transaction.CreatedAtUtc);
    }

    private static PlatformCommissionResponse ToCommissionResponse(PlatformCommission commission)
    {
        return new PlatformCommissionResponse(
            commission.Id,
            commission.SellerEarningId,
            commission.SellerId,
            commission.OrderId,
            commission.Amount,
            commission.Rate,
            commission.CreatedAtUtc);
    }

    private static SellerBalanceResponse ToSellerBalance(
        Guid sellerId,
        IEnumerable<SellerEarning> earnings,
        IEnumerable<SellerPayout> payouts,
        IEnumerable<FinanceTransaction> transactions)
    {
        var earningsArray = earnings.ToArray();
        var payoutsArray = payouts.ToArray();
        var transactionsArray = transactions.ToArray();
        var adjustmentBalance = transactionsArray
            .Where(transaction => transaction.Type == FinanceTransactionType.Adjustment)
            .Sum(transaction => transaction.Amount);

        return new SellerBalanceResponse(
            sellerId,
            earningsArray
                .Where(earning => earning.Status == SellerEarningStatus.EarningAvailable)
                .Sum(earning => earning.NetAmount) + adjustmentBalance,
            earningsArray
                .Where(earning => earning.Status == SellerEarningStatus.EarningPending)
                .Sum(earning => earning.NetAmount),
            payoutsArray
                .Where(payout => payout.Status == SellerPayoutStatus.Paid)
                .Sum(payout => payout.Amount),
            Math.Abs(transactionsArray
                .Where(transaction =>
                    transaction.Type is FinanceTransactionType.Refund or FinanceTransactionType.Adjustment)
                .Sum(transaction => transaction.Amount)),
            adjustmentBalance);
    }
}
