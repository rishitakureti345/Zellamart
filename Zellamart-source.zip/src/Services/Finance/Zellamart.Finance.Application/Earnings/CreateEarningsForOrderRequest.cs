namespace Zellamart.Finance.Application.Earnings;

public sealed record CreateEarningsForOrderRequest(Guid OrderId);
