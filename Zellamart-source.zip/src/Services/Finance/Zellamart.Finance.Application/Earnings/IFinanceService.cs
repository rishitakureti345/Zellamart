using Zellamart.Finance.Application.Payouts;
using Zellamart.Finance.Application.Refunds;
using Zellamart.Finance.Application.Reports;
using Zellamart.Finance.Application.Transactions;
using Zellamart.Finance.Domain.Commissions;
using Zellamart.SharedKernel.Results;

namespace Zellamart.Finance.Application.Earnings;

public interface IFinanceService
{
    Task<Result<IReadOnlyList<SellerEarningResponse>>> CreateEarningsForOrderAsync(
        CreateEarningsForOrderRequest request,
        string bearerToken,
        CancellationToken cancellationToken);

    Task<Result<IReadOnlyList<SellerEarningResponse>>> GetSellerEarningsAsync(
        Guid sellerId,
        CancellationToken cancellationToken);

    Task<Result<IReadOnlyList<SellerPayoutResponse>>> GetSellerPayoutsAsync(
        Guid sellerId,
        CancellationToken cancellationToken);

    Task<Result<SellerPayoutResponse>> RequestSellerPayoutAsync(
        Guid sellerId,
        CancellationToken cancellationToken);

    Task<Result<SellerPayoutResponse>> MarkPayoutPaidAsync(
        Guid? actorUserId,
        Guid payoutId,
        CancellationToken cancellationToken);

    Task<Result<FinanceTransactionResponse>> CreateRefundForReturnAsync(
        Guid? actorUserId,
        CreateRefundForReturnRequest request,
        string bearerToken,
        CancellationToken cancellationToken);

    Task<Result<IReadOnlyList<FinanceTransactionResponse>>> GetSellerTransactionsAsync(
        Guid sellerId,
        CancellationToken cancellationToken);

    Task<Result<SellerBalanceResponse>> GetSellerBalanceAsync(
        Guid sellerId,
        CancellationToken cancellationToken);

    Task<Result<AdminFinanceSummaryResponse>> GetAdminSummaryAsync(CancellationToken cancellationToken);

    Task<Result<IReadOnlyList<AdminSellerBalanceResponse>>> GetAdminSellerBalancesAsync(CancellationToken cancellationToken);

    Task<Result<IReadOnlyList<PlatformCommissionResponse>>> GetAdminCommissionsAsync(CancellationToken cancellationToken);

    Task<Result<IReadOnlyList<SellerPayoutResponse>>> GetAdminPayoutsAsync(CancellationToken cancellationToken);
}
