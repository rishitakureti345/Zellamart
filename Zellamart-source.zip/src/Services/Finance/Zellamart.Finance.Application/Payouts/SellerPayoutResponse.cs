using Zellamart.Finance.Domain.Payouts;

namespace Zellamart.Finance.Application.Payouts;

public sealed record SellerPayoutResponse(
    Guid Id,
    Guid SellerId,
    decimal Amount,
    SellerPayoutStatus Status,
    DateTimeOffset RequestedAtUtc,
    DateTimeOffset? PaidAtUtc,
    string ReferenceNumber);
