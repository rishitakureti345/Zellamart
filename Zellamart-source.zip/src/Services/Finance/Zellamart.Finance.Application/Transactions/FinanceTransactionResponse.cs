using Zellamart.Finance.Domain.Transactions;

namespace Zellamart.Finance.Application.Transactions;

public sealed record FinanceTransactionResponse(
    Guid Id,
    Guid SellerId,
    Guid? OrderId,
    FinanceTransactionType Type,
    decimal Amount,
    string Description,
    Guid? ReferenceId,
    DateTimeOffset CreatedAtUtc);
