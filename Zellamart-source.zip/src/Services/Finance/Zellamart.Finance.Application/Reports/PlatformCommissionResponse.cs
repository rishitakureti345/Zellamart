namespace Zellamart.Finance.Application.Reports;

public sealed record PlatformCommissionResponse(
    Guid Id,
    Guid SellerEarningId,
    Guid SellerId,
    Guid OrderId,
    decimal Amount,
    decimal Rate,
    DateTimeOffset CreatedAtUtc);
