namespace Zellamart.Finance.Application.Reports;

public sealed record AdminFinanceSummaryResponse(
    decimal TotalSales,
    decimal TotalCommission,
    decimal TotalSellerEarnings,
    decimal TotalPayouts,
    decimal TotalRefunds,
    decimal PendingPayoutAmount);
