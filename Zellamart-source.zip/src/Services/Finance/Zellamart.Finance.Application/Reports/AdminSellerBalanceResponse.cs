namespace Zellamart.Finance.Application.Reports;

public sealed record AdminSellerBalanceResponse(
    Guid SellerId,
    decimal AvailableBalance,
    decimal PendingEarnings,
    decimal TotalPaidOut,
    decimal RefundDeductions,
    decimal AdjustmentBalance);
