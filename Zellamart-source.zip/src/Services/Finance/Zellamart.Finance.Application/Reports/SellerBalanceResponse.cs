namespace Zellamart.Finance.Application.Reports;

public sealed record SellerBalanceResponse(
    Guid SellerId,
    decimal AvailableBalance,
    decimal PendingEarnings,
    decimal TotalPaidOut,
    decimal RefundDeductions,
    decimal AdjustmentBalance);
