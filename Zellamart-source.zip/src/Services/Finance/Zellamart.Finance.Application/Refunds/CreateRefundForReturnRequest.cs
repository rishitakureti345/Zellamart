namespace Zellamart.Finance.Application.Refunds;

public sealed record CreateRefundForReturnRequest(Guid ReturnId);
