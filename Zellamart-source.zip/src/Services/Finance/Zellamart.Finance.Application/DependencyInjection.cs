using Microsoft.Extensions.DependencyInjection;
using Zellamart.Finance.Application.Earnings;

namespace Zellamart.Finance.Application;

public static class DependencyInjection
{
    public static IServiceCollection AddFinanceApplication(this IServiceCollection services)
    {
        services.AddScoped<IFinanceService, FinanceService>();
        return services;
    }
}
