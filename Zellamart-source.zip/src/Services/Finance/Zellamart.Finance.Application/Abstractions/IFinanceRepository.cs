using Zellamart.Finance.Domain.Commissions;
using Zellamart.Finance.Domain.Audit;
using Zellamart.Finance.Domain.Earnings;
using Zellamart.Finance.Domain.Payouts;
using Zellamart.Finance.Domain.Transactions;

namespace Zellamart.Finance.Application.Abstractions;

public interface IFinanceRepository
{
    Task<SellerEarning?> GetEarningByOrderItemIdAsync(Guid orderItemId, CancellationToken cancellationToken);

    Task<IReadOnlyList<SellerEarning>> GetEarningsBySellerIdAsync(Guid sellerId, CancellationToken cancellationToken);

    Task<IReadOnlyList<SellerEarning>> GetAllEarningsAsync(CancellationToken cancellationToken);

    Task<IReadOnlyList<SellerEarning>> GetAvailableEarningsBySellerIdAsync(Guid sellerId, CancellationToken cancellationToken);

    Task<SellerPayout?> GetPayoutByIdAsync(Guid payoutId, CancellationToken cancellationToken);

    Task<IReadOnlyList<SellerPayout>> GetPayoutsBySellerIdAsync(Guid sellerId, CancellationToken cancellationToken);

    Task<IReadOnlyList<SellerPayout>> GetAllPayoutsAsync(CancellationToken cancellationToken);

    Task<IReadOnlyList<PlatformCommission>> GetAllCommissionsAsync(CancellationToken cancellationToken);

    Task<IReadOnlyList<FinanceTransaction>> GetTransactionsBySellerIdAsync(Guid sellerId, CancellationToken cancellationToken);

    Task<IReadOnlyList<FinanceTransaction>> GetAllTransactionsAsync(CancellationToken cancellationToken);

    Task AddEarningAsync(SellerEarning earning, CancellationToken cancellationToken);

    Task AddCommissionAsync(PlatformCommission commission, CancellationToken cancellationToken);

    Task AddTransactionAsync(FinanceTransaction transaction, CancellationToken cancellationToken);

    Task AddPayoutAsync(SellerPayout payout, CancellationToken cancellationToken);

    Task AddAuditLogAsync(AuditLog auditLog, CancellationToken cancellationToken);

    Task SaveChangesAsync(CancellationToken cancellationToken);
}
