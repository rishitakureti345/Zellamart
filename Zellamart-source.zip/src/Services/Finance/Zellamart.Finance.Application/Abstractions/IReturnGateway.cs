namespace Zellamart.Finance.Application.Abstractions;

public interface IReturnGateway
{
    Task<ReturnSnapshot?> GetReturnAsync(
        Guid returnId,
        string bearerToken,
        CancellationToken cancellationToken);
}

public sealed record ReturnSnapshot(
    Guid Id,
    Guid OrderId,
    Guid OrderItemId,
    Guid CustomerId,
    Guid ProductId,
    string Status,
    decimal RefundAmount);
