namespace Zellamart.Finance.Application.Abstractions;

public interface ISellerProfileGateway
{
    Task<SellerProfileSnapshot?> GetMineAsync(string bearerToken, CancellationToken cancellationToken);
}

public sealed record SellerProfileSnapshot(Guid Id, Guid UserId, string BusinessName, string Status);
