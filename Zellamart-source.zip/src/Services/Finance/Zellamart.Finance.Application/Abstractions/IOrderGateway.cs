namespace Zellamart.Finance.Application.Abstractions;

public interface IOrderGateway
{
    Task<OrderSnapshot?> GetOrderAsync(
        Guid orderId,
        string bearerToken,
        CancellationToken cancellationToken);
}

public sealed record OrderSnapshot(
    Guid Id,
    Guid CustomerId,
    string Status,
    IReadOnlyList<OrderItemSnapshot> Items);

public sealed record OrderItemSnapshot(
    Guid Id,
    Guid ProductId,
    Guid SellerId,
    decimal LineTotal);
