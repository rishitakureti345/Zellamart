using Zellamart.SharedKernel.Entities;

namespace Zellamart.Finance.Domain.Commissions;

public sealed class PlatformCommission : BaseEntity
{
    private PlatformCommission()
    {
    }

    public PlatformCommission(Guid sellerEarningId, Guid sellerId, Guid orderId, decimal amount, decimal rate)
    {
        SellerEarningId = sellerEarningId;
        SellerId = sellerId;
        OrderId = orderId;
        Amount = amount;
        Rate = rate;
        CreatedAtUtc = DateTimeOffset.UtcNow;
    }

    public Guid SellerEarningId { get; private set; }

    public Guid SellerId { get; private set; }

    public Guid OrderId { get; private set; }

    public decimal Amount { get; private set; }

    public decimal Rate { get; private set; }

    public DateTimeOffset CreatedAtUtc { get; private set; }
}
