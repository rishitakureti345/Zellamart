using Zellamart.SharedKernel.Entities;

namespace Zellamart.Finance.Domain.Earnings;

public sealed class SellerEarning : AuditableEntity
{
    private SellerEarning()
    {
    }

    public SellerEarning(
        Guid sellerId,
        Guid orderId,
        Guid orderItemId,
        Guid productId,
        decimal grossAmount,
        decimal commissionRate)
    {
        if (sellerId == Guid.Empty)
        {
            throw new ArgumentException("Seller id is required.", nameof(sellerId));
        }

        if (orderId == Guid.Empty)
        {
            throw new ArgumentException("Order id is required.", nameof(orderId));
        }

        if (orderItemId == Guid.Empty)
        {
            throw new ArgumentException("Order item id is required.", nameof(orderItemId));
        }

        if (productId == Guid.Empty)
        {
            throw new ArgumentException("Product id is required.", nameof(productId));
        }

        if (grossAmount <= 0)
        {
            throw new ArgumentException("Gross amount must be greater than zero.", nameof(grossAmount));
        }

        SellerId = sellerId;
        OrderId = orderId;
        OrderItemId = orderItemId;
        ProductId = productId;
        GrossAmount = decimal.Round(grossAmount, 2, MidpointRounding.AwayFromZero);
        CommissionAmount = decimal.Round(GrossAmount * commissionRate, 2, MidpointRounding.AwayFromZero);
        NetAmount = GrossAmount - CommissionAmount;
        Status = SellerEarningStatus.EarningAvailable;
    }

    public Guid SellerId { get; private set; }

    public Guid OrderId { get; private set; }

    public Guid OrderItemId { get; private set; }

    public Guid ProductId { get; private set; }

    public decimal GrossAmount { get; private set; }

    public decimal CommissionAmount { get; private set; }

    public decimal NetAmount { get; private set; }

    public SellerEarningStatus Status { get; private set; }

    public void MarkPaid()
    {
        if (Status != SellerEarningStatus.EarningAvailable)
        {
            throw new InvalidOperationException("Only available earnings can be marked paid.");
        }

        Status = SellerEarningStatus.Paid;
        UpdatedAtUtc = DateTimeOffset.UtcNow;
    }

    public void MarkRefunded()
    {
        if (Status != SellerEarningStatus.EarningAvailable)
        {
            throw new InvalidOperationException("Only available earnings can be marked refunded.");
        }

        Status = SellerEarningStatus.Refunded;
        UpdatedAtUtc = DateTimeOffset.UtcNow;
    }
}
