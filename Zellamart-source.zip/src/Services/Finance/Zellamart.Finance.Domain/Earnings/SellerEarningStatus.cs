namespace Zellamart.Finance.Domain.Earnings;

public enum SellerEarningStatus
{
    EarningPending = 1,
    EarningAvailable = 2,
    Refunded = 3,
    Cancelled = 4,
    Paid = 5
}
