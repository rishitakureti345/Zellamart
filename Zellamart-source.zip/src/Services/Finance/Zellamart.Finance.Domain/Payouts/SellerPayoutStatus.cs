namespace Zellamart.Finance.Domain.Payouts;

public enum SellerPayoutStatus
{
    PayoutRequested = 1,
    PayoutProcessing = 2,
    Paid = 3,
    Cancelled = 4
}
