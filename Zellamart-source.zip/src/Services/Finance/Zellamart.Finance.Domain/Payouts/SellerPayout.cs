using Zellamart.Finance.Domain.Earnings;
using Zellamart.SharedKernel.Entities;

namespace Zellamart.Finance.Domain.Payouts;

public sealed class SellerPayout : BaseEntity
{
    private SellerPayout()
    {
    }

    public SellerPayout(Guid sellerId, decimal amount, string referenceNumber)
    {
        if (sellerId == Guid.Empty)
        {
            throw new ArgumentException("Seller id is required.", nameof(sellerId));
        }

        if (amount <= 0)
        {
            throw new ArgumentException("Payout amount must be greater than zero.", nameof(amount));
        }

        SellerId = sellerId;
        Amount = decimal.Round(amount, 2, MidpointRounding.AwayFromZero);
        Status = SellerPayoutStatus.PayoutProcessing;
        RequestedAtUtc = DateTimeOffset.UtcNow;
        ReferenceNumber = referenceNumber.Trim();
    }

    public Guid SellerId { get; private set; }

    public decimal Amount { get; private set; }

    public SellerPayoutStatus Status { get; private set; }

    public DateTimeOffset RequestedAtUtc { get; private set; }

    public DateTimeOffset? PaidAtUtc { get; private set; }

    public string ReferenceNumber { get; private set; } = string.Empty;

    public void MarkPaid(IEnumerable<SellerEarning> earnings)
    {
        if (Status != SellerPayoutStatus.PayoutProcessing)
        {
            throw new InvalidOperationException("Only payout processing records can be marked paid.");
        }

        foreach (var earning in earnings)
        {
            earning.MarkPaid();
        }

        Status = SellerPayoutStatus.Paid;
        PaidAtUtc = DateTimeOffset.UtcNow;
    }
}
