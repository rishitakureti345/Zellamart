using Zellamart.SharedKernel.Entities;

namespace Zellamart.Finance.Domain.Transactions;

public sealed class FinanceTransaction : BaseEntity
{
    private FinanceTransaction()
    {
    }

    public FinanceTransaction(
        Guid sellerId,
        Guid? orderId,
        FinanceTransactionType type,
        decimal amount,
        string description,
        Guid? referenceId = null)
    {
        SellerId = sellerId;
        OrderId = orderId;
        Type = type;
        Amount = decimal.Round(amount, 2, MidpointRounding.AwayFromZero);
        Description = description.Trim();
        ReferenceId = referenceId;
        CreatedAtUtc = DateTimeOffset.UtcNow;
    }

    public Guid SellerId { get; private set; }

    public Guid? OrderId { get; private set; }

    public FinanceTransactionType Type { get; private set; }

    public decimal Amount { get; private set; }

    public string Description { get; private set; } = string.Empty;

    public Guid? ReferenceId { get; private set; }

    public DateTimeOffset CreatedAtUtc { get; private set; }
}
