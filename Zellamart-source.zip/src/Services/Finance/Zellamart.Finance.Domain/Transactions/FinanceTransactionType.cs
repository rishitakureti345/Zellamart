namespace Zellamart.Finance.Domain.Transactions;

public enum FinanceTransactionType
{
    Earning = 1,
    Commission = 2,
    Payout = 3,
    Refund = 4,
    Adjustment = 5
}
