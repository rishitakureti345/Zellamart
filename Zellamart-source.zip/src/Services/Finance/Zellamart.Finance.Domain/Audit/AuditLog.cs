using Zellamart.SharedKernel.Entities;

namespace Zellamart.Finance.Domain.Audit;

public sealed class AuditLog : BaseEntity
{
    private AuditLog()
    {
    }

    public AuditLog(
        Guid? userId,
        string action,
        string entityName,
        Guid entityId,
        string details)
    {
        UserId = userId;
        Action = action.Trim();
        EntityName = entityName.Trim();
        EntityId = entityId;
        Details = details.Trim();
        CreatedAtUtc = DateTimeOffset.UtcNow;
    }

    public Guid? UserId { get; private set; }

    public string Action { get; private set; } = string.Empty;

    public string EntityName { get; private set; } = string.Empty;

    public Guid EntityId { get; private set; }

    public string Details { get; private set; } = string.Empty;

    public DateTimeOffset CreatedAtUtc { get; private set; }
}
