using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Zellamart.Finance.Application.Abstractions;
using Zellamart.Finance.Application.Earnings;
using Zellamart.Finance.Application.Refunds;
using Zellamart.SharedKernel.Results;

namespace Zellamart.Finance.Api.Controllers;

[ApiController]
[Authorize]
[Route("api/finance")]
public sealed class FinanceController : ControllerBase
{
    private readonly IFinanceService _financeService;
    private readonly ISellerProfileGateway _sellerProfileGateway;

    public FinanceController(
        IFinanceService financeService,
        ISellerProfileGateway sellerProfileGateway)
    {
        _financeService = financeService;
        _sellerProfileGateway = sellerProfileGateway;
    }

    [Authorize(Roles = "SuperAdmin,Admin,FinanceManager,PaymentTeam,OrderManager")]
    [HttpPost("earnings/create-for-order")]
    public async Task<IActionResult> CreateEarningsForOrder(
        CreateEarningsForOrderRequest request,
        CancellationToken cancellationToken)
    {
        var bearerToken = GetBearerToken();
        if (bearerToken is null)
        {
            return Unauthorized();
        }

        var result = await _financeService.CreateEarningsForOrderAsync(
            request,
            bearerToken,
            cancellationToken);
        return result.Success ? Ok(result) : ToFailureResult(result);
    }

    [Authorize(Roles = "SuperAdmin,Admin,FinanceManager,PaymentTeam")]
    [HttpGet("sellers/{sellerId:guid}/earnings")]
    public async Task<IActionResult> GetSellerEarnings(Guid sellerId, CancellationToken cancellationToken)
    {
        var result = await _financeService.GetSellerEarningsAsync(sellerId, cancellationToken);
        return result.Success ? Ok(result) : ToFailureResult(result);
    }

    [Authorize(Roles = "SuperAdmin,Admin,FinanceManager,PaymentTeam")]
    [HttpGet("sellers/{sellerId:guid}/payouts")]
    public async Task<IActionResult> GetSellerPayouts(Guid sellerId, CancellationToken cancellationToken)
    {
        var result = await _financeService.GetSellerPayoutsAsync(sellerId, cancellationToken);
        return result.Success ? Ok(result) : ToFailureResult(result);
    }

    [Authorize(Roles = "SuperAdmin,Seller")]
    [HttpPost("sellers/{sellerId:guid}/payouts/request")]
    public async Task<IActionResult> RequestSellerPayout(Guid sellerId, CancellationToken cancellationToken)
    {
        if (User.IsInRole("Seller") && !await IsCurrentSellerAsync(sellerId, cancellationToken))
        {
            return Forbid();
        }

        var result = await _financeService.RequestSellerPayoutAsync(sellerId, cancellationToken);
        return result.Success ? Ok(result) : ToFailureResult(result);
    }

    [Authorize(Roles = "SuperAdmin,FinanceManager,PaymentTeam")]
    [HttpPost("payouts/{payoutId:guid}/mark-paid")]
    public async Task<IActionResult> MarkPayoutPaid(Guid payoutId, CancellationToken cancellationToken)
    {
        var result = await _financeService.MarkPayoutPaidAsync(GetCurrentUserId(), payoutId, cancellationToken);
        return result.Success ? Ok(result) : ToFailureResult(result);
    }

    [Authorize(Roles = "SuperAdmin,Admin,FinanceManager,PaymentTeam,SupportManager")]
    [HttpPost("refunds/create-for-return")]
    public async Task<IActionResult> CreateRefundForReturn(
        CreateRefundForReturnRequest request,
        CancellationToken cancellationToken)
    {
        var bearerToken = GetBearerToken();
        if (bearerToken is null)
        {
            return Unauthorized();
        }

        var result = await _financeService.CreateRefundForReturnAsync(
            GetCurrentUserId(),
            request,
            bearerToken,
            cancellationToken);
        return result.Success ? Ok(result) : ToFailureResult(result);
    }

    [Authorize(Roles = "SuperAdmin,Admin,FinanceManager,PaymentTeam")]
    [HttpGet("sellers/{sellerId:guid}/transactions")]
    public async Task<IActionResult> GetSellerTransactions(Guid sellerId, CancellationToken cancellationToken)
    {
        var result = await _financeService.GetSellerTransactionsAsync(sellerId, cancellationToken);
        return result.Success ? Ok(result) : ToFailureResult(result);
    }

    [Authorize(Roles = "SuperAdmin,Admin,FinanceManager,PaymentTeam")]
    [HttpGet("admin/summary")]
    public async Task<IActionResult> GetAdminSummary(CancellationToken cancellationToken)
    {
        var result = await _financeService.GetAdminSummaryAsync(cancellationToken);
        return Ok(result);
    }

    [Authorize(Roles = "SuperAdmin,Admin,FinanceManager,PaymentTeam")]
    [HttpGet("admin/seller-balances")]
    public async Task<IActionResult> GetAdminSellerBalances(CancellationToken cancellationToken)
    {
        var result = await _financeService.GetAdminSellerBalancesAsync(cancellationToken);
        return Ok(result);
    }

    [Authorize(Roles = "SuperAdmin,Admin,FinanceManager,PaymentTeam")]
    [HttpGet("admin/commissions")]
    public async Task<IActionResult> GetAdminCommissions(CancellationToken cancellationToken)
    {
        var result = await _financeService.GetAdminCommissionsAsync(cancellationToken);
        return Ok(result);
    }

    [Authorize(Roles = "SuperAdmin,Admin,FinanceManager,PaymentTeam")]
    [HttpGet("admin/payouts")]
    public async Task<IActionResult> GetAdminPayouts(CancellationToken cancellationToken)
    {
        var result = await _financeService.GetAdminPayoutsAsync(cancellationToken);
        return Ok(result);
    }

    [Authorize(Roles = "SuperAdmin,Seller")]
    [HttpGet("me/earnings")]
    public async Task<IActionResult> GetMyEarnings(CancellationToken cancellationToken)
    {
        var seller = await GetCurrentSellerAsync(cancellationToken);
        if (seller is null)
        {
            return Unauthorized();
        }

        var result = await _financeService.GetSellerEarningsAsync(seller.Id, cancellationToken);
        return result.Success ? Ok(result) : ToFailureResult(result);
    }

    [Authorize(Roles = "SuperAdmin,Seller")]
    [HttpGet("me/balance")]
    public async Task<IActionResult> GetMyBalance(CancellationToken cancellationToken)
    {
        var seller = await GetCurrentSellerAsync(cancellationToken);
        if (seller is null)
        {
            return Unauthorized();
        }

        var result = await _financeService.GetSellerBalanceAsync(seller.Id, cancellationToken);
        return result.Success ? Ok(result) : ToFailureResult(result);
    }

    [Authorize(Roles = "SuperAdmin,Seller")]
    [HttpGet("me/payouts")]
    public async Task<IActionResult> GetMyPayouts(CancellationToken cancellationToken)
    {
        var seller = await GetCurrentSellerAsync(cancellationToken);
        if (seller is null)
        {
            return Unauthorized();
        }

        var result = await _financeService.GetSellerPayoutsAsync(seller.Id, cancellationToken);
        return result.Success ? Ok(result) : ToFailureResult(result);
    }

    [Authorize(Roles = "SuperAdmin,Seller")]
    [HttpGet("me/transactions")]
    public async Task<IActionResult> GetMyTransactions(CancellationToken cancellationToken)
    {
        var seller = await GetCurrentSellerAsync(cancellationToken);
        if (seller is null)
        {
            return Unauthorized();
        }

        var result = await _financeService.GetSellerTransactionsAsync(seller.Id, cancellationToken);
        return result.Success ? Ok(result) : ToFailureResult(result);
    }

    private string? GetBearerToken()
    {
        var authorization = Request.Headers.Authorization.ToString();
        return authorization.StartsWith("Bearer ", StringComparison.OrdinalIgnoreCase)
            ? authorization["Bearer ".Length..].Trim()
            : null;
    }

    private Guid? GetCurrentUserId()
    {
        var userIdValue = User.FindFirstValue(ClaimTypes.NameIdentifier)
            ?? User.FindFirst(JwtRegisteredClaimNames.Sub)?.Value;

        return Guid.TryParse(userIdValue, out var userId) ? userId : null;
    }

    private async Task<bool> IsCurrentSellerAsync(Guid sellerId, CancellationToken cancellationToken)
    {
        var seller = await GetCurrentSellerAsync(cancellationToken);
        return seller?.Id == sellerId;
    }

    private async Task<SellerProfileSnapshot?> GetCurrentSellerAsync(CancellationToken cancellationToken)
    {
        var bearerToken = GetBearerToken();
        return string.IsNullOrWhiteSpace(bearerToken)
            ? null
            : await _sellerProfileGateway.GetMineAsync(bearerToken, cancellationToken);
    }

    private IActionResult ToFailureResult<T>(Result<T> result)
    {
        return result.Error.Code switch
        {
            "NotFound" => NotFound(result),
            "Conflict" => Conflict(result),
            "Unauthorized" => Unauthorized(result),
            _ => BadRequest(result)
        };
    }
}
