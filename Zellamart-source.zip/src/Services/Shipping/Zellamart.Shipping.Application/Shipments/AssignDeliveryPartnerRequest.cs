namespace Zellamart.Shipping.Application.Shipments;

public sealed record AssignDeliveryPartnerRequest(Guid DeliveryPartnerId);
