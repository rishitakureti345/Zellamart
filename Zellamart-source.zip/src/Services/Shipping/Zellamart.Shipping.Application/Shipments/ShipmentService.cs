using Zellamart.Shipping.Application.Abstractions;
using Zellamart.Shipping.Domain.Shipments;
using Zellamart.SharedKernel.Results;

namespace Zellamart.Shipping.Application.Shipments;

public sealed class ShipmentService : IShipmentService
{
    private readonly IShipmentRepository _repository;
    private readonly INotificationGateway _notificationGateway;

    public ShipmentService(IShipmentRepository repository, INotificationGateway notificationGateway)
    {
        _repository = repository;
        _notificationGateway = notificationGateway;
    }

    public async Task<Result<ShipmentResponse>> CreateForOrderAsync(
        Guid customerId,
        CreateShipmentForOrderRequest request,
        CancellationToken cancellationToken)
    {
        if (request.OrderId == Guid.Empty)
        {
            return Result.Fail<ShipmentResponse>(Error.Validation("Order id is required."));
        }

        if (string.IsNullOrWhiteSpace(request.ShippingAddress))
        {
            return Result.Fail<ShipmentResponse>(Error.Validation("Shipping address is required."));
        }

        var existing = await _repository.GetByOrderIdAsync(request.OrderId, cancellationToken);
        if (existing is not null)
        {
            return Result.Fail<ShipmentResponse>(Error.Conflict("Shipment already exists for this order."));
        }

        var shipment = new Shipment(
            request.OrderId,
            customerId,
            request.ShippingAddress,
            CreateTrackingNumber());

        await _repository.AddAsync(shipment, cancellationToken);
        await _repository.SaveChangesAsync(cancellationToken);
        await NotifyAsync(
            shipment.CustomerId,
            "ShipmentCreated",
            "Shipment created",
            $"Shipment {shipment.TrackingNumber} was created for your order.",
            cancellationToken);

        return Result.Ok(ToResponse(shipment));
    }

    public async Task<Result<ShipmentResponse>> GetByOrderIdAsync(
        Guid customerId,
        Guid orderId,
        CancellationToken cancellationToken)
    {
        var shipment = await _repository.GetByOrderIdAsync(orderId, cancellationToken);
        if (shipment is null || shipment.CustomerId != customerId)
        {
            return Result.Fail<ShipmentResponse>(Error.NotFound("Shipment was not found."));
        }

        return Result.Ok(ToResponse(shipment));
    }

    public async Task<Result<ShipmentResponse>> GetByOrderIdForStaffAsync(
        Guid orderId,
        CancellationToken cancellationToken)
    {
        var shipment = await _repository.GetByOrderIdAsync(orderId, cancellationToken);
        return shipment is null
            ? Result.Fail<ShipmentResponse>(Error.NotFound("Shipment was not found."))
            : Result.Ok(ToResponse(shipment));
    }

    public async Task<Result<ShipmentResponse>> GetByIdForStaffAsync(
        Guid shipmentId,
        CancellationToken cancellationToken)
    {
        var shipment = await _repository.GetByIdAsync(shipmentId, cancellationToken);
        return shipment is null
            ? Result.Fail<ShipmentResponse>(Error.NotFound("Shipment was not found."))
            : Result.Ok(ToResponse(shipment));
    }

    public async Task<Result<IReadOnlyList<ShipmentResponse>>> GetMineAsync(
        Guid customerId,
        CancellationToken cancellationToken)
    {
        var shipments = await _repository.GetByCustomerIdAsync(customerId, cancellationToken);
        return Result.Ok<IReadOnlyList<ShipmentResponse>>(shipments.Select(ToResponse).ToArray());
    }

    public async Task<Result<IReadOnlyList<ShipmentResponse>>> GetByDeliveryPartnerAsync(
        Guid deliveryPartnerId,
        CancellationToken cancellationToken)
    {
        var shipments = await _repository.GetByDeliveryPartnerIdAsync(deliveryPartnerId, cancellationToken);
        return Result.Ok<IReadOnlyList<ShipmentResponse>>(shipments.Select(ToResponse).ToArray());
    }

    public async Task<Result<IReadOnlyList<ShipmentResponse>>> GetAllForStaffAsync(CancellationToken cancellationToken)
    {
        var shipments = await _repository.GetAllAsync(cancellationToken);
        return Result.Ok<IReadOnlyList<ShipmentResponse>>(shipments.Select(ToResponse).ToArray());
    }

    public async Task<Result<IReadOnlyList<ShipmentResponse>>> GetByStatusForStaffAsync(
        ShipmentStatus status,
        CancellationToken cancellationToken)
    {
        var shipments = await _repository.GetByStatusAsync(status, cancellationToken);
        return Result.Ok<IReadOnlyList<ShipmentResponse>>(shipments.Select(ToResponse).ToArray());
    }

    public Task<Result<ShipmentResponse>> PackAsync(Guid shipmentId, Guid changedByUserId, CancellationToken cancellationToken)
    {
        return ChangeAsync(
            shipmentId,
            shipment => shipment.Pack(changedByUserId),
            "ShipmentPacked",
            "Shipment packed",
            "Your shipment has been packed.",
            cancellationToken);
    }

    public Task<Result<ShipmentResponse>> ShipAsync(Guid shipmentId, Guid changedByUserId, CancellationToken cancellationToken)
    {
        return ChangeAsync(
            shipmentId,
            shipment => shipment.Ship(changedByUserId),
            "ShipmentShipped",
            "Shipment shipped",
            "Your shipment has been shipped.",
            cancellationToken);
    }

    public Task<Result<ShipmentResponse>> AssignPartnerAsync(
        Guid shipmentId,
        Guid changedByUserId,
        AssignDeliveryPartnerRequest request,
        CancellationToken cancellationToken)
    {
        return ChangeAsync(
            shipmentId,
            shipment => shipment.AssignPartner(request.DeliveryPartnerId, changedByUserId),
            "DeliveryPartnerAssigned",
            "Delivery partner assigned",
            "A delivery partner has been assigned to your shipment.",
            cancellationToken);
    }

    public Task<Result<ShipmentResponse>> MarkOutForDeliveryAsync(
        Guid shipmentId,
        Guid changedByUserId,
        CancellationToken cancellationToken)
    {
        return ChangeAsync(
            shipmentId,
            shipment => shipment.MarkOutForDelivery(changedByUserId),
            "ShipmentOutForDelivery",
            "Out for delivery",
            "Your shipment is out for delivery.",
            cancellationToken);
    }

    public Task<Result<ShipmentResponse>> MarkDeliveredAsync(
        Guid shipmentId,
        Guid changedByUserId,
        CancellationToken cancellationToken)
    {
        return ChangeAsync(
            shipmentId,
            shipment => shipment.MarkDelivered(changedByUserId),
            "ShipmentDelivered",
            "Shipment delivered",
            "Your shipment has been delivered.",
            cancellationToken);
    }

    public Task<Result<ShipmentResponse>> MarkDeliveryFailedAsync(
        Guid shipmentId,
        Guid changedByUserId,
        DeliveryFailedRequest request,
        CancellationToken cancellationToken)
    {
        return ChangeAsync(
            shipmentId,
            shipment => shipment.MarkDeliveryFailed(request.Reason ?? "Delivery failed.", changedByUserId),
            "DeliveryFailed",
            "Delivery failed",
            request.Reason ?? "Delivery failed.",
            cancellationToken);
    }

    public Task<Result<ShipmentResponse>> CancelAsync(
        Guid shipmentId,
        Guid changedByUserId,
        CancelShipmentRequest request,
        CancellationToken cancellationToken)
    {
        return ChangeAsync(
            shipmentId,
            shipment => shipment.Cancel(request.Reason ?? "Shipment cancelled.", changedByUserId),
            "ShipmentCancelled",
            "Shipment cancelled",
            request.Reason ?? "Shipment cancelled.",
            cancellationToken);
    }

    private async Task<Result<ShipmentResponse>> ChangeAsync(
        Guid shipmentId,
        Action<Shipment> change,
        string? notificationType,
        string? notificationTitle,
        string? notificationMessage,
        CancellationToken cancellationToken)
    {
        var shipment = await _repository.GetByIdAsync(shipmentId, cancellationToken);
        if (shipment is null)
        {
            return Result.Fail<ShipmentResponse>(Error.NotFound("Shipment was not found."));
        }

        try
        {
            change(shipment);
        }
        catch (InvalidOperationException ex)
        {
            return Result.Fail<ShipmentResponse>(Error.Validation(ex.Message));
        }

        await _repository.SaveChangesAsync(cancellationToken);
        if (notificationType is not null && notificationTitle is not null && notificationMessage is not null)
        {
            await NotifyAsync(
                shipment.CustomerId,
                notificationType,
                notificationTitle,
                notificationMessage,
                cancellationToken);
        }

        return Result.Ok(ToResponse(shipment));
    }

    private Task NotifyAsync(
        Guid customerId,
        string type,
        string title,
        string message,
        CancellationToken cancellationToken)
    {
        return _notificationGateway.CreateAsync(customerId, type, title, message, cancellationToken);
    }

    private static string CreateTrackingNumber()
    {
        return $"ZLM-{DateTimeOffset.UtcNow:yyyyMMddHHmmss}-{Random.Shared.Next(1000, 9999)}";
    }

    private static ShipmentResponse ToResponse(Shipment shipment)
    {
        return new ShipmentResponse(
            shipment.Id,
            shipment.OrderId,
            shipment.CustomerId,
            shipment.DeliveryPartnerId,
            shipment.Status,
            shipment.ShippingAddress,
            shipment.TrackingNumber,
            shipment.StatusHistory.Select(history => new ShipmentStatusHistoryResponse(
                history.Id,
                history.Status,
                history.Note,
                history.ChangedByUserId,
                history.ChangedAtUtc)).ToArray(),
            shipment.CreatedAtUtc);
    }
}
