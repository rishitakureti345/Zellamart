using Zellamart.Shipping.Domain.Shipments;

namespace Zellamart.Shipping.Application.Shipments;

public sealed record ShipmentResponse(
    Guid Id,
    Guid OrderId,
    Guid CustomerId,
    Guid? DeliveryPartnerId,
    ShipmentStatus Status,
    string ShippingAddress,
    string TrackingNumber,
    IReadOnlyList<ShipmentStatusHistoryResponse> StatusHistory,
    DateTimeOffset CreatedAtUtc);

public sealed record ShipmentStatusHistoryResponse(
    Guid Id,
    ShipmentStatus Status,
    string Note,
    Guid? ChangedByUserId,
    DateTimeOffset ChangedAtUtc);
