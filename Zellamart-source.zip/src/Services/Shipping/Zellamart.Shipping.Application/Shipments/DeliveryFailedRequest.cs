namespace Zellamart.Shipping.Application.Shipments;

public sealed record DeliveryFailedRequest(string? Reason);
