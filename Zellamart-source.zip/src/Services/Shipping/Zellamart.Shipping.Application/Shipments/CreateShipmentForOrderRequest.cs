namespace Zellamart.Shipping.Application.Shipments;

public sealed record CreateShipmentForOrderRequest(
    Guid OrderId,
    string ShippingAddress);
