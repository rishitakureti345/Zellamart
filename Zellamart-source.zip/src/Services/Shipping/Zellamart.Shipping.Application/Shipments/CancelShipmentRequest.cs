namespace Zellamart.Shipping.Application.Shipments;

public sealed record CancelShipmentRequest(string? Reason);
