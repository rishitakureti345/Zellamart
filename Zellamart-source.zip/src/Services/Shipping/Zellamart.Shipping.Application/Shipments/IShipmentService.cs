using Zellamart.SharedKernel.Results;
using Zellamart.Shipping.Domain.Shipments;

namespace Zellamart.Shipping.Application.Shipments;

public interface IShipmentService
{
    Task<Result<ShipmentResponse>> CreateForOrderAsync(
        Guid customerId,
        CreateShipmentForOrderRequest request,
        CancellationToken cancellationToken);

    Task<Result<ShipmentResponse>> GetByOrderIdAsync(
        Guid customerId,
        Guid orderId,
        CancellationToken cancellationToken);

    Task<Result<ShipmentResponse>> GetByOrderIdForStaffAsync(
        Guid orderId,
        CancellationToken cancellationToken);

    Task<Result<ShipmentResponse>> GetByIdForStaffAsync(
        Guid shipmentId,
        CancellationToken cancellationToken);

    Task<Result<IReadOnlyList<ShipmentResponse>>> GetMineAsync(
        Guid customerId,
        CancellationToken cancellationToken);

    Task<Result<IReadOnlyList<ShipmentResponse>>> GetByDeliveryPartnerAsync(
        Guid deliveryPartnerId,
        CancellationToken cancellationToken);

    Task<Result<IReadOnlyList<ShipmentResponse>>> GetAllForStaffAsync(CancellationToken cancellationToken);

    Task<Result<IReadOnlyList<ShipmentResponse>>> GetByStatusForStaffAsync(
        ShipmentStatus status,
        CancellationToken cancellationToken);

    Task<Result<ShipmentResponse>> PackAsync(Guid shipmentId, Guid changedByUserId, CancellationToken cancellationToken);

    Task<Result<ShipmentResponse>> ShipAsync(Guid shipmentId, Guid changedByUserId, CancellationToken cancellationToken);

    Task<Result<ShipmentResponse>> AssignPartnerAsync(
        Guid shipmentId,
        Guid changedByUserId,
        AssignDeliveryPartnerRequest request,
        CancellationToken cancellationToken);

    Task<Result<ShipmentResponse>> MarkOutForDeliveryAsync(
        Guid shipmentId,
        Guid changedByUserId,
        CancellationToken cancellationToken);

    Task<Result<ShipmentResponse>> MarkDeliveredAsync(
        Guid shipmentId,
        Guid changedByUserId,
        CancellationToken cancellationToken);

    Task<Result<ShipmentResponse>> MarkDeliveryFailedAsync(
        Guid shipmentId,
        Guid changedByUserId,
        DeliveryFailedRequest request,
        CancellationToken cancellationToken);

    Task<Result<ShipmentResponse>> CancelAsync(
        Guid shipmentId,
        Guid changedByUserId,
        CancelShipmentRequest request,
        CancellationToken cancellationToken);
}
