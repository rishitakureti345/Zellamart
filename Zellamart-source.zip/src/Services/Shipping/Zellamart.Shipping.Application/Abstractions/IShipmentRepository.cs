using Zellamart.Shipping.Domain.Shipments;

namespace Zellamart.Shipping.Application.Abstractions;

public interface IShipmentRepository
{
    Task<Shipment?> GetByIdAsync(Guid shipmentId, CancellationToken cancellationToken);

    Task<Shipment?> GetByOrderIdAsync(Guid orderId, CancellationToken cancellationToken);

    Task<IReadOnlyList<Shipment>> GetByCustomerIdAsync(Guid customerId, CancellationToken cancellationToken);

    Task<IReadOnlyList<Shipment>> GetByDeliveryPartnerIdAsync(Guid deliveryPartnerId, CancellationToken cancellationToken);

    Task<IReadOnlyList<Shipment>> GetAllAsync(CancellationToken cancellationToken);

    Task<IReadOnlyList<Shipment>> GetByStatusAsync(ShipmentStatus status, CancellationToken cancellationToken);

    Task AddAsync(Shipment shipment, CancellationToken cancellationToken);

    Task SaveChangesAsync(CancellationToken cancellationToken);
}
