namespace Zellamart.Shipping.Application.Abstractions;

public interface INotificationGateway
{
    Task CreateAsync(
        Guid userId,
        string type,
        string title,
        string message,
        CancellationToken cancellationToken);
}
