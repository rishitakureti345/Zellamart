using Microsoft.Extensions.DependencyInjection;
using Zellamart.Shipping.Application.Shipments;

namespace Zellamart.Shipping.Application;

public static class DependencyInjection
{
    public static IServiceCollection AddShippingApplication(this IServiceCollection services)
    {
        services.AddScoped<IShipmentService, ShipmentService>();

        return services;
    }
}
