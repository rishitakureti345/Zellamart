using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Zellamart.Shipping.Application.Shipments;
using Zellamart.Shipping.Domain.Shipments;
using Zellamart.SharedKernel.Results;

namespace Zellamart.Shipping.Api.Controllers;

[ApiController]
[Authorize]
[Route("api/shipping")]
public sealed class ShippingController : ControllerBase
{
    private readonly IShipmentService _shipmentService;

    public ShippingController(IShipmentService shipmentService)
    {
        _shipmentService = shipmentService;
    }

    [Authorize(Roles = "SuperAdmin,Admin,Customer,OrderManager")]
    [HttpPost("create-for-order")]
    public async Task<IActionResult> CreateForOrder(
        CreateShipmentForOrderRequest request,
        CancellationToken cancellationToken)
    {
        var customerId = GetCurrentUserId();
        if (customerId is null)
        {
            return Unauthorized();
        }

        var result = await _shipmentService.CreateForOrderAsync(customerId.Value, request, cancellationToken);
        return result.Success ? Ok(result) : ToFailureResult(result);
    }

    [Authorize(Roles = "SuperAdmin,Admin,Customer,OrderManager,WarehouseManager,DeliveryManager,DeliveryPartner")]
    [HttpGet("order/{orderId:guid}")]
    public async Task<IActionResult> GetByOrder(Guid orderId, CancellationToken cancellationToken)
    {
        var customerId = GetCurrentUserId();
        if (customerId is null)
        {
            return Unauthorized();
        }

        var result = await _shipmentService.GetByOrderIdAsync(customerId.Value, orderId, cancellationToken);
        return result.Success ? Ok(result) : ToFailureResult(result);
    }

    [Authorize(Roles = "SuperAdmin,Admin,OrderManager,WarehouseManager,DeliveryManager,DeliveryPartner,SupportManager,SupportAgent")]
    [HttpGet("admin/order/{orderId:guid}")]
    public async Task<IActionResult> GetByOrderForStaff(Guid orderId, CancellationToken cancellationToken)
    {
        var userId = GetCurrentUserId();
        if (userId is null)
        {
            return Unauthorized();
        }

        var result = await _shipmentService.GetByOrderIdForStaffAsync(orderId, cancellationToken);
        if (result.Success
            && User.IsInRole("DeliveryPartner")
            && !CanManageAllShipments()
            && result.Value?.DeliveryPartnerId != userId.Value)
        {
            return Forbid();
        }

        return result.Success ? Ok(result) : ToFailureResult(result);
    }

    [Authorize(Roles = "SuperAdmin,Admin,Customer")]
    [HttpGet("me")]
    public async Task<IActionResult> GetMine(CancellationToken cancellationToken)
    {
        var customerId = GetCurrentUserId();
        if (customerId is null)
        {
            return Unauthorized();
        }

        var result = await _shipmentService.GetMineAsync(customerId.Value, cancellationToken);
        return Ok(result);
    }

    [Authorize(Roles = "SuperAdmin,Admin,WarehouseManager,DeliveryManager,DeliveryPartner,OrderManager")]
    [HttpGet("admin/all")]
    public async Task<IActionResult> GetAllForStaff(CancellationToken cancellationToken)
    {
        var userId = GetCurrentUserId();
        if (userId is null)
        {
            return Unauthorized();
        }

        var result = User.IsInRole("DeliveryPartner") && !CanManageAllShipments()
            ? await _shipmentService.GetByDeliveryPartnerAsync(userId.Value, cancellationToken)
            : await _shipmentService.GetAllForStaffAsync(cancellationToken);
        return Ok(result);
    }

    [Authorize(Roles = "SuperAdmin,Admin,WarehouseManager,DeliveryManager,DeliveryPartner,OrderManager")]
    [HttpGet("admin/status/{status}")]
    public async Task<IActionResult> GetByStatusForStaff(
        ShipmentStatus status,
        CancellationToken cancellationToken)
    {
        var userId = GetCurrentUserId();
        if (userId is null)
        {
            return Unauthorized();
        }

        if (User.IsInRole("DeliveryPartner") && !CanManageAllShipments())
        {
            var assignedResult = await _shipmentService.GetByDeliveryPartnerAsync(userId.Value, cancellationToken);
            if (!assignedResult.Success)
            {
                return ToFailureResult(assignedResult);
            }

            var assignedByStatus = assignedResult.Value?
                .Where(shipment => shipment.Status == status)
                .ToArray() ?? Array.Empty<ShipmentResponse>();

            return Ok(Result.Ok<IReadOnlyList<ShipmentResponse>>(assignedByStatus));
        }

        var result = await _shipmentService.GetByStatusForStaffAsync(status, cancellationToken);
        return Ok(result);
    }

    [Authorize(Roles = "SuperAdmin,Admin,WarehouseManager,InventoryStaff")]
    [HttpPost("{shipmentId:guid}/pack")]
    public async Task<IActionResult> Pack(Guid shipmentId, CancellationToken cancellationToken)
    {
        var userId = GetCurrentUserId();
        if (userId is null)
        {
            return Unauthorized();
        }

        var result = await _shipmentService.PackAsync(shipmentId, userId.Value, cancellationToken);
        return result.Success ? Ok(result) : ToFailureResult(result);
    }

    [Authorize(Roles = "SuperAdmin,Admin,WarehouseManager,DeliveryManager")]
    [HttpPost("{shipmentId:guid}/ship")]
    public async Task<IActionResult> Ship(Guid shipmentId, CancellationToken cancellationToken)
    {
        var userId = GetCurrentUserId();
        if (userId is null)
        {
            return Unauthorized();
        }

        var result = await _shipmentService.ShipAsync(shipmentId, userId.Value, cancellationToken);
        return result.Success ? Ok(result) : ToFailureResult(result);
    }

    [Authorize(Roles = "SuperAdmin,Admin,DeliveryManager")]
    [HttpPost("{shipmentId:guid}/assign-partner")]
    public async Task<IActionResult> AssignPartner(
        Guid shipmentId,
        AssignDeliveryPartnerRequest request,
        CancellationToken cancellationToken)
    {
        var userId = GetCurrentUserId();
        if (userId is null)
        {
            return Unauthorized();
        }

        var result = await _shipmentService.AssignPartnerAsync(shipmentId, userId.Value, request, cancellationToken);
        return result.Success ? Ok(result) : ToFailureResult(result);
    }

    [Authorize(Roles = "SuperAdmin,Admin,DeliveryManager,DeliveryPartner")]
    [HttpPost("{shipmentId:guid}/out-for-delivery")]
    public async Task<IActionResult> MarkOutForDelivery(Guid shipmentId, CancellationToken cancellationToken)
    {
        var userId = GetCurrentUserId();
        if (userId is null)
        {
            return Unauthorized();
        }

        if (User.IsInRole("DeliveryPartner") && !CanManageAllShipments() && !await CanDeliveryPartnerAccessShipmentAsync(shipmentId, userId.Value, cancellationToken))
        {
            return Forbid();
        }

        var result = await _shipmentService.MarkOutForDeliveryAsync(shipmentId, userId.Value, cancellationToken);
        return result.Success ? Ok(result) : ToFailureResult(result);
    }

    [Authorize(Roles = "SuperAdmin,Admin,DeliveryManager,DeliveryPartner")]
    [HttpPost("{shipmentId:guid}/delivered")]
    public async Task<IActionResult> MarkDelivered(Guid shipmentId, CancellationToken cancellationToken)
    {
        var userId = GetCurrentUserId();
        if (userId is null)
        {
            return Unauthorized();
        }

        if (User.IsInRole("DeliveryPartner") && !CanManageAllShipments() && !await CanDeliveryPartnerAccessShipmentAsync(shipmentId, userId.Value, cancellationToken))
        {
            return Forbid();
        }

        var result = await _shipmentService.MarkDeliveredAsync(shipmentId, userId.Value, cancellationToken);
        return result.Success ? Ok(result) : ToFailureResult(result);
    }

    [Authorize(Roles = "SuperAdmin,Admin,DeliveryManager,DeliveryPartner")]
    [HttpPost("{shipmentId:guid}/delivery-failed")]
    public async Task<IActionResult> MarkDeliveryFailed(
        Guid shipmentId,
        DeliveryFailedRequest request,
        CancellationToken cancellationToken)
    {
        var userId = GetCurrentUserId();
        if (userId is null)
        {
            return Unauthorized();
        }

        if (User.IsInRole("DeliveryPartner") && !CanManageAllShipments() && !await CanDeliveryPartnerAccessShipmentAsync(shipmentId, userId.Value, cancellationToken))
        {
            return Forbid();
        }

        var result = await _shipmentService.MarkDeliveryFailedAsync(shipmentId, userId.Value, request, cancellationToken);
        return result.Success ? Ok(result) : ToFailureResult(result);
    }

    [Authorize(Roles = "SuperAdmin,Admin,Customer,OrderManager")]
    [HttpPost("{shipmentId:guid}/cancel")]
    public async Task<IActionResult> Cancel(
        Guid shipmentId,
        CancelShipmentRequest request,
        CancellationToken cancellationToken)
    {
        var userId = GetCurrentUserId();
        if (userId is null)
        {
            return Unauthorized();
        }

        var result = await _shipmentService.CancelAsync(shipmentId, userId.Value, request, cancellationToken);
        return result.Success ? Ok(result) : ToFailureResult(result);
    }

    private Guid? GetCurrentUserId()
    {
        var userIdValue = User.FindFirstValue(ClaimTypes.NameIdentifier)
            ?? User.FindFirst(JwtRegisteredClaimNames.Sub)?.Value;

        return Guid.TryParse(userIdValue, out var userId) ? userId : null;
    }

    private bool CanManageAllShipments()
    {
        return User.IsInRole("SuperAdmin")
            || User.IsInRole("Admin")
            || User.IsInRole("WarehouseManager")
            || User.IsInRole("DeliveryManager")
            || User.IsInRole("OrderManager");
    }

    private async Task<bool> CanDeliveryPartnerAccessShipmentAsync(
        Guid shipmentId,
        Guid deliveryPartnerId,
        CancellationToken cancellationToken)
    {
        var result = await _shipmentService.GetByIdForStaffAsync(shipmentId, cancellationToken);
        return result.Success && result.Value?.DeliveryPartnerId == deliveryPartnerId;
    }

    private IActionResult ToFailureResult<T>(Result<T> result)
    {
        return result.Error.Code switch
        {
            "NotFound" => NotFound(result),
            "Conflict" => Conflict(result),
            _ => BadRequest(result)
        };
    }
}
