using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Zellamart.Shipping.Application.Abstractions;
using Zellamart.Shipping.Infrastructure.Persistence;
using Zellamart.Shipping.Infrastructure.Services;

namespace Zellamart.Shipping.Infrastructure;

public static class DependencyInjection
{
    public static IServiceCollection AddShippingInfrastructure(
        this IServiceCollection services,
        IConfiguration configuration)
    {
        services.AddDbContext<ShippingDbContext>(options =>
            options.UseNpgsql(configuration.GetConnectionString("Shipping")));

        services.AddScoped<IShipmentRepository, ShipmentRepository>();
        services.AddHttpClient<INotificationGateway, NotificationGateway>(client =>
        {
            client.BaseAddress = new Uri(configuration["Services:Notifications"] ?? "http://localhost:5108");
        });

        return services;
    }
}
