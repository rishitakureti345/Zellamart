using Microsoft.Extensions.Configuration;
using System.Net.Http.Json;
using Zellamart.Shipping.Application.Abstractions;

namespace Zellamart.Shipping.Infrastructure.Services;

public sealed class NotificationGateway : INotificationGateway
{
    private const string InternalServiceKeyHeader = "X-Internal-Service-Key";

    private readonly HttpClient _httpClient;
    private readonly string? _internalServiceKey;

    public NotificationGateway(HttpClient httpClient, IConfiguration configuration)
    {
        _httpClient = httpClient;
        _internalServiceKey = configuration["InternalService:NotificationKey"];
    }

    public async Task CreateAsync(
        Guid userId,
        string type,
        string title,
        string message,
        CancellationToken cancellationToken)
    {
        var request = new CreateNotificationRequest(userId, type, title, message);
        try
        {
            using var messageRequest = new HttpRequestMessage(HttpMethod.Post, "/api/notifications");
            if (!string.IsNullOrWhiteSpace(_internalServiceKey))
            {
                messageRequest.Headers.Add(InternalServiceKeyHeader, _internalServiceKey);
            }

            messageRequest.Content = JsonContent.Create(request);
            using var _ = await _httpClient.SendAsync(messageRequest, cancellationToken);
        }
        catch (HttpRequestException)
        {
            // V1 notifications should not block shipping operations.
        }
    }

    private sealed record CreateNotificationRequest(
        Guid UserId,
        string Type,
        string Title,
        string Message);
}
