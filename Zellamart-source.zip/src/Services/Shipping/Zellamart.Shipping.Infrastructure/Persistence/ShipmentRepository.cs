using Microsoft.EntityFrameworkCore;
using Zellamart.Shipping.Application.Abstractions;
using Zellamart.Shipping.Domain.Shipments;

namespace Zellamart.Shipping.Infrastructure.Persistence;

public sealed class ShipmentRepository : IShipmentRepository
{
    private readonly ShippingDbContext _dbContext;

    public ShipmentRepository(ShippingDbContext dbContext)
    {
        _dbContext = dbContext;
    }

    public Task<Shipment?> GetByIdAsync(Guid shipmentId, CancellationToken cancellationToken)
    {
        return ShipmentQuery().FirstOrDefaultAsync(shipment => shipment.Id == shipmentId, cancellationToken);
    }

    public Task<Shipment?> GetByOrderIdAsync(Guid orderId, CancellationToken cancellationToken)
    {
        return ShipmentQuery().FirstOrDefaultAsync(shipment => shipment.OrderId == orderId, cancellationToken);
    }

    public async Task<IReadOnlyList<Shipment>> GetByCustomerIdAsync(Guid customerId, CancellationToken cancellationToken)
    {
        return await ShipmentQuery()
            .Where(shipment => shipment.CustomerId == customerId)
            .OrderByDescending(shipment => shipment.CreatedAtUtc)
            .ToArrayAsync(cancellationToken);
    }

    public async Task<IReadOnlyList<Shipment>> GetByDeliveryPartnerIdAsync(
        Guid deliveryPartnerId,
        CancellationToken cancellationToken)
    {
        return await ShipmentQuery()
            .Where(shipment => shipment.DeliveryPartnerId == deliveryPartnerId)
            .OrderByDescending(shipment => shipment.CreatedAtUtc)
            .ToArrayAsync(cancellationToken);
    }

    public async Task<IReadOnlyList<Shipment>> GetAllAsync(CancellationToken cancellationToken)
    {
        return await ShipmentQuery()
            .OrderByDescending(shipment => shipment.CreatedAtUtc)
            .ToArrayAsync(cancellationToken);
    }

    public async Task<IReadOnlyList<Shipment>> GetByStatusAsync(
        ShipmentStatus status,
        CancellationToken cancellationToken)
    {
        return await ShipmentQuery()
            .Where(shipment => shipment.Status == status)
            .OrderByDescending(shipment => shipment.CreatedAtUtc)
            .ToArrayAsync(cancellationToken);
    }

    public async Task AddAsync(Shipment shipment, CancellationToken cancellationToken)
    {
        await _dbContext.Shipments.AddAsync(shipment, cancellationToken);
    }

    public Task SaveChangesAsync(CancellationToken cancellationToken)
    {
        return _dbContext.SaveChangesAsync(cancellationToken);
    }

    private IQueryable<Shipment> ShipmentQuery()
    {
        return _dbContext.Shipments.Include(shipment => shipment.StatusHistory);
    }
}
