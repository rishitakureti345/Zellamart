using Microsoft.EntityFrameworkCore;
using Zellamart.Shipping.Domain.Shipments;

namespace Zellamart.Shipping.Infrastructure.Persistence;

public sealed class ShippingDbContext : DbContext
{
    public ShippingDbContext(DbContextOptions<ShippingDbContext> options)
        : base(options)
    {
    }

    public DbSet<Shipment> Shipments => Set<Shipment>();

    public DbSet<ShipmentStatusHistory> ShipmentStatusHistory => Set<ShipmentStatusHistory>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Shipment>(builder =>
        {
            builder.ToTable("shipments");
            builder.HasKey(shipment => shipment.Id);
            builder.Property(shipment => shipment.Id).ValueGeneratedNever();
            builder.Property(shipment => shipment.Status).HasConversion<string>().HasMaxLength(40).IsRequired();
            builder.Property(shipment => shipment.ShippingAddress).HasMaxLength(800).IsRequired();
            builder.Property(shipment => shipment.TrackingNumber).HasMaxLength(80).IsRequired();
            builder.HasIndex(shipment => shipment.OrderId).IsUnique();
            builder.HasIndex(shipment => shipment.CustomerId);
            builder.HasIndex(shipment => shipment.DeliveryPartnerId);
            builder.HasIndex(shipment => shipment.Status);
            builder.HasIndex(shipment => shipment.TrackingNumber).IsUnique();
            builder.Navigation(shipment => shipment.StatusHistory).UsePropertyAccessMode(PropertyAccessMode.Field);
        });

        modelBuilder.Entity<ShipmentStatusHistory>(builder =>
        {
            builder.ToTable("shipment_status_history");
            builder.HasKey(history => history.Id);
            builder.Property(history => history.Id).ValueGeneratedNever();
            builder.Property(history => history.Status).HasConversion<string>().HasMaxLength(40).IsRequired();
            builder.Property(history => history.Note).HasMaxLength(600).IsRequired();
            builder.HasOne(history => history.Shipment)
                .WithMany(shipment => shipment.StatusHistory)
                .HasForeignKey(history => history.ShipmentId);
            builder.HasIndex(history => history.ShipmentId);
        });
    }
}
