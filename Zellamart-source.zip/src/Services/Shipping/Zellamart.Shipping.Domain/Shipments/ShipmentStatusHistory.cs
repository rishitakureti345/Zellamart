using Zellamart.SharedKernel.Entities;

namespace Zellamart.Shipping.Domain.Shipments;

public sealed class ShipmentStatusHistory : BaseEntity
{
    private ShipmentStatusHistory()
    {
    }

    public ShipmentStatusHistory(Guid shipmentId, ShipmentStatus status, string note, Guid? changedByUserId)
    {
        ShipmentId = shipmentId;
        Status = status;
        Note = note.Trim();
        ChangedByUserId = changedByUserId;
        ChangedAtUtc = DateTimeOffset.UtcNow;
    }

    public Guid ShipmentId { get; private set; }

    public ShipmentStatus Status { get; private set; }

    public string Note { get; private set; } = string.Empty;

    public Guid? ChangedByUserId { get; private set; }

    public DateTimeOffset ChangedAtUtc { get; private set; }

    public Shipment Shipment { get; private set; } = null!;
}
