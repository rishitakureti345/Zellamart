using Zellamart.SharedKernel.Entities;

namespace Zellamart.Shipping.Domain.Shipments;

public sealed class Shipment : AuditableEntity
{
    private readonly List<ShipmentStatusHistory> _statusHistory = [];

    private Shipment()
    {
    }

    public Shipment(Guid orderId, Guid customerId, string shippingAddress, string trackingNumber)
    {
        if (orderId == Guid.Empty)
        {
            throw new InvalidOperationException("Order id is required.");
        }

        if (customerId == Guid.Empty)
        {
            throw new InvalidOperationException("Customer id is required.");
        }

        OrderId = orderId;
        CustomerId = customerId;
        ShippingAddress = shippingAddress.Trim();
        TrackingNumber = trackingNumber.Trim();
        Status = ShipmentStatus.PendingPacking;

        AddStatusHistory(ShipmentStatus.PendingPacking, "Shipment created and waiting for packing.", null);
    }

    public Guid OrderId { get; private set; }

    public Guid CustomerId { get; private set; }

    public Guid? DeliveryPartnerId { get; private set; }

    public ShipmentStatus Status { get; private set; }

    public string ShippingAddress { get; private set; } = string.Empty;

    public string TrackingNumber { get; private set; } = string.Empty;

    public IReadOnlyCollection<ShipmentStatusHistory> StatusHistory => _statusHistory;

    public void Pack(Guid? changedByUserId)
    {
        EnsureStatus(ShipmentStatus.PendingPacking, "Only pending packing shipments can be packed.");
        ChangeStatus(ShipmentStatus.Packed, "Shipment packed.", changedByUserId);
    }

    public void Ship(Guid? changedByUserId)
    {
        EnsureStatus(ShipmentStatus.Packed, "Only packed shipments can be shipped.");
        ChangeStatus(ShipmentStatus.Shipped, "Shipment shipped.", changedByUserId);
    }

    public void AssignPartner(Guid deliveryPartnerId, Guid? changedByUserId)
    {
        if (deliveryPartnerId == Guid.Empty)
        {
            throw new InvalidOperationException("Delivery partner id is required.");
        }

        EnsureStatus(ShipmentStatus.Shipped, "Delivery partner can be assigned only after shipment is shipped.");
        DeliveryPartnerId = deliveryPartnerId;
        UpdatedAtUtc = DateTimeOffset.UtcNow;
        AddStatusHistory(Status, "Delivery partner assigned.", changedByUserId);
    }

    public void MarkOutForDelivery(Guid? changedByUserId)
    {
        EnsureStatus(ShipmentStatus.Shipped, "Only shipped shipments can move out for delivery.");
        if (DeliveryPartnerId is null)
        {
            throw new InvalidOperationException("Delivery partner must be assigned before out for delivery.");
        }

        ChangeStatus(ShipmentStatus.OutForDelivery, "Shipment is out for delivery.", changedByUserId);
    }

    public void MarkDelivered(Guid? changedByUserId)
    {
        EnsureStatus(ShipmentStatus.OutForDelivery, "Only out for delivery shipments can be delivered.");
        ChangeStatus(ShipmentStatus.Delivered, "Shipment delivered.", changedByUserId);
    }

    public void MarkDeliveryFailed(string reason, Guid? changedByUserId)
    {
        EnsureStatus(ShipmentStatus.OutForDelivery, "Only out for delivery shipments can fail delivery.");
        var note = string.IsNullOrWhiteSpace(reason) ? "Delivery failed." : reason;
        ChangeStatus(ShipmentStatus.DeliveryFailed, note, changedByUserId);
    }

    public void Cancel(string reason, Guid? changedByUserId)
    {
        if (Status != ShipmentStatus.PendingPacking)
        {
            throw new InvalidOperationException("Only pending packing shipments can be cancelled.");
        }

        var note = string.IsNullOrWhiteSpace(reason) ? "Shipment cancelled." : reason;
        ChangeStatus(ShipmentStatus.Cancelled, note, changedByUserId);
    }

    private void EnsureStatus(ShipmentStatus expectedStatus, string message)
    {
        if (Status != expectedStatus)
        {
            throw new InvalidOperationException(message);
        }
    }

    private void ChangeStatus(ShipmentStatus status, string note, Guid? changedByUserId)
    {
        Status = status;
        UpdatedAtUtc = DateTimeOffset.UtcNow;
        AddStatusHistory(status, note, changedByUserId);
    }

    private void AddStatusHistory(ShipmentStatus status, string note, Guid? changedByUserId)
    {
        _statusHistory.Add(new ShipmentStatusHistory(Id, status, note, changedByUserId));
    }
}
