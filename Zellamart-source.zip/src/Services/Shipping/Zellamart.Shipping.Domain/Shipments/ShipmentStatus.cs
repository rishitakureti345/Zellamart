namespace Zellamart.Shipping.Domain.Shipments;

public enum ShipmentStatus
{
    PendingPacking = 1,
    Packed = 2,
    Shipped = 3,
    OutForDelivery = 4,
    Delivered = 5,
    DeliveryFailed = 6,
    Cancelled = 7
}
