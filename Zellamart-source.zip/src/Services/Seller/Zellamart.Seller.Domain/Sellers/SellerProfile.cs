using Zellamart.SharedKernel.Entities;

namespace Zellamart.Seller.Domain.Sellers;

public sealed class SellerProfile : AuditableEntity
{
    private readonly List<SellerStatusHistory> _statusHistory = [];

    private SellerProfile()
    {
    }

    public SellerProfile(
        Guid userId,
        string businessName,
        string ownerName,
        string contactEmail,
        string phone,
        string address,
        string? gstNumber)
    {
        UserId = userId;
        BusinessName = businessName.Trim();
        OwnerName = ownerName.Trim();
        ContactEmail = contactEmail.Trim().ToLowerInvariant();
        Phone = phone.Trim();
        Address = address.Trim();
        GstNumber = string.IsNullOrWhiteSpace(gstNumber) ? null : gstNumber.Trim();
        Status = SellerStatus.Pending;

        _statusHistory.Add(new SellerStatusHistory(Id, SellerStatus.Pending, "Seller application submitted.", null));
    }

    public Guid UserId { get; private set; }

    public string BusinessName { get; private set; } = string.Empty;

    public string OwnerName { get; private set; } = string.Empty;

    public string ContactEmail { get; private set; } = string.Empty;

    public string Phone { get; private set; } = string.Empty;

    public string Address { get; private set; } = string.Empty;

    public string? GstNumber { get; private set; }

    public SellerStatus Status { get; private set; } = SellerStatus.Pending;

    public IReadOnlyCollection<SellerStatusHistory> StatusHistory => _statusHistory;

    public void Approve(Guid approvedByUserId)
    {
        Status = SellerStatus.Approved;
        _statusHistory.Add(new SellerStatusHistory(Id, SellerStatus.Approved, "Seller approved.", approvedByUserId));
    }

    public void Reject(Guid rejectedByUserId, string reason)
    {
        Status = SellerStatus.Rejected;
        _statusHistory.Add(new SellerStatusHistory(Id, SellerStatus.Rejected, reason, rejectedByUserId));
    }

    public void Suspend(Guid suspendedByUserId, string reason)
    {
        Status = SellerStatus.Suspended;
        _statusHistory.Add(new SellerStatusHistory(Id, SellerStatus.Suspended, reason, suspendedByUserId));
    }

    public void Reactivate(Guid reactivatedByUserId)
    {
        Status = SellerStatus.Approved;
        _statusHistory.Add(new SellerStatusHistory(Id, SellerStatus.Approved, "Seller reactivated.", reactivatedByUserId));
    }
}
