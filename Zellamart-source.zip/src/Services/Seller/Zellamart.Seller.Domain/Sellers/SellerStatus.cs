namespace Zellamart.Seller.Domain.Sellers;

public enum SellerStatus
{
    Pending = 1,
    Approved = 2,
    Rejected = 3,
    Suspended = 4
}
