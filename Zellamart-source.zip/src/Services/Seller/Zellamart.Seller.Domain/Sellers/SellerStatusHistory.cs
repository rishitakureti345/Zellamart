using Zellamart.SharedKernel.Entities;

namespace Zellamart.Seller.Domain.Sellers;

public sealed class SellerStatusHistory : BaseEntity
{
    private SellerStatusHistory()
    {
    }

    public SellerStatusHistory(Guid sellerId, SellerStatus status, string note, Guid? changedByUserId)
    {
        SellerId = sellerId;
        Status = status;
        Note = note.Trim();
        ChangedByUserId = changedByUserId;
        ChangedAtUtc = DateTimeOffset.UtcNow;
    }

    public Guid SellerId { get; private set; }

    public SellerStatus Status { get; private set; }

    public string Note { get; private set; } = string.Empty;

    public Guid? ChangedByUserId { get; private set; }

    public DateTimeOffset ChangedAtUtc { get; private set; }

    public SellerProfile Seller { get; private set; } = null!;
}
