namespace Zellamart.Seller.Application.Sellers;

public sealed record RejectSellerRequest(string Reason);
