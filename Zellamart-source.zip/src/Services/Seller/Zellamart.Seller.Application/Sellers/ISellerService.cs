using Zellamart.SharedKernel.Results;

namespace Zellamart.Seller.Application.Sellers;

public interface ISellerService
{
    Task<Result<SellerResponse>> ApplyAsync(Guid userId, ApplySellerRequest request, CancellationToken cancellationToken);

    Task<Result<SellerResponse>> GetMineAsync(Guid userId, CancellationToken cancellationToken);

    Task<Result<IReadOnlyList<SellerResponse>>> GetAllAsync(CancellationToken cancellationToken);

    Task<Result<IReadOnlyList<SellerResponse>>> GetPendingAsync(CancellationToken cancellationToken);

    Task<Result<SellerResponse>> ApproveAsync(Guid sellerId, Guid approvedByUserId, CancellationToken cancellationToken);

    Task<Result<SellerResponse>> RejectAsync(Guid sellerId, Guid rejectedByUserId, RejectSellerRequest request, CancellationToken cancellationToken);

    Task<Result<SellerResponse>> SuspendAsync(Guid sellerId, Guid suspendedByUserId, SuspendSellerRequest request, CancellationToken cancellationToken);

    Task<Result<SellerResponse>> ReactivateAsync(Guid sellerId, Guid reactivatedByUserId, CancellationToken cancellationToken);
}
