namespace Zellamart.Seller.Application.Sellers;

public sealed record SuspendSellerRequest(string Reason);
