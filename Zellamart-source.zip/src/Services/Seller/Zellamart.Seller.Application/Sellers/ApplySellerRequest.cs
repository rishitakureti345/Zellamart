namespace Zellamart.Seller.Application.Sellers;

public sealed record ApplySellerRequest(
    string BusinessName,
    string OwnerName,
    string ContactEmail,
    string Phone,
    string Address,
    string? GstNumber);
