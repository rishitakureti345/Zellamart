using Zellamart.Seller.Domain.Sellers;

namespace Zellamart.Seller.Application.Sellers;

public sealed record SellerResponse(
    Guid Id,
    Guid UserId,
    string BusinessName,
    string OwnerName,
    string ContactEmail,
    string Phone,
    string Address,
    string? GstNumber,
    SellerStatus Status);
