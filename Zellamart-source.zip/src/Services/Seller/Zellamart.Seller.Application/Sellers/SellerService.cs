using Zellamart.Seller.Application.Abstractions;
using Zellamart.Seller.Domain.Sellers;
using Zellamart.SharedKernel.Results;

namespace Zellamart.Seller.Application.Sellers;

public sealed class SellerService : ISellerService
{
    private readonly ISellerRepository _repository;
    private readonly ISellerEventPublisher _eventPublisher;

    public SellerService(ISellerRepository repository, ISellerEventPublisher eventPublisher)
    {
        _repository = repository;
        _eventPublisher = eventPublisher;
    }

    public async Task<Result<SellerResponse>> ApplyAsync(Guid userId, ApplySellerRequest request, CancellationToken cancellationToken)
    {
        if (string.IsNullOrWhiteSpace(request.BusinessName))
        {
            return Result.Fail<SellerResponse>(Error.Validation("Business name is required."));
        }

        if (string.IsNullOrWhiteSpace(request.OwnerName))
        {
            return Result.Fail<SellerResponse>(Error.Validation("Owner name is required."));
        }

        if (string.IsNullOrWhiteSpace(request.ContactEmail))
        {
            return Result.Fail<SellerResponse>(Error.Validation("Contact email is required."));
        }

        var existingSeller = await _repository.GetByUserIdAsync(userId, cancellationToken);
        if (existingSeller is not null)
        {
            return Result.Fail<SellerResponse>(Error.Conflict("Seller application already exists for this user."));
        }

        var seller = new SellerProfile(
            userId,
            request.BusinessName,
            request.OwnerName,
            request.ContactEmail,
            request.Phone,
            request.Address,
            request.GstNumber);

        await _repository.AddAsync(seller, cancellationToken);
        await _repository.SaveChangesAsync(cancellationToken);
        await _eventPublisher.PublishAppliedAsync(seller, cancellationToken);

        return Result.Ok(ToResponse(seller));
    }

    public async Task<Result<SellerResponse>> GetMineAsync(Guid userId, CancellationToken cancellationToken)
    {
        var seller = await _repository.GetByUserIdAsync(userId, cancellationToken);
        return seller is null
            ? Result.Fail<SellerResponse>(Error.NotFound("Seller profile was not found."))
            : Result.Ok(ToResponse(seller));
    }

    public async Task<Result<IReadOnlyList<SellerResponse>>> GetAllAsync(CancellationToken cancellationToken)
    {
        var sellers = await _repository.GetAllAsync(cancellationToken);
        return Result.Ok<IReadOnlyList<SellerResponse>>(sellers.Select(ToResponse).ToArray());
    }

    public async Task<Result<IReadOnlyList<SellerResponse>>> GetPendingAsync(CancellationToken cancellationToken)
    {
        var sellers = await _repository.GetPendingAsync(cancellationToken);
        return Result.Ok<IReadOnlyList<SellerResponse>>(sellers.Select(ToResponse).ToArray());
    }

    public async Task<Result<SellerResponse>> ApproveAsync(Guid sellerId, Guid approvedByUserId, CancellationToken cancellationToken)
    {
        var seller = await _repository.GetByIdAsync(sellerId, cancellationToken);
        if (seller is null)
        {
            return Result.Fail<SellerResponse>(Error.NotFound("Seller was not found."));
        }

        seller.Approve(approvedByUserId);
        await _repository.SaveChangesAsync(cancellationToken);
        await _eventPublisher.PublishApprovedAsync(seller, approvedByUserId, cancellationToken);

        return Result.Ok(ToResponse(seller));
    }

    public async Task<Result<SellerResponse>> RejectAsync(
        Guid sellerId,
        Guid rejectedByUserId,
        RejectSellerRequest request,
        CancellationToken cancellationToken)
    {
        var seller = await _repository.GetByIdAsync(sellerId, cancellationToken);
        if (seller is null)
        {
            return Result.Fail<SellerResponse>(Error.NotFound("Seller was not found."));
        }

        var reason = string.IsNullOrWhiteSpace(request.Reason) ? "Seller application rejected." : request.Reason;
        seller.Reject(rejectedByUserId, reason);
        await _repository.SaveChangesAsync(cancellationToken);
        await _eventPublisher.PublishRejectedAsync(seller, rejectedByUserId, reason, cancellationToken);

        return Result.Ok(ToResponse(seller));
    }

    public async Task<Result<SellerResponse>> SuspendAsync(
        Guid sellerId,
        Guid suspendedByUserId,
        SuspendSellerRequest request,
        CancellationToken cancellationToken)
    {
        var seller = await _repository.GetByIdAsync(sellerId, cancellationToken);
        if (seller is null)
        {
            return Result.Fail<SellerResponse>(Error.NotFound("Seller was not found."));
        }

        var reason = string.IsNullOrWhiteSpace(request.Reason) ? "Seller suspended." : request.Reason;
        seller.Suspend(suspendedByUserId, reason);
        await _repository.SaveChangesAsync(cancellationToken);

        return Result.Ok(ToResponse(seller));
    }

    public async Task<Result<SellerResponse>> ReactivateAsync(
        Guid sellerId,
        Guid reactivatedByUserId,
        CancellationToken cancellationToken)
    {
        var seller = await _repository.GetByIdAsync(sellerId, cancellationToken);
        if (seller is null)
        {
            return Result.Fail<SellerResponse>(Error.NotFound("Seller was not found."));
        }

        seller.Reactivate(reactivatedByUserId);
        await _repository.SaveChangesAsync(cancellationToken);

        return Result.Ok(ToResponse(seller));
    }

    private static SellerResponse ToResponse(SellerProfile seller)
    {
        return new SellerResponse(
            seller.Id,
            seller.UserId,
            seller.BusinessName,
            seller.OwnerName,
            seller.ContactEmail,
            seller.Phone,
            seller.Address,
            seller.GstNumber,
            seller.Status);
    }
}
