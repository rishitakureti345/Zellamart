using Microsoft.Extensions.DependencyInjection;
using Zellamart.Seller.Application.Sellers;

namespace Zellamart.Seller.Application;

public static class DependencyInjection
{
    public static IServiceCollection AddSellerApplication(this IServiceCollection services)
    {
        services.AddScoped<ISellerService, SellerService>();
        return services;
    }
}
