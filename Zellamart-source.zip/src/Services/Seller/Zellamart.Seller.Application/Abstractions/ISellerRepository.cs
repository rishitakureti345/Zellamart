using Zellamart.Seller.Domain.Sellers;

namespace Zellamart.Seller.Application.Abstractions;

public interface ISellerRepository
{
    Task<SellerProfile?> GetByIdAsync(Guid sellerId, CancellationToken cancellationToken);

    Task<SellerProfile?> GetByUserIdAsync(Guid userId, CancellationToken cancellationToken);

    Task<IReadOnlyList<SellerProfile>> GetAllAsync(CancellationToken cancellationToken);

    Task<IReadOnlyList<SellerProfile>> GetPendingAsync(CancellationToken cancellationToken);

    Task AddAsync(SellerProfile seller, CancellationToken cancellationToken);

    Task SaveChangesAsync(CancellationToken cancellationToken);
}
