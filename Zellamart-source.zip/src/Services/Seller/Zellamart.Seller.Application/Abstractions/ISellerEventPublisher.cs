using Zellamart.Seller.Domain.Sellers;

namespace Zellamart.Seller.Application.Abstractions;

public interface ISellerEventPublisher
{
    Task PublishAppliedAsync(SellerProfile seller, CancellationToken cancellationToken);

    Task PublishApprovedAsync(SellerProfile seller, Guid approvedByUserId, CancellationToken cancellationToken);

    Task PublishRejectedAsync(SellerProfile seller, Guid rejectedByUserId, string reason, CancellationToken cancellationToken);
}
