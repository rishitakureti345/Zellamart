using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Zellamart.Seller.Application.Abstractions;
using Zellamart.Seller.Infrastructure.Events;
using Zellamart.Seller.Infrastructure.Persistence;

namespace Zellamart.Seller.Infrastructure;

public static class DependencyInjection
{
    public static IServiceCollection AddSellerInfrastructure(
        this IServiceCollection services,
        IConfiguration configuration)
    {
        services.AddDbContext<SellerDbContext>(options =>
            options.UseNpgsql(configuration.GetConnectionString("Seller")));

        services.AddScoped<ISellerRepository, SellerRepository>();
        services.AddScoped<ISellerEventPublisher, LoggingSellerEventPublisher>();

        return services;
    }
}
