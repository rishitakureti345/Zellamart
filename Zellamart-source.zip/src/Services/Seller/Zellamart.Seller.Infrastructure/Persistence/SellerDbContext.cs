using Microsoft.EntityFrameworkCore;
using Zellamart.Seller.Domain.Sellers;

namespace Zellamart.Seller.Infrastructure.Persistence;

public sealed class SellerDbContext : DbContext
{
    public SellerDbContext(DbContextOptions<SellerDbContext> options)
        : base(options)
    {
    }

    public DbSet<SellerProfile> Sellers => Set<SellerProfile>();

    public DbSet<SellerStatusHistory> SellerStatusHistory => Set<SellerStatusHistory>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<SellerProfile>(builder =>
        {
            builder.ToTable("sellers");
            builder.HasKey(seller => seller.Id);
            builder.Property(seller => seller.Id).ValueGeneratedNever();
            builder.Property(seller => seller.BusinessName).HasMaxLength(180).IsRequired();
            builder.Property(seller => seller.OwnerName).HasMaxLength(160).IsRequired();
            builder.Property(seller => seller.ContactEmail).HasMaxLength(320).IsRequired();
            builder.Property(seller => seller.Phone).HasMaxLength(40).IsRequired();
            builder.Property(seller => seller.Address).HasMaxLength(600).IsRequired();
            builder.Property(seller => seller.GstNumber).HasMaxLength(40);
            builder.Property(seller => seller.Status).HasConversion<string>().HasMaxLength(40).IsRequired();
            builder.HasIndex(seller => seller.UserId).IsUnique();
            builder.HasIndex(seller => seller.ContactEmail);
            builder.Navigation(seller => seller.StatusHistory).UsePropertyAccessMode(PropertyAccessMode.Field);
        });

        modelBuilder.Entity<SellerStatusHistory>(builder =>
        {
            builder.ToTable("seller_status_history");
            builder.HasKey(history => history.Id);
            builder.Property(history => history.Id).ValueGeneratedNever();
            builder.Property(history => history.Status).HasConversion<string>().HasMaxLength(40).IsRequired();
            builder.Property(history => history.Note).HasMaxLength(600).IsRequired();
            builder.HasOne(history => history.Seller)
                .WithMany(seller => seller.StatusHistory)
                .HasForeignKey(history => history.SellerId);
            builder.HasIndex(history => history.SellerId);
        });
    }
}
