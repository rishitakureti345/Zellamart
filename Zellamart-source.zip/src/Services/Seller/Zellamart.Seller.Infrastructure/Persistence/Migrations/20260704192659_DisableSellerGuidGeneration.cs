﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Zellamart.Seller.Infrastructure.Persistence.Migrations
{
    /// <inheritdoc />
    public partial class DisableSellerGuidGeneration : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
