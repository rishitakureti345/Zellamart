using Microsoft.EntityFrameworkCore;
using Zellamart.Seller.Application.Abstractions;
using Zellamart.Seller.Domain.Sellers;

namespace Zellamart.Seller.Infrastructure.Persistence;

public sealed class SellerRepository : ISellerRepository
{
    private readonly SellerDbContext _dbContext;

    public SellerRepository(SellerDbContext dbContext)
    {
        _dbContext = dbContext;
    }

    public Task<SellerProfile?> GetByIdAsync(Guid sellerId, CancellationToken cancellationToken)
    {
        return SellerQuery().FirstOrDefaultAsync(seller => seller.Id == sellerId, cancellationToken);
    }

    public Task<SellerProfile?> GetByUserIdAsync(Guid userId, CancellationToken cancellationToken)
    {
        return SellerQuery().FirstOrDefaultAsync(seller => seller.UserId == userId, cancellationToken);
    }

    public async Task<IReadOnlyList<SellerProfile>> GetAllAsync(CancellationToken cancellationToken)
    {
        return await SellerQuery()
            .OrderByDescending(seller => seller.CreatedAtUtc)
            .ToArrayAsync(cancellationToken);
    }

    public async Task<IReadOnlyList<SellerProfile>> GetPendingAsync(CancellationToken cancellationToken)
    {
        return await SellerQuery()
            .Where(seller => seller.Status == SellerStatus.Pending)
            .OrderBy(seller => seller.CreatedAtUtc)
            .ToArrayAsync(cancellationToken);
    }

    public async Task AddAsync(SellerProfile seller, CancellationToken cancellationToken)
    {
        await _dbContext.Sellers.AddAsync(seller, cancellationToken);
    }

    public Task SaveChangesAsync(CancellationToken cancellationToken)
    {
        return _dbContext.SaveChangesAsync(cancellationToken);
    }

    private IQueryable<SellerProfile> SellerQuery()
    {
        return _dbContext.Sellers.Include(seller => seller.StatusHistory);
    }
}
