using Microsoft.Extensions.Logging;
using Zellamart.Contracts.Events.Sellers;
using Zellamart.Seller.Application.Abstractions;
using Zellamart.Seller.Domain.Sellers;

namespace Zellamart.Seller.Infrastructure.Events;

public sealed class LoggingSellerEventPublisher : ISellerEventPublisher
{
    private readonly ILogger<LoggingSellerEventPublisher> _logger;

    public LoggingSellerEventPublisher(ILogger<LoggingSellerEventPublisher> logger)
    {
        _logger = logger;
    }

    public Task PublishAppliedAsync(SellerProfile seller, CancellationToken cancellationToken)
    {
        var integrationEvent = new SellerAppliedEvent(
            Guid.NewGuid(),
            DateTimeOffset.UtcNow,
            seller.Id,
            seller.UserId,
            seller.BusinessName,
            seller.ContactEmail);

        LogEvent(integrationEvent);
        return Task.CompletedTask;
    }

    public Task PublishApprovedAsync(SellerProfile seller, Guid approvedByUserId, CancellationToken cancellationToken)
    {
        var integrationEvent = new SellerApprovedEvent(
            Guid.NewGuid(),
            DateTimeOffset.UtcNow,
            seller.Id,
            approvedByUserId);

        LogEvent(integrationEvent);
        return Task.CompletedTask;
    }

    public Task PublishRejectedAsync(
        SellerProfile seller,
        Guid rejectedByUserId,
        string reason,
        CancellationToken cancellationToken)
    {
        var integrationEvent = new SellerRejectedEvent(
            Guid.NewGuid(),
            DateTimeOffset.UtcNow,
            seller.Id,
            rejectedByUserId,
            reason);

        LogEvent(integrationEvent);
        return Task.CompletedTask;
    }

    private void LogEvent<TEvent>(TEvent integrationEvent)
        where TEvent : class
    {
        _logger.LogInformation(
            "Integration event ready: {EventType} {@IntegrationEvent}",
            typeof(TEvent).Name,
            integrationEvent);
    }
}
