using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Zellamart.Seller.Application.Sellers;

namespace Zellamart.Seller.Api.Controllers;

[ApiController]
[Route("api/sellers")]
public sealed class SellersController : ControllerBase
{
    private readonly ISellerService _sellerService;

    public SellersController(ISellerService sellerService)
    {
        _sellerService = sellerService;
    }

    [Authorize(Roles = "SuperAdmin,Admin,Customer")]
    [HttpPost("apply")]
    public async Task<IActionResult> Apply(ApplySellerRequest request, CancellationToken cancellationToken)
    {
        var userId = GetCurrentUserId();
        if (userId is null)
        {
            return Unauthorized();
        }

        var result = await _sellerService.ApplyAsync(userId.Value, request, cancellationToken);
        return result.Success ? Ok(result) : BadRequest(result);
    }

    [Authorize(Roles = "SuperAdmin,Admin,Seller")]
    [HttpGet("me")]
    public async Task<IActionResult> GetMine(CancellationToken cancellationToken)
    {
        var userId = GetCurrentUserId();
        if (userId is null)
        {
            return Unauthorized();
        }

        var result = await _sellerService.GetMineAsync(userId.Value, cancellationToken);
        return result.Success ? Ok(result) : NotFound(result);
    }

    [Authorize(Roles = "SuperAdmin,Admin,InventoryStaff,WarehouseManager")]
    [HttpGet("admin/all")]
    public async Task<IActionResult> GetAll(CancellationToken cancellationToken)
    {
        var result = await _sellerService.GetAllAsync(cancellationToken);
        return Ok(result);
    }

    [Authorize(Roles = "SuperAdmin,Admin")]
    [HttpGet("pending")]
    public async Task<IActionResult> GetPending(CancellationToken cancellationToken)
    {
        var result = await _sellerService.GetPendingAsync(cancellationToken);
        return Ok(result);
    }

    [Authorize(Roles = "SuperAdmin,Admin")]
    [HttpPost("{sellerId:guid}/approve")]
    public async Task<IActionResult> Approve(Guid sellerId, CancellationToken cancellationToken)
    {
        var userId = GetCurrentUserId();
        if (userId is null)
        {
            return Unauthorized();
        }

        var result = await _sellerService.ApproveAsync(sellerId, userId.Value, cancellationToken);
        return result.Success ? Ok(result) : NotFound(result);
    }

    [Authorize(Roles = "SuperAdmin,Admin")]
    [HttpPost("{sellerId:guid}/reject")]
    public async Task<IActionResult> Reject(Guid sellerId, RejectSellerRequest request, CancellationToken cancellationToken)
    {
        var userId = GetCurrentUserId();
        if (userId is null)
        {
            return Unauthorized();
        }

        var result = await _sellerService.RejectAsync(sellerId, userId.Value, request, cancellationToken);
        return result.Success ? Ok(result) : NotFound(result);
    }

    [Authorize(Roles = "SuperAdmin,Admin")]
    [HttpPost("{sellerId:guid}/suspend")]
    public async Task<IActionResult> Suspend(Guid sellerId, SuspendSellerRequest request, CancellationToken cancellationToken)
    {
        var userId = GetCurrentUserId();
        if (userId is null)
        {
            return Unauthorized();
        }

        var result = await _sellerService.SuspendAsync(sellerId, userId.Value, request, cancellationToken);
        return result.Success ? Ok(result) : NotFound(result);
    }

    [Authorize(Roles = "SuperAdmin,Admin")]
    [HttpPost("{sellerId:guid}/reactivate")]
    public async Task<IActionResult> Reactivate(Guid sellerId, CancellationToken cancellationToken)
    {
        var userId = GetCurrentUserId();
        if (userId is null)
        {
            return Unauthorized();
        }

        var result = await _sellerService.ReactivateAsync(sellerId, userId.Value, cancellationToken);
        return result.Success ? Ok(result) : NotFound(result);
    }

    private Guid? GetCurrentUserId()
    {
        var userIdValue = User.FindFirstValue(ClaimTypes.NameIdentifier)
            ?? User.FindFirst(JwtRegisteredClaimNames.Sub)?.Value;

        return Guid.TryParse(userIdValue, out var userId) ? userId : null;
    }
}
