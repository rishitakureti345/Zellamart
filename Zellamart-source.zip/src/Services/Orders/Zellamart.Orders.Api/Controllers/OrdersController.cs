using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Zellamart.Orders.Application.Abstractions;
using Zellamart.Orders.Application.Orders;
using Zellamart.SharedKernel.Results;

namespace Zellamart.Orders.Api.Controllers;

[ApiController]
[Authorize]
[Route("api/orders")]
public sealed class OrdersController : ControllerBase
{
    private readonly IOrderService _orderService;
    private readonly ISellerProfileGateway _sellerProfileGateway;

    public OrdersController(
        IOrderService orderService,
        ISellerProfileGateway sellerProfileGateway)
    {
        _orderService = orderService;
        _sellerProfileGateway = sellerProfileGateway;
    }

    [Authorize(Roles = "SuperAdmin,Admin,Customer")]
    [HttpPost("from-cart")]
    public async Task<IActionResult> CreateFromCart(CreateOrderFromCartRequest request, CancellationToken cancellationToken)
    {
        var customerId = GetCurrentUserId();
        if (customerId is null)
        {
            return Unauthorized();
        }

        var result = await _orderService.CreateFromCartAsync(customerId.Value, request, GetBearerToken() ?? string.Empty, cancellationToken);
        return result.Success ? Ok(result) : ToFailureResult(result);
    }

    [Authorize(Roles = "SuperAdmin,Admin,Customer")]
    [HttpGet("me")]
    public async Task<IActionResult> GetMine(CancellationToken cancellationToken)
    {
        var customerId = GetCurrentUserId();
        if (customerId is null)
        {
            return Unauthorized();
        }

        var result = await _orderService.GetMineAsync(customerId.Value, cancellationToken);
        return Ok(result);
    }

    [Authorize(Roles = "SuperAdmin,Admin,Customer,OrderManager,FinanceManager,SupportManager,SupportAgent,DeliveryManager")]
    [HttpGet("{orderId:guid}")]
    public async Task<IActionResult> GetById(Guid orderId, CancellationToken cancellationToken)
    {
        var customerId = GetCurrentUserId();
        if (customerId is null)
        {
            return Unauthorized();
        }

        var result = CanReadOrders()
            ? await _orderService.GetByIdForStaffAsync(orderId, cancellationToken)
            : await _orderService.GetByIdAsync(customerId.Value, orderId, cancellationToken);
        return result.Success ? Ok(result) : ToFailureResult(result);
    }

    [Authorize(Roles = "SuperAdmin,Admin,Seller,OrderManager")]
    [HttpGet("seller/{sellerId:guid}")]
    public async Task<IActionResult> GetBySeller(Guid sellerId, CancellationToken cancellationToken)
    {
        if (User.IsInRole("Seller") && !await IsCurrentSellerAsync(sellerId, cancellationToken))
        {
            return Forbid();
        }

        var result = await _orderService.GetBySellerIdAsync(sellerId, cancellationToken);
        return Ok(result);
    }

    [Authorize(Roles = "SuperAdmin,Admin,OrderManager,FinanceManager,SupportManager,SupportAgent")]
    [HttpGet("admin/all")]
    public async Task<IActionResult> GetAllForStaff(CancellationToken cancellationToken)
    {
        var result = await _orderService.GetAllForStaffAsync(cancellationToken);
        return Ok(result);
    }

    [Authorize(Roles = "SuperAdmin,Admin,Customer,PaymentTeam")]
    [HttpPost("{orderId:guid}/payment-succeeded")]
    public async Task<IActionResult> MarkPaymentSucceeded(Guid orderId, CancellationToken cancellationToken)
    {
        var customerId = GetCurrentUserId();
        if (customerId is null)
        {
            return Unauthorized();
        }

        var result = await _orderService.MarkPaymentSucceededAsync(customerId.Value, orderId, cancellationToken);
        return result.Success ? Ok(result) : ToFailureResult(result);
    }

    [Authorize(Roles = "SuperAdmin,Admin,Customer,PaymentTeam")]
    [HttpPost("{orderId:guid}/payment-failed")]
    public async Task<IActionResult> MarkPaymentFailed(Guid orderId, CancellationToken cancellationToken)
    {
        var customerId = GetCurrentUserId();
        if (customerId is null)
        {
            return Unauthorized();
        }

        var result = await _orderService.MarkPaymentFailedAsync(customerId.Value, orderId, cancellationToken);
        return result.Success ? Ok(result) : ToFailureResult(result);
    }

    [Authorize(Roles = "SuperAdmin,Admin,Customer,OrderManager")]
    [HttpPost("{orderId:guid}/confirm")]
    public async Task<IActionResult> Confirm(Guid orderId, CancellationToken cancellationToken)
    {
        var customerId = GetCurrentUserId();
        if (customerId is null)
        {
            return Unauthorized();
        }

        var result = await _orderService.ConfirmAsync(customerId.Value, orderId, cancellationToken);
        return result.Success ? Ok(result) : ToFailureResult(result);
    }

    [Authorize(Roles = "SuperAdmin,Admin,Customer,OrderManager")]
    [HttpPost("{orderId:guid}/cancel")]
    public async Task<IActionResult> Cancel(Guid orderId, CancellationToken cancellationToken)
    {
        var customerId = GetCurrentUserId();
        if (customerId is null)
        {
            return Unauthorized();
        }

        var result = await _orderService.CancelAsync(customerId.Value, orderId, cancellationToken);
        return result.Success ? Ok(result) : ToFailureResult(result);
    }

    [Authorize(Roles = "SuperAdmin,Admin,OrderManager")]
    [HttpPost("admin/{orderId:guid}/cancel")]
    public async Task<IActionResult> CancelForStaff(Guid orderId, CancelOrderRequest request, CancellationToken cancellationToken)
    {
        var userId = GetCurrentUserId();
        if (userId is null)
        {
            return Unauthorized();
        }

        var result = await _orderService.CancelForStaffAsync(orderId, userId.Value, request, cancellationToken);
        return result.Success ? Ok(result) : ToFailureResult(result);
    }

    [Authorize(Roles = "SuperAdmin,Admin,OrderManager")]
    [HttpPost("admin/{orderId:guid}/force-status")]
    public async Task<IActionResult> ForceStatusForStaff(Guid orderId, ForceOrderStatusRequest request, CancellationToken cancellationToken)
    {
        var userId = GetCurrentUserId();
        if (userId is null)
        {
            return Unauthorized();
        }

        var result = await _orderService.ForceStatusForStaffAsync(orderId, userId.Value, request, cancellationToken);
        return result.Success ? Ok(result) : ToFailureResult(result);
    }

    [Authorize(Roles = "SuperAdmin,Admin,Customer,OrderManager,DeliveryManager")]
    [HttpPost("{orderId:guid}/delivered")]
    public async Task<IActionResult> MarkDelivered(Guid orderId, CancellationToken cancellationToken)
    {
        var customerId = GetCurrentUserId();
        if (customerId is null)
        {
            return Unauthorized();
        }

        var result = await _orderService.MarkDeliveredAsync(customerId.Value, orderId, cancellationToken);
        return result.Success ? Ok(result) : ToFailureResult(result);
    }

    private Guid? GetCurrentUserId()
    {
        var userIdValue = User.FindFirstValue(ClaimTypes.NameIdentifier)
            ?? User.FindFirst(JwtRegisteredClaimNames.Sub)?.Value;

        return Guid.TryParse(userIdValue, out var userId) ? userId : null;
    }

    private async Task<bool> IsCurrentSellerAsync(Guid sellerId, CancellationToken cancellationToken)
    {
        var seller = await GetCurrentSellerAsync(cancellationToken);
        return seller?.Id == sellerId;
    }

    private async Task<SellerProfileSnapshot?> GetCurrentSellerAsync(CancellationToken cancellationToken)
    {
        var bearerToken = GetBearerToken();
        return string.IsNullOrWhiteSpace(bearerToken)
            ? null
            : await _sellerProfileGateway.GetMineAsync(bearerToken, cancellationToken);
    }

    private string? GetBearerToken()
    {
        var authorization = Request.Headers.Authorization.ToString();
        return authorization.StartsWith("Bearer ", StringComparison.OrdinalIgnoreCase)
            ? authorization["Bearer ".Length..].Trim()
            : null;
    }

    private bool CanReadOrders()
    {
        return User.IsInRole("SuperAdmin")
            || User.IsInRole("Admin")
            || User.IsInRole("OrderManager")
            || User.IsInRole("FinanceManager")
            || User.IsInRole("SupportManager")
            || User.IsInRole("SupportAgent")
            || User.IsInRole("DeliveryManager");
    }

    private IActionResult ToFailureResult<T>(Result<T> result)
    {
        return result.Error.Code switch
        {
            "NotFound" => NotFound(result),
            "Conflict" => Conflict(result),
            _ => BadRequest(result)
        };
    }
}
