using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Zellamart.Orders.Application.Abstractions;
using Zellamart.Orders.Infrastructure.Persistence;
using Zellamart.Orders.Infrastructure.Services;

namespace Zellamart.Orders.Infrastructure;

public static class DependencyInjection
{
    public static IServiceCollection AddOrdersInfrastructure(
        this IServiceCollection services,
        IConfiguration configuration)
    {
        services.AddDbContext<OrdersDbContext>(options =>
            options.UseNpgsql(configuration.GetConnectionString("Orders")));

        services.AddScoped<IOrderRepository, OrderRepository>();
        services.AddHttpClient<ISellerProfileGateway, SellerProfileGateway>(client =>
        {
            client.BaseAddress = new Uri(configuration["Services:Seller"] ?? "http://localhost:5102");
        });
        services.AddHttpClient<ICartGateway, CartGateway>(client =>
        {
            client.BaseAddress = new Uri(configuration["Services:Cart"] ?? "http://localhost:5105");
        });

        return services;
    }
}
