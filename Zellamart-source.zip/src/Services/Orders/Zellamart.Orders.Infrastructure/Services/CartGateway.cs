using System.Net.Http.Headers;
using System.Net.Http.Json;
using Zellamart.Orders.Application.Abstractions;

namespace Zellamart.Orders.Infrastructure.Services;

public sealed class CartGateway : ICartGateway
{
    private readonly HttpClient _httpClient;

    public CartGateway(HttpClient httpClient)
    {
        _httpClient = httpClient;
    }

    public async Task<CartSnapshot?> GetMineAsync(string bearerToken, CancellationToken cancellationToken)
    {
        if (string.IsNullOrWhiteSpace(bearerToken))
        {
            return null;
        }

        using var request = CreateAuthorizedRequest(HttpMethod.Get, "/api/cart/me", bearerToken);
        using var response = await _httpClient.SendAsync(request, cancellationToken);
        if (!response.IsSuccessStatusCode)
        {
            return null;
        }

        var result = await response.Content.ReadFromJsonAsync<GatewayResult<CartGatewayResponse>>(cancellationToken);
        if (result?.Success != true || result.Value is null)
        {
            return null;
        }

        return new CartSnapshot(
            result.Value.Id,
            result.Value.CustomerId,
            result.Value.Items.Select(item => new CartItemSnapshot(
                item.Id,
                item.ProductId,
                item.SellerId,
                item.ProductName,
                item.UnitPrice,
                item.Quantity,
                item.Currency,
                item.LineTotal)).ToArray(),
            result.Value.Subtotal,
            result.Value.TotalItems,
            result.Value.Currency);
    }

    public async Task ClearMineAsync(string bearerToken, CancellationToken cancellationToken)
    {
        if (string.IsNullOrWhiteSpace(bearerToken))
        {
            return;
        }

        using var request = CreateAuthorizedRequest(HttpMethod.Delete, "/api/cart/clear", bearerToken);
        using var response = await _httpClient.SendAsync(request, cancellationToken);
    }

    private static HttpRequestMessage CreateAuthorizedRequest(HttpMethod method, string path, string bearerToken)
    {
        var request = new HttpRequestMessage(method, path);
        request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", bearerToken);
        return request;
    }

    private sealed record CartGatewayResponse(
        Guid Id,
        Guid CustomerId,
        IReadOnlyList<CartItemGatewayResponse> Items,
        decimal Subtotal,
        int TotalItems,
        string Currency);

    private sealed record CartItemGatewayResponse(
        Guid Id,
        Guid ProductId,
        Guid SellerId,
        string ProductName,
        decimal UnitPrice,
        int Quantity,
        string Currency,
        decimal LineTotal);

    private sealed class GatewayResult<T>
    {
        public bool Success { get; set; }

        public T? Value { get; set; }
    }
}
