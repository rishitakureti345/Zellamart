using Microsoft.EntityFrameworkCore;
using Zellamart.Orders.Domain.Orders;

namespace Zellamart.Orders.Infrastructure.Persistence;

public sealed class OrdersDbContext : DbContext
{
    public OrdersDbContext(DbContextOptions<OrdersDbContext> options)
        : base(options)
    {
    }

    public DbSet<Order> Orders => Set<Order>();

    public DbSet<OrderItem> OrderItems => Set<OrderItem>();

    public DbSet<OrderStatusHistory> OrderStatusHistory => Set<OrderStatusHistory>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Order>(builder =>
        {
            builder.ToTable("orders");
            builder.HasKey(order => order.Id);
            builder.Property(order => order.Id).ValueGeneratedNever();
            builder.Property(order => order.OrderNumber).HasMaxLength(40).IsRequired();
            builder.Property(order => order.Status).HasConversion<string>().HasMaxLength(40).IsRequired();
            builder.Property(order => order.Subtotal).HasPrecision(18, 2);
            builder.Property(order => order.Currency).HasMaxLength(3).IsRequired();
            builder.Property(order => order.ShippingAddress).HasMaxLength(600).IsRequired();
            builder.Property(order => order.DeliveryNote).HasMaxLength(240);
            builder.HasIndex(order => order.CustomerId);
            builder.HasIndex(order => order.OrderNumber).IsUnique();
            builder.HasIndex(order => order.Status);
            builder.Navigation(order => order.Items).UsePropertyAccessMode(PropertyAccessMode.Field);
            builder.Navigation(order => order.StatusHistory).UsePropertyAccessMode(PropertyAccessMode.Field);
        });

        modelBuilder.Entity<OrderItem>(builder =>
        {
            builder.ToTable("order_items");
            builder.HasKey(item => item.Id);
            builder.Property(item => item.Id).ValueGeneratedNever();
            builder.Property(item => item.ProductName).HasMaxLength(220).IsRequired();
            builder.Property(item => item.UnitPrice).HasPrecision(18, 2);
            builder.Property(item => item.LineTotal).HasPrecision(18, 2);
            builder.HasOne(item => item.Order)
                .WithMany(order => order.Items)
                .HasForeignKey(item => item.OrderId);
            builder.HasIndex(item => item.OrderId);
            builder.HasIndex(item => item.ProductId);
            builder.HasIndex(item => item.SellerId);
        });

        modelBuilder.Entity<OrderStatusHistory>(builder =>
        {
            builder.ToTable("order_status_history");
            builder.HasKey(history => history.Id);
            builder.Property(history => history.Id).ValueGeneratedNever();
            builder.Property(history => history.Status).HasConversion<string>().HasMaxLength(40).IsRequired();
            builder.Property(history => history.Note).HasMaxLength(600).IsRequired();
            builder.HasOne(history => history.Order)
                .WithMany(order => order.StatusHistory)
                .HasForeignKey(history => history.OrderId);
            builder.HasIndex(history => history.OrderId);
        });
    }
}
