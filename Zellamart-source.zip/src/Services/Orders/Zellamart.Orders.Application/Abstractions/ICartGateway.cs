namespace Zellamart.Orders.Application.Abstractions;

public interface ICartGateway
{
    Task<CartSnapshot?> GetMineAsync(string bearerToken, CancellationToken cancellationToken);

    Task ClearMineAsync(string bearerToken, CancellationToken cancellationToken);
}

public sealed record CartSnapshot(
    Guid Id,
    Guid CustomerId,
    IReadOnlyList<CartItemSnapshot> Items,
    decimal Subtotal,
    int TotalItems,
    string Currency);

public sealed record CartItemSnapshot(
    Guid Id,
    Guid ProductId,
    Guid SellerId,
    string ProductName,
    decimal UnitPrice,
    int Quantity,
    string Currency,
    decimal LineTotal);
