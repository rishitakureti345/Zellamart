using Zellamart.Orders.Domain.Orders;

namespace Zellamart.Orders.Application.Orders;

public sealed record OrderResponse(
    Guid Id,
    Guid CustomerId,
    string OrderNumber,
    OrderStatus Status,
    decimal Subtotal,
    string Currency,
    string ShippingAddress,
    string? DeliveryNote,
    IReadOnlyList<OrderItemResponse> Items,
    IReadOnlyList<OrderStatusHistoryResponse> StatusHistory,
    DateTimeOffset CreatedAtUtc);
