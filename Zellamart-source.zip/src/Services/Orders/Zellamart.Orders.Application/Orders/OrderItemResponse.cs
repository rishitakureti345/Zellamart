namespace Zellamart.Orders.Application.Orders;

public sealed record OrderItemResponse(
    Guid Id,
    Guid ProductId,
    Guid SellerId,
    string ProductName,
    decimal UnitPrice,
    int Quantity,
    decimal LineTotal);
