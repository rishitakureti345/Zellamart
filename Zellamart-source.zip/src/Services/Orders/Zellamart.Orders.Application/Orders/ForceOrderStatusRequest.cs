using Zellamart.Orders.Domain.Orders;

namespace Zellamart.Orders.Application.Orders;

public sealed record ForceOrderStatusRequest(OrderStatus Status, string? Note);
