using Zellamart.SharedKernel.Results;

namespace Zellamart.Orders.Application.Orders;

public interface IOrderService
{
    Task<Result<OrderResponse>> CreateFromCartAsync(
        Guid customerId,
        CreateOrderFromCartRequest request,
        string bearerToken,
        CancellationToken cancellationToken);

    Task<Result<IReadOnlyList<OrderResponse>>> GetMineAsync(Guid customerId, CancellationToken cancellationToken);

    Task<Result<OrderResponse>> GetByIdAsync(Guid customerId, Guid orderId, CancellationToken cancellationToken);

    Task<Result<OrderResponse>> GetByIdForStaffAsync(Guid orderId, CancellationToken cancellationToken);

    Task<Result<IReadOnlyList<OrderResponse>>> GetAllForStaffAsync(CancellationToken cancellationToken);

    Task<Result<IReadOnlyList<SellerOrderItemResponse>>> GetBySellerIdAsync(Guid sellerId, CancellationToken cancellationToken);

    Task<Result<OrderResponse>> MarkPaymentSucceededAsync(Guid customerId, Guid orderId, CancellationToken cancellationToken);

    Task<Result<OrderResponse>> MarkPaymentFailedAsync(Guid customerId, Guid orderId, CancellationToken cancellationToken);

    Task<Result<OrderResponse>> ConfirmAsync(Guid customerId, Guid orderId, CancellationToken cancellationToken);

    Task<Result<OrderResponse>> CancelAsync(Guid customerId, Guid orderId, CancellationToken cancellationToken);

    Task<Result<OrderResponse>> MarkDeliveredAsync(Guid customerId, Guid orderId, CancellationToken cancellationToken);

    Task<Result<OrderResponse>> CancelForStaffAsync(Guid orderId, Guid changedByUserId, CancelOrderRequest request, CancellationToken cancellationToken);

    Task<Result<OrderResponse>> ForceStatusForStaffAsync(Guid orderId, Guid changedByUserId, ForceOrderStatusRequest request, CancellationToken cancellationToken);
}
