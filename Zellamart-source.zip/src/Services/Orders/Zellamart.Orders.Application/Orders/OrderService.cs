using Zellamart.Orders.Application.Abstractions;
using Zellamart.Orders.Domain.Orders;
using Zellamart.SharedKernel.Results;

namespace Zellamart.Orders.Application.Orders;

public sealed class OrderService : IOrderService
{
    private readonly IOrderRepository _repository;
    private readonly ICartGateway _cartGateway;

    public OrderService(IOrderRepository repository, ICartGateway cartGateway)
    {
        _repository = repository;
        _cartGateway = cartGateway;
    }

    public async Task<Result<OrderResponse>> CreateFromCartAsync(
        Guid customerId,
        CreateOrderFromCartRequest request,
        string bearerToken,
        CancellationToken cancellationToken)
    {
        var validation = Validate(request);
        if (validation is not null)
        {
            return Result.Fail<OrderResponse>(validation);
        }

        var cart = await _cartGateway.GetMineAsync(bearerToken, cancellationToken);
        if (cart is null || cart.CustomerId != customerId)
        {
            return Result.Fail<OrderResponse>(Error.NotFound("Cart was not found."));
        }

        if (cart.Items.Count == 0)
        {
            return Result.Fail<OrderResponse>(Error.Validation("Cart is empty."));
        }

        var order = new Domain.Orders.Order(
            customerId,
            CreateOrderNumber(),
            cart.Currency,
            request.ShippingAddress,
            request.DeliveryNote);

        foreach (var item in cart.Items)
        {
            order.AddItem(item.ProductId, item.SellerId, item.ProductName, item.UnitPrice, item.Quantity);
        }

        await _repository.AddAsync(order, cancellationToken);
        await _repository.SaveChangesAsync(cancellationToken);
        await _cartGateway.ClearMineAsync(bearerToken, cancellationToken);

        return Result.Ok(ToResponse(order));
    }

    public async Task<Result<IReadOnlyList<OrderResponse>>> GetMineAsync(Guid customerId, CancellationToken cancellationToken)
    {
        var orders = await _repository.GetByCustomerIdAsync(customerId, cancellationToken);
        return Result.Ok<IReadOnlyList<OrderResponse>>(orders.Select(ToResponse).ToArray());
    }

    public async Task<Result<OrderResponse>> GetByIdAsync(Guid customerId, Guid orderId, CancellationToken cancellationToken)
    {
        var order = await _repository.GetByIdAsync(orderId, cancellationToken);
        if (order is null || order.CustomerId != customerId)
        {
            return Result.Fail<OrderResponse>(Error.NotFound("Order was not found."));
        }

        return Result.Ok(ToResponse(order));
    }

    public async Task<Result<OrderResponse>> GetByIdForStaffAsync(Guid orderId, CancellationToken cancellationToken)
    {
        var order = await _repository.GetByIdAsync(orderId, cancellationToken);
        return order is null
            ? Result.Fail<OrderResponse>(Error.NotFound("Order was not found."))
            : Result.Ok(ToResponse(order));
    }

    public async Task<Result<IReadOnlyList<OrderResponse>>> GetAllForStaffAsync(CancellationToken cancellationToken)
    {
        var orders = await _repository.GetAllAsync(cancellationToken);
        return Result.Ok<IReadOnlyList<OrderResponse>>(orders.Select(ToResponse).ToArray());
    }

    public async Task<Result<IReadOnlyList<SellerOrderItemResponse>>> GetBySellerIdAsync(
        Guid sellerId,
        CancellationToken cancellationToken)
    {
        var orders = await _repository.GetBySellerIdAsync(sellerId, cancellationToken);
        var sellerItems = orders
            .SelectMany(order => order.Items
                .Where(item => item.SellerId == sellerId)
                .Select(item => new SellerOrderItemResponse(
                    order.Id,
                    order.OrderNumber,
                    order.CustomerId,
                    order.Status,
                    item.Id,
                    item.ProductId,
                    item.SellerId,
                    item.ProductName,
                    item.UnitPrice,
                    item.Quantity,
                    item.LineTotal,
                    order.CreatedAtUtc)))
            .OrderByDescending(item => item.CreatedAtUtc)
            .ToArray();

        return Result.Ok<IReadOnlyList<SellerOrderItemResponse>>(sellerItems);
    }

    public async Task<Result<OrderResponse>> MarkPaymentSucceededAsync(
        Guid customerId,
        Guid orderId,
        CancellationToken cancellationToken)
    {
        var order = await GetOwnedOrderAsync(customerId, orderId, cancellationToken);
        if (order is null)
        {
            return Result.Fail<OrderResponse>(Error.NotFound("Order was not found."));
        }

        if (order.Status != OrderStatus.PendingPayment)
        {
            return Result.Fail<OrderResponse>(Error.Validation("Only pending payment orders can be marked payment succeeded."));
        }

        order.MarkPaymentSucceeded(customerId);
        await _repository.SaveChangesAsync(cancellationToken);

        return Result.Ok(ToResponse(order));
    }

    public async Task<Result<OrderResponse>> MarkPaymentFailedAsync(
        Guid customerId,
        Guid orderId,
        CancellationToken cancellationToken)
    {
        var order = await GetOwnedOrderAsync(customerId, orderId, cancellationToken);
        if (order is null)
        {
            return Result.Fail<OrderResponse>(Error.NotFound("Order was not found."));
        }

        if (order.Status != OrderStatus.PendingPayment)
        {
            return Result.Fail<OrderResponse>(Error.Validation("Only pending payment orders can be marked payment failed."));
        }

        order.MarkPaymentFailed(customerId);
        await _repository.SaveChangesAsync(cancellationToken);

        return Result.Ok(ToResponse(order));
    }

    public async Task<Result<OrderResponse>> ConfirmAsync(Guid customerId, Guid orderId, CancellationToken cancellationToken)
    {
        var order = await GetOwnedOrderAsync(customerId, orderId, cancellationToken);
        if (order is null)
        {
            return Result.Fail<OrderResponse>(Error.NotFound("Order was not found."));
        }

        if (order.Status != OrderStatus.PaymentSucceeded)
        {
            return Result.Fail<OrderResponse>(Error.Validation("Only payment succeeded orders can be confirmed."));
        }

        order.Confirm(customerId);
        await _repository.SaveChangesAsync(cancellationToken);

        return Result.Ok(ToResponse(order));
    }

    public async Task<Result<OrderResponse>> CancelAsync(Guid customerId, Guid orderId, CancellationToken cancellationToken)
    {
        var order = await GetOwnedOrderAsync(customerId, orderId, cancellationToken);
        if (order is null)
        {
            return Result.Fail<OrderResponse>(Error.NotFound("Order was not found."));
        }

        if (order.Status == OrderStatus.Delivered)
        {
            return Result.Fail<OrderResponse>(Error.Validation("Delivered orders cannot be cancelled."));
        }

        if (order.Status == OrderStatus.Cancelled)
        {
            return Result.Fail<OrderResponse>(Error.Conflict("Order is already cancelled."));
        }

        order.Cancel(customerId, "Order cancelled.");
        await _repository.SaveChangesAsync(cancellationToken);

        return Result.Ok(ToResponse(order));
    }

    public async Task<Result<OrderResponse>> MarkDeliveredAsync(Guid customerId, Guid orderId, CancellationToken cancellationToken)
    {
        var order = await GetOwnedOrderAsync(customerId, orderId, cancellationToken);
        if (order is null)
        {
            return Result.Fail<OrderResponse>(Error.NotFound("Order was not found."));
        }

        if (order.Status != OrderStatus.Confirmed)
        {
            return Result.Fail<OrderResponse>(Error.Validation("Only confirmed orders can be marked delivered."));
        }

        order.MarkDelivered(customerId);
        await _repository.SaveChangesAsync(cancellationToken);

        return Result.Ok(ToResponse(order));
    }

    public async Task<Result<OrderResponse>> CancelForStaffAsync(
        Guid orderId,
        Guid changedByUserId,
        CancelOrderRequest request,
        CancellationToken cancellationToken)
    {
        var order = await _repository.GetByIdAsync(orderId, cancellationToken);
        if (order is null)
        {
            return Result.Fail<OrderResponse>(Error.NotFound("Order was not found."));
        }

        if (order.Status == OrderStatus.Delivered)
        {
            return Result.Fail<OrderResponse>(Error.Validation("Delivered orders cannot be cancelled."));
        }

        if (order.Status == OrderStatus.Cancelled)
        {
            return Result.Fail<OrderResponse>(Error.Conflict("Order is already cancelled."));
        }

        var reason = string.IsNullOrWhiteSpace(request.Reason) ? "Order cancelled by admin." : request.Reason;
        order.Cancel(changedByUserId, reason);
        await _repository.SaveChangesAsync(cancellationToken);

        return Result.Ok(ToResponse(order));
    }

    public async Task<Result<OrderResponse>> ForceStatusForStaffAsync(
        Guid orderId,
        Guid changedByUserId,
        ForceOrderStatusRequest request,
        CancellationToken cancellationToken)
    {
        var order = await _repository.GetByIdAsync(orderId, cancellationToken);
        if (order is null)
        {
            return Result.Fail<OrderResponse>(Error.NotFound("Order was not found."));
        }

        var note = string.IsNullOrWhiteSpace(request.Note)
            ? $"Status forced to {request.Status} by admin."
            : request.Note;

        order.ForceStatus(request.Status, changedByUserId, note);
        await _repository.SaveChangesAsync(cancellationToken);

        return Result.Ok(ToResponse(order));
    }

    private async Task<Domain.Orders.Order?> GetOwnedOrderAsync(
        Guid customerId,
        Guid orderId,
        CancellationToken cancellationToken)
    {
        var order = await _repository.GetByIdAsync(orderId, cancellationToken);
        return order is not null && order.CustomerId == customerId ? order : null;
    }

    private static Error? Validate(CreateOrderFromCartRequest request)
    {
        if (string.IsNullOrWhiteSpace(request.ShippingAddress))
        {
            return Error.Validation("Shipping address is required.");
        }

        if (request.ShippingAddress.Trim().Length > 600)
        {
            return Error.Validation("Shipping address must be 600 characters or fewer.");
        }

        if (!string.IsNullOrWhiteSpace(request.DeliveryNote) && request.DeliveryNote.Trim().Length > 240)
        {
            return Error.Validation("Delivery note must be 240 characters or fewer.");
        }

        return null;
    }

    private static string CreateOrderNumber()
    {
        return $"ORD-{DateTimeOffset.UtcNow:yyyyMMddHHmmss}-{Random.Shared.Next(1000, 9999)}";
    }

    private static OrderResponse ToResponse(Domain.Orders.Order order)
    {
        return new OrderResponse(
            order.Id,
            order.CustomerId,
            order.OrderNumber,
            order.Status,
            order.Subtotal,
            order.Currency,
            order.ShippingAddress,
            order.DeliveryNote,
            order.Items.Select(item => new OrderItemResponse(
                item.Id,
                item.ProductId,
                item.SellerId,
                item.ProductName,
                item.UnitPrice,
                item.Quantity,
                item.LineTotal)).ToArray(),
            order.StatusHistory.Select(history => new OrderStatusHistoryResponse(
                history.Id,
                history.Status,
                history.Note,
                history.ChangedByUserId,
                history.ChangedAtUtc)).ToArray(),
            order.CreatedAtUtc);
    }
}
