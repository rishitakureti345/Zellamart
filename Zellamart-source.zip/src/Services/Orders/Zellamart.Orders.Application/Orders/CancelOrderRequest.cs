namespace Zellamart.Orders.Application.Orders;

public sealed record CancelOrderRequest(string? Reason);
