using Zellamart.Orders.Domain.Orders;

namespace Zellamart.Orders.Application.Orders;

public sealed record OrderStatusHistoryResponse(
    Guid Id,
    OrderStatus Status,
    string Note,
    Guid? ChangedByUserId,
    DateTimeOffset ChangedAtUtc);
