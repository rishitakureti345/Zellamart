namespace Zellamart.Orders.Application.Orders;

public sealed record CreateOrderFromCartRequest(
    string ShippingAddress,
    string? DeliveryNote);
