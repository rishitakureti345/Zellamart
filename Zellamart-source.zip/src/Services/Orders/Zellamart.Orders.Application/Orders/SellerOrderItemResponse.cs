using Zellamart.Orders.Domain.Orders;

namespace Zellamart.Orders.Application.Orders;

public sealed record SellerOrderItemResponse(
    Guid OrderId,
    string OrderNumber,
    Guid CustomerId,
    OrderStatus Status,
    Guid OrderItemId,
    Guid ProductId,
    Guid SellerId,
    string ProductName,
    decimal UnitPrice,
    int Quantity,
    decimal LineTotal,
    DateTimeOffset CreatedAtUtc);
