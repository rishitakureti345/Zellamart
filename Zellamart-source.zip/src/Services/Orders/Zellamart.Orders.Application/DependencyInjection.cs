using Microsoft.Extensions.DependencyInjection;
using Zellamart.Orders.Application.Orders;

namespace Zellamart.Orders.Application;

public static class DependencyInjection
{
    public static IServiceCollection AddOrdersApplication(this IServiceCollection services)
    {
        services.AddScoped<IOrderService, OrderService>();

        return services;
    }
}
