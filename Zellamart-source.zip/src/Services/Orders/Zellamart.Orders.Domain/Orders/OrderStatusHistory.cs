using Zellamart.SharedKernel.Entities;

namespace Zellamart.Orders.Domain.Orders;

public sealed class OrderStatusHistory : BaseEntity
{
    private OrderStatusHistory()
    {
    }

    public OrderStatusHistory(Guid orderId, OrderStatus status, string note, Guid? changedByUserId)
    {
        OrderId = orderId;
        Status = status;
        Note = note.Trim();
        ChangedByUserId = changedByUserId;
        ChangedAtUtc = DateTimeOffset.UtcNow;
    }

    public Guid OrderId { get; private set; }

    public OrderStatus Status { get; private set; }

    public string Note { get; private set; } = string.Empty;

    public Guid? ChangedByUserId { get; private set; }

    public DateTimeOffset ChangedAtUtc { get; private set; }

    public Order Order { get; private set; } = null!;
}
