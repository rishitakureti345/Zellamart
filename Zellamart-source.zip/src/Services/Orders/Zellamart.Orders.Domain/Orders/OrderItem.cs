using Zellamart.SharedKernel.Entities;

namespace Zellamart.Orders.Domain.Orders;

public sealed class OrderItem : BaseEntity
{
    private OrderItem()
    {
    }

    public OrderItem(
        Guid orderId,
        Guid productId,
        Guid sellerId,
        string productName,
        decimal unitPrice,
        int quantity)
    {
        OrderId = orderId;
        ProductId = productId;
        SellerId = sellerId;
        ProductName = productName.Trim();
        UnitPrice = unitPrice;
        Quantity = quantity;
        LineTotal = unitPrice * quantity;
    }

    public Guid OrderId { get; private set; }

    public Guid ProductId { get; private set; }

    public Guid SellerId { get; private set; }

    public string ProductName { get; private set; } = string.Empty;

    public decimal UnitPrice { get; private set; }

    public int Quantity { get; private set; }

    public decimal LineTotal { get; private set; }

    public Order Order { get; private set; } = null!;
}
