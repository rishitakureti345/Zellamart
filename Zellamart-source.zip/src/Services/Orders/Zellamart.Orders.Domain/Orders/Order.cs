using Zellamart.SharedKernel.Entities;

namespace Zellamart.Orders.Domain.Orders;

public sealed class Order : AuditableEntity
{
    private readonly List<OrderItem> _items = [];
    private readonly List<OrderStatusHistory> _statusHistory = [];

    private Order()
    {
    }

    public Order(Guid customerId, string orderNumber, string currency, string shippingAddress, string? deliveryNote)
    {
        CustomerId = customerId;
        OrderNumber = orderNumber.Trim();
        Currency = currency.Trim().ToUpperInvariant();
        ShippingAddress = shippingAddress.Trim();
        DeliveryNote = string.IsNullOrWhiteSpace(deliveryNote) ? null : deliveryNote.Trim();
        Status = OrderStatus.PendingPayment;
        AddStatusHistory(OrderStatus.PendingPayment, "Order created and waiting for payment.", null);
    }

    public Guid CustomerId { get; private set; }

    public string OrderNumber { get; private set; } = string.Empty;

    public OrderStatus Status { get; private set; }

    public decimal Subtotal { get; private set; }

    public string Currency { get; private set; } = "INR";

    public string ShippingAddress { get; private set; } = string.Empty;

    public string? DeliveryNote { get; private set; }

    public IReadOnlyCollection<OrderItem> Items => _items;

    public IReadOnlyCollection<OrderStatusHistory> StatusHistory => _statusHistory;

    public void AddItem(Guid productId, Guid sellerId, string productName, decimal unitPrice, int quantity)
    {
        var item = new OrderItem(Id, productId, sellerId, productName, unitPrice, quantity);
        _items.Add(item);
        Subtotal = _items.Sum(orderItem => orderItem.LineTotal);
    }

    public void MarkPaymentSucceeded(Guid? changedByUserId)
    {
        Status = OrderStatus.PaymentSucceeded;
        UpdatedAtUtc = DateTimeOffset.UtcNow;
        AddStatusHistory(OrderStatus.PaymentSucceeded, "Payment succeeded.", changedByUserId);
    }

    public void MarkPaymentFailed(Guid? changedByUserId)
    {
        Status = OrderStatus.PaymentFailed;
        UpdatedAtUtc = DateTimeOffset.UtcNow;
        AddStatusHistory(OrderStatus.PaymentFailed, "Payment failed.", changedByUserId);
    }

    public void Confirm(Guid? changedByUserId)
    {
        Status = OrderStatus.Confirmed;
        UpdatedAtUtc = DateTimeOffset.UtcNow;
        AddStatusHistory(OrderStatus.Confirmed, "Order confirmed.", changedByUserId);
    }

    public void Cancel(Guid? changedByUserId, string reason)
    {
        Status = OrderStatus.Cancelled;
        UpdatedAtUtc = DateTimeOffset.UtcNow;
        AddStatusHistory(OrderStatus.Cancelled, reason, changedByUserId);
    }

    public void MarkDelivered(Guid? changedByUserId)
    {
        Status = OrderStatus.Delivered;
        UpdatedAtUtc = DateTimeOffset.UtcNow;
        AddStatusHistory(OrderStatus.Delivered, "Order delivered.", changedByUserId);
    }

    public void ForceStatus(OrderStatus status, Guid? changedByUserId, string note)
    {
        Status = status;
        UpdatedAtUtc = DateTimeOffset.UtcNow;
        AddStatusHistory(status, note, changedByUserId);
    }

    private void AddStatusHistory(OrderStatus status, string note, Guid? changedByUserId)
    {
        _statusHistory.Add(new OrderStatusHistory(Id, status, note, changedByUserId));
    }
}
