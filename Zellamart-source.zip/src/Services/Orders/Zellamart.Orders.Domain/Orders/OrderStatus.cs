namespace Zellamart.Orders.Domain.Orders;

public enum OrderStatus
{
    PendingPayment = 1,
    PaymentSucceeded = 2,
    PaymentFailed = 3,
    Confirmed = 4,
    Cancelled = 5,
    Delivered = 6,
    Packed = 7,
    Shipped = 8,
    Refunded = 9
}
