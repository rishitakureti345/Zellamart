namespace Zellamart.Contracts.Events.Inventory;

public sealed record InventoryCreatedEvent(
    Guid EventId,
    DateTimeOffset OccurredAtUtc,
    Guid InventoryItemId,
    Guid ProductId,
    Guid SellerId) : IIntegrationEvent;
