namespace Zellamart.Contracts.Events.Sellers;

public sealed record SellerRejectedEvent(
    Guid EventId,
    DateTimeOffset OccurredAtUtc,
    Guid SellerId,
    Guid RejectedByUserId,
    string Reason) : IIntegrationEvent;
