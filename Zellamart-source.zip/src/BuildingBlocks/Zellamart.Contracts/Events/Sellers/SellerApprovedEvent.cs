namespace Zellamart.Contracts.Events.Sellers;

public sealed record SellerApprovedEvent(
    Guid EventId,
    DateTimeOffset OccurredAtUtc,
    Guid SellerId,
    Guid ApprovedByUserId) : IIntegrationEvent;
