namespace Zellamart.Contracts.Events.Sellers;

public sealed record SellerAppliedEvent(
    Guid EventId,
    DateTimeOffset OccurredAtUtc,
    Guid SellerId,
    Guid UserId,
    string BusinessName,
    string ContactEmail) : IIntegrationEvent;
