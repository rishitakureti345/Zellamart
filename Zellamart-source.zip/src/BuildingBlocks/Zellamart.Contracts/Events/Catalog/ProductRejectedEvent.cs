namespace Zellamart.Contracts.Events.Catalog;

public sealed record ProductRejectedEvent(
    Guid EventId,
    DateTimeOffset OccurredAtUtc,
    Guid ProductId,
    Guid SellerId,
    Guid RejectedByUserId,
    string Reason) : IIntegrationEvent;
