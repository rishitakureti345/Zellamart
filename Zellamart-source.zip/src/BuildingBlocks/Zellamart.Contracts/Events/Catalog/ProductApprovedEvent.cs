namespace Zellamart.Contracts.Events.Catalog;

public sealed record ProductApprovedEvent(
    Guid EventId,
    DateTimeOffset OccurredAtUtc,
    Guid ProductId,
    Guid SellerId,
    string ProductName,
    Guid ApprovedByUserId) : IIntegrationEvent;
