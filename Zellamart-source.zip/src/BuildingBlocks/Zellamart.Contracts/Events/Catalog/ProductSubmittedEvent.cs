namespace Zellamart.Contracts.Events.Catalog;

public sealed record ProductSubmittedEvent(
    Guid EventId,
    DateTimeOffset OccurredAtUtc,
    Guid ProductId,
    Guid SellerId,
    string ProductName) : IIntegrationEvent;
