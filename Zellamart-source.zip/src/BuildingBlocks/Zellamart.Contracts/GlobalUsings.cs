global using Zellamart.Contracts.Events;
