namespace Zellamart.SharedKernel.Results;

public class Result
{
    protected Result(bool success, Error error)
    {
        if (success && error != Error.None)
        {
            throw new InvalidOperationException("Successful results cannot contain an error.");
        }

        if (!success && error == Error.None)
        {
            throw new InvalidOperationException("Failed results must contain an error.");
        }

        Success = success;
        Error = error;
    }

    public bool Success { get; }

    public bool IsFailure => !Success;

    public Error Error { get; }

    public static Result Ok() => new(true, Error.None);

    public static Result Fail(Error error) => new(false, error);

    public static Result<T> Ok<T>(T value) => new(value, true, Error.None);

    public static Result<T> Fail<T>(Error error) => new(default, false, error);
}

public sealed class Result<T> : Result
{
    internal Result(T? value, bool success, Error error)
        : base(success, error)
    {
        Value = value;
    }

    public T? Value { get; }
}
