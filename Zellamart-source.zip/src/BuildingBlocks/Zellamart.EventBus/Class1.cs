﻿namespace Zellamart.EventBus;

public class Class1
{

}
