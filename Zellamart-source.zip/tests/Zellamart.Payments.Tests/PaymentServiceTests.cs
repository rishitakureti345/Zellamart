using Xunit;
using Zellamart.Orders.Domain.Orders;
using Zellamart.Payments.Application.Abstractions;
using Zellamart.Payments.Application.Payments;
using Zellamart.Payments.Domain.Payments;

namespace Zellamart.Payments.Tests;

public sealed class PaymentServiceTests
{
    [Fact]
    public async Task Payment_success_confirms_order_and_deducts_stock()
    {
        var customerId = Guid.NewGuid();
        var orderId = Guid.NewGuid();
        var productId = Guid.NewGuid();
        var repository = new InMemoryPaymentRepository();
        var orderGateway = new FakeOrderGateway();
        var inventoryGateway = new FakeInventoryGateway();
        var notificationGateway = new FakeNotificationGateway();
        orderGateway.AddOrder(new OrderSnapshot(
            orderId,
            customerId,
            OrderStatus.PendingPayment,
            24999,
            "INR",
            [new OrderItemSnapshot(productId, Guid.NewGuid(), "Zella Phone", 24999, 1, 24999)]));

        var service = new PaymentService(repository, orderGateway, inventoryGateway, notificationGateway);

        var started = await service.StartAsync(
            customerId,
            "token",
            new StartPaymentRequest(orderId),
            CancellationToken.None);
        var succeeded = await service.MarkSucceededAsync(customerId, "token", started.Value!.Id, CancellationToken.None);

        Assert.True(started.Success);
        Assert.True(succeeded.Success);
        Assert.Equal(PaymentStatus.Succeeded, succeeded.Value!.Status);
        Assert.Equal(OrderStatus.Confirmed, orderGateway.GetStatus(orderId));
        Assert.Equal(1, inventoryGateway.GetDeductedQuantity(productId));
        Assert.Contains(notificationGateway.Notifications, notification => notification.Type == "OrderConfirmed");
    }

    [Fact]
    public async Task Payment_failure_marks_order_failed_without_deducting_stock()
    {
        var customerId = Guid.NewGuid();
        var orderId = Guid.NewGuid();
        var productId = Guid.NewGuid();
        var repository = new InMemoryPaymentRepository();
        var orderGateway = new FakeOrderGateway();
        var inventoryGateway = new FakeInventoryGateway();
        var notificationGateway = new FakeNotificationGateway();
        orderGateway.AddOrder(new OrderSnapshot(
            orderId,
            customerId,
            OrderStatus.PendingPayment,
            999,
            "INR",
            [new OrderItemSnapshot(productId, Guid.NewGuid(), "Zella Case", 999, 1, 999)]));

        var service = new PaymentService(repository, orderGateway, inventoryGateway, notificationGateway);

        var started = await service.StartAsync(customerId, "token", new StartPaymentRequest(orderId), CancellationToken.None);
        var failed = await service.MarkFailedAsync(
            customerId,
            "token",
            started.Value!.Id,
            new FailPaymentRequest("Card declined."),
            CancellationToken.None);

        Assert.True(failed.Success);
        Assert.Equal(PaymentStatus.Failed, failed.Value!.Status);
        Assert.Equal(OrderStatus.PaymentFailed, orderGateway.GetStatus(orderId));
        Assert.Equal(0, inventoryGateway.GetDeductedQuantity(productId));
        Assert.Contains(notificationGateway.Notifications, notification => notification.Type == "PaymentFailed");
    }

    [Fact]
    public async Task Duplicate_payment_success_is_rejected()
    {
        var customerId = Guid.NewGuid();
        var orderId = Guid.NewGuid();
        var repository = new InMemoryPaymentRepository();
        var orderGateway = new FakeOrderGateway();
        var inventoryGateway = new FakeInventoryGateway();
        var notificationGateway = new FakeNotificationGateway();
        orderGateway.AddOrder(new OrderSnapshot(
            orderId,
            customerId,
            OrderStatus.PendingPayment,
            500,
            "INR",
            [new OrderItemSnapshot(Guid.NewGuid(), Guid.NewGuid(), "Zella Cable", 500, 1, 500)]));

        var service = new PaymentService(repository, orderGateway, inventoryGateway, notificationGateway);

        var started = await service.StartAsync(customerId, "token", new StartPaymentRequest(orderId), CancellationToken.None);
        var firstSuccess = await service.MarkSucceededAsync(customerId, "token", started.Value!.Id, CancellationToken.None);
        var duplicateSuccess = await service.MarkSucceededAsync(customerId, "token", started.Value.Id, CancellationToken.None);

        Assert.True(firstSuccess.Success);
        Assert.False(duplicateSuccess.Success);
        Assert.Equal("Conflict", duplicateSuccess.Error.Code);
    }

    [Fact]
    public async Task Payment_for_missing_order_is_rejected()
    {
        var service = new PaymentService(
            new InMemoryPaymentRepository(),
            new FakeOrderGateway(),
            new FakeInventoryGateway(),
            new FakeNotificationGateway());

        var started = await service.StartAsync(
            Guid.NewGuid(),
            "token",
            new StartPaymentRequest(Guid.NewGuid()),
            CancellationToken.None);

        Assert.False(started.Success);
        Assert.Equal("NotFound", started.Error.Code);
    }

    [Fact]
    public async Task Payment_success_with_insufficient_stock_is_rejected_and_order_stays_pending()
    {
        var customerId = Guid.NewGuid();
        var orderId = Guid.NewGuid();
        var productId = Guid.NewGuid();
        var repository = new InMemoryPaymentRepository();
        var orderGateway = new FakeOrderGateway();
        var inventoryGateway = new FakeInventoryGateway();
        var notificationGateway = new FakeNotificationGateway();
        inventoryGateway.SetAvailableQuantity(productId, 0);
        orderGateway.AddOrder(new OrderSnapshot(
            orderId,
            customerId,
            OrderStatus.PendingPayment,
            24999,
            "INR",
            [new OrderItemSnapshot(productId, Guid.NewGuid(), "Zella Phone", 24999, 1, 24999)]));

        var service = new PaymentService(repository, orderGateway, inventoryGateway, notificationGateway);

        var started = await service.StartAsync(customerId, "token", new StartPaymentRequest(orderId), CancellationToken.None);
        var succeeded = await service.MarkSucceededAsync(customerId, "token", started.Value!.Id, CancellationToken.None);

        var storedPayment = await repository.GetByIdAsync(started.Value.Id, CancellationToken.None);
        Assert.False(succeeded.Success);
        Assert.Equal("Validation", succeeded.Error.Code);
        Assert.Equal(PaymentStatus.Pending, storedPayment!.Status);
        Assert.Equal(OrderStatus.PendingPayment, orderGateway.GetStatus(orderId));
        Assert.Equal(0, inventoryGateway.GetDeductedQuantity(productId));
        Assert.Empty(notificationGateway.Notifications);
    }

    private sealed class InMemoryPaymentRepository : IPaymentRepository
    {
        private readonly List<Payment> _payments = [];

        public Task<Payment?> GetByIdAsync(Guid paymentId, CancellationToken cancellationToken)
        {
            return Task.FromResult(_payments.FirstOrDefault(payment => payment.Id == paymentId));
        }

        public Task<Payment?> GetPendingByOrderIdAsync(Guid orderId, CancellationToken cancellationToken)
        {
            return Task.FromResult(_payments.FirstOrDefault(
                payment => payment.OrderId == orderId && payment.Status == PaymentStatus.Pending));
        }

        public Task<IReadOnlyList<Payment>> GetByOrderIdAsync(Guid orderId, CancellationToken cancellationToken)
        {
            return Task.FromResult<IReadOnlyList<Payment>>(
                _payments.Where(payment => payment.OrderId == orderId).ToArray());
        }

        public Task AddAsync(Payment payment, CancellationToken cancellationToken)
        {
            _payments.Add(payment);
            return Task.CompletedTask;
        }

        public Task SaveChangesAsync(CancellationToken cancellationToken)
        {
            return Task.CompletedTask;
        }
    }

    private sealed class FakeOrderGateway : IOrderGateway
    {
        private readonly Dictionary<Guid, OrderSnapshot> _orders = [];

        public void AddOrder(OrderSnapshot order)
        {
            _orders[order.Id] = order;
        }

        public OrderStatus? GetStatus(Guid orderId)
        {
            return _orders.TryGetValue(orderId, out var order) ? order.Status : null;
        }

        public Task<OrderSnapshot?> GetOrderAsync(
            Guid customerId,
            Guid orderId,
            string bearerToken,
            CancellationToken cancellationToken)
        {
            if (!_orders.TryGetValue(orderId, out var order) || order.CustomerId != customerId)
            {
                return Task.FromResult<OrderSnapshot?>(null);
            }

            return Task.FromResult<OrderSnapshot?>(order);
        }

        public Task<bool> MarkPaymentSucceededAsync(Guid orderId, string bearerToken, CancellationToken cancellationToken)
        {
            return UpdateStatusAsync(orderId, OrderStatus.PaymentSucceeded);
        }

        public Task<bool> MarkPaymentFailedAsync(Guid orderId, string bearerToken, CancellationToken cancellationToken)
        {
            return UpdateStatusAsync(orderId, OrderStatus.PaymentFailed);
        }

        public Task<bool> ConfirmAsync(Guid orderId, string bearerToken, CancellationToken cancellationToken)
        {
            return UpdateStatusAsync(orderId, OrderStatus.Confirmed);
        }

        private Task<bool> UpdateStatusAsync(Guid orderId, OrderStatus status)
        {
            if (!_orders.TryGetValue(orderId, out var order))
            {
                return Task.FromResult(false);
            }

            _orders[orderId] = order with { Status = status };
            return Task.FromResult(true);
        }
    }

    private sealed class FakeInventoryGateway : IInventoryGateway
    {
        private readonly Dictionary<Guid, int> _deductedQuantities = [];
        private readonly Dictionary<Guid, int> _availableQuantities = [];

        public void SetAvailableQuantity(Guid productId, int quantity)
        {
            _availableQuantities[productId] = quantity;
        }

        public Task<bool> HasAvailableStockAsync(
            Guid productId,
            int quantity,
            string bearerToken,
            CancellationToken cancellationToken)
        {
            return Task.FromResult(_availableQuantities.GetValueOrDefault(productId, 10) >= quantity);
        }

        public Task<bool> DeductStockAsync(
            Guid productId,
            int quantity,
            Guid orderId,
            string bearerToken,
            CancellationToken cancellationToken)
        {
            _deductedQuantities[productId] = GetDeductedQuantity(productId) + quantity;
            return Task.FromResult(true);
        }

        public int GetDeductedQuantity(Guid productId)
        {
            return _deductedQuantities.GetValueOrDefault(productId);
        }
    }

    private sealed class FakeNotificationGateway : INotificationGateway
    {
        public List<NotificationCall> Notifications { get; } = [];

        public Task CreateAsync(
            Guid userId,
            string type,
            string title,
            string message,
            string bearerToken,
            CancellationToken cancellationToken)
        {
            Notifications.Add(new NotificationCall(userId, type, title, message));
            return Task.CompletedTask;
        }
    }

    private sealed record NotificationCall(Guid UserId, string Type, string Title, string Message);
}
