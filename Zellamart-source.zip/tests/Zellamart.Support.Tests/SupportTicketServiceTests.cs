using Xunit;
using Zellamart.Support.Application.Abstractions;
using Zellamart.Support.Application.Tickets;
using Zellamart.Support.Domain.Tickets;

namespace Zellamart.Support.Tests;

public sealed class SupportTicketServiceTests
{
    [Fact]
    public async Task Create_get_mine_message_assign_resolve_and_close_work()
    {
        var repository = new InMemorySupportTicketRepository();
        var orderGateway = new FakeOrderGateway();
        var notifications = new FakeNotificationGateway();
        var service = new SupportTicketService(repository, orderGateway, notifications);
        var customerId = Guid.NewGuid();
        var agentId = Guid.NewGuid();
        var orderId = Guid.NewGuid();
        orderGateway.Allow(customerId, orderId);

        var created = await service.CreateAsync(
            customerId,
            "token",
            new CreateSupportTicketRequest(
                orderId,
                SupportTicketType.ProductIssue,
                "Product damaged",
                "The product arrived damaged."),
            CancellationToken.None);
        var mine = await service.GetMineAsync(customerId, CancellationToken.None);
        var customerMessage = await service.AddMessageAsync(
            customerId,
            created.Value!.Id,
            new AddSupportTicketMessageRequest("My product is damaged."),
            CancellationToken.None);
        var assigned = await service.AssignAsync(
            agentId,
            created.Value.Id,
            new AssignSupportTicketRequest(agentId),
            CancellationToken.None);
        var supportMessage = await service.AddMessageAsync(
            agentId,
            created.Value.Id,
            new AddSupportTicketMessageRequest("Please upload photo."),
            CancellationToken.None);
        var resolved = await service.ResolveAsync(agentId, created.Value.Id, CancellationToken.None);
        var closed = await service.CloseAsync(customerId, created.Value.Id, CancellationToken.None);

        Assert.True(created.Success);
        Assert.Equal(SupportTicketStatus.Open, created.Value.Status);
        Assert.True(mine.Success);
        Assert.Single(mine.Value!);
        Assert.True(customerMessage.Success);
        Assert.Single(customerMessage.Value!.Messages);
        Assert.True(assigned.Success);
        Assert.Equal(SupportTicketStatus.InProgress, assigned.Value!.Status);
        Assert.Equal(agentId, assigned.Value.AssignedAgentId);
        Assert.True(supportMessage.Success);
        Assert.Equal(2, supportMessage.Value!.Messages.Count);
        Assert.True(resolved.Success);
        Assert.Equal(SupportTicketStatus.Resolved, resolved.Value!.Status);
        Assert.True(closed.Success);
        Assert.Equal(SupportTicketStatus.Closed, closed.Value!.Status);
        Assert.Contains(notifications.Notifications, notification => notification.Type == "SupportTicketCreated");
        Assert.Contains(notifications.Notifications, notification => notification.Type == "SupportTicketResolved");
    }

    [Fact]
    public async Task Empty_subject_invalid_order_and_other_customer_access_are_rejected()
    {
        var repository = new InMemorySupportTicketRepository();
        var orderGateway = new FakeOrderGateway();
        var service = new SupportTicketService(repository, orderGateway, new FakeNotificationGateway());
        var customerId = Guid.NewGuid();
        var otherCustomerId = Guid.NewGuid();
        var orderId = Guid.NewGuid();
        orderGateway.Allow(customerId, orderId);

        var emptySubject = await service.CreateAsync(
            customerId,
            "token",
            new CreateSupportTicketRequest(orderId, SupportTicketType.OrderIssue, "", "Need help."),
            CancellationToken.None);
        var invalidOrder = await service.CreateAsync(
            customerId,
            "token",
            new CreateSupportTicketRequest(Guid.NewGuid(), SupportTicketType.OrderIssue, "Order issue", "Need help."),
            CancellationToken.None);
        var created = await service.CreateAsync(
            customerId,
            "token",
            new CreateSupportTicketRequest(orderId, SupportTicketType.DeliveryIssue, "Late delivery", "It is late."),
            CancellationToken.None);
        var otherCustomerLookup = await service.GetByIdAsync(otherCustomerId, created.Value!.Id, CancellationToken.None);
        var otherCustomerMessage = await service.AddMessageAsync(
            otherCustomerId,
            created.Value.Id,
            new AddSupportTicketMessageRequest("I should not see this."),
            CancellationToken.None);

        Assert.False(emptySubject.Success);
        Assert.Equal("Validation", emptySubject.Error.Code);
        Assert.False(invalidOrder.Success);
        Assert.Equal("Validation", invalidOrder.Error.Code);
        Assert.True(created.Success);
        Assert.False(otherCustomerLookup.Success);
        Assert.Equal("NotFound", otherCustomerLookup.Error.Code);
        Assert.False(otherCustomerMessage.Success);
        Assert.Equal("NotFound", otherCustomerMessage.Error.Code);
    }

    [Fact]
    public async Task Invalid_status_transition_and_wrong_agent_are_rejected()
    {
        var repository = new InMemorySupportTicketRepository();
        var orderGateway = new FakeOrderGateway();
        var service = new SupportTicketService(repository, orderGateway, new FakeNotificationGateway());
        var customerId = Guid.NewGuid();
        var agentId = Guid.NewGuid();
        var orderId = Guid.NewGuid();
        orderGateway.Allow(customerId, orderId);

        var created = await service.CreateAsync(
            customerId,
            "token",
            new CreateSupportTicketRequest(orderId, SupportTicketType.PaymentIssue, "Payment failed", "Money debited."),
            CancellationToken.None);
        var resolveBeforeAssign = await service.ResolveAsync(agentId, created.Value!.Id, CancellationToken.None);
        await service.AssignAsync(agentId, created.Value.Id, new AssignSupportTicketRequest(agentId), CancellationToken.None);
        var wrongAgentResolve = await service.ResolveAsync(Guid.NewGuid(), created.Value.Id, CancellationToken.None);

        Assert.False(resolveBeforeAssign.Success);
        Assert.Equal("Unauthorized", resolveBeforeAssign.Error.Code);
        Assert.False(wrongAgentResolve.Success);
        Assert.Equal("Unauthorized", wrongAgentResolve.Error.Code);
    }

    private sealed class InMemorySupportTicketRepository : ISupportTicketRepository
    {
        private readonly List<SupportTicket> _tickets = [];

        public Task<SupportTicket?> GetByIdAsync(Guid ticketId, CancellationToken cancellationToken)
        {
            return Task.FromResult(_tickets.FirstOrDefault(ticket => ticket.Id == ticketId));
        }

        public Task<IReadOnlyList<SupportTicket>> GetByCustomerIdAsync(Guid customerId, CancellationToken cancellationToken)
        {
            return Task.FromResult<IReadOnlyList<SupportTicket>>(
                _tickets.Where(ticket => ticket.CustomerId == customerId).ToArray());
        }

        public Task<IReadOnlyList<SupportTicket>> GetAllAsync(CancellationToken cancellationToken)
        {
            return Task.FromResult<IReadOnlyList<SupportTicket>>(_tickets.ToArray());
        }

        public Task AddAsync(SupportTicket ticket, CancellationToken cancellationToken)
        {
            _tickets.Add(ticket);
            return Task.CompletedTask;
        }

        public Task SaveChangesAsync(CancellationToken cancellationToken)
        {
            return Task.CompletedTask;
        }
    }

    private sealed class FakeOrderGateway : IOrderGateway
    {
        private readonly HashSet<(Guid CustomerId, Guid OrderId)> _allowedOrders = [];

        public void Allow(Guid customerId, Guid orderId)
        {
            _allowedOrders.Add((customerId, orderId));
        }

        public Task<bool> ExistsForCustomerAsync(
            Guid customerId,
            Guid orderId,
            string bearerToken,
            CancellationToken cancellationToken)
        {
            return Task.FromResult(_allowedOrders.Contains((customerId, orderId)));
        }

        public Task<OrderSnapshot?> GetOrderAsync(
            Guid customerId,
            Guid orderId,
            string bearerToken,
            CancellationToken cancellationToken)
        {
            return Task.FromResult<OrderSnapshot?>(
                _allowedOrders.Contains((customerId, orderId))
                    ? new OrderSnapshot(orderId, customerId, "Delivered", [])
                    : null);
        }
    }

    private sealed class FakeNotificationGateway : INotificationGateway
    {
        public List<NotificationCall> Notifications { get; } = [];

        public Task CreateAsync(
            Guid userId,
            string type,
            string title,
            string message,
            CancellationToken cancellationToken)
        {
            Notifications.Add(new NotificationCall(userId, type, title, message));
            return Task.CompletedTask;
        }
    }

    private sealed record NotificationCall(Guid UserId, string Type, string Title, string Message);
}
