using Xunit;
using Zellamart.Support.Application.Abstractions;
using Zellamart.Support.Application.Returns;
using Zellamart.Support.Domain.Returns;

namespace Zellamart.Support.Tests;

public sealed class ReturnRequestServiceTests
{
    [Fact]
    public async Task Create_approve_pickup_and_refund_work()
    {
        var repository = new InMemoryReturnRequestRepository();
        var orderGateway = new FakeOrderGateway();
        var notifications = new FakeNotificationGateway();
        var service = new ReturnRequestService(repository, orderGateway, notifications);
        var customerId = Guid.NewGuid();
        var supportUserId = Guid.NewGuid();
        var order = orderGateway.AddDeliveredOrder(customerId);
        var item = order.Items[0];

        var created = await service.CreateAsync(
            customerId,
            "token",
            new CreateReturnRequestRequest(order.Id, item.Id, item.ProductId, "Product is damaged."),
            CancellationToken.None);
        var mine = await service.GetMineAsync(customerId, CancellationToken.None);
        var approved = await service.ApproveAsync(supportUserId, created.Value!.Id, CancellationToken.None);
        var pickedUp = await service.MarkPickedUpAsync(supportUserId, created.Value.Id, CancellationToken.None);
        var refunded = await service.MarkRefundedAsync(supportUserId, created.Value.Id, CancellationToken.None);

        Assert.True(created.Success);
        Assert.Equal(ReturnRequestStatus.Requested, created.Value.Status);
        Assert.Equal(item.LineTotal, created.Value.RefundAmount);
        Assert.True(mine.Success);
        Assert.Single(mine.Value!);
        Assert.True(approved.Success);
        Assert.Equal(ReturnRequestStatus.Approved, approved.Value!.Status);
        Assert.True(pickedUp.Success);
        Assert.Equal(ReturnRequestStatus.PickedUp, pickedUp.Value!.Status);
        Assert.True(refunded.Success);
        Assert.Equal(ReturnRequestStatus.Refunded, refunded.Value!.Status);
        Assert.Equal(6, refunded.Value.StatusHistory.Count);
        Assert.Contains(notifications.Notifications, notification => notification.Type == "ReturnRequested");
        Assert.Contains(notifications.Notifications, notification => notification.Type == "ReturnRefunded");
    }

    [Fact]
    public async Task Reject_return_works()
    {
        var repository = new InMemoryReturnRequestRepository();
        var orderGateway = new FakeOrderGateway();
        var service = new ReturnRequestService(repository, orderGateway, new FakeNotificationGateway());
        var customerId = Guid.NewGuid();
        var order = orderGateway.AddDeliveredOrder(customerId);
        var item = order.Items[0];

        var created = await service.CreateAsync(
            customerId,
            "token",
            new CreateReturnRequestRequest(order.Id, item.Id, item.ProductId, "Wrong item."),
            CancellationToken.None);
        var rejected = await service.RejectAsync(Guid.NewGuid(), created.Value!.Id, CancellationToken.None);

        Assert.True(rejected.Success);
        Assert.Equal(ReturnRequestStatus.Rejected, rejected.Value!.Status);
    }

    [Fact]
    public async Task Order_not_delivered_invalid_product_duplicate_and_other_customer_order_are_rejected()
    {
        var repository = new InMemoryReturnRequestRepository();
        var orderGateway = new FakeOrderGateway();
        var service = new ReturnRequestService(repository, orderGateway, new FakeNotificationGateway());
        var customerId = Guid.NewGuid();
        var otherCustomerId = Guid.NewGuid();
        var deliveredOrder = orderGateway.AddDeliveredOrder(customerId);
        var notDeliveredOrder = orderGateway.AddOrder(customerId, "Confirmed");
        var otherCustomerOrder = orderGateway.AddDeliveredOrder(otherCustomerId);
        var item = deliveredOrder.Items[0];

        var notDelivered = await service.CreateAsync(
            customerId,
            "token",
            new CreateReturnRequestRequest(
                notDeliveredOrder.Id,
                notDeliveredOrder.Items[0].Id,
                notDeliveredOrder.Items[0].ProductId,
                "Need return."),
            CancellationToken.None);
        var invalidProduct = await service.CreateAsync(
            customerId,
            "token",
            new CreateReturnRequestRequest(deliveredOrder.Id, item.Id, Guid.NewGuid(), "Need return."),
            CancellationToken.None);
        var created = await service.CreateAsync(
            customerId,
            "token",
            new CreateReturnRequestRequest(deliveredOrder.Id, item.Id, item.ProductId, "Need return."),
            CancellationToken.None);
        var duplicate = await service.CreateAsync(
            customerId,
            "token",
            new CreateReturnRequestRequest(deliveredOrder.Id, item.Id, item.ProductId, "Need return again."),
            CancellationToken.None);
        var otherCustomerOrderResult = await service.CreateAsync(
            customerId,
            "token",
            new CreateReturnRequestRequest(
                otherCustomerOrder.Id,
                otherCustomerOrder.Items[0].Id,
                otherCustomerOrder.Items[0].ProductId,
                "Not mine."),
            CancellationToken.None);

        Assert.False(notDelivered.Success);
        Assert.Equal("Validation", notDelivered.Error.Code);
        Assert.False(invalidProduct.Success);
        Assert.Equal("Validation", invalidProduct.Error.Code);
        Assert.True(created.Success);
        Assert.False(duplicate.Success);
        Assert.Equal("Conflict", duplicate.Error.Code);
        Assert.False(otherCustomerOrderResult.Success);
        Assert.Equal("Validation", otherCustomerOrderResult.Error.Code);
    }

    [Fact]
    public async Task Invalid_status_transition_is_rejected()
    {
        var repository = new InMemoryReturnRequestRepository();
        var orderGateway = new FakeOrderGateway();
        var service = new ReturnRequestService(repository, orderGateway, new FakeNotificationGateway());
        var customerId = Guid.NewGuid();
        var order = orderGateway.AddDeliveredOrder(customerId);
        var item = order.Items[0];

        var created = await service.CreateAsync(
            customerId,
            "token",
            new CreateReturnRequestRequest(order.Id, item.Id, item.ProductId, "Need return."),
            CancellationToken.None);
        var refundBeforeApproval = await service.MarkRefundedAsync(Guid.NewGuid(), created.Value!.Id, CancellationToken.None);

        Assert.False(refundBeforeApproval.Success);
        Assert.Equal("Validation", refundBeforeApproval.Error.Code);
    }

    private sealed class InMemoryReturnRequestRepository : IReturnRequestRepository
    {
        private readonly List<ReturnRequest> _returns = [];

        public Task<ReturnRequest?> GetByIdAsync(Guid returnId, CancellationToken cancellationToken)
        {
            return Task.FromResult(_returns.FirstOrDefault(returnRequest => returnRequest.Id == returnId));
        }

        public Task<ReturnRequest?> GetByOrderItemIdAsync(Guid orderItemId, CancellationToken cancellationToken)
        {
            return Task.FromResult(_returns.FirstOrDefault(returnRequest => returnRequest.OrderItemId == orderItemId));
        }

        public Task<IReadOnlyList<ReturnRequest>> GetByCustomerIdAsync(Guid customerId, CancellationToken cancellationToken)
        {
            return Task.FromResult<IReadOnlyList<ReturnRequest>>(
                _returns.Where(returnRequest => returnRequest.CustomerId == customerId).ToArray());
        }

        public Task<IReadOnlyList<ReturnRequest>> GetAllAsync(CancellationToken cancellationToken)
        {
            return Task.FromResult<IReadOnlyList<ReturnRequest>>(_returns.ToArray());
        }

        public Task AddAsync(ReturnRequest returnRequest, CancellationToken cancellationToken)
        {
            _returns.Add(returnRequest);
            return Task.CompletedTask;
        }

        public Task SaveChangesAsync(CancellationToken cancellationToken)
        {
            return Task.CompletedTask;
        }
    }

    private sealed class FakeOrderGateway : IOrderGateway
    {
        private readonly List<OrderSnapshot> _orders = [];

        public OrderSnapshot AddDeliveredOrder(Guid customerId)
        {
            return AddOrder(customerId, "Delivered");
        }

        public OrderSnapshot AddOrder(Guid customerId, string status)
        {
            var order = new OrderSnapshot(
                Guid.NewGuid(),
                customerId,
                status,
                [new OrderItemSnapshot(Guid.NewGuid(), Guid.NewGuid(), 4999)]);

            _orders.Add(order);
            return order;
        }

        public Task<bool> ExistsForCustomerAsync(
            Guid customerId,
            Guid orderId,
            string bearerToken,
            CancellationToken cancellationToken)
        {
            return Task.FromResult(_orders.Any(order => order.Id == orderId && order.CustomerId == customerId));
        }

        public Task<OrderSnapshot?> GetOrderAsync(
            Guid customerId,
            Guid orderId,
            string bearerToken,
            CancellationToken cancellationToken)
        {
            return Task.FromResult(_orders.FirstOrDefault(order => order.Id == orderId && order.CustomerId == customerId));
        }
    }

    private sealed class FakeNotificationGateway : INotificationGateway
    {
        public List<NotificationCall> Notifications { get; } = [];

        public Task CreateAsync(
            Guid userId,
            string type,
            string title,
            string message,
            CancellationToken cancellationToken)
        {
            Notifications.Add(new NotificationCall(userId, type, title, message));
            return Task.CompletedTask;
        }
    }

    private sealed record NotificationCall(Guid UserId, string Type, string Title, string Message);
}
