using Zellamart.Cart.Application.Abstractions;
using Zellamart.Cart.Application.Carts;
using Zellamart.Cart.Domain.Carts;

namespace Zellamart.Cart.Tests;

public sealed class CartServiceTests
{
    [Fact]
    public async Task Add_update_remove_clear_and_totals_work()
    {
        var productGateway = new FakeProductGateway();
        var inventoryGateway = new FakeInventoryGateway();
        var service = new CartService(new InMemoryCartRepository(), productGateway, inventoryGateway);
        var customerId = Guid.NewGuid();
        var productId = Guid.NewGuid();
        var sellerId = Guid.NewGuid();
        productGateway.Add(productId, sellerId, "Zella Phone", 24999, "INR");
        inventoryGateway.SetAvailable(productId, 10);

        var added = await service.AddItemAsync(
            customerId,
            new AddCartItemRequest(productId, sellerId, "Zella Phone", 24999, 2, "INR"),
            "token",
            CancellationToken.None);

        Assert.True(added.Success);
        Assert.Equal(2, added.Value!.TotalItems);
        Assert.Equal(49998, added.Value.Subtotal);
        Assert.Equal("INR", added.Value.Currency);
        var itemId = Assert.Single(added.Value.Items).Id;

        var updated = await service.UpdateItemAsync(
            customerId,
            itemId,
            new UpdateCartItemRequest(3),
            "token",
            CancellationToken.None);

        Assert.True(updated.Success);
        Assert.Equal(3, updated.Value!.TotalItems);
        Assert.Equal(74997, updated.Value.Subtotal);

        var removed = await service.RemoveItemAsync(customerId, itemId, CancellationToken.None);

        Assert.True(removed.Success);
        Assert.Empty(removed.Value!.Items);
        Assert.Equal(0, removed.Value.TotalItems);
        Assert.Equal(0, removed.Value.Subtotal);

        await service.AddItemAsync(
            customerId,
            new AddCartItemRequest(productId, sellerId, "Zella Phone", 24999, 1, "INR"),
            "token",
            CancellationToken.None);

        var cleared = await service.ClearAsync(customerId, CancellationToken.None);

        Assert.True(cleared.Success);
        Assert.Empty(cleared.Value!.Items);
        Assert.Equal(0, cleared.Value.TotalItems);
        Assert.Equal(0, cleared.Value.Subtotal);
    }

    [Fact]
    public async Task Negative_cases_are_rejected()
    {
        var productGateway = new FakeProductGateway();
        var inventoryGateway = new FakeInventoryGateway();
        var service = new CartService(new InMemoryCartRepository(), productGateway, inventoryGateway);
        var customerId = Guid.NewGuid();
        var otherCustomerId = Guid.NewGuid();
        var productId = Guid.NewGuid();
        var sellerId = Guid.NewGuid();
        productGateway.Add(productId, sellerId, "Zella Phone", 24999, "INR");
        inventoryGateway.SetAvailable(productId, 10);

        var invalidQuantity = await service.AddItemAsync(
            customerId,
            new AddCartItemRequest(productId, sellerId, "Zella Phone", 24999, 0, "INR"),
            "token",
            CancellationToken.None);

        Assert.False(invalidQuantity.Success);
        Assert.Equal("Validation", invalidQuantity.Error.Code);

        var added = await service.AddItemAsync(
            customerId,
            new AddCartItemRequest(productId, sellerId, "Zella Phone", 24999, 1, "INR"),
            "token",
            CancellationToken.None);
        var duplicate = await service.AddItemAsync(
            customerId,
            new AddCartItemRequest(productId, sellerId, "Zella Phone", 24999, 1, "INR"),
            "token",
            CancellationToken.None);

        Assert.True(added.Success);
        Assert.False(duplicate.Success);
        Assert.Equal("Conflict", duplicate.Error.Code);

        var itemId = Assert.Single(added.Value!.Items).Id;
        var otherCustomerUpdate = await service.UpdateItemAsync(
            otherCustomerId,
            itemId,
            new UpdateCartItemRequest(2),
            "token",
            CancellationToken.None);

        Assert.False(otherCustomerUpdate.Success);
        Assert.Equal("NotFound", otherCustomerUpdate.Error.Code);
    }

    [Fact]
    public async Task Add_item_rejects_unapproved_or_out_of_stock_products()
    {
        var productGateway = new FakeProductGateway();
        var inventoryGateway = new FakeInventoryGateway();
        var service = new CartService(new InMemoryCartRepository(), productGateway, inventoryGateway);
        var customerId = Guid.NewGuid();
        var productId = Guid.NewGuid();
        var sellerId = Guid.NewGuid();

        var unavailable = await service.AddItemAsync(
            customerId,
            new AddCartItemRequest(productId, sellerId, "Pending Product", 100, 1, "INR"),
            "token",
            CancellationToken.None);

        productGateway.Add(productId, sellerId, "Approved Product", 100, "INR");
        inventoryGateway.SetAvailable(productId, 0);

        var outOfStock = await service.AddItemAsync(
            customerId,
            new AddCartItemRequest(productId, sellerId, "Approved Product", 100, 1, "INR"),
            "token",
            CancellationToken.None);

        Assert.False(unavailable.Success);
        Assert.Equal("Validation", unavailable.Error.Code);
        Assert.False(outOfStock.Success);
        Assert.Equal("Validation", outOfStock.Error.Code);
    }

    private sealed class InMemoryCartRepository : ICartRepository
    {
        private readonly List<Domain.Carts.Cart> _carts = [];

        public Task<Domain.Carts.Cart?> GetActiveByCustomerIdAsync(Guid customerId, CancellationToken cancellationToken)
        {
            return Task.FromResult(_carts.FirstOrDefault(cart =>
                cart.CustomerId == customerId && cart.Status == CartStatus.Active));
        }

        public Task AddAsync(Domain.Carts.Cart cart, CancellationToken cancellationToken)
        {
            _carts.Add(cart);
            return Task.CompletedTask;
        }

        public Task SaveChangesAsync(CancellationToken cancellationToken)
        {
            return Task.CompletedTask;
        }
    }

    private sealed class FakeProductGateway : IProductGateway
    {
        private readonly Dictionary<Guid, ProductSnapshot> _products = [];

        public Task<ProductSnapshot?> GetApprovedAsync(Guid productId, CancellationToken cancellationToken)
        {
            _products.TryGetValue(productId, out var product);
            return Task.FromResult(product);
        }

        public void Add(Guid productId, Guid sellerId, string name, decimal price, string currency)
        {
            _products[productId] = new ProductSnapshot(productId, sellerId, name, price, currency);
        }
    }

    private sealed class FakeInventoryGateway : IInventoryGateway
    {
        private readonly Dictionary<Guid, int> _available = [];

        public Task<bool> HasAvailableStockAsync(
            Guid productId,
            int quantity,
            string bearerToken,
            CancellationToken cancellationToken)
        {
            return Task.FromResult(
                !string.IsNullOrWhiteSpace(bearerToken) &&
                _available.TryGetValue(productId, out var available) &&
                available >= quantity);
        }

        public void SetAvailable(Guid productId, int availableQuantity)
        {
            _available[productId] = availableQuantity;
        }
    }
}
