using Xunit;
using Zellamart.Orders.Application.Abstractions;
using Zellamart.Orders.Application.Orders;
using Zellamart.Orders.Domain.Orders;
using Zellamart.Payments.Application.Payments;
using Zellamart.Payments.Domain.Payments;
using Zellamart.Shipping.Application.Shipments;
using Zellamart.Shipping.Domain.Shipments;
using Zellamart.Support.Application.Returns;
using Zellamart.Support.Application.Tickets;
using Zellamart.Support.Domain.Returns;
using Zellamart.Support.Domain.Tickets;
using PaymentAbstractions = Zellamart.Payments.Application.Abstractions;
using ShippingAbstractions = Zellamart.Shipping.Application.Abstractions;
using SupportAbstractions = Zellamart.Support.Application.Abstractions;

namespace Zellamart.Month3.Tests;

public sealed class Month3FullFlowTests
{
    [Fact]
    public async Task Customer_order_shipping_support_return_and_refund_flow_works()
    {
        var cancellationToken = CancellationToken.None;
        var customerId = Guid.NewGuid();
        var sellerId = Guid.NewGuid();
        var productId = Guid.NewGuid();
        var deliveryPartnerId = Guid.NewGuid();
        var supportAgentId = Guid.NewGuid();
        var notifications = new FakeNotificationGateway();

        var orderRepository = new InMemoryOrderRepository();
        var orderCartGateway = new FakeOrderCartGateway();
        orderCartGateway.SetCart(customerId, "INR", [
            new CartItemSnapshot(Guid.NewGuid(), productId, sellerId, "Month 3 Demo Phone", 25000, 1, "INR", 25000)
        ]);
        var orderService = new OrderService(orderRepository, orderCartGateway);
        var paymentRepository = new InMemoryPaymentRepository();
        var paymentOrderGateway = new PaymentOrderGateway(orderService);
        var inventoryGateway = new FakeInventoryGateway();
        var paymentService = new PaymentService(paymentRepository, paymentOrderGateway, inventoryGateway, notifications);
        var shippingService = new ShipmentService(new InMemoryShipmentRepository(), notifications);
        var supportOrderGateway = new SupportOrderGateway(orderService);
        var ticketService = new SupportTicketService(new InMemorySupportTicketRepository(), supportOrderGateway, notifications);
        var returnService = new ReturnRequestService(new InMemoryReturnRequestRepository(), supportOrderGateway, notifications);

        var order = await orderService.CreateFromCartAsync(
            customerId,
            new CreateOrderFromCartRequest("Hyderabad, Telangana", null),
            "token",
            cancellationToken);
        var payment = await paymentService.StartAsync(customerId, "token", new StartPaymentRequest(order.Value!.Id), cancellationToken);
        var paymentSucceeded = await paymentService.MarkSucceededAsync(customerId, "token", payment.Value!.Id, cancellationToken);
        var confirmedOrder = await orderService.GetByIdAsync(customerId, order.Value.Id, cancellationToken);

        var shipment = await shippingService.CreateForOrderAsync(
            customerId,
            new CreateShipmentForOrderRequest(order.Value.Id, "Hyderabad, Telangana"),
            cancellationToken);
        await shippingService.PackAsync(shipment.Value!.Id, customerId, cancellationToken);
        await shippingService.ShipAsync(shipment.Value.Id, customerId, cancellationToken);
        await shippingService.AssignPartnerAsync(
            shipment.Value.Id,
            customerId,
            new AssignDeliveryPartnerRequest(deliveryPartnerId),
            cancellationToken);
        await shippingService.MarkOutForDeliveryAsync(shipment.Value.Id, customerId, cancellationToken);
        var deliveredShipment = await shippingService.MarkDeliveredAsync(shipment.Value.Id, customerId, cancellationToken);
        var deliveredOrder = await orderService.MarkDeliveredAsync(customerId, order.Value.Id, cancellationToken);

        var ticket = await ticketService.CreateAsync(
            customerId,
            "token",
            new CreateSupportTicketRequest(order.Value.Id, SupportTicketType.ProductIssue, "Product damaged", "The box was damaged."),
            cancellationToken);
        await ticketService.AddMessageAsync(
            customerId,
            ticket.Value!.Id,
            new AddSupportTicketMessageRequest("My product is damaged."),
            cancellationToken);
        await ticketService.AssignAsync(
            supportAgentId,
            ticket.Value.Id,
            new AssignSupportTicketRequest(supportAgentId),
            cancellationToken);
        var resolvedTicket = await ticketService.ResolveAsync(supportAgentId, ticket.Value.Id, cancellationToken);

        var orderItem = deliveredOrder.Value!.Items.Single();
        var returnRequest = await returnService.CreateAsync(
            customerId,
            "token",
            new CreateReturnRequestRequest(order.Value.Id, orderItem.Id, productId, "Product damaged."),
            cancellationToken);
        var approvedReturn = await returnService.ApproveAsync(supportAgentId, returnRequest.Value!.Id, cancellationToken);
        await returnService.MarkPickedUpAsync(supportAgentId, returnRequest.Value.Id, cancellationToken);
        var refundedReturn = await returnService.MarkRefundedAsync(supportAgentId, returnRequest.Value.Id, cancellationToken);

        Assert.True(order.Success);
        Assert.True(paymentSucceeded.Success);
        Assert.Equal(PaymentStatus.Succeeded, paymentSucceeded.Value!.Status);
        Assert.Equal(OrderStatus.Confirmed, confirmedOrder.Value!.Status);
        Assert.Equal(ShipmentStatus.Delivered, deliveredShipment.Value!.Status);
        Assert.Equal(OrderStatus.Delivered, deliveredOrder.Value.Status);
        Assert.Equal(SupportTicketStatus.Resolved, resolvedTicket.Value!.Status);
        Assert.Equal(ReturnRequestStatus.Approved, approvedReturn.Value!.Status);
        Assert.Equal(ReturnRequestStatus.Refunded, refundedReturn.Value!.Status);
        Assert.Contains(notifications.Notifications, notification => notification.Type == "OrderConfirmed");
        Assert.Contains(notifications.Notifications, notification => notification.Type == "ShipmentDelivered");
        Assert.Contains(notifications.Notifications, notification => notification.Type == "SupportTicketCreated");
        Assert.Contains(notifications.Notifications, notification => notification.Type == "ReturnRefunded");
    }

    private sealed class FakeOrderCartGateway : ICartGateway
    {
        private CartSnapshot? _cart;

        public Task<CartSnapshot?> GetMineAsync(string bearerToken, CancellationToken cancellationToken)
        {
            return Task.FromResult(string.IsNullOrWhiteSpace(bearerToken) ? null : _cart);
        }

        public Task ClearMineAsync(string bearerToken, CancellationToken cancellationToken)
        {
            _cart = _cart is null
                ? null
                : _cart with { Items = [] };
            return Task.CompletedTask;
        }

        public void SetCart(Guid customerId, string currency, IReadOnlyList<CartItemSnapshot> items)
        {
            _cart = new CartSnapshot(
                Guid.NewGuid(),
                customerId,
                items,
                items.Sum(item => item.LineTotal),
                items.Sum(item => item.Quantity),
                currency);
        }
    }

    private sealed class InMemoryOrderRepository : IOrderRepository
    {
        private readonly List<Order> _orders = [];

        public Task<Order?> GetByIdAsync(Guid orderId, CancellationToken cancellationToken)
        {
            return Task.FromResult(_orders.FirstOrDefault(order => order.Id == orderId));
        }

        public Task<IReadOnlyList<Order>> GetByCustomerIdAsync(Guid customerId, CancellationToken cancellationToken)
        {
            return Task.FromResult<IReadOnlyList<Order>>(_orders.Where(order => order.CustomerId == customerId).ToArray());
        }

        public Task<IReadOnlyList<Order>> GetBySellerIdAsync(Guid sellerId, CancellationToken cancellationToken)
        {
            return Task.FromResult<IReadOnlyList<Order>>(_orders.Where(order => order.Items.Any(item => item.SellerId == sellerId)).ToArray());
        }

        public Task<IReadOnlyList<Order>> GetAllAsync(CancellationToken cancellationToken)
        {
            return Task.FromResult<IReadOnlyList<Order>>(_orders.ToArray());
        }

        public Task AddAsync(Order order, CancellationToken cancellationToken)
        {
            _orders.Add(order);
            return Task.CompletedTask;
        }

        public Task SaveChangesAsync(CancellationToken cancellationToken) => Task.CompletedTask;
    }

    private sealed class InMemoryPaymentRepository : PaymentAbstractions.IPaymentRepository
    {
        private readonly List<Payment> _payments = [];

        public Task<Payment?> GetByIdAsync(Guid paymentId, CancellationToken cancellationToken)
        {
            return Task.FromResult(_payments.FirstOrDefault(payment => payment.Id == paymentId));
        }

        public Task<Payment?> GetPendingByOrderIdAsync(Guid orderId, CancellationToken cancellationToken)
        {
            return Task.FromResult(_payments.FirstOrDefault(payment => payment.OrderId == orderId && payment.Status == PaymentStatus.Pending));
        }

        public Task<IReadOnlyList<Payment>> GetByOrderIdAsync(Guid orderId, CancellationToken cancellationToken)
        {
            return Task.FromResult<IReadOnlyList<Payment>>(_payments.Where(payment => payment.OrderId == orderId).ToArray());
        }

        public Task AddAsync(Payment payment, CancellationToken cancellationToken)
        {
            _payments.Add(payment);
            return Task.CompletedTask;
        }

        public Task SaveChangesAsync(CancellationToken cancellationToken) => Task.CompletedTask;
    }

    private sealed class PaymentOrderGateway : PaymentAbstractions.IOrderGateway
    {
        private readonly OrderService _orderService;
        private readonly Dictionary<Guid, Guid> _orderCustomers = [];

        public PaymentOrderGateway(OrderService orderService)
        {
            _orderService = orderService;
        }

        public async Task<PaymentAbstractions.OrderSnapshot?> GetOrderAsync(
            Guid customerId,
            Guid orderId,
            string bearerToken,
            CancellationToken cancellationToken)
        {
            var result = await _orderService.GetByIdAsync(customerId, orderId, cancellationToken);
            if (!result.Success || result.Value is null)
            {
                return null;
            }

            _orderCustomers[orderId] = customerId;

            return new PaymentAbstractions.OrderSnapshot(
                result.Value.Id,
                result.Value.CustomerId,
                result.Value.Status,
                result.Value.Subtotal,
                result.Value.Currency,
                result.Value.Items.Select(item => new PaymentAbstractions.OrderItemSnapshot(
                    item.ProductId,
                    item.SellerId,
                    item.ProductName,
                    item.UnitPrice,
                    item.Quantity,
                    item.LineTotal)).ToArray());
        }

        public async Task<bool> MarkPaymentSucceededAsync(Guid orderId, string bearerToken, CancellationToken cancellationToken)
        {
            if (!_orderCustomers.TryGetValue(orderId, out var customerId))
            {
                return false;
            }

            var result = await _orderService.MarkPaymentSucceededAsync(customerId, orderId, cancellationToken);
            return result.Success;
        }

        public async Task<bool> MarkPaymentFailedAsync(Guid orderId, string bearerToken, CancellationToken cancellationToken)
        {
            if (!_orderCustomers.TryGetValue(orderId, out var customerId))
            {
                return false;
            }

            var result = await _orderService.MarkPaymentFailedAsync(customerId, orderId, cancellationToken);
            return result.Success;
        }

        public async Task<bool> ConfirmAsync(Guid orderId, string bearerToken, CancellationToken cancellationToken)
        {
            if (!_orderCustomers.TryGetValue(orderId, out var customerId))
            {
                return false;
            }

            var result = await _orderService.ConfirmAsync(customerId, orderId, cancellationToken);
            return result.Success;
        }
    }

    private sealed class FakeInventoryGateway : PaymentAbstractions.IInventoryGateway
    {
        public Task<bool> HasAvailableStockAsync(
            Guid productId,
            int quantity,
            string bearerToken,
            CancellationToken cancellationToken)
        {
            return Task.FromResult(true);
        }

        public Task<bool> DeductStockAsync(
            Guid productId,
            int quantity,
            Guid orderId,
            string bearerToken,
            CancellationToken cancellationToken)
        {
            return Task.FromResult(true);
        }
    }

    private sealed class InMemoryShipmentRepository : ShippingAbstractions.IShipmentRepository
    {
        private readonly List<Shipment> _shipments = [];

        public Task<Shipment?> GetByIdAsync(Guid shipmentId, CancellationToken cancellationToken)
        {
            return Task.FromResult(_shipments.FirstOrDefault(shipment => shipment.Id == shipmentId));
        }

        public Task<Shipment?> GetByOrderIdAsync(Guid orderId, CancellationToken cancellationToken)
        {
            return Task.FromResult(_shipments.FirstOrDefault(shipment => shipment.OrderId == orderId));
        }

        public Task<IReadOnlyList<Shipment>> GetByCustomerIdAsync(Guid customerId, CancellationToken cancellationToken)
        {
            return Task.FromResult<IReadOnlyList<Shipment>>(_shipments.Where(shipment => shipment.CustomerId == customerId).ToArray());
        }

        public Task<IReadOnlyList<Shipment>> GetByDeliveryPartnerIdAsync(Guid deliveryPartnerId, CancellationToken cancellationToken)
        {
            return Task.FromResult<IReadOnlyList<Shipment>>(_shipments.Where(shipment => shipment.DeliveryPartnerId == deliveryPartnerId).ToArray());
        }

        public Task<IReadOnlyList<Shipment>> GetAllAsync(CancellationToken cancellationToken)
        {
            return Task.FromResult<IReadOnlyList<Shipment>>(_shipments.ToArray());
        }

        public Task<IReadOnlyList<Shipment>> GetByStatusAsync(ShipmentStatus status, CancellationToken cancellationToken)
        {
            return Task.FromResult<IReadOnlyList<Shipment>>(_shipments.Where(shipment => shipment.Status == status).ToArray());
        }

        public Task AddAsync(Shipment shipment, CancellationToken cancellationToken)
        {
            _shipments.Add(shipment);
            return Task.CompletedTask;
        }

        public Task SaveChangesAsync(CancellationToken cancellationToken) => Task.CompletedTask;
    }

    private sealed class InMemorySupportTicketRepository : SupportAbstractions.ISupportTicketRepository
    {
        private readonly List<SupportTicket> _tickets = [];

        public Task<SupportTicket?> GetByIdAsync(Guid ticketId, CancellationToken cancellationToken)
        {
            return Task.FromResult(_tickets.FirstOrDefault(ticket => ticket.Id == ticketId));
        }

        public Task<IReadOnlyList<SupportTicket>> GetByCustomerIdAsync(Guid customerId, CancellationToken cancellationToken)
        {
            return Task.FromResult<IReadOnlyList<SupportTicket>>(_tickets.Where(ticket => ticket.CustomerId == customerId).ToArray());
        }

        public Task<IReadOnlyList<SupportTicket>> GetAllAsync(CancellationToken cancellationToken)
        {
            return Task.FromResult<IReadOnlyList<SupportTicket>>(_tickets.ToArray());
        }

        public Task AddAsync(SupportTicket ticket, CancellationToken cancellationToken)
        {
            _tickets.Add(ticket);
            return Task.CompletedTask;
        }

        public Task SaveChangesAsync(CancellationToken cancellationToken) => Task.CompletedTask;
    }

    private sealed class InMemoryReturnRequestRepository : SupportAbstractions.IReturnRequestRepository
    {
        private readonly List<ReturnRequest> _returns = [];

        public Task<ReturnRequest?> GetByIdAsync(Guid returnId, CancellationToken cancellationToken)
        {
            return Task.FromResult(_returns.FirstOrDefault(returnRequest => returnRequest.Id == returnId));
        }

        public Task<ReturnRequest?> GetByOrderItemIdAsync(Guid orderItemId, CancellationToken cancellationToken)
        {
            return Task.FromResult(_returns.FirstOrDefault(returnRequest => returnRequest.OrderItemId == orderItemId));
        }

        public Task<IReadOnlyList<ReturnRequest>> GetByCustomerIdAsync(Guid customerId, CancellationToken cancellationToken)
        {
            return Task.FromResult<IReadOnlyList<ReturnRequest>>(_returns.Where(returnRequest => returnRequest.CustomerId == customerId).ToArray());
        }

        public Task<IReadOnlyList<ReturnRequest>> GetAllAsync(CancellationToken cancellationToken)
        {
            return Task.FromResult<IReadOnlyList<ReturnRequest>>(_returns.ToArray());
        }

        public Task AddAsync(ReturnRequest returnRequest, CancellationToken cancellationToken)
        {
            _returns.Add(returnRequest);
            return Task.CompletedTask;
        }

        public Task SaveChangesAsync(CancellationToken cancellationToken) => Task.CompletedTask;
    }

    private sealed class SupportOrderGateway : SupportAbstractions.IOrderGateway
    {
        private readonly OrderService _orderService;

        public SupportOrderGateway(OrderService orderService)
        {
            _orderService = orderService;
        }

        public async Task<bool> ExistsForCustomerAsync(
            Guid customerId,
            Guid orderId,
            string bearerToken,
            CancellationToken cancellationToken)
        {
            return await GetOrderAsync(customerId, orderId, bearerToken, cancellationToken) is not null;
        }

        public async Task<SupportAbstractions.OrderSnapshot?> GetOrderAsync(
            Guid customerId,
            Guid orderId,
            string bearerToken,
            CancellationToken cancellationToken)
        {
            var result = await _orderService.GetByIdAsync(customerId, orderId, cancellationToken);
            if (!result.Success || result.Value is null)
            {
                return null;
            }

            return new SupportAbstractions.OrderSnapshot(
                result.Value.Id,
                result.Value.CustomerId,
                result.Value.Status.ToString(),
                result.Value.Items.Select(item => new SupportAbstractions.OrderItemSnapshot(
                    item.Id,
                    item.ProductId,
                    item.LineTotal)).ToArray());
        }
    }

    private sealed class FakeNotificationGateway :
        PaymentAbstractions.INotificationGateway,
        ShippingAbstractions.INotificationGateway,
        SupportAbstractions.INotificationGateway
    {
        public List<NotificationCall> Notifications { get; } = [];

        public Task CreateAsync(
            Guid userId,
            string type,
            string title,
            string message,
            string bearerToken,
            CancellationToken cancellationToken)
        {
            Notifications.Add(new NotificationCall(userId, type, title, message));
            return Task.CompletedTask;
        }

        public Task CreateAsync(
            Guid userId,
            string type,
            string title,
            string message,
            CancellationToken cancellationToken)
        {
            Notifications.Add(new NotificationCall(userId, type, title, message));
            return Task.CompletedTask;
        }
    }

    private sealed record NotificationCall(Guid UserId, string Type, string Title, string Message);
}
