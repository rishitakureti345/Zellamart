using Xunit;
using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Zellamart.Finance.Api.Controllers;
using Zellamart.Finance.Application.Abstractions;
using Zellamart.Finance.Application.Earnings;
using Zellamart.Finance.Application.Refunds;
using Zellamart.Finance.Application.Payouts;
using Zellamart.Finance.Application.Reports;
using Zellamart.Finance.Application.Transactions;
using Zellamart.Finance.Domain.Audit;
using Zellamart.Finance.Domain.Commissions;
using Zellamart.Finance.Domain.Earnings;
using Zellamart.Finance.Domain.Payouts;
using Zellamart.Finance.Domain.Transactions;
using Zellamart.SharedKernel.Results;

namespace Zellamart.Finance.Tests;

public sealed class FinanceServiceTests
{
    [Fact]
    public async Task Create_earnings_calculates_commission_and_net_amount()
    {
        var repository = new InMemoryFinanceRepository();
        var orderGateway = new FakeOrderGateway();
        var service = new FinanceService(repository, orderGateway, new FakeReturnGateway());
        var sellerId = Guid.NewGuid();
        var order = orderGateway.AddOrder("Delivered", sellerId, 1000m);

        var result = await service.CreateEarningsForOrderAsync(
            new CreateEarningsForOrderRequest(order.Id),
            "token",
            CancellationToken.None);

        Assert.True(result.Success);
        var earning = Assert.Single(result.Value!);
        Assert.Equal(sellerId, earning.SellerId);
        Assert.Equal(1000m, earning.GrossAmount);
        Assert.Equal(100m, earning.CommissionAmount);
        Assert.Equal(900m, earning.NetAmount);
        Assert.Equal(SellerEarningStatus.EarningAvailable, earning.Status);
    }

    [Fact]
    public async Task Get_seller_earnings_returns_created_earnings()
    {
        var repository = new InMemoryFinanceRepository();
        var orderGateway = new FakeOrderGateway();
        var service = new FinanceService(repository, orderGateway, new FakeReturnGateway());
        var sellerId = Guid.NewGuid();
        var order = orderGateway.AddOrder("Delivered", sellerId, 4999m);
        await service.CreateEarningsForOrderAsync(
            new CreateEarningsForOrderRequest(order.Id),
            "token",
            CancellationToken.None);

        var result = await service.GetSellerEarningsAsync(sellerId, CancellationToken.None);

        Assert.True(result.Success);
        var earning = Assert.Single(result.Value!);
        Assert.Equal(4499.10m, earning.NetAmount);
    }

    [Fact]
    public async Task Request_payout_and_mark_paid_work()
    {
        var repository = new InMemoryFinanceRepository();
        var orderGateway = new FakeOrderGateway();
        var service = new FinanceService(repository, orderGateway, new FakeReturnGateway());
        var sellerId = Guid.NewGuid();
        var order = orderGateway.AddOrder("Delivered", sellerId, 2000m);
        await service.CreateEarningsForOrderAsync(
            new CreateEarningsForOrderRequest(order.Id),
            "token",
            CancellationToken.None);

        var requested = await service.RequestSellerPayoutAsync(sellerId, CancellationToken.None);
        var payouts = await service.GetSellerPayoutsAsync(sellerId, CancellationToken.None);
        var paid = await service.MarkPayoutPaidAsync(Guid.NewGuid(), requested.Value!.Id, CancellationToken.None);
        var earnings = await service.GetSellerEarningsAsync(sellerId, CancellationToken.None);

        Assert.True(requested.Success);
        Assert.Equal(1800m, requested.Value.Amount);
        Assert.Equal(SellerPayoutStatus.PayoutProcessing, requested.Value.Status);
        Assert.StartsWith("PO-", requested.Value.ReferenceNumber);
        Assert.True(payouts.Success);
        Assert.Single(payouts.Value!);
        Assert.True(paid.Success);
        Assert.Equal(SellerPayoutStatus.Paid, paid.Value!.Status);
        Assert.NotNull(paid.Value.PaidAtUtc);
        Assert.All(earnings.Value!, earning => Assert.Equal(SellerEarningStatus.Paid, earning.Status));
        Assert.Contains(repository.AuditLogs, auditLog => auditLog.Action == "PayoutPaid");
    }

    [Fact]
    public async Task Request_payout_without_available_balance_rejects_missing_seller()
    {
        var service = new FinanceService(
            new InMemoryFinanceRepository(),
            new FakeOrderGateway(),
            new FakeReturnGateway());

        var result = await service.RequestSellerPayoutAsync(Guid.NewGuid(), CancellationToken.None);

        Assert.False(result.Success);
        Assert.Equal("NotFound", result.Error.Code);
    }

    [Fact]
    public async Task Not_delivered_order_duplicate_earning_and_missing_payout_are_rejected()
    {
        var repository = new InMemoryFinanceRepository();
        var orderGateway = new FakeOrderGateway();
        var service = new FinanceService(repository, orderGateway, new FakeReturnGateway());
        var notDelivered = orderGateway.AddOrder("Confirmed", Guid.NewGuid(), 1000m);
        var delivered = orderGateway.AddOrder("Delivered", Guid.NewGuid(), 1000m);

        var invalidStatus = await service.CreateEarningsForOrderAsync(
            new CreateEarningsForOrderRequest(notDelivered.Id),
            "token",
            CancellationToken.None);
        var created = await service.CreateEarningsForOrderAsync(
            new CreateEarningsForOrderRequest(delivered.Id),
            "token",
            CancellationToken.None);
        var duplicate = await service.CreateEarningsForOrderAsync(
            new CreateEarningsForOrderRequest(delivered.Id),
            "token",
            CancellationToken.None);
        var missingPayout = await service.MarkPayoutPaidAsync(Guid.NewGuid(), Guid.NewGuid(), CancellationToken.None);

        Assert.False(invalidStatus.Success);
        Assert.Equal("Validation", invalidStatus.Error.Code);
        Assert.True(created.Success);
        Assert.False(duplicate.Success);
        Assert.Equal("Conflict", duplicate.Error.Code);
        Assert.False(missingPayout.Success);
        Assert.Equal("NotFound", missingPayout.Error.Code);
    }

    [Fact]
    public async Task Refund_reduces_seller_balance_and_refunded_earnings_cannot_be_paid_out()
    {
        var repository = new InMemoryFinanceRepository();
        var orderGateway = new FakeOrderGateway();
        var returnGateway = new FakeReturnGateway();
        var service = new FinanceService(repository, orderGateway, returnGateway);
        var sellerId = Guid.NewGuid();
        var order = orderGateway.AddOrder("Delivered", sellerId, 1000m);
        var item = order.Items[0];
        await service.CreateEarningsForOrderAsync(
            new CreateEarningsForOrderRequest(order.Id),
            "token",
            CancellationToken.None);
        var returnRequest = returnGateway.AddReturn(
            order.Id,
            item.Id,
            order.CustomerId,
            item.ProductId,
            "Refunded",
            1000m);

        var refund = await service.CreateRefundForReturnAsync(
            Guid.NewGuid(),
            new CreateRefundForReturnRequest(returnRequest.Id),
            "token",
            CancellationToken.None);
        var balance = await service.GetSellerBalanceAsync(sellerId, CancellationToken.None);
        var payout = await service.RequestSellerPayoutAsync(sellerId, CancellationToken.None);

        Assert.True(refund.Success);
        Assert.Equal(FinanceTransactionType.Refund, refund.Value!.Type);
        Assert.Equal(-900m, refund.Value.Amount);
        Assert.Contains(repository.AuditLogs, auditLog => auditLog.Action == "RefundRecorded");
        Assert.True(balance.Success);
        Assert.Equal(0m, balance.Value!.AvailableBalance);
        Assert.Equal(900m, balance.Value.RefundDeductions);
        Assert.False(payout.Success);
        Assert.Equal("NotFound", payout.Error.Code);
    }

    [Fact]
    public void Finance_admin_and_sensitive_endpoints_are_role_protected()
    {
        AssertRoles(
            nameof(FinanceController.GetAdminSummary),
            "SuperAdmin,Admin,FinanceManager");
        AssertRoles(
            nameof(FinanceController.GetAdminSellerBalances),
            "SuperAdmin,Admin,FinanceManager");
        AssertRoles(
            nameof(FinanceController.MarkPayoutPaid),
            "SuperAdmin,FinanceManager");
        AssertRoles(
            nameof(FinanceController.RequestSellerPayout),
            "SuperAdmin,Seller");
        AssertRoles(
            nameof(FinanceController.CreateRefundForReturn),
            "SuperAdmin,Admin,FinanceManager,SupportManager");
    }

    [Fact]
    public async Task Seller_cannot_request_payout_for_another_seller()
    {
        var currentSellerId = Guid.NewGuid();
        var controller = new FinanceController(
            new FakeFinanceService(),
            new FakeSellerProfileGateway(currentSellerId))
        {
            ControllerContext = new ControllerContext
            {
                HttpContext = new DefaultHttpContext
                {
                    User = new ClaimsPrincipal(new ClaimsIdentity(
                        [
                            new Claim(ClaimTypes.NameIdentifier, currentSellerId.ToString()),
                            new Claim(ClaimTypes.Role, "Seller")
                        ],
                        "TestAuth"))
                }
            }
        };

        var result = await controller.RequestSellerPayout(Guid.NewGuid(), CancellationToken.None);

        Assert.IsType<ForbidResult>(result);
    }

    [Fact]
    public async Task Admin_summary_and_seller_balance_return_expected_totals()
    {
        var repository = new InMemoryFinanceRepository();
        var orderGateway = new FakeOrderGateway();
        var returnGateway = new FakeReturnGateway();
        var service = new FinanceService(repository, orderGateway, returnGateway);
        var sellerId = Guid.NewGuid();
        var firstOrder = orderGateway.AddOrder("Delivered", sellerId, 1000m);
        var secondOrder = orderGateway.AddOrder("Delivered", sellerId, 500m);
        await service.CreateEarningsForOrderAsync(
            new CreateEarningsForOrderRequest(firstOrder.Id),
            "token",
            CancellationToken.None);
        await service.CreateEarningsForOrderAsync(
            new CreateEarningsForOrderRequest(secondOrder.Id),
            "token",
            CancellationToken.None);
        var secondItem = secondOrder.Items[0];
        var returnRequest = returnGateway.AddReturn(
            secondOrder.Id,
            secondItem.Id,
            secondOrder.CustomerId,
            secondItem.ProductId,
            "Refunded",
            500m);
        await service.CreateRefundForReturnAsync(
            Guid.NewGuid(),
            new CreateRefundForReturnRequest(returnRequest.Id),
            "token",
            CancellationToken.None);

        var summary = await service.GetAdminSummaryAsync(CancellationToken.None);
        var balances = await service.GetAdminSellerBalancesAsync(CancellationToken.None);
        var sellerBalance = await service.GetSellerBalanceAsync(sellerId, CancellationToken.None);
        var payout = await service.RequestSellerPayoutAsync(sellerId, CancellationToken.None);

        Assert.True(summary.Success);
        Assert.Equal(1500m, summary.Value!.TotalSales);
        Assert.Equal(150m, summary.Value.TotalCommission);
        Assert.Equal(1350m, summary.Value.TotalSellerEarnings);
        Assert.Equal(450m, summary.Value.TotalRefunds);
        Assert.True(balances.Success);
        Assert.Single(balances.Value!);
        Assert.Equal(900m, sellerBalance.Value!.AvailableBalance);
        Assert.True(payout.Success);
        Assert.Equal(900m, payout.Value!.Amount);
    }

    [Fact]
    public async Task Refund_after_paid_payout_creates_negative_adjustment()
    {
        var repository = new InMemoryFinanceRepository();
        var orderGateway = new FakeOrderGateway();
        var returnGateway = new FakeReturnGateway();
        var service = new FinanceService(repository, orderGateway, returnGateway);
        var sellerId = Guid.NewGuid();
        var order = orderGateway.AddOrder("Delivered", sellerId, 1000m);
        var item = order.Items[0];
        await service.CreateEarningsForOrderAsync(
            new CreateEarningsForOrderRequest(order.Id),
            "token",
            CancellationToken.None);
        var payout = await service.RequestSellerPayoutAsync(sellerId, CancellationToken.None);
        await service.MarkPayoutPaidAsync(Guid.NewGuid(), payout.Value!.Id, CancellationToken.None);
        var returnRequest = returnGateway.AddReturn(
            order.Id,
            item.Id,
            order.CustomerId,
            item.ProductId,
            "Refunded",
            1000m);

        var adjustment = await service.CreateRefundForReturnAsync(
            Guid.NewGuid(),
            new CreateRefundForReturnRequest(returnRequest.Id),
            "token",
            CancellationToken.None);
        var balance = await service.GetSellerBalanceAsync(sellerId, CancellationToken.None);

        Assert.True(adjustment.Success);
        Assert.Equal(FinanceTransactionType.Adjustment, adjustment.Value!.Type);
        Assert.Equal(-900m, adjustment.Value.Amount);
        Assert.Equal(-900m, balance.Value!.AvailableBalance);
        Assert.Equal(900m, balance.Value.TotalPaidOut);
    }

    private sealed class InMemoryFinanceRepository : IFinanceRepository
    {
        private readonly List<SellerEarning> _earnings = [];
        private readonly List<SellerPayout> _payouts = [];
        private readonly List<PlatformCommission> _commissions = [];
        private readonly List<FinanceTransaction> _transactions = [];

        public List<AuditLog> AuditLogs { get; } = [];

        public Task<SellerEarning?> GetEarningByOrderItemIdAsync(Guid orderItemId, CancellationToken cancellationToken)
        {
            return Task.FromResult(_earnings.FirstOrDefault(earning => earning.OrderItemId == orderItemId));
        }

        public Task<IReadOnlyList<SellerEarning>> GetEarningsBySellerIdAsync(Guid sellerId, CancellationToken cancellationToken)
        {
            return Task.FromResult<IReadOnlyList<SellerEarning>>(
                _earnings.Where(earning => earning.SellerId == sellerId).ToArray());
        }

        public Task<IReadOnlyList<SellerEarning>> GetAllEarningsAsync(CancellationToken cancellationToken)
        {
            return Task.FromResult<IReadOnlyList<SellerEarning>>(_earnings.ToArray());
        }

        public Task<IReadOnlyList<SellerEarning>> GetAvailableEarningsBySellerIdAsync(
            Guid sellerId,
            CancellationToken cancellationToken)
        {
            return Task.FromResult<IReadOnlyList<SellerEarning>>(
                _earnings
                    .Where(earning => earning.SellerId == sellerId && earning.Status == SellerEarningStatus.EarningAvailable)
                    .ToArray());
        }

        public Task<SellerPayout?> GetPayoutByIdAsync(Guid payoutId, CancellationToken cancellationToken)
        {
            return Task.FromResult(_payouts.FirstOrDefault(payout => payout.Id == payoutId));
        }

        public Task<IReadOnlyList<SellerPayout>> GetPayoutsBySellerIdAsync(Guid sellerId, CancellationToken cancellationToken)
        {
            return Task.FromResult<IReadOnlyList<SellerPayout>>(
                _payouts.Where(payout => payout.SellerId == sellerId).ToArray());
        }

        public Task<IReadOnlyList<SellerPayout>> GetAllPayoutsAsync(CancellationToken cancellationToken)
        {
            return Task.FromResult<IReadOnlyList<SellerPayout>>(_payouts.ToArray());
        }

        public Task<IReadOnlyList<PlatformCommission>> GetAllCommissionsAsync(CancellationToken cancellationToken)
        {
            return Task.FromResult<IReadOnlyList<PlatformCommission>>(_commissions.ToArray());
        }

        public Task<IReadOnlyList<FinanceTransaction>> GetTransactionsBySellerIdAsync(
            Guid sellerId,
            CancellationToken cancellationToken)
        {
            return Task.FromResult<IReadOnlyList<FinanceTransaction>>(
                _transactions.Where(transaction => transaction.SellerId == sellerId).ToArray());
        }

        public Task<IReadOnlyList<FinanceTransaction>> GetAllTransactionsAsync(CancellationToken cancellationToken)
        {
            return Task.FromResult<IReadOnlyList<FinanceTransaction>>(_transactions.ToArray());
        }

        public Task AddEarningAsync(SellerEarning earning, CancellationToken cancellationToken)
        {
            _earnings.Add(earning);
            return Task.CompletedTask;
        }

        public Task AddCommissionAsync(PlatformCommission commission, CancellationToken cancellationToken)
        {
            _commissions.Add(commission);
            return Task.CompletedTask;
        }

        public Task AddTransactionAsync(FinanceTransaction transaction, CancellationToken cancellationToken)
        {
            _transactions.Add(transaction);
            return Task.CompletedTask;
        }

        public Task AddPayoutAsync(SellerPayout payout, CancellationToken cancellationToken)
        {
            _payouts.Add(payout);
            return Task.CompletedTask;
        }

        public Task AddAuditLogAsync(AuditLog auditLog, CancellationToken cancellationToken)
        {
            AuditLogs.Add(auditLog);
            return Task.CompletedTask;
        }

        public Task SaveChangesAsync(CancellationToken cancellationToken)
        {
            return Task.CompletedTask;
        }
    }

    private sealed class FakeOrderGateway : IOrderGateway
    {
        private readonly List<OrderSnapshot> _orders = [];

        public OrderSnapshot AddOrder(string status, Guid sellerId, decimal lineTotal)
        {
            var order = new OrderSnapshot(
                Guid.NewGuid(),
                Guid.NewGuid(),
                status,
                [new OrderItemSnapshot(Guid.NewGuid(), Guid.NewGuid(), sellerId, lineTotal)]);

            _orders.Add(order);
            return order;
        }

        public Task<OrderSnapshot?> GetOrderAsync(
            Guid orderId,
            string bearerToken,
            CancellationToken cancellationToken)
        {
            return Task.FromResult(_orders.FirstOrDefault(order => order.Id == orderId));
        }
    }

    private sealed class FakeReturnGateway : IReturnGateway
    {
        private readonly List<ReturnSnapshot> _returns = [];

        public ReturnSnapshot AddReturn(
            Guid orderId,
            Guid orderItemId,
            Guid customerId,
            Guid productId,
            string status,
            decimal refundAmount)
        {
            var returnRequest = new ReturnSnapshot(
                Guid.NewGuid(),
                orderId,
                orderItemId,
                customerId,
                productId,
                status,
                refundAmount);

            _returns.Add(returnRequest);
            return returnRequest;
        }

        public Task<ReturnSnapshot?> GetReturnAsync(
            Guid returnId,
            string bearerToken,
            CancellationToken cancellationToken)
        {
            return Task.FromResult(_returns.FirstOrDefault(returnRequest => returnRequest.Id == returnId));
        }
    }

    private sealed class FakeFinanceService : IFinanceService
    {
        public Task<Result<IReadOnlyList<SellerEarningResponse>>> CreateEarningsForOrderAsync(
            CreateEarningsForOrderRequest request,
            string bearerToken,
            CancellationToken cancellationToken)
        {
            throw new NotSupportedException();
        }

        public Task<Result<IReadOnlyList<SellerEarningResponse>>> GetSellerEarningsAsync(
            Guid sellerId,
            CancellationToken cancellationToken)
        {
            throw new NotSupportedException();
        }

        public Task<Result<IReadOnlyList<SellerPayoutResponse>>> GetSellerPayoutsAsync(
            Guid sellerId,
            CancellationToken cancellationToken)
        {
            throw new NotSupportedException();
        }

        public Task<Result<SellerPayoutResponse>> RequestSellerPayoutAsync(
            Guid sellerId,
            CancellationToken cancellationToken)
        {
            throw new InvalidOperationException("This should not be called when seller id does not match.");
        }

        public Task<Result<SellerPayoutResponse>> MarkPayoutPaidAsync(
            Guid? actorUserId,
            Guid payoutId,
            CancellationToken cancellationToken)
        {
            throw new NotSupportedException();
        }

        public Task<Result<FinanceTransactionResponse>> CreateRefundForReturnAsync(
            Guid? actorUserId,
            CreateRefundForReturnRequest request,
            string bearerToken,
            CancellationToken cancellationToken)
        {
            throw new NotSupportedException();
        }

        public Task<Result<IReadOnlyList<FinanceTransactionResponse>>> GetSellerTransactionsAsync(
            Guid sellerId,
            CancellationToken cancellationToken)
        {
            throw new NotSupportedException();
        }

        public Task<Result<SellerBalanceResponse>> GetSellerBalanceAsync(
            Guid sellerId,
            CancellationToken cancellationToken)
        {
            throw new NotSupportedException();
        }

        public Task<Result<AdminFinanceSummaryResponse>> GetAdminSummaryAsync(CancellationToken cancellationToken)
        {
            throw new NotSupportedException();
        }

        public Task<Result<IReadOnlyList<AdminSellerBalanceResponse>>> GetAdminSellerBalancesAsync(
            CancellationToken cancellationToken)
        {
            throw new NotSupportedException();
        }

        public Task<Result<IReadOnlyList<PlatformCommissionResponse>>> GetAdminCommissionsAsync(
            CancellationToken cancellationToken)
        {
            throw new NotSupportedException();
        }

        public Task<Result<IReadOnlyList<SellerPayoutResponse>>> GetAdminPayoutsAsync(CancellationToken cancellationToken)
        {
            throw new NotSupportedException();
        }
    }

    private sealed class FakeSellerProfileGateway : ISellerProfileGateway
    {
        private readonly Guid _sellerId;

        public FakeSellerProfileGateway(Guid sellerId)
        {
            _sellerId = sellerId;
        }

        public Task<SellerProfileSnapshot?> GetMineAsync(string bearerToken, CancellationToken cancellationToken)
        {
            return Task.FromResult<SellerProfileSnapshot?>(new SellerProfileSnapshot(
                _sellerId,
                Guid.NewGuid(),
                "Test seller",
                "Approved"));
        }
    }

    private static void AssertRoles(string actionName, string expectedRoles)
    {
        var method = typeof(FinanceController).GetMethod(actionName)
            ?? throw new InvalidOperationException($"Action {actionName} was not found.");

        var authorizeAttribute = method
            .GetCustomAttributes(typeof(AuthorizeAttribute), inherit: false)
            .OfType<AuthorizeAttribute>()
            .SingleOrDefault();

        Assert.NotNull(authorizeAttribute);
        Assert.Equal(expectedRoles, authorizeAttribute!.Roles);
    }
}
