using Zellamart.Catalog.Application.Abstractions;
using Zellamart.Catalog.Application.Categories;
using Zellamart.Catalog.Application.Products;
using Zellamart.Catalog.Domain.Categories;
using Zellamart.Catalog.Domain.Products;
using Zellamart.Identity.Application.Abstractions;
using Zellamart.Identity.Application.Auth;
using Zellamart.Identity.Domain.Users;
using Zellamart.Inventory.Application.Abstractions;
using Zellamart.Inventory.Application.Inventory;
using Zellamart.Inventory.Domain.Inventory;
using Zellamart.Seller.Application.Abstractions;
using Zellamart.Seller.Application.Sellers;
using Zellamart.Seller.Domain.Sellers;

namespace Zellamart.Month1.Tests;

public sealed class Month1DemoFlowTests
{
    [Fact]
    public async Task Month1_demo_flow_completes_from_login_to_customer_product_listing()
    {
        var cancellationToken = CancellationToken.None;
        var identityService = new AuthService(
            new InMemoryIdentityRepository(),
            new TestPasswordHasher(),
            new TestTokenService());
        var sellerService = new SellerService(new InMemorySellerRepository(), new NoOpSellerEventPublisher());
        var catalogRepository = new InMemoryCatalogRepository();
        var categoryService = new CategoryService(catalogRepository);
        var productService = new ProductService(catalogRepository, new NoOpCatalogEventPublisher());
        var inventoryService = new InventoryService(new InMemoryInventoryRepository(), new NoOpInventoryEventPublisher());

        var customer = await RegisterAndLoginAsync(identityService, "Customer", "customer@zellamart.test", cancellationToken);
        var sellerUser = await RegisterAndLoginAsync(identityService, "Seller", "seller@zellamart.test", cancellationToken);
        var admin = await RegisterAndLoginAsync(identityService, "Admin", "admin@zellamart.test", cancellationToken);

        Assert.NotEqual(Guid.Empty, customer.UserId);
        Assert.NotEqual(Guid.Empty, sellerUser.UserId);
        Assert.NotEqual(Guid.Empty, admin.UserId);

        var sellerApplication = await sellerService.ApplyAsync(
            sellerUser.UserId,
            new ApplySellerRequest(
                "Zellamart Demo Store",
                "Demo Owner",
                "seller@zellamart.test",
                "9999999999",
                "Hyderabad",
                "29ABCDE1234F1Z5"),
            cancellationToken);

        Assert.True(sellerApplication.Success);
        Assert.Equal(SellerStatus.Pending, sellerApplication.Value!.Status);

        var approvedSeller = await sellerService.ApproveAsync(
            sellerApplication.Value.Id,
            admin.UserId,
            cancellationToken);

        Assert.True(approvedSeller.Success);
        Assert.Equal(SellerStatus.Approved, approvedSeller.Value!.Status);

        var category = await categoryService.CreateAsync(
            new CategoryRequest("Mobiles", "mobiles", "Smartphones", null),
            cancellationToken);

        Assert.True(category.Success);

        var submittedProduct = await productService.SubmitAsync(
            new SubmitProductRequest(
                approvedSeller.Value.Id,
                category.Value!.Id,
                "Zella Phone",
                "zella-phone",
                "Month 1 demo smartphone",
                24999,
                "INR",
                "https://example.com/zella-phone.png"),
            cancellationToken);

        Assert.True(submittedProduct.Success);
        Assert.Equal(ProductStatus.Pending, submittedProduct.Value!.Status);

        var approvedProduct = await productService.ApproveAsync(
            submittedProduct.Value.Id,
            admin.UserId,
            cancellationToken);

        Assert.True(approvedProduct.Success);
        Assert.Equal(ProductStatus.Approved, approvedProduct.Value!.Status);

        var inventory = await inventoryService.CreateFromProductApprovedAsync(
            new CreateInventoryFromProductApprovedRequest(
                approvedProduct.Value.Id,
                approvedSeller.Value.Id,
                "ZELLA-PHONE-001"),
            cancellationToken);

        Assert.True(inventory.Success);
        Assert.Equal(0, inventory.Value!.QuantityOnHand);

        var stockedInventory = await inventoryService.AddStockAsync(
            inventory.Value.Id,
            admin.UserId,
            new AddStockRequest(75, "Opening stock received", Guid.NewGuid()),
            cancellationToken);

        Assert.True(stockedInventory.Success);
        Assert.Equal(75, stockedInventory.Value!.QuantityOnHand);
        Assert.Equal(75, stockedInventory.Value.AvailableQuantity);

        var customerProducts = await productService.GetApprovedAsync(null, "Zella", cancellationToken);

        Assert.True(customerProducts.Success);
        var visibleProduct = Assert.Single(customerProducts.Value!);
        Assert.Equal("Zella Phone", visibleProduct.Name);
        Assert.Equal(ProductStatus.Approved, visibleProduct.Status);
    }

    [Fact]
    public async Task Month1_negative_cases_are_rejected()
    {
        var cancellationToken = CancellationToken.None;
        var sellerService = new SellerService(new InMemorySellerRepository(), new NoOpSellerEventPublisher());
        var inventoryService = new InventoryService(new InMemoryInventoryRepository(), new NoOpInventoryEventPublisher());
        var sellerUserId = Guid.NewGuid();
        var adminUserId = Guid.NewGuid();
        var productId = Guid.NewGuid();
        var sellerId = Guid.NewGuid();

        var firstApplication = await sellerService.ApplyAsync(
            sellerUserId,
            new ApplySellerRequest("Store", "Owner", "seller@zellamart.test", "9999999999", "Hyderabad", null),
            cancellationToken);
        var duplicateApplication = await sellerService.ApplyAsync(
            sellerUserId,
            new ApplySellerRequest("Store 2", "Owner", "seller@zellamart.test", "9999999999", "Hyderabad", null),
            cancellationToken);

        Assert.True(firstApplication.Success);
        Assert.False(duplicateApplication.Success);
        Assert.Equal("Conflict", duplicateApplication.Error.Code);

        var inventory = await inventoryService.CreateFromProductApprovedAsync(
            new CreateInventoryFromProductApprovedRequest(productId, sellerId, "SKU-001"),
            cancellationToken);
        var duplicateInventory = await inventoryService.CreateFromProductApprovedAsync(
            new CreateInventoryFromProductApprovedRequest(productId, sellerId, "SKU-002"),
            cancellationToken);
        var invalidStock = await inventoryService.AddStockAsync(
            inventory.Value!.Id,
            adminUserId,
            new AddStockRequest(0, "Invalid quantity", null),
            cancellationToken);

        Assert.True(inventory.Success);
        Assert.False(duplicateInventory.Success);
        Assert.Equal("Conflict", duplicateInventory.Error.Code);
        Assert.False(invalidStock.Success);
        Assert.Equal("Validation", invalidStock.Error.Code);
    }

    private static async Task<AuthResponse> RegisterAndLoginAsync(
        AuthService authService,
        string fullName,
        string email,
        CancellationToken cancellationToken)
    {
        const string password = "Password@12345";

        var register = await authService.RegisterAsync(
            new RegisterRequest(fullName, email, password),
            cancellationToken);
        Assert.True(register.Success);

        var login = await authService.LoginAsync(
            new LoginRequest(email, password),
            cancellationToken);
        Assert.True(login.Success);
        Assert.False(string.IsNullOrWhiteSpace(login.Value!.AccessToken));

        return login.Value;
    }

    private sealed class InMemoryIdentityRepository : IIdentityRepository
    {
        private readonly List<User> _users = [];
        private readonly Role _customerRole = new("Customer", "Customer");

        public Task<User?> GetUserByIdAsync(Guid userId, CancellationToken cancellationToken)
        {
            return Task.FromResult(_users.FirstOrDefault(user => user.Id == userId));
        }

        public Task<User?> GetUserByEmailAsync(string email, CancellationToken cancellationToken)
        {
            var normalizedEmail = email.Trim().ToLowerInvariant();
            return Task.FromResult(_users.FirstOrDefault(user => user.Email == normalizedEmail));
        }

        public Task<Role?> GetRoleByNameAsync(string roleName, CancellationToken cancellationToken)
        {
            return Task.FromResult<Role?>(string.Equals(roleName, "Customer", StringComparison.OrdinalIgnoreCase)
                ? _customerRole
                : null);
        }

        public Task<IReadOnlyList<Role>> GetRolesAsync(CancellationToken cancellationToken)
        {
            return Task.FromResult<IReadOnlyList<Role>>([_customerRole]);
        }

        public Task<IReadOnlyList<User>> GetUsersAsync(CancellationToken cancellationToken)
        {
            return Task.FromResult<IReadOnlyList<User>>(_users.ToArray());
        }

        public Task AddUserAsync(User user, CancellationToken cancellationToken)
        {
            _users.Add(user);
            return Task.CompletedTask;
        }

        public Task AddRoleAsync(Role role, CancellationToken cancellationToken)
        {
            return Task.CompletedTask;
        }

        public Task SaveChangesAsync(CancellationToken cancellationToken)
        {
            return Task.CompletedTask;
        }
    }

    private sealed class TestPasswordHasher : IPasswordHasher
    {
        public string Hash(string password) => $"hashed::{password}";

        public bool Verify(string password, string passwordHash) => passwordHash == Hash(password);
    }

    private sealed class TestTokenService : ITokenService
    {
        public string CreateAccessToken(User user, IReadOnlyList<string> roles, IReadOnlyList<string> permissions)
        {
            return $"test-token::{user.Id}";
        }
    }

    private sealed class InMemorySellerRepository : ISellerRepository
    {
        private readonly List<SellerProfile> _sellers = [];

        public Task<SellerProfile?> GetByIdAsync(Guid sellerId, CancellationToken cancellationToken)
        {
            return Task.FromResult(_sellers.FirstOrDefault(seller => seller.Id == sellerId));
        }

        public Task<SellerProfile?> GetByUserIdAsync(Guid userId, CancellationToken cancellationToken)
        {
            return Task.FromResult(_sellers.FirstOrDefault(seller => seller.UserId == userId));
        }

        public Task<IReadOnlyList<SellerProfile>> GetAllAsync(CancellationToken cancellationToken)
        {
            return Task.FromResult<IReadOnlyList<SellerProfile>>(_sellers.ToArray());
        }

        public Task<IReadOnlyList<SellerProfile>> GetPendingAsync(CancellationToken cancellationToken)
        {
            return Task.FromResult<IReadOnlyList<SellerProfile>>(
                _sellers.Where(seller => seller.Status == SellerStatus.Pending).ToArray());
        }

        public Task AddAsync(SellerProfile seller, CancellationToken cancellationToken)
        {
            _sellers.Add(seller);
            return Task.CompletedTask;
        }

        public Task SaveChangesAsync(CancellationToken cancellationToken)
        {
            return Task.CompletedTask;
        }
    }

    private sealed class NoOpSellerEventPublisher : ISellerEventPublisher
    {
        public Task PublishAppliedAsync(SellerProfile seller, CancellationToken cancellationToken) => Task.CompletedTask;

        public Task PublishApprovedAsync(SellerProfile seller, Guid approvedByUserId, CancellationToken cancellationToken) => Task.CompletedTask;

        public Task PublishRejectedAsync(SellerProfile seller, Guid rejectedByUserId, string reason, CancellationToken cancellationToken) => Task.CompletedTask;
    }

    private sealed class InMemoryCatalogRepository : ICatalogRepository
    {
        private readonly List<Category> _categories = [];
        private readonly List<Product> _products = [];

        public Task<Category?> GetCategoryByIdAsync(Guid categoryId, CancellationToken cancellationToken)
        {
            return Task.FromResult(_categories.FirstOrDefault(category => category.Id == categoryId));
        }

        public Task<Category?> GetCategoryBySlugAsync(string slug, CancellationToken cancellationToken)
        {
            return Task.FromResult(_categories.FirstOrDefault(category => category.Slug == slug));
        }

        public Task<IReadOnlyList<Category>> GetActiveCategoriesAsync(CancellationToken cancellationToken)
        {
            return Task.FromResult<IReadOnlyList<Category>>(_categories.Where(category => category.IsActive).ToArray());
        }

        public Task<IReadOnlyList<Category>> GetAllCategoriesAsync(CancellationToken cancellationToken)
        {
            return Task.FromResult<IReadOnlyList<Category>>(_categories.ToArray());
        }

        public Task AddCategoryAsync(Category category, CancellationToken cancellationToken)
        {
            _categories.Add(category);
            return Task.CompletedTask;
        }

        public Task<Product?> GetProductByIdAsync(Guid productId, CancellationToken cancellationToken)
        {
            return Task.FromResult(_products.FirstOrDefault(product => product.Id == productId));
        }

        public Task<Product?> GetApprovedProductByIdAsync(Guid productId, CancellationToken cancellationToken)
        {
            return Task.FromResult(_products.FirstOrDefault(product =>
                product.Id == productId && product.Status == ProductStatus.Approved));
        }

        public Task<IReadOnlyList<Product>> GetPendingProductsAsync(CancellationToken cancellationToken)
        {
            return Task.FromResult<IReadOnlyList<Product>>(
                _products.Where(product => product.Status == ProductStatus.Pending).ToArray());
        }

        public Task<IReadOnlyList<Product>> GetAllProductsAsync(CancellationToken cancellationToken)
        {
            return Task.FromResult<IReadOnlyList<Product>>(_products.ToArray());
        }

        public Task<IReadOnlyList<Product>> GetApprovedProductsAsync(
            Guid? categoryId,
            string? search,
            CancellationToken cancellationToken)
        {
            var query = _products.Where(product => product.Status == ProductStatus.Approved);

            if (categoryId is not null)
            {
                query = query.Where(product => product.CategoryId == categoryId.Value);
            }

            if (!string.IsNullOrWhiteSpace(search))
            {
                query = query.Where(product => product.Name.Contains(search, StringComparison.OrdinalIgnoreCase));
            }

            return Task.FromResult<IReadOnlyList<Product>>(query.ToArray());
        }

        public Task<IReadOnlyList<Product>> GetProductsBySellerAsync(Guid sellerId, CancellationToken cancellationToken)
        {
            return Task.FromResult<IReadOnlyList<Product>>(
                _products.Where(product => product.SellerId == sellerId).ToArray());
        }

        public Task AddProductAsync(Product product, CancellationToken cancellationToken)
        {
            _products.Add(product);
            return Task.CompletedTask;
        }

        public Task SaveChangesAsync(CancellationToken cancellationToken)
        {
            return Task.CompletedTask;
        }
    }

    private sealed class NoOpCatalogEventPublisher : ICatalogEventPublisher
    {
        public Task PublishSubmittedAsync(Product product, CancellationToken cancellationToken) => Task.CompletedTask;

        public Task PublishApprovedAsync(Product product, Guid approvedByUserId, CancellationToken cancellationToken) => Task.CompletedTask;

        public Task PublishRejectedAsync(Product product, Guid rejectedByUserId, string reason, CancellationToken cancellationToken) => Task.CompletedTask;
    }

    private sealed class InMemoryInventoryRepository : IInventoryRepository
    {
        private readonly List<InventoryItem> _inventoryItems = [];

        public Task<InventoryItem?> GetByIdAsync(Guid inventoryItemId, CancellationToken cancellationToken)
        {
            return Task.FromResult(_inventoryItems.FirstOrDefault(item => item.Id == inventoryItemId));
        }

        public Task<InventoryItem?> GetByProductIdAsync(Guid productId, CancellationToken cancellationToken)
        {
            return Task.FromResult(_inventoryItems.FirstOrDefault(item => item.ProductId == productId));
        }

        public Task<IReadOnlyList<InventoryItem>> GetBySellerIdAsync(Guid sellerId, CancellationToken cancellationToken)
        {
            return Task.FromResult<IReadOnlyList<InventoryItem>>(
                _inventoryItems.Where(item => item.SellerId == sellerId).ToArray());
        }

        public Task<IReadOnlyList<InventoryItem>> GetAllAsync(CancellationToken cancellationToken)
        {
            return Task.FromResult<IReadOnlyList<InventoryItem>>(_inventoryItems.ToArray());
        }

        public Task<IReadOnlyList<StockMovement>> GetMovementsAsync(Guid inventoryItemId, CancellationToken cancellationToken)
        {
            return Task.FromResult<IReadOnlyList<StockMovement>>(
                _inventoryItems
                    .FirstOrDefault(item => item.Id == inventoryItemId)?
                    .StockMovements
                    .OrderBy(movement => movement.ChangedAtUtc)
                    .ToArray() ?? []);
        }

        public Task AddAsync(InventoryItem inventoryItem, CancellationToken cancellationToken)
        {
            _inventoryItems.Add(inventoryItem);
            return Task.CompletedTask;
        }

        public Task SaveChangesAsync(CancellationToken cancellationToken)
        {
            return Task.CompletedTask;
        }
    }

    private sealed class NoOpInventoryEventPublisher : IInventoryEventPublisher
    {
        public Task PublishCreatedAsync(InventoryItem inventoryItem, CancellationToken cancellationToken) => Task.CompletedTask;
    }
}
