using Xunit;
using Zellamart.Notifications.Application.Abstractions;
using Zellamart.Notifications.Application.Notifications;
using Zellamart.Notifications.Domain.Notifications;

namespace Zellamart.Notifications.Tests;

public sealed class NotificationServiceTests
{
    [Fact]
    public async Task Create_get_mine_and_mark_read_work()
    {
        var repository = new InMemoryNotificationRepository();
        var service = new NotificationService(repository);
        var userId = Guid.NewGuid();

        var created = await service.CreateAsync(
            new CreateNotificationRequest(userId, "OrderConfirmed", "Order confirmed", "Your order is confirmed."),
            CancellationToken.None);

        var mine = await service.GetMineAsync(userId, CancellationToken.None);
        var read = await service.MarkReadAsync(userId, created.Value!.Id, CancellationToken.None);

        Assert.True(created.Success);
        Assert.False(created.Value!.IsRead);
        Assert.True(mine.Success);
        Assert.Single(mine.Value!);
        Assert.True(read.Success);
        Assert.True(read.Value!.IsRead);
        Assert.NotNull(read.Value.ReadAtUtc);
    }

    [Fact]
    public async Task Invalid_create_and_other_user_read_are_rejected()
    {
        var repository = new InMemoryNotificationRepository();
        var service = new NotificationService(repository);
        var userId = Guid.NewGuid();

        var invalid = await service.CreateAsync(
            new CreateNotificationRequest(Guid.Empty, "", "", ""),
            CancellationToken.None);
        var created = await service.CreateAsync(
            new CreateNotificationRequest(userId, "PaymentFailed", "Payment failed", "Try again."),
            CancellationToken.None);
        var otherRead = await service.MarkReadAsync(Guid.NewGuid(), created.Value!.Id, CancellationToken.None);

        Assert.False(invalid.Success);
        Assert.Equal("Validation", invalid.Error.Code);
        Assert.False(otherRead.Success);
        Assert.Equal("NotFound", otherRead.Error.Code);
    }

    private sealed class InMemoryNotificationRepository : INotificationRepository
    {
        private readonly List<Notification> _notifications = [];

        public Task<Notification?> GetByIdAsync(Guid notificationId, CancellationToken cancellationToken)
        {
            return Task.FromResult(_notifications.FirstOrDefault(notification => notification.Id == notificationId));
        }

        public Task<IReadOnlyList<Notification>> GetByUserIdAsync(Guid userId, CancellationToken cancellationToken)
        {
            return Task.FromResult<IReadOnlyList<Notification>>(
                _notifications.Where(notification => notification.UserId == userId).ToArray());
        }

        public Task<IReadOnlyList<Notification>> GetAllAsync(CancellationToken cancellationToken)
        {
            return Task.FromResult<IReadOnlyList<Notification>>(_notifications.ToArray());
        }

        public Task AddAsync(Notification notification, CancellationToken cancellationToken)
        {
            _notifications.Add(notification);
            return Task.CompletedTask;
        }

        public Task SaveChangesAsync(CancellationToken cancellationToken)
        {
            return Task.CompletedTask;
        }
    }
}
