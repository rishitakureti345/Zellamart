using Xunit;
using Zellamart.Shipping.Application.Abstractions;
using Zellamart.Shipping.Application.Shipments;
using Zellamart.Shipping.Domain.Shipments;

namespace Zellamart.Shipping.Tests;

public sealed class ShipmentServiceTests
{
    [Fact]
    public async Task Create_pack_ship_assign_out_for_delivery_and_deliver_work()
    {
        var repository = new InMemoryShipmentRepository();
        var notifications = new FakeNotificationGateway();
        var service = new ShipmentService(repository, notifications);
        var customerId = Guid.NewGuid();
        var deliveryPartnerId = Guid.NewGuid();

        var created = await service.CreateForOrderAsync(
            customerId,
            new CreateShipmentForOrderRequest(Guid.NewGuid(), "Hyderabad, Telangana"),
            CancellationToken.None);
        var packed = await service.PackAsync(created.Value!.Id, customerId, CancellationToken.None);
        var shipped = await service.ShipAsync(created.Value.Id, customerId, CancellationToken.None);
        var assigned = await service.AssignPartnerAsync(
            created.Value.Id,
            customerId,
            new AssignDeliveryPartnerRequest(deliveryPartnerId),
            CancellationToken.None);
        var outForDelivery = await service.MarkOutForDeliveryAsync(created.Value.Id, customerId, CancellationToken.None);
        var delivered = await service.MarkDeliveredAsync(created.Value.Id, customerId, CancellationToken.None);

        Assert.True(created.Success);
        Assert.Equal(ShipmentStatus.PendingPacking, created.Value.Status);
        Assert.StartsWith("ZLM-", created.Value.TrackingNumber);
        Assert.True(packed.Success);
        Assert.Equal(ShipmentStatus.Packed, packed.Value!.Status);
        Assert.True(shipped.Success);
        Assert.Equal(ShipmentStatus.Shipped, shipped.Value!.Status);
        Assert.True(assigned.Success);
        Assert.Equal(deliveryPartnerId, assigned.Value!.DeliveryPartnerId);
        Assert.True(outForDelivery.Success);
        Assert.Equal(ShipmentStatus.OutForDelivery, outForDelivery.Value!.Status);
        Assert.True(delivered.Success);
        Assert.Equal(ShipmentStatus.Delivered, delivered.Value!.Status);
        Assert.Equal(6, delivered.Value.StatusHistory.Count);
        Assert.Contains(notifications.Notifications, notification => notification.UserId == customerId && notification.Type == "ShipmentPacked");
        Assert.Contains(notifications.Notifications, notification => notification.UserId == customerId && notification.Type == "ShipmentShipped");
        Assert.Contains(notifications.Notifications, notification => notification.UserId == customerId && notification.Type == "DeliveryPartnerAssigned");
        Assert.Contains(notifications.Notifications, notification => notification.UserId == customerId && notification.Type == "ShipmentOutForDelivery");
        Assert.Contains(notifications.Notifications, notification => notification.Type == "ShipmentDelivered");
    }

    [Fact]
    public async Task Get_by_order_get_mine_and_duplicate_order_work()
    {
        var repository = new InMemoryShipmentRepository();
        var service = new ShipmentService(repository, new FakeNotificationGateway());
        var customerId = Guid.NewGuid();
        var orderId = Guid.NewGuid();

        var created = await service.CreateForOrderAsync(
            customerId,
            new CreateShipmentForOrderRequest(orderId, "Bengaluru, Karnataka"),
            CancellationToken.None);
        var byOrder = await service.GetByOrderIdAsync(customerId, orderId, CancellationToken.None);
        var mine = await service.GetMineAsync(customerId, CancellationToken.None);
        var duplicate = await service.CreateForOrderAsync(
            customerId,
            new CreateShipmentForOrderRequest(orderId, "Bengaluru, Karnataka"),
            CancellationToken.None);

        Assert.True(created.Success);
        Assert.True(byOrder.Success);
        Assert.Equal(created.Value!.Id, byOrder.Value!.Id);
        Assert.True(mine.Success);
        Assert.Single(mine.Value!);
        Assert.False(duplicate.Success);
        Assert.Equal("Conflict", duplicate.Error.Code);
    }

    [Fact]
    public async Task Invalid_transition_and_missing_shipment_are_rejected()
    {
        var repository = new InMemoryShipmentRepository();
        var service = new ShipmentService(repository, new FakeNotificationGateway());
        var customerId = Guid.NewGuid();

        var created = await service.CreateForOrderAsync(
            customerId,
            new CreateShipmentForOrderRequest(Guid.NewGuid(), "Chennai, Tamil Nadu"),
            CancellationToken.None);
        var invalidDelivered = await service.MarkDeliveredAsync(created.Value!.Id, customerId, CancellationToken.None);
        var missingPack = await service.PackAsync(Guid.NewGuid(), customerId, CancellationToken.None);

        Assert.False(invalidDelivered.Success);
        Assert.Equal("Validation", invalidDelivered.Error.Code);
        Assert.False(missingPack.Success);
        Assert.Equal("NotFound", missingPack.Error.Code);
    }

    [Fact]
    public async Task Delivery_failed_and_cancel_paths_work()
    {
        var repository = new InMemoryShipmentRepository();
        var notifications = new FakeNotificationGateway();
        var service = new ShipmentService(repository, notifications);
        var customerId = Guid.NewGuid();

        var failedFlow = await service.CreateForOrderAsync(
            customerId,
            new CreateShipmentForOrderRequest(Guid.NewGuid(), "Pune, Maharashtra"),
            CancellationToken.None);
        await service.PackAsync(failedFlow.Value!.Id, customerId, CancellationToken.None);
        await service.ShipAsync(failedFlow.Value.Id, customerId, CancellationToken.None);
        await service.AssignPartnerAsync(
            failedFlow.Value.Id,
            customerId,
            new AssignDeliveryPartnerRequest(Guid.NewGuid()),
            CancellationToken.None);
        await service.MarkOutForDeliveryAsync(failedFlow.Value.Id, customerId, CancellationToken.None);
        var failed = await service.MarkDeliveryFailedAsync(
            failedFlow.Value.Id,
            customerId,
            new DeliveryFailedRequest("Customer unavailable."),
            CancellationToken.None);

        var cancelFlow = await service.CreateForOrderAsync(
            customerId,
            new CreateShipmentForOrderRequest(Guid.NewGuid(), "Delhi"),
            CancellationToken.None);
        var cancelled = await service.CancelAsync(
            cancelFlow.Value!.Id,
            customerId,
            new CancelShipmentRequest("Customer cancelled."),
            CancellationToken.None);
        var shippedCancelFlow = await service.CreateForOrderAsync(
            customerId,
            new CreateShipmentForOrderRequest(Guid.NewGuid(), "Mumbai"),
            CancellationToken.None);
        await service.PackAsync(shippedCancelFlow.Value!.Id, customerId, CancellationToken.None);
        await service.ShipAsync(shippedCancelFlow.Value.Id, customerId, CancellationToken.None);
        var cancelAfterShipped = await service.CancelAsync(
            shippedCancelFlow.Value.Id,
            customerId,
            new CancelShipmentRequest("Too late."),
            CancellationToken.None);

        Assert.True(failed.Success);
        Assert.Equal(ShipmentStatus.DeliveryFailed, failed.Value!.Status);
        Assert.Contains(notifications.Notifications, notification => notification.UserId == customerId && notification.Type == "DeliveryFailed" && notification.Message == "Customer unavailable.");
        Assert.True(cancelled.Success);
        Assert.Equal(ShipmentStatus.Cancelled, cancelled.Value!.Status);
        Assert.False(cancelAfterShipped.Success);
        Assert.Equal("Validation", cancelAfterShipped.Error.Code);
    }

    private sealed class InMemoryShipmentRepository : IShipmentRepository
    {
        private readonly List<Shipment> _shipments = [];

        public Task<Shipment?> GetByIdAsync(Guid shipmentId, CancellationToken cancellationToken)
        {
            return Task.FromResult(_shipments.FirstOrDefault(shipment => shipment.Id == shipmentId));
        }

        public Task<Shipment?> GetByOrderIdAsync(Guid orderId, CancellationToken cancellationToken)
        {
            return Task.FromResult(_shipments.FirstOrDefault(shipment => shipment.OrderId == orderId));
        }

        public Task<IReadOnlyList<Shipment>> GetByCustomerIdAsync(Guid customerId, CancellationToken cancellationToken)
        {
            return Task.FromResult<IReadOnlyList<Shipment>>(
                _shipments.Where(shipment => shipment.CustomerId == customerId).ToArray());
        }

        public Task<IReadOnlyList<Shipment>> GetByDeliveryPartnerIdAsync(Guid deliveryPartnerId, CancellationToken cancellationToken)
        {
            return Task.FromResult<IReadOnlyList<Shipment>>(
                _shipments.Where(shipment => shipment.DeliveryPartnerId == deliveryPartnerId).ToArray());
        }

        public Task<IReadOnlyList<Shipment>> GetAllAsync(CancellationToken cancellationToken)
        {
            return Task.FromResult<IReadOnlyList<Shipment>>(_shipments.ToArray());
        }

        public Task<IReadOnlyList<Shipment>> GetByStatusAsync(ShipmentStatus status, CancellationToken cancellationToken)
        {
            return Task.FromResult<IReadOnlyList<Shipment>>(
                _shipments.Where(shipment => shipment.Status == status).ToArray());
        }

        public Task AddAsync(Shipment shipment, CancellationToken cancellationToken)
        {
            _shipments.Add(shipment);
            return Task.CompletedTask;
        }

        public Task SaveChangesAsync(CancellationToken cancellationToken)
        {
            return Task.CompletedTask;
        }
    }

    private sealed class FakeNotificationGateway : INotificationGateway
    {
        public List<NotificationCall> Notifications { get; } = [];

        public Task CreateAsync(
            Guid userId,
            string type,
            string title,
            string message,
            CancellationToken cancellationToken)
        {
            Notifications.Add(new NotificationCall(userId, type, title, message));
            return Task.CompletedTask;
        }
    }

    private sealed record NotificationCall(Guid UserId, string Type, string Title, string Message);
}
