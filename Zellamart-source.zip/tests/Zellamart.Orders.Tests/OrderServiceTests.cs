using Zellamart.Orders.Application.Abstractions;
using Zellamart.Orders.Application.Orders;
using Zellamart.Orders.Domain.Orders;

namespace Zellamart.Orders.Tests;

public sealed class OrderServiceTests
{
    [Fact]
    public async Task Create_order_from_cart_customer_history_and_seller_view_work()
    {
        var cartGateway = new FakeCartGateway();
        var service = new OrderService(new InMemoryOrderRepository(), cartGateway);
        var customerId = Guid.NewGuid();
        var sellerA = Guid.NewGuid();
        var sellerB = Guid.NewGuid();
        var productA = Guid.NewGuid();
        var productB = Guid.NewGuid();
        cartGateway.SetCart(customerId, "INR", [
            new CartItemSnapshot(Guid.NewGuid(), productA, sellerA, "Zella Phone", 24999, 2, "INR", 49998),
            new CartItemSnapshot(Guid.NewGuid(), productB, sellerB, "Zella Case", 999, 1, "INR", 999)
        ]);

        var created = await service.CreateFromCartAsync(
            customerId,
            new CreateOrderFromCartRequest("Hyderabad, Telangana", "Leave at security"),
            "token",
            CancellationToken.None);

        Assert.True(created.Success);
        Assert.Equal(OrderStatus.PendingPayment, created.Value!.Status);
        Assert.Equal(50997, created.Value.Subtotal);
        Assert.Equal("INR", created.Value.Currency);
        Assert.Equal(2, created.Value.Items.Count);
        Assert.Single(created.Value.StatusHistory);

        var customerOrders = await service.GetMineAsync(customerId, CancellationToken.None);

        Assert.True(customerOrders.Success);
        var customerOrder = Assert.Single(customerOrders.Value!);
        Assert.Equal(created.Value.Id, customerOrder.Id);

        var orderById = await service.GetByIdAsync(customerId, created.Value.Id, CancellationToken.None);

        Assert.True(orderById.Success);
        Assert.Equal(created.Value.OrderNumber, orderById.Value!.OrderNumber);

        var sellerOrders = await service.GetBySellerIdAsync(sellerA, CancellationToken.None);

        Assert.True(sellerOrders.Success);
        var sellerItem = Assert.Single(sellerOrders.Value!);
        Assert.Equal(sellerA, sellerItem.SellerId);
        Assert.Equal(productA, sellerItem.ProductId);
        Assert.Equal("Zella Phone", sellerItem.ProductName);
        Assert.Equal(49998, sellerItem.LineTotal);
    }

    [Fact]
    public async Task Empty_cart_and_other_customer_order_access_are_rejected()
    {
        var cartGateway = new FakeCartGateway();
        var service = new OrderService(new InMemoryOrderRepository(), cartGateway);
        var customerId = Guid.NewGuid();
        var otherCustomerId = Guid.NewGuid();
        cartGateway.SetCart(customerId, "INR", []);

        var emptyCart = await service.CreateFromCartAsync(
            customerId,
            new CreateOrderFromCartRequest("Hyderabad, Telangana", null),
            "token",
            CancellationToken.None);

        Assert.False(emptyCart.Success);
        Assert.Equal("Validation", emptyCart.Error.Code);

        cartGateway.SetCart(customerId, "INR", [
            new CartItemSnapshot(Guid.NewGuid(), Guid.NewGuid(), Guid.NewGuid(), "Zella Phone", 24999, 1, "INR", 24999)
        ]);

        var created = await service.CreateFromCartAsync(
            customerId,
            new CreateOrderFromCartRequest("Hyderabad, Telangana", null),
            "token",
            CancellationToken.None);
        var otherCustomerLookup = await service.GetByIdAsync(otherCustomerId, created.Value!.Id, CancellationToken.None);

        Assert.True(created.Success);
        Assert.False(otherCustomerLookup.Success);
        Assert.Equal("NotFound", otherCustomerLookup.Error.Code);
    }

    [Fact]
    public async Task Confirmed_order_can_be_cancelled_but_delivered_order_cannot()
    {
        var cartGateway = new FakeCartGateway();
        var service = new OrderService(new InMemoryOrderRepository(), cartGateway);
        var customerId = Guid.NewGuid();

        cartGateway.SetCart(customerId, "INR", [
            new CartItemSnapshot(Guid.NewGuid(), Guid.NewGuid(), Guid.NewGuid(), "Zella Phone", 24999, 1, "INR", 24999)
        ]);
        var cancellable = await service.CreateFromCartAsync(
            customerId,
            new CreateOrderFromCartRequest("Hyderabad, Telangana", null),
            "token",
            CancellationToken.None);
        await service.MarkPaymentSucceededAsync(customerId, cancellable.Value!.Id, CancellationToken.None);
        await service.ConfirmAsync(customerId, cancellable.Value.Id, CancellationToken.None);
        var cancelled = await service.CancelAsync(customerId, cancellable.Value.Id, CancellationToken.None);

        cartGateway.SetCart(customerId, "INR", [
            new CartItemSnapshot(Guid.NewGuid(), Guid.NewGuid(), Guid.NewGuid(), "Zella Case", 999, 1, "INR", 999)
        ]);
        var delivered = await service.CreateFromCartAsync(
            customerId,
            new CreateOrderFromCartRequest("Hyderabad, Telangana", null),
            "token",
            CancellationToken.None);
        await service.MarkPaymentSucceededAsync(customerId, delivered.Value!.Id, CancellationToken.None);
        await service.ConfirmAsync(customerId, delivered.Value.Id, CancellationToken.None);
        await service.MarkDeliveredAsync(customerId, delivered.Value.Id, CancellationToken.None);
        var cancelDelivered = await service.CancelAsync(customerId, delivered.Value.Id, CancellationToken.None);

        Assert.True(cancelled.Success);
        Assert.Equal(OrderStatus.Cancelled, cancelled.Value!.Status);
        Assert.False(cancelDelivered.Success);
        Assert.Equal("Validation", cancelDelivered.Error.Code);
    }

    private sealed class InMemoryOrderRepository : IOrderRepository
    {
        private readonly List<Order> _orders = [];

        public Task<Order?> GetByIdAsync(Guid orderId, CancellationToken cancellationToken)
        {
            return Task.FromResult(_orders.FirstOrDefault(order => order.Id == orderId));
        }

        public Task<IReadOnlyList<Order>> GetByCustomerIdAsync(Guid customerId, CancellationToken cancellationToken)
        {
            return Task.FromResult<IReadOnlyList<Order>>(
                _orders.Where(order => order.CustomerId == customerId).ToArray());
        }

        public Task<IReadOnlyList<Order>> GetBySellerIdAsync(Guid sellerId, CancellationToken cancellationToken)
        {
            return Task.FromResult<IReadOnlyList<Order>>(
                _orders.Where(order => order.Items.Any(item => item.SellerId == sellerId)).ToArray());
        }

        public Task<IReadOnlyList<Order>> GetAllAsync(CancellationToken cancellationToken)
        {
            return Task.FromResult<IReadOnlyList<Order>>(_orders.ToArray());
        }

        public Task AddAsync(Order order, CancellationToken cancellationToken)
        {
            _orders.Add(order);
            return Task.CompletedTask;
        }

        public Task SaveChangesAsync(CancellationToken cancellationToken)
        {
            return Task.CompletedTask;
        }
    }

    private sealed class FakeCartGateway : ICartGateway
    {
        private CartSnapshot? _cart;

        public Task<CartSnapshot?> GetMineAsync(string bearerToken, CancellationToken cancellationToken)
        {
            return Task.FromResult(string.IsNullOrWhiteSpace(bearerToken) ? null : _cart);
        }

        public Task ClearMineAsync(string bearerToken, CancellationToken cancellationToken)
        {
            _cart = _cart is null
                ? null
                : _cart with { Items = [] };
            return Task.CompletedTask;
        }

        public void SetCart(Guid customerId, string currency, IReadOnlyList<CartItemSnapshot> items)
        {
            _cart = new CartSnapshot(
                Guid.NewGuid(),
                customerId,
                items,
                items.Sum(item => item.LineTotal),
                items.Sum(item => item.Quantity),
                currency);
        }
    }
}
