# Deployment

Version 1 is designed for Docker Compose, not Kubernetes.

## Local Compose

```bash
docker compose up -d --build
```

Open:

```text
Angular Web: http://localhost:8080
Gateway:     http://localhost:5100
RabbitMQ:    http://localhost:15672
PostgreSQL:  localhost:55432
```

## Databases

Each service owns its database:

- `zellamart_identity`
- `zellamart_seller`
- `zellamart_catalog`
- `zellamart_inventory`
- `zellamart_cart`
- `zellamart_orders`
- `zellamart_payments`
- `zellamart_notifications`
- `zellamart_shipping`
- `zellamart_support`
- `zellamart_finance`

Apply EF Core migrations before running the demo. The compose file starts infrastructure and services; it does not run migrations automatically.

## Environment

Every API service receives:

- `ASPNETCORE_ENVIRONMENT=Development`
- Its own PostgreSQL connection string.
- Service URLs for direct service-to-service calls where needed.

Gateway routes forward `/api/...` calls to each service. The Angular app calls `/api/...` through nginx, which proxies to the gateway.

## Health Checks

Infrastructure containers include health checks:

- PostgreSQL uses `pg_isready`.
- RabbitMQ uses `rabbitmq-diagnostics ping`.

API services expose `/health` endpoints for manual verification and script preflight checks.

## Final Demo Checklist

- `dotnet build Zellamart.sln`
- `dotnet test Zellamart.sln`
- `docker compose up -d --build`
- Apply migrations.
- Open `http://localhost:8080`.
- Run `scripts/month4-demo-flow.sh`.
