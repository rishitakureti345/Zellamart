# Frontend Architecture

The Angular app lives in `src/Web/Zellamart.Web`.

## Folder Structure

```text
src/app
  app.config.ts                 Application providers
  app.routes.ts                 Route map
  core
    interceptors                HTTP interceptors
    models                      API response and DTO contracts
    services                    Auth, API clients, shared infrastructure
  features
    finance
      admin-finance             Admin and finance manager reports
      seller-finance            Seller balance, earnings, payouts
    operations
      customer-dashboard        Customer order/shipping/return view
      shipping-dashboard        Warehouse and delivery view
      support-dashboard         Tickets and returns view
  layout
    app-shell                   Sidebar, auth box, routed content area
  shared
    pipes                       Reusable formatting helpers
```

## Rules For V1 And V2

- Put API calls in `core/services`, not inside layout components.
- Put DTO contracts in `core/models`.
- Put page-specific state and actions inside the feature component.
- Put reusable formatting and UI helpers in `shared`.
- Add new role dashboards as feature folders, then register them in `app.routes.ts`.
- Keep `AppComponent` small; it should only host the router.

## Backend Calls

The UI calls backend APIs with relative `/api/...` URLs. In Docker, nginx proxies those calls to the API gateway. During local Angular development, run the gateway and configure a dev proxy later if you want `ng serve` to forward `/api`.

## Current V1 Pages

- `/finance`: admin/finance summary, seller balances, payout approval.
- `/admin`: same finance dashboard for admin monitoring.
- `/seller`: seller balance, earnings, payout request, payout history, transactions.
- `/customer`: customer orders, shipments, returns.
- `/support`: tickets and returns.
- `/shipping`: shipments and delivery state.
