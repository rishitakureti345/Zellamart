# Manual Testing Guide

This guide tests Zellamart V1 manually with the backend services, gateway, Angular UI, and the Month 4 end-to-end flow.

## 1. Install Local Prerequisites

You need:

- PostgreSQL running on `localhost:55432`.
- RabbitMQ running on `localhost:5672`.
- .NET SDK available at `/Users/rishitha/.dotnet/dotnet`.
- Node.js and npm for the Angular UI. On this machine they are available from `/Users/rishitha/.local/node/bin`.
- Docker only if you want the compose path.

If your shell cannot find Node/npm, run frontend commands with:

```bash
PATH="/Users/rishitha/.local/node/bin:$PATH" npm run build
```

## 2. Start Infrastructure

Docker path:

```bash
docker compose up -d postgres rabbitmq
```

Manual path:

- Start PostgreSQL on port `55432`.
- Start RabbitMQ on port `5672`.

RabbitMQ dashboard:

```text
http://localhost:15672
guest / guest
```

## 3. Apply Migrations

```bash
chmod +x scripts/apply-migrations.sh
scripts/apply-migrations.sh
```

If EF tooling is missing:

```bash
/Users/rishitha/.dotnet/dotnet tool install --global dotnet-ef
```

## 4. Run Backend Services

```bash
chmod +x scripts/run-local-services.sh scripts/stop-local-services.sh
scripts/run-local-services.sh
```

Important local ports:

```text
Gateway:       http://localhost:5100
Identity:      http://localhost:5101
Seller:        http://localhost:5102
Catalog:       http://localhost:5103
Inventory:     http://localhost:5104
Cart:          http://localhost:5105
Orders:        http://localhost:5106
Payments:      http://localhost:5107
Notifications: http://localhost:5108
Shipping:      http://localhost:5109
Finance:       http://localhost:5110
Support:       http://localhost:5222
```

Health check:

```bash
for port in 5100 5101 5102 5103 5104 5105 5106 5107 5108 5109 5110 5222; do
  curl -fsS "http://localhost:$port/health" && echo
done
```

Stop services:

```bash
scripts/stop-local-services.sh
```

## 5. Run The Angular UI

```bash
cd src/Web/Zellamart.Web
npm install
npm start
```

Open:

```text
http://localhost:4200
```

If you use Docker for the full app:

```bash
docker compose up -d --build
```

Open:

```text
http://localhost:8080
```

## 6. Run The Full Demo Data Flow

In another terminal from the repo root:

```bash
chmod +x scripts/month4-demo-flow.sh
scripts/month4-demo-flow.sh
```

Expected ending:

```text
Month 4 demo passed.
```

The script prints emails and IDs. Use those generated emails in the UI to log in and inspect dashboards.

## 7. Manual Feature Flow

Use Swagger or curl through the gateway at `http://localhost:5100`.

### Identity

1. Register admin, seller, finance manager, and customer users.
2. Login each user.
3. Login as SuperAdmin and open `/superadmin/roles`.
4. Click `Create missing core roles` to create the standard role rows for the current test run.
5. Assign roles from `/superadmin/roles` or `/superadmin/users`.

### SuperAdmin Workspace

1. Login as a user with the `SuperAdmin` role.
2. Confirm login redirects to `/superadmin/dashboard`.
3. Confirm the top navigation shows SuperAdmin-focused links instead of every customer/seller shortcut.
4. Open `/superadmin/users`.
5. Create a staff user, then activate, suspend, and reactivate an account.
6. Open `/superadmin/roles`.
7. Create a role and assign an existing role to a user.
8. Open `/superadmin/marketplace`, `/superadmin/finance`, `/superadmin/operations`, `/superadmin/audit`, and `/superadmin/settings`.

Expected:

- `/superadmin` is blocked for Customer and Seller users.
- Sidebar shows Dashboard, Users, Roles & Permissions, Marketplace, Finance, Operations, Audit Logs, and Platform Settings.
- Dashboard metrics load from real backend APIs.
- Users page can create staff and manage account status.
- Roles page can create missing core roles, create a custom role, and assign roles.
- Marketplace, finance, operations, audit, and settings pages expose the real management workflows.
- SuperAdmin can still open `/admin` for operational admin work.

### Seller Onboarding

1. Login as seller.
2. `POST /api/sellers/apply`.
3. Login as admin.
4. `POST /api/sellers/{sellerId}/approve`.

Expected:

- Seller status becomes approved.

### Catalog And Inventory

1. Admin creates category with `POST /api/categories`.
2. Seller submits product with `POST /api/products/submit`.
3. Admin approves product with `POST /api/products/{productId}/approve`.
4. Admin creates inventory with `POST /api/inventory/from-product-approved`.
5. Admin adds stock with `POST /api/inventory/{inventoryId}/stock/add`.

Expected:

- Approved product is visible.
- Inventory stock is available.

### Seller Product Submission UI

1. Login as an approved seller.
2. Open `/seller/products/new`.
3. Select category, enter name, description, price, currency, and image URL.
4. Submit the product.
5. Open `/seller/products`.
6. Filter by `Pending`, then login as admin and approve or reject the product from `/admin/products`.
7. Return to `/seller/products`, refresh, and select the product row.

Expected:

- Seller cannot submit products until the seller profile is approved.
- Submitted product appears for admin approval.
- Seller product status changes after admin approval, rejection, or disable.
- Rejection/disable reason is visible in the product detail panel.
- Category, price, image, and stock summary are visible.

### Seller Inventory, Orders, Earnings, And Payouts UI

1. Login as an approved seller.
2. Open `/seller/inventory`.
3. Select a stock row, review available/reserved/on-hand quantities, and inspect movement history.
4. Add stock manually and refresh the page.
5. Open `/seller/orders` and filter by order status.
6. Select an order row and review customer ID, order status, payment status, shipping status, and seller-owned line item details.
7. Open `/seller/earnings` and review balance cards, earnings rows, and finance transactions.
8. Open `/seller/payouts` and request payout only when available balance is greater than zero.

Expected:

- Seller can only read/update inventory for their own seller profile.
- Seller can only view orders containing their own products.
- Finance seller `me` endpoints use seller profile ID, not auth user ID.
- Payout request is blocked for non-approved sellers or zero available balance.
- Payout history shows Requested/Processing/Paid style status labels.

### Cart, Order, Payment

1. Customer adds product to cart with `POST /api/cart/items`.
2. Customer checks cart with `GET /api/cart/me`.
3. Customer creates order with `POST /api/orders/from-cart`.
4. Customer starts payment with `POST /api/payments/start`.
5. Customer marks payment success with `POST /api/payments/{paymentId}/success`.

Expected:

- Order status becomes `Confirmed`.
- Inventory is deducted/reserved according to the payment flow.

### Shipping

1. Customer creates shipment with `POST /api/shipping/create-for-order`.
2. Warehouse/admin packs shipment with `POST /api/shipping/{shipmentId}/pack`.
3. Warehouse/admin ships with `POST /api/shipping/{shipmentId}/ship`.
4. Delivery manager assigns partner with `POST /api/shipping/{shipmentId}/assign-partner`.
5. Delivery partner/admin marks out for delivery.
6. Delivery partner/admin marks delivered.
7. Customer marks order delivered with `POST /api/orders/{orderId}/delivered`.

Expected:

- Shipment status becomes `Delivered`.
- Customer dashboard shows shipment status.
- Customer notification page shows shipment updates for packed, shipped, out for delivery, delivered, and delivery failed events.

### Operations Notifications Compatibility

Use this after the shared Operations UI is available at `/operations`.

1. Login as a customer and create a paid order.
2. Create or confirm a shipment exists for that order.
3. Login as `WarehouseManager` and open `/operations/packing`.
4. Mark the shipment packed.
5. Login as the customer and open `/customer/notifications`.
6. Login as `WarehouseManager` or `DeliveryManager` and open `/operations/shipments`.
7. Mark the shipment shipped.
8. Login as `DeliveryManager` and assign a delivery partner.
9. Login as the assigned `DeliveryPartner` and open `/operations/delivery`.
10. Mark the shipment out for delivery.
11. Login as the customer and refresh `/customer/notifications` and `/customer/shipments`.
12. Login as the assigned `DeliveryPartner` and mark the shipment delivered.
13. Login as the customer and refresh `/customer/notifications`, `/customer/shipments`, and `/customer/returns`.
14. Repeat with a second shipment and mark delivery failed.

Expected:

- Packed and shipped actions create customer notification records grouped as `Shipment update`.
- Out-for-delivery creates a customer notification grouped as `Shipment update`.
- Delivered creates a customer notification grouped as `Shipment update` and customer shipment status becomes delivered.
- Delivery failed creates a customer notification grouped as `Shipment update` and is visible to admin/support.
- Delivery partners can see and update only shipments assigned to their user.
- Customer can request a return only after the delivered status is visible.

### Operations Manual Flow

This is the full Step 9 compatibility flow for the shared Operations area.

1. Customer places an order and pays successfully.
2. Operations opens `/operations/packing`.
3. Warehouse marks the shipment packed.
4. WarehouseManager or DeliveryManager marks the shipment shipped from `/operations/shipments`.
5. DeliveryManager assigns a delivery partner.
6. DeliveryPartner opens `/operations/delivery` and marks the shipment out for delivery.
7. Customer opens `/customer/notifications` and `/customer/shipments`.
8. DeliveryPartner marks the shipment delivered.
9. Customer confirms delivered status on `/customer/shipments`.
10. Customer opens `/customer/returns` and requests return only after delivery.
11. InventoryStaff opens `/operations/inventory` and checks low-stock and out-of-stock worklists.
12. InventoryStaff adds stock from the quick stock update UI.
13. Seller opens `/seller/inventory` and verifies the updated stock.
14. Customer opens `/customer/products` and verifies product stock availability.

Expected:

- Paid order appears in the packing queue.
- Packing, shipping, assignment, delivery, and failure statuses stay aligned across Operations, Admin shipping, and Customer shipment tracking.
- Customer notifications are created for every shipment status change from operations.
- Return creation is blocked before delivery and allowed after delivery.
- InventoryStaff stock changes update seller inventory and customer product availability after refresh.
- Admin/SuperAdmin can still perform every operations action.

### Support Ticket

1. Customer creates ticket with `POST /api/support/tickets`.
2. Customer adds message with `POST /api/support/tickets/{ticketId}/messages`.
3. Support manager assigns ticket.
4. Support agent resolves or rejects ticket.
5. Customer closes resolved ticket.

Expected:

- Support dashboard shows ticket status.

### Return And Refund

1. Customer creates return with `POST /api/support/returns`.
2. Support/admin approves return.
3. Support/admin marks picked up.
4. Support/admin marks refunded.
5. Finance manager records refund with `POST /api/finance/refunds/create-for-return`.

Expected:

- Return status becomes `Refunded`.
- Finance transaction type is `Refund`.
- Seller earning for refunded item becomes `Refunded`.

### Finance

1. Finance manager creates earnings with `POST /api/finance/earnings/create-for-order`.
2. Seller opens `/seller` in the UI.
3. Seller requests payout.
4. Finance manager opens `/finance` in the UI.
5. Finance manager marks payout paid.

Expected:

- Seller balance changes.
- Payout status becomes `Paid`.
- Admin finance summary updates.

## 8. UI Pages To Check

## 8. Full Compatibility Testing

Run this after the customer, seller, admin, shipping, support, returns, finance, and notification screens are available. This is the Version 1 proof flow: seller joins, admin controls catalog/inventory, customer buys, operations delivers, support handles issues, finance records the refund, and seller earnings reflect the result.

### Preflight

1. Start infrastructure and backend services.
2. Apply migrations.
3. Start Angular.
4. Confirm all health checks pass.
5. Use fresh test users or run `scripts/month4-demo-flow.sh` to generate a clean dataset.

Expected:

- Gateway and all services return healthy.
- Admin, seller, customer, support/admin, shipping/admin, and finance/admin users can log in.
- The Angular UI can reach APIs through the gateway.

### End-To-End Marketplace Flow

1. Seller applies from `/seller/apply`.

Expected:

- Seller profile status becomes `Pending`.
- Admin sees the seller in `/admin/sellers`.
- Seller dashboard/profile shows pending status and blocks seller-only operations that require approval.

2. Admin approves seller from `/admin/sellers`.

Expected:

- Seller status becomes `Approved`.
- Seller refreshes `/seller/profile` or `/seller/dashboard` and sees approved status.

3. Seller submits product from `/seller/products/new`.

Expected:

- Seller can select a category and submit product details.
- Product status is `Pending`.
- Product appears in `/admin/products` pending list.

4. Admin approves product from `/admin/products`.

Expected:

- Product status becomes `Approved`.
- Seller sees product approval on `/seller/products`.
- Customer product browsing can see the product only after approval.

5. Admin creates/adds inventory from `/admin/inventory`.

Expected:

- Inventory record exists for the approved product.
- Available/on-hand stock is greater than zero.
- Seller inventory page reflects the stock for that seller's product.

6. Customer browses product from `/customer/products`.

Expected:

- Only approved/enabled products are visible.
- Product detail shows image, price, category, seller, and stock availability.

7. Customer adds product to cart from product browsing/detail.

Expected:

- Cart item appears in `/customer/cart`.
- Quantity and subtotal are correct.
- Out-of-stock or unapproved products cannot be added.

8. Customer checks out from `/customer/checkout`.

Expected:

- Customer enters shipping address.
- Order is created from the authenticated customer's cart.
- Cart is cleared after order creation.
- Order items preserve seller IDs so seller order view works.

9. Customer pays successfully from payment page.

Expected:

- Payment status becomes `Succeeded`.
- Order status becomes `Confirmed`.
- Inventory updates according to payment flow.
- Customer receives a payment/order notification.

10. Seller sees order from `/seller/orders`.

Expected:

- Seller sees only order items belonging to their seller profile.
- Seller can view order status, payment status, shipping status, and item totals.

11. Admin sees order from `/admin/orders`.

Expected:

- Admin can view all order details.
- Payment and shipping status are visible.
- Admin can intervene only through intended order actions.

12. Shipping updates delivery from `/admin/shipping`.

Expected:

- Shipment can move through packed, shipped, out for delivery, delivered, or failed.
- Delivery partner assignment is visible when used.
- Customer receives shipment notifications.

13. Customer tracks shipment from `/customer/shipments`.

Expected:

- Customer sees only own shipments.
- Shipment detail shows tracking number, status timeline, shipping address, and order link.

14. Customer opens support ticket from `/customer/support/new`.

Expected:

- Ticket is linked to the customer/order.
- Admin/support sees the ticket in `/admin/support`.
- Customer sees staff replies and ticket status changes.

15. Customer requests return/refund from `/customer/returns/new`.

Expected:

- Only delivered order items can be selected.
- Reason is required.
- Refund amount uses the order item line total.
- Duplicate return for the same order item is blocked.

16. Admin/support approves return from `/admin/returns`.

Expected:

- Return moves from requested to approved, picked up, and refunded.
- Customer return detail shows the full status history.
- Customer receives return/refund notifications.

17. Finance records refund.

Expected:

- Admin approve-refund action also calls finance refund recording.
- Finance transaction is created for the return.
- Admin finance summary/reports include the refund.

18. Seller earnings reflect refund.

Expected:

- Refunded order item earning becomes refunded or adjustment is created after payout.
- Seller earnings page shows refund deductions.
- Seller available balance updates correctly.

### Compatibility Pass Criteria

- Customer cannot see another customer's cart, orders, shipments, tickets, returns, or notifications.
- Seller cannot see another seller's products, inventory, orders, earnings, or payouts.
- Admin can see and act across marketplace control pages.
- Support/admin return approval connects to finance refund recording.
- Notifications are visible to the customer for payment/order, shipment, support, refund, and admin announcement events.
- Seller, customer, and admin UIs stay aligned after refresh because status changes come from backend state.

## 9. UI Pages To Check

```text
/finance  Admin finance reports and payout approval
/admin    Same admin finance monitoring view
/seller   Seller balance, earnings, payouts, transactions
/customer Orders, shipments, returns
/support  Tickets and returns
/shipping Shipment status view
```

### Admin Settings

1. Login as an admin.
2. Open `/admin/settings`.
3. Change commission percentage, default currency, support email, return window days, and low stock threshold.
4. Change payment mode/provider and shipping mode/default warehouse placeholders.
5. Click `Save settings`.
6. Refresh the page.
7. Click `Reset defaults`.

Expected:

- Saved values remain after refresh.
- Invalid support email or out-of-range numeric values show a validation message.
- Payment and shipping placeholder controls are visible but clearly marked as V1 UI.
- Reset defaults restores the original marketplace settings.

## 10. Fastest Manual Routine

1. Start infrastructure.
2. Apply migrations.
3. Run backend services.
4. Run `scripts/month4-demo-flow.sh`.
5. Start Angular.
6. Login with the generated seller email and check `/seller`.
7. Login with the generated finance email and check `/finance`.
8. Login with the generated customer email and check `/customer`.
