# Month 4 Demo

This demo proves the Version 1 success condition: a seller joins, a product is approved, a customer buys, delivery completes, support/return/refund works, seller earnings are calculated, payout is simulated, and finance/admin can monitor the result.

## Prerequisites

- PostgreSQL and RabbitMQ running.
- All service databases created and migrations applied.
- All API services running on their local ports.
- `python3`, `curl`, and `psql` available.
- Admin, seller, finance, and customer users can register through Identity.

The script defaults to PostgreSQL on `localhost:55432` with user/password `zellamart`.

## Run

```bash
chmod +x scripts/month4-demo-flow.sh
scripts/month4-demo-flow.sh
```

Override service URLs if needed:

```bash
IDENTITY_URL=http://localhost:5101 FINANCE_URL=http://localhost:5110 scripts/month4-demo-flow.sh
```

## Flow Covered

1. Admin, seller, finance manager, and customer register.
2. Seller applies for onboarding.
3. Admin approves the seller.
4. Admin creates a category.
5. Seller submits two products.
6. Admin approves both products.
7. Inventory is created and stock is added.
8. Customer adds both products to cart.
9. Customer places an order.
10. Payment succeeds and confirms the order.
11. Shipment is created, packed, shipped, assigned, and delivered.
12. Order is marked delivered.
13. Finance creates seller earnings.
14. Customer creates a support ticket and message.
15. Customer requests a return for one item.
16. Support/admin approves, picks up, and refunds the return.
17. Finance records the refund and marks that earning as refunded.
18. Seller requests payout for the remaining earning.
19. Finance manager marks the payout paid.

## Expected Result

The script ends with `Month 4 demo passed.` and prints the generated IDs for the seller, products, order, shipment, support ticket, return, refunded earning, and payout.
