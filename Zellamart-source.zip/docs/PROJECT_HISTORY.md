# Zellamart Project History

This file captures the important decisions and context from the Codex planning chat so the project folder carries its own history.

## Project Vision

Zellamart is an Amazon-inspired e-commerce marketplace project intended to be built version by version.

The goal is to learn and build a serious real-world style marketplace with:

- Multi-role access
- Seller onboarding
- Product catalog
- Product approval
- Inventory
- Cart
- Orders
- Payments
- Shipping and delivery flow
- Support tickets
- Returns and refunds
- Finance and seller earnings
- Notifications
- Reviews
- Security
- Scalable backend architecture

## Architecture Decision

Use a .NET microservices backend with PostgreSQL.

Selected backend stack:

- .NET 8 Web API
- PostgreSQL
- Entity Framework Core
- YARP API Gateway
- RabbitMQ
- MassTransit
- Clean Architecture per service
- Docker Compose for local infrastructure

The architecture is:

```text
Frontend
  |
  v
Zellamart.Gateway
  |
  +-- Identity Service
  +-- Seller Service
  +-- Catalog Service
  +-- Inventory Service
  +-- Cart Service
  +-- Orders Service
  +-- Payments Service
  +-- Shipping Service
  +-- Support Service
  +-- Finance Service
  +-- Notifications Service
  +-- Reviews Service

RabbitMQ carries business events.
Each service owns its own PostgreSQL database.
```

## Why Version-Wise

The project should copy Amazon-style architecture principles, not full Amazon complexity from day one.

The plan is to build a serious first version in 4 months:

- Month 1: foundation, identity, seller, catalog, inventory
- Month 2: cart, orders, payments, stock deduction
- Month 3: shipping, support, returns, refunds
- Month 4: finance, notifications, reviews, security, testing, polish

## Month 1 Target

Month 1 should make this flow work:

```text
Seller applies
Admin approves seller
Seller creates product
Admin approves product
Inventory record is created
Seller adds stock
Customer sees approved product
```

Month 1 services:

- Zellamart.Gateway
- Zellamart.Identity
- Zellamart.Seller
- Zellamart.Catalog
- Zellamart.Inventory

## Version 1 Services

The backend structure includes these services:

- Identity
- Seller
- Catalog
- Inventory
- Cart
- Orders
- Payments
- Shipping
- Support
- Finance
- Notifications
- Reviews

Each service has:

```text
Zellamart.<Service>.Api
Zellamart.<Service>.Application
Zellamart.<Service>.Domain
Zellamart.<Service>.Infrastructure
```

Layer responsibilities:

- Api: Controllers, Swagger, auth, HTTP endpoints
- Application: Use cases, DTOs, validation
- Domain: Entities, enums, business rules
- Infrastructure: PostgreSQL, EF Core, repositories, event consumers

## Current Scaffold Status

The project was separated from the old `Nueriq-main` folder and moved to:

```text
/Users/rishitha/Downloads/Zellamart
```

Current files include:

```text
Zellamart.sln
README.md
docker-compose.yml
src/
docs/
```

The solution currently builds successfully:

```text
~/.dotnet/dotnet build Zellamart.sln
Build succeeded.
0 warnings.
0 errors.
```

## Local Infrastructure

The `docker-compose.yml` includes:

- PostgreSQL
- RabbitMQ with management dashboard

PostgreSQL:

```text
Host: localhost
Port: 5432
User: zellamart
Password: zellamart
Default database: zellamart_identity
```

RabbitMQ dashboard:

```text
URL: http://localhost:15672
User: guest
Password: guest
```

## Important Environment Notes

The .NET SDK is available at:

```text
~/.dotnet/dotnet
```

The `dotnet` command may not be on the shell PATH yet.

Docker was not available from the shell during setup, so containers were not started yet.

## Next Implementation Step

Start the real implementation with the shared backend foundation:

1. Create common result/error models in `Zellamart.SharedKernel`
2. Create event contracts in `Zellamart.Contracts`
3. Configure gateway routes in `Zellamart.Gateway`
4. Start Identity Service:
   - Users
   - Roles
   - Permissions
   - JWT login
   - Define SuperAdmin/Admin/Seller/Customer role support
