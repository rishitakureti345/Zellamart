# Roles And Permissions

Version 1 uses role-based authorization in controllers and keeps permission names documented for the next permission-based pass.

## Core Roles

- `SuperAdmin`: platform owner access through `/superadmin`, including users, roles, marketplace, finance, operations, audit, and settings.
- `Admin`: seller/product/order/report oversight.
- `ProductManager`: product approval and catalog operations.
- `CategoryManager`: category operations.
- `Seller`: seller dashboard, product submission, earnings, payout request.
- `Customer`: shopping, orders, shipping view, tickets, returns.
- `OrderManager`: order management.
- `WarehouseManager`: packing and shipping operations.
- `InventoryStaff`: inventory stock operations.
- `SupportManager`: support and return workflow.
- `SupportAgent`: assigned support ticket workflow.
- `DeliveryManager`: delivery assignment and delivery status management.
- `DeliveryPartner`: delivery status updates.
- `FinanceManager`: earnings, refunds, payouts, finance reports.
- `PaymentTeam`: payment operations.

## Month 4 Permission Names

- `finance.read`
- `finance.manage`
- `payout.request`
- `payout.approve`
- `seller.earnings.read`
- `admin.reports.read`
- `support.manage`
- `shipping.manage`
- `orders.manage`
- `products.approve`

## Practical Mapping

| Role | Permissions |
| --- | --- |
| SuperAdmin | all permissions |
| FinanceManager | `finance.read`, `finance.manage`, `payout.approve`, `admin.reports.read` |
| Seller | `seller.earnings.read`, `payout.request` |
| Admin | `admin.reports.read`, `finance.read`, `products.approve`, `orders.manage` |
| ProductManager | `products.approve` |
| OrderManager | `orders.manage` |
| WarehouseManager | `shipping.manage` |
| DeliveryManager | `shipping.manage` |
| SupportManager | `support.manage` |
| SupportAgent | `support.manage` |

## Protected Areas

- SuperAdmin UI is available at `/superadmin` and requires the `SuperAdmin` role.
- SuperAdmin can create roles, create staff users, assign roles, activate/suspend/block users, and open all platform management modules.
- In an empty database, SuperAdmin can use `/superadmin/roles` to create the missing core roles instead of relying on seed data.
- Admin UI remains available at `/admin` for `Admin` and `SuperAdmin`, but SuperAdmin now redirects to `/superadmin/dashboard` after login.
- Finance admin APIs require `SuperAdmin`, `Admin`, or `FinanceManager`.
- Marking payouts paid requires `SuperAdmin` or `FinanceManager`.
- Seller finance dashboard APIs require `SuperAdmin` or `Seller`.
- Shipping management APIs are protected for admin/operations roles.
- Support management APIs are protected for admin/support roles.
- Product approval APIs are protected for admin/product roles.
