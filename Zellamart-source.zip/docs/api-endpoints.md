# API Endpoints

All endpoints are also available through the gateway under the same `/api/...` path.

## Identity

- `POST /api/auth/register`
- `POST /api/auth/login`
- `GET /api/auth/me`
- `GET /api/users`
- `POST /api/roles`
- `GET /api/roles`
- `POST /api/roles/assign`

## Seller

- `POST /api/sellers/apply`
- `GET /api/sellers/me`
- `GET /api/sellers/pending`
- `POST /api/sellers/{sellerId}/approve`
- `POST /api/sellers/{sellerId}/reject`

## Catalog

- `POST /api/categories`
- `GET /api/categories`
- `POST /api/products/submit`
- `GET /api/products`
- `GET /api/products/{productId}`
- `GET /api/products/seller/{sellerId}`
- `GET /api/products/pending`
- `POST /api/products/{productId}/approve`
- `POST /api/products/{productId}/reject`

## Inventory

- `POST /api/inventory/from-product-approved`
- `GET /api/inventory/product/{productId}`
- `GET /api/inventory/seller/{sellerId}`
- `GET /api/inventory/{inventoryItemId}/movements`
- `POST /api/inventory/{inventoryId}/stock/add`
- `POST /api/inventory/product/{productId}/stock/reserve`
- `POST /api/inventory/product/{productId}/stock/release`
- `POST /api/inventory/product/{productId}/stock/deduct`

## Cart

- `GET /api/cart/me`
- `POST /api/cart/items`
- `PUT /api/cart/items/{itemId}`
- `DELETE /api/cart/items/{itemId}`
- `DELETE /api/cart/clear`

## Orders

- `POST /api/orders/from-cart`
- `GET /api/orders/me`
- `GET /api/orders/{orderId}`
- `GET /api/orders/seller/{sellerId}`
- `GET /api/orders/admin/all`
- `POST /api/orders/{orderId}/payment-succeeded`
- `POST /api/orders/{orderId}/payment-failed`
- `POST /api/orders/{orderId}/confirm`
- `POST /api/orders/{orderId}/cancel`
- `POST /api/orders/{orderId}/delivered`

## Payments

- `POST /api/payments/start`
- `POST /api/payments/{paymentId}/success`
- `POST /api/payments/{paymentId}/fail`
- `GET /api/payments/order/{orderId}`

## Shipping

- `POST /api/shipping/create-for-order`
- `GET /api/shipping/order/{orderId}`
- `GET /api/shipping/me`
- `GET /api/shipping/admin/all`
- `GET /api/shipping/admin/status/{status}`
- `POST /api/shipping/{shipmentId}/pack`
- `POST /api/shipping/{shipmentId}/ship`
- `POST /api/shipping/{shipmentId}/assign-partner`
- `POST /api/shipping/{shipmentId}/out-for-delivery`
- `POST /api/shipping/{shipmentId}/delivered`
- `POST /api/shipping/{shipmentId}/delivery-failed`
- `POST /api/shipping/{shipmentId}/cancel`

## Support

- `POST /api/support/tickets`
- `GET /api/support/tickets/me`
- `GET /api/support/tickets/admin/all`
- `GET /api/support/tickets/{ticketId}`
- `POST /api/support/tickets/{ticketId}/messages`
- `POST /api/support/tickets/{ticketId}/assign`
- `POST /api/support/tickets/{ticketId}/resolve`
- `POST /api/support/tickets/{ticketId}/reject`
- `POST /api/support/tickets/{ticketId}/close`
- `POST /api/support/returns`
- `GET /api/support/returns/me`
- `GET /api/support/returns/admin/all`
- `GET /api/support/returns/{returnId}`
- `POST /api/support/returns/{returnId}/approve`
- `POST /api/support/returns/{returnId}/reject`
- `POST /api/support/returns/{returnId}/mark-picked-up`
- `POST /api/support/returns/{returnId}/refund`

## Finance

- `POST /api/finance/earnings/create-for-order`
- `GET /api/finance/sellers/{sellerId}/earnings`
- `GET /api/finance/sellers/{sellerId}/payouts`
- `POST /api/finance/sellers/{sellerId}/payouts/request`
- `POST /api/finance/payouts/{payoutId}/mark-paid`
- `POST /api/finance/refunds/create-for-return`
- `GET /api/finance/sellers/{sellerId}/transactions`
- `GET /api/finance/admin/summary`
- `GET /api/finance/admin/seller-balances`
- `GET /api/finance/admin/commissions`
- `GET /api/finance/admin/payouts`
- `GET /api/finance/me/earnings`
- `GET /api/finance/me/balance`
- `GET /api/finance/me/payouts`
- `GET /api/finance/me/transactions`
