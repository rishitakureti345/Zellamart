# Zellamart Version 1 Marketplace MVP

Zellamart is a .NET 8 microservices marketplace with an Angular frontend. Version 1 covers seller onboarding, product approval, inventory, cart, orders, payment simulation, shipping, support tickets, returns/refunds, finance reports, and simulated seller payouts.

## Services

```text
Angular Web
  |
  v
Zellamart.Gateway
  |
  +-- Identity
  +-- Seller
  +-- Catalog
  +-- Inventory
  +-- Cart
  +-- Orders
  +-- Payments
  +-- Shipping
  +-- Support
  +-- Finance
  +-- Notifications

RabbitMQ is used for business events.
Each service owns its own PostgreSQL database.
```

## Project Layers

Each service uses this structure:

```text
Api              Controllers, Swagger, auth, HTTP endpoints
Application      Use cases, DTOs, validation
Domain           Entities, enums, business rules
Infrastructure   PostgreSQL, EF Core, repositories, event consumers
```

## Run With Docker

```bash
docker compose up -d
```

The compose stack exposes:

```text
Web:        http://localhost:8080
Gateway:    http://localhost:5100
Identity:   http://localhost:5101
Seller:     http://localhost:5102
Catalog:    http://localhost:5103
Inventory:  http://localhost:5104
Cart:       http://localhost:5105
Orders:     http://localhost:5106
Payments:   http://localhost:5107
RabbitMQ:   http://localhost:15672
Shipping:   http://localhost:5109
Finance:    http://localhost:5110
Support:    http://localhost:5222
PostgreSQL: localhost:55432
```

PostgreSQL credentials:

```text
User: zellamart
Password: zellamart
Default database: zellamart_identity
```

RabbitMQ credentials:

```text
User: guest
Password: guest
```

## Build And Test

```bash
~/.dotnet/dotnet build Zellamart.sln
~/.dotnet/dotnet test Zellamart.sln
```

Angular requires Node.js and npm:

```bash
cd src/Web/Zellamart.Web
npm install
npm run build
```

## Demo

Apply EF Core migrations for each service database, start the services, then run:

```bash
scripts/month4-demo-flow.sh
```

The script creates demo users, approves a seller, creates two products, places an order, delivers it, creates finance earnings, raises a support ticket, refunds one item, and pays out the remaining seller earning.

More detail:

- [Month 4 demo](docs/month4-demo.md)
- [API endpoints](docs/api-endpoints.md)
- [Roles and permissions](docs/roles-permissions.md)
- [Deployment](docs/deployment.md)
- [Frontend architecture](docs/frontend-architecture.md)
- [Manual testing guide](docs/manual-testing.md)
